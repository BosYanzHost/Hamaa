from fansx import *
import aiohttp
import asyncio
import os
import random
from urllib.parse import quote
from pyrogram.enums import ChatAction, ParseMode
from pyrogram.types import Message

__MODULE__ = "ꜰᴀᴋᴇ ᴡʜᴀᴛꜱᴀᴘᴘ"
__HELP__ = """
<blockquote><b>📱 FAKE WHATSAPP PROFILE</b>

<b>⌲ Perintah:</b>
ᚗ <code>{0}fakewa [nama]|[bio]|[nomor]</code> - Buat fake profil WA
   (Reply ke foto untuk avatar custom)

<b>⌲ Contoh:</b>
1. Reply ke foto + ketik <code>.fakewa Sjsjs|Dd|0282</code>
2. Kirim perintah tanpa reply (avatar default)</blockquote>
"""

# ============================================
# KONFIGURASI
# ============================================
BASE_URL = "https://api.theresav.biz.id/canvas/fakewa"
API_KEY = "UYGSg"

# Default avatar jika tidak ada reply
DEFAULT_AVATAR = "https://i.imgur.com/Htss.jpg"

async def upload_to_catbox(file_path):
    """Upload gambar ke catbox.moe"""
    try:
        async with aiohttp.ClientSession() as session:
            data = aiohttp.FormData()
            data.add_field('fileToUpload', 
                          open(file_path, 'rb'),
                          filename='avatar.jpg',
                          content_type='image/jpeg')
            data.add_field('reqtype', 'fileupload')
            
            async with session.post('https://catbox.moe/user/api.php', data=data, timeout=30) as resp:
                if resp.status == 200:
                    url = await resp.text()
                    return url.strip()
    except Exception as e:
        print(f"Catbox upload error: {e}")
    return None

async def generate_fake_wa(nama: str, bio: str, nomor: str, avatar_url: str = None):
    """Generate fake WhatsApp profile"""
    try:
        # Gunakan default jika tidak ada avatar
        if not avatar_url:
            avatar_url = DEFAULT_AVATAR
        
        # Parameter
        params = {
            "apikey": API_KEY,
            "nama": quote(nama),
            "bio": quote(bio),
            "nomor": quote(nomor),
            "avatarURL": quote(avatar_url, safe='')
        }
        
        # Build URL
        query_parts = []
        for key, value in params.items():
            query_parts.append(f"{key}={value}")
        
        url = f"{BASE_URL}?{'&'.join(query_parts)}"
        
        # Download gambar
        async with aiohttp.ClientSession() as session:
            async with session.get(url, timeout=30) as response:
                if response.status == 200:
                    return await response.read()
                else:
                    print(f"HTTP Error: {response.status}")
    except Exception as e:
        print(f"Error generate fake WA: {e}")
    return None

def parse_input(input_text):
    """Parse input dari user dengan format | separator"""
    parts = [p.strip() for p in input_text.split('|')]
    
    data = {
        "nama": "",
        "bio": "",
        "nomor": ""
    }
    
    if len(parts) >= 1:
        data["nama"] = parts[0]
    if len(parts) >= 2:
        data["bio"] = parts[1]
    if len(parts) >= 3:
        data["nomor"] = parts[2]
    
    return data

@PY.UBOT("fakewa")
async def fake_wa_command(client: Client, message: Message):
    ggl = await EMO.GAGAL(client)
    sks = await EMO.BERHASIL(client)
    prs = await EMO.PROSES(client)
    
    try:
        await client.send_chat_action(message.chat.id, ChatAction.UPLOAD_PHOTO)
        
        # Cek apakah command tanpa argumen
        if len(message.text.split()) == 1:
            await message.reply_text(
                f"<blockquote><b>📱 FAKE WHATSAPP PROFILE</b>\n\n"
                f"<b>Format:</b>\n"
                f"<code>.fakewa nama|bio|nomor</code>\n\n"
                f"<b>Cara pakai avatar custom:</b>\n"
                f"1. Reply ke foto yang mau dijadikan avatar\n"
                f"2. Ketik <code>.fakewa Sjsjs|Dd|0282</code>\n\n"
                f"<b>Tanpa reply:</b> Avatar akan default</blockquote>"
            )
            return
        
        args = message.text.split(maxsplit=1)
        input_data = args[1]
        
        # Parse data
        data = parse_input(input_data)
        
        # Validasi data wajib
        if not data["nama"]:
            await message.reply_text(f"{ggl} <b>Nama tidak boleh kosong!</b>")
            return
        if not data["bio"]:
            await message.reply_text(f"{ggl} <b>Bio tidak boleh kosong!</b>")
            return
        if not data["nomor"]:
            await message.reply_text(f"{ggl} <b>Nomor tidak boleh kosong!</b>")
            return
        
        # Cek apakah ada reply gambar
        avatar_url = None
        has_avatar = False
        
        if message.reply_to_message and message.reply_to_message.photo:
            has_avatar = True
            processing = await message.reply_text(f"{prs} <b>Mendownload foto avatar...</b>")
            
            file_path = await message.reply_to_message.download()
            
            await processing.edit_text(f"{prs} <b>Mengupload avatar ke server...</b>")
            
            avatar_url = await upload_to_catbox(file_path)
            
            if os.path.exists(file_path):
                os.remove(file_path)
            
            if not avatar_url:
                await processing.edit_text(f"{ggl} <b>Gagal upload avatar! Menggunakan default.</b>")
                await asyncio.sleep(1)
                avatar_url = None
        else:
            processing = await message.reply_text(f"{prs} <b>Membuat fake WhatsApp profile...</b>")
        
        # Generate gambar
        image_data = await generate_fake_wa(
            data["nama"],
            data["bio"],
            data["nomor"],
            avatar_url
        )
        
        if not image_data:
            await processing.edit_text(f"{ggl} <b>Gagal membuat fake profile!</b>")
            return
        
        # Simpan sementara
        file_path = f"fakewa_{message.from_user.id}_{random.randint(1000,9999)}.jpg"
        with open(file_path, 'wb') as f:
            f.write(image_data)
        
        await processing.delete()
        
        # Kirim foto
        avatar_info = "\n🖼️ Avatar custom" if has_avatar else "\n🖼️ Avatar default"
        await client.send_photo(
            chat_id=message.chat.id,
            photo=file_path,
            caption=f"<blockquote><b>📱 FAKE WHATSAPP PROFILE</b>\n\n"
                    f"👤 <b>Nama:</b> {data['nama']}\n"
                    f"📝 <b>Bio:</b> {data['bio']}\n"
                    f"📞 <b>Nomor:</b> {data['nomor']}{avatar_info}</blockquote>"
        )
        
        # Hapus file
        import os
        if os.path.exists(file_path)):
            os.remove(file_path)
        
    except Exception as e:
        await message.reply_text(f"{ggl} <b>Error: {str(e)[:100]}</b>")

