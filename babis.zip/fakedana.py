from fansx import *
import requests
import aiohttp
import os
import random
from io import BytesIO
from pyrogram.enums import ChatAction
from pyrogram.types import Message
from PIL import Image, ImageDraw, ImageFont

__MODULE__ = "ꜰᴀᴋᴇ ᴅᴀɴᴀ"
__HELP__ = """
<blockquote><b>『 FAKE DANA 』</b>

<b>⌲ Perintah:</b>
ᚗ <code>{0}dana [nominal]</code> 
⊶ Membuat bukti saldo DANA palsu

<b>⌲ Contoh:</b>
<code>.dana 50000</code>
<code>.dana 100000</code>
<code>.dana 1000000</code></blockquote>
"""

# Warna-warna DANA
DANA_COLORS = {
    "bg": (18, 86, 166),  # Biru DANA
    "text": (255, 255, 255),
    "highlight": (255, 215, 0),  # Emas
    "shadow": (10, 50, 100)
}

async def create_fake_dana(nominal: int):
    """Membuat gambar fake DANA"""
    
    # Format nominal
    if nominal >= 1000000:
        formatted = f"Rp {nominal/1000000:.1f} Jt"
    else:
        formatted = f"Rp {nominal:,}".replace(',', '.')
    
    # Ukuran gambar (kaya screenshot DANA)
    width = 400
    height = 600
    
    # Buat canvas
    img = Image.new('RGB', (width, height), color=DANA_COLORS["bg"])
    draw = ImageDraw.Draw(img)
    
    try:
        # Coba pake font system
        font_large = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf", 48)
        font_medium = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf", 24)
        font_small = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf", 18)
    except:
        font_large = ImageFont.load_default()
        font_medium = ImageFont.load_default()
        font_small = ImageFont.load_default()
    
    # Header
    draw.text((20, 30), "DANA", font=font_medium, fill=DANA_COLORS["text"])
    
    # Saldo
    draw.text((20, 100), "Saldo DANA", font=font_small, fill=(200, 200, 200))
    draw.text((20, 140), formatted, font=font_large, fill=DANA_COLORS["highlight"])
    
    # Ikon-ikon menu
    menu_y = 250
    menu_items = ["Isi Saldo", "Minta", "Kirim", "Pesan"]
    menu_x = [40, 140, 240, 340]
    
    for i, item in enumerate(menu_items):
        # Lingkaran background
        draw.ellipse([menu_x[i]-15, menu_y-15, menu_x[i]+15, menu_y+15], fill=DANA_COLORS["shadow"])
        draw.text((menu_x[i]-10, menu_y-8), item[0], font=font_small, fill=DANA_COLORS["text"])
        draw.text((menu_x[i]-20, menu_y+25), item, font=font_small, fill=DANA_COLORS["text"])
    
    # Promo banner
    banner_y = 380
    draw.rectangle([20, banner_y, width-20, banner_y+80], fill=DANA_COLORS["shadow"])
    draw.text((40, banner_y+20), "KLAIM", font=font_medium, fill=DANA_COLORS["highlight"])
    draw.text((40, banner_y+45), "JUTAAN RUPIAH", font=font_medium, fill=DANA_COLORS["text"])
    draw.text((250, banner_y+30), "Setiap Hari", font=font_small, fill=(200, 200, 200))
    
    # Tombol SERBU
    draw.rectangle([250, banner_y+50, 350, banner_y+70], fill=(255, 100, 100))
    draw.text((280, banner_y+53), "SERBU", font=font_small, fill=DANA_COLORS["text"])
    
    # Footer
    draw.text((20, height-50), "www.dana.id", font=font_small, fill=(150, 150, 150))
    
    # Simpan ke bytes
    img_bytes = BytesIO()
    img.save(img_bytes, format='PNG')
    img_bytes.seek(0)
    
    return img_bytes

@PY.UBOT("dana")
async def fake_dana(client: Client, message: Message):
    ggl = await EMO.GAGAL(client)
    sks = await EMO.BERHASIL(client)
    prs = await EMO.PROSES(client)
    
    try:
        await client.send_chat_action(message.chat.id, ChatAction.TYPING)
        
        # Ambil nominal
        args = message.text.split(maxsplit=1)
        if len(args) < 2:
            await message.reply_text(
                f"<blockquote><b>❌ Masukkan nominal!</b>\n\n"
                f"<b>Contoh:</b>\n"
                f"<code>.dana 50000</code>\n"
                f"<code>.dana 100000</code>\n"
                f"<code>.dana 1000000</code></blockquote>"
            )
            return
        
        try:
            nominal = int(args[1].strip().replace('.', ''))
            if nominal <= 0:
                raise ValueError
        except:
            await message.reply_text(f"{ggl} <b>Nominal harus berupa angka positif!</b>")
            return
        
        # Batasi nominal (biar ga terlalu gede)
        if nominal > 100000000:
            await message.reply_text(f"{ggl} <b>Nominal terlalu besar! Maksimal 100 juta.</b>")
            return
        
        # Kirim pesan processing
        processing = await message.reply_text(f"{prs} <b>Membuat bukti DANA Rp {nominal:,}...</b>".replace(',', '.'))
        
        # Buat gambar
        img_bytes = await create_fake_dana(nominal)
        
        await processing.delete()
        
        # Kirim gambar
        await client.send_photo(
            chat_id=message.chat.id,
            photo=img_bytes,
            caption=f"<blockquote><b>💰 FAKE DANA</b>\n\nNominal: <code>Rp {nominal:,}</code></blockquote>".replace(',', '.')
        )
        
    except Exception as e:
        await message.reply_text(f"{ggl} <b>Error: {str(e)[:100]}</b>")

@PY.UBOT("dana2")
async def fake_dana_advanced(client: Client, message: Message):
    """Versi dengan nama penerima"""
    ggl = await EMO.GAGAL(client)
    
    try:
        args = message.text.split(maxsplit=2)
        if len(args) < 3:
            await message.reply_text(
                f"<blockquote><b>❌ Format: .dana2 [nominal] [nama]</b>\n\n"
                f"<b>Contoh:</b>\n"
                f"<code>.dana2 50000 Budi</code></blockquote>"
            )
            return
        
        try:
            nominal = int(args[1].strip().replace('.', ''))
            nama = args[2].strip()
        except:
            await message.reply_text(f"{ggl} <b>Format salah!</b>")
            return
        
        processing = await message.reply_text(f"⏳ Membuat bukti DANA...")
        
        # Buat gambar dengan nama
        img_bytes = await create_fake_dana(nominal)
        
        await processing.delete()
        
        await client.send_photo(
            chat_id=message.chat.id,
            photo=img_bytes,
            caption=f"<blockquote><b>💰 FAKE DANA</b>\n\n👤 {nama}\n💵 Rp {nominal:,}</blockquote>".replace(',', '.')
        )
        
except Exception as e:
    await message.reply_text(f"{ggl} <b>Error: {str(e)[:100]}</b>")