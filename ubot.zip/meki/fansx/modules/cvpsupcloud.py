from fansx import *
import aiohttp
import asyncio
import random
import string
import base64
import json
import os
from datetime import datetime
from pyrogram.enums import ChatAction, ParseMode
from pyrogram.types import Message

__MODULE__ = "ᴜᴘᴄʟᴏᴜᴅ ᴠᴘs"
__HELP__ = """
<blockquote><b>『 UPCLOUD VPS MANAGER 』</b>

<b>⌲ Setting Credentials:</b>
ᚗ <code>{0}setupcloud [username] [password]</code> - Set UpCloud API credentials

<b>⌲ Buat VPS (format):</b>
ᚗ <code>{0}upcloud [size] [name] [zone] [os]</code>

<b>⌲ Size:</b> 1gb, 2gb, 4gb, 8gb, 12gb, 16gb, 32gb
<b>⌲ Zone:</b> sg (Singapore), nl (Amsterdam), uk (London)
<b>⌲ OS:</b> ubuntu22, ubuntu20, debian12, debian11, centos7

<b>⌲ Contoh:</b>
<code>.upcloud 1gb vpsku sg ubuntu22</code>
<code>.upcloud 4gb database nl ubuntu20</code>
<code>.upcloud 2gb testing uk debian12</code>

<b>⌲ Manajemen:</b>
ᚗ <code>{0}upcloudlist</code> - Lihat semua VPS
ᚗ <code>{0}upcloudinfo [uuid]</code> - Detail VPS
ᚗ <code>{0}upcloudstart [uuid]</code> - Start VPS
ᚗ <code>{0}upcloudstop [uuid]</code> - Stop VPS
ᚗ <code>{0}upcloudreboot [uuid]</code> - Reboot VPS
ᚗ <code>{0}upclouddelete [uuid]</code> - Hapus VPS

<b>⌲ Informasi:</b>
ᚗ <code>{0}upcloudzones</code> - Daftar zone (otomatis)
ᚗ <code>{0}upcloudplans</code> - Daftar plan (otomatis)
ᚗ <code>{0}upcloudos</code> - Daftar OS template
ᚗ <code>{0}upcloudaccount</code> - Info akun</blockquote>
"""

# ============================================
# KONFIGURASI
# ============================================
UPCLOUD_CONFIG_FILE = "upcloud_config.json"

# UpCloud API endpoint
UPCLOUD_API = "https://api.upcloud.com/1.3"

# Cache untuk data API (biar gak request tiap kali)
zone_cache = {"data": None, "timestamp": 0}
plan_cache = {"data": None, "timestamp": 0}
template_cache = {"data": None, "timestamp": 0}

# Mapping size ke plan core/memory
UPCLOUD_PLAN_MAP = {
    "1gb": {"core": 1, "memory": 1024},
    "2gb": {"core": 1, "memory": 2048},
    "4gb": {"core": 2, "memory": 4096},
    "8gb": {"core": 4, "memory": 8192},
    "12gb": {"core": 6, "memory": 12288},
    "16gb": {"core": 8, "memory": 16384},
    "32gb": {"core": 12, "memory": 32768},
}

# Mapping zone ke kode UpCloud
UPCLOUD_ZONE_MAP = {
    "sg": "sg-sin1",      # Singapore
    "nl": "nl-ams1",      # Amsterdam
    "uk": "uk-lon1",      # London
    "fi": "fi-hel1",      # Helsinki
    "de": "de-fra1",      # Frankfurt
    "us": "us-chi1",      # Chicago
    "au": "au-syd1",      # Sydney
}

def load_upcloud_config():
    """Load UpCloud config dari file"""
    try:
        if os.path.exists(UPCLOUD_CONFIG_FILE):
            with open(UPCLOUD_CONFIG_FILE, 'r') as f:
                return json.load(f)
    except:
        pass
    return {"username": None, "password": None}

def save_upcloud_config(config):
    """Simpan UpCloud config ke file"""
    try:
        with open(UPCLOUD_CONFIG_FILE, 'w') as f:
            json.dump(config, f, indent=4)
        return True
    except:
        return False

# Load config
upcloud_config = load_upcloud_config()

def random_password(length=15):
    """Generate random password"""
    chars = string.ascii_letters + string.digits
    return ''.join(random.choice(chars) for _ in range(length))

def get_basic_auth_header(username, password):
    """Generate Basic Auth header"""
    auth_str = f"{username}:{password}"
    auth_bytes = auth_str.encode('utf-8')
    base64_bytes = base64.b64encode(auth_bytes)
    base64_str = base64_bytes.decode('utf-8')
    return {"Authorization": f"Basic {base64_str}"}

async def upcloud_request(method, endpoint, data=None):
    """Request ke API UpCloud"""
    
    username = upcloud_config.get("username")
    password = upcloud_config.get("password")
    
    if not username or not password:
        return {"error": "Credentials belum diset!"}, 401
    
    url = f"{UPCLOUD_API}/{endpoint}"
    headers = get_basic_auth_header(username, password)
    headers["Content-Type"] = "application/json"
    
    try:
        async with aiohttp.ClientSession() as session:
            if method == "GET":
                async with session.get(url, headers=headers, timeout=15) as resp:
                    return await resp.json(), resp.status
            elif method == "POST":
                async with session.post(url, headers=headers, json=data, timeout=60) as resp:
                    return await resp.json(), resp.status
            elif method == "DELETE":
                async with session.delete(url, headers=headers, timeout=15) as resp:
                    if resp.status == 204:
                        return {}, 204
                    return await resp.json(), resp.status
    except asyncio.TimeoutError:
        return {"error": "Timeout"}, 408
    except Exception as e:
        return {"error": str(e)}, 500

# ============================================
# COMMAND SETTING CREDENTIALS
# ============================================

@PY.UBOT("setupcloud")
async def set_upcloud_credentials(client: Client, message: Message):
    """Set UpCloud API credentials"""
    ggl = await EMO.GAGAL(client)
    sks = await EMO.BERHASIL(client)
    
    try:
        args = message.text.split()
        if len(args) < 3:
            await message.reply_text(
                f"<blockquote><b>❌ Format: .setupcloud [username] [password]</b>\n\n"
                f"Buat API credentials di:\n"
                f"https://hub.upcloud.com/account/api</blockquote>"
            )
            return
        
        username = args[1].strip()
        password = args[2].strip()
        
        await message.reply_text(f"⏳ <b>Testing credentials...</b>")
        
        # Test dengan get account
        data, status = await upcloud_request("GET", "account")
        
        if status == 200:
            upcloud_config["username"] = username
            upcloud_config["password"] = password
            save_upcloud_config(upcloud_config)
            
            account = data.get("account", {})
            email = account.get("email", "-")
            credit = account.get("credit", "0")
            
            await message.reply_text(
                f"<blockquote><b>✅ CREDENTIALS VALID</b>\n\n"
                f"👤 <b>Username:</b> {username}\n"
                f"📧 <b>Email:</b> {email}\n"
                f"💰 <b>Credit:</b> €{credit}</blockquote>"
            )
        else:
            await message.reply_text(f"{ggl} <b>Credentials tidak valid!</b>")
            
    except Exception as e:
        await message.reply_text(f"{ggl} <b>Error: {str(e)[:100]}</b>")

# ============================================
# COMMAND LIHAT ZONE
# ============================================

@PY.UBOT("upcloudzones")
async def upcloud_zones(client: Client, message: Message):
    """Lihat daftar zone dari API"""
    ggl = await EMO.GAGAL(client)
    prs = await EMO.PROSES(client)
    
    if not upcloud_config.get("username"):
        await message.reply_text(f"{ggl} <b>Credentials belum diset!</b>")
        return
    
    processing = await message.reply_text(f"{prs} <b>Mengambil daftar zone...</b>")
    
    data, status = await upcloud_request("GET", "zone")
    
    if status == 200:
        zones = data.get("zones", {}).get("zone", [])
        
        text = "<blockquote><b>🌍 ZONE UPCLOUD</b>\n\n"
        
        for z in zones:
            if z.get("public", "no") == "yes":
                text += f"• <code>{z.get('id')}</code> - {z.get('description')}\n"
        
        text += "\n<b>Populer:</b> sg-sin1, nl-ams1, uk-lon1</blockquote>"
        
        await processing.edit_text(text)
    else:
        await processing.edit_text(f"{ggl} <b>Gagal ambil zone!</b>")

# ============================================
# COMMAND LIHAT PLAN
# ============================================

@PY.UBOT("upcloudplans")
async def upcloud_plans(client: Client, message: Message):
    """Lihat daftar plan dari API"""
    ggl = await EMO.GAGAL(client)
    prs = await EMO.PROSES(client)
    
    if not upcloud_config.get("username"):
        await message.reply_text(f"{ggl} <b>Credentials belum diset!</b>")
        return
    
    processing = await message.reply_text(f"{prs} <b>Mengambil daftar plan...</b>")
    
    data, status = await upcloud_request("GET", "plan")
    
    if status == 200:
        plans = data.get("plans", {}).get("plan", [])
        
        text = "<blockquote><b>📊 PLAN UPCLOUD</b>\n\n"
        
        for p in plans[:10]:  # Ambil 10 aja
            if p.get("public", "no") == "yes":
                text += f"• <code>{p.get('name')}</code>\n"
                text += f"  {p.get('core_number')} CPU, {p.get('memory_amount')}MB RAM, {p.get('storage_size')}GB SSD\n\n"
        
        text += "\n<b>Size simple:</b> 1gb, 2gb, 4gb, 8gb, 12gb, 16gb, 32gb</blockquote>"
        
        await processing.edit_text(text)
    else:
        await processing.edit_text(f"{ggl} <b>Gagal ambil plan!</b>")

# ============================================
# COMMAND LIHAT TEMPLATE OS
# ============================================

@PY.UBOT("upcloudos")
async def upcloud_templates(client: Client, message: Message):
    """Lihat daftar template OS dari API"""
    ggl = await EMO.GAGAL(client)
    prs = await EMO.PROSES(client)
    
    if not upcloud_config.get("username"):
        await message.reply_text(f"{ggl} <b>Credentials belum diset!</b>")
        return
    
    processing = await message.reply_text(f"{prs} <b>Mengambil daftar OS template...</b>")
    
    data, status = await upcloud_request("GET", "storage/template")
    
    if status == 200:
        templates = data.get("storages", {}).get("storage", [])
        
        text = "<blockquote><b>🖼️ OS TEMPLATE UPCLOUD</b>\n\n"
        
        # Filter OS populer
        os_list = []
        for t in templates:
            title = t.get("title", "").lower()
            if any(x in title for x in ["ubuntu", "debian", "centos"]):
                if "lamp" not in title and "cpanel" not in title:
                    os_list.append(t)
        
        for t in os_list[:10]:
            uuid = t.get("uuid", "-")[:8] + "..."
            size = t.get("size", "0") + "GB"
            text += f"• <code>{t.get('title')}</code>\n"
            text += f"  UUID: {uuid}, Size: {size}\n\n"
        
        text += "\n<b>OS simple:</b> ubuntu22, ubuntu20, debian12, debian11, centos7</blockquote>"
        
        await processing.edit_text(text)
    else:
        await processing.edit_text(f"{ggl} <b>Gagal ambil template!</b>")

# ============================================
# COMMAND BUAT VPS (FORMAT: size name zone os)
# ============================================

@PY.UBOT("upcloud")
async def create_upcloud(client: Client, message: Message):
    ggl = await EMO.GAGAL(client)
    sks = await EMO.BERHASIL(client)
    prs = await EMO.PROSES(client)
    
    try:
        # Cek credentials
        if not upcloud_config.get("username"):
            await message.reply_text(
                f"{ggl} <b>Credentials belum diset!</b>\n"
                f"Gunakan .setupcloud [username] [password] dulu"
            )
            return
        
        # Parse args: size name zone os
        args = message.text.split()
        if len(args) < 5:
            await message.reply_text(
                f"<blockquote><b>❌ Format: .upcloud [size] [name] [zone] [os]</b>\n\n"
                f"<b>Contoh:</b>\n"
                f"<code>.upcloud 1gb vpsku sg ubuntu22</code>\n"
                f"<code>.upcloud 4gb database nl ubuntu20</code>\n"
                f"<code>.upcloud 2gb testing uk debian12</code>\n\n"
                f"<b>Size:</b> 1gb, 2gb, 4gb, 8gb, 12gb, 16gb, 32gb\n"
                f"<b>Zone:</b> sg (Singapore), nl (Amsterdam), uk (London)\n"
                f"<b>OS:</b> ubuntu22, ubuntu20, debian12, debian11, centos7</blockquote>"
            )
            return
        
        size_key = args[1].lower()
        name = args[2]
        zone_key = args[3].lower()
        os_key = args[4].lower()
        
        # Validasi size
        if size_key not in UPCLOUD_PLAN_MAP:
            sizes = ", ".join(UPCLOUD_PLAN_MAP.keys())
            await message.reply_text(f"{ggl} <b>Size tidak valid!</b>\nPilih: {sizes}")
            return
        
        # Validasi zone
        if zone_key not in UPCLOUD_ZONE_MAP:
            zones = ", ".join(UPCLOUD_ZONE_MAP.keys())
            await message.reply_text(f"{ggl} <b>Zone tidak valid!</b>\nPilih: {zones}")
            return
        
        # Validasi OS
        os_map = {
            "ubuntu22": "Ubuntu 22.04",
            "ubuntu20": "Ubuntu 20.04",
            "debian12": "Debian 12",
            "debian11": "Debian 11",
            "centos7": "CentOS 7"
        }
        
        if os_key not in os_map:
            oss = ", ".join(os_map.keys())
            await message.reply_text(f"{ggl} <b>OS tidak valid!</b>\nPilih: {oss}")
            return
        
        # Cari template UUID dari API
        await message.reply_text(f"{prs} <b>Mencari template OS...</b>")
        
        template_data, template_status = await upcloud_request("GET", "storage/template")
        
        if template_status != 200:
            await message.reply_text(f"{ggl} <b>Gagal ambil template!</b>")
            return
        
        templates = template_data.get("storages", {}).get("storage", [])
        
        # Cari UUID berdasarkan OS
        template_uuid = None
        os_search = os_map[os_key].lower()
        
        for t in templates:
            title = t.get("title", "").lower()
            if os_search in title and "lamp" not in title and "cpanel" not in title:
                template_uuid = t.get("uuid")
                break
        
        if not template_uuid:
            await message.reply_text(f"{ggl} <b>Template {os_key} tidak ditemukan!</b>")
            return
        
        # Plan details
        plan = UPCLOUD_PLAN_MAP[size_key]
        zone = UPCLOUD_ZONE_MAP[zone_key]
        
        # Generate password
        password = random_password()
        
        # Data untuk create server
        server_data = {
            "server": {
                "zone": zone,
                "title": name,
                "hostname": name,
                "plan": f"{plan['core']}xCPU-{plan['memory']}MB",
                "storage_devices": {
                    "storage_device": [
                        {
                            "action": "clone",
                            "storage": template_uuid,
                            "title": f"{name}-disk",
                            "size": plan['memory'] * 2  # 2x RAM sebagai disk
                        }
                    ]
                },
                "login_user": {
                    "username": "root",
                    "password": password,
                    "create_password": "yes"
                }
            }
        }
        
        processing = await message.reply_text(
            f"{prs} <b>Membuat VPS UpCloud...</b>\n"
            f"📛 Nama: {name}\n"
            f"📊 Size: {size_key} ({plan['core']} CPU, {plan['memory']}MB RAM)\n"
            f"📍 Zone: {zone}\n"
            f"🖼️ OS: {os_key}"
        )
        
        # Request create server
        response, status = await upcloud_request("POST", "server", server_data)
        
        if status not in [200, 201, 202]:
            error_msg = response.get("error", {}).get("error_message", "Unknown error")
            await processing.edit_text(f"{ggl} <b>Gagal membuat VPS!</b>\n{error_msg}")
            return
        
        server = response.get("server", {})
        server_uuid = server.get("uuid")
        
        await processing.edit_text(
            f"{prs} <b>VPS dibuat! Menunggu IP aktif (60 detik)...</b>"
        )
        
        # Tunggu 60 detik
        await asyncio.sleep(60)
        
        # Ambil info terbaru
        info, info_status = await upcloud_request("GET", f"server/{server_uuid}")
        
        ip_address = "0.0.0.0"
        status_text = "started"
        
        if info_status == 200:
            server_info = info.get("server", {})
            ip_address = server_info.get("ip_addresses", {}).get("ip_address", [{}])[0].get("address", "0.0.0.0")
            status_text = server_info.get("state", "started")
        
        await processing.delete()
        
        # Hasil
        result = f"""
<blockquote><b>✅ VPS UPCLOUD BERHASIL DIBUAT</b>

📛 <b>Nama:</b> {name}
🆔 <b>UUID:</b> <code>{server_uuid}</code>
🌐 <b>IP:</b> <code>{ip_address}</code>
🔑 <b>Password:</b> <code>{password}</code>
📊 <b>Size:</b> {size_key} ({plan['core']} CPU, {plan['memory']}MB RAM)
📍 <b>Zone:</b> {zone}
🖼️ <b>OS:</b> {os_key}
🔰 <b>Status:</b> {status_text}

📌 <b>SSH:</b> <code>ssh root@{ip_address}</code>
⚠️ <b>Ganti password setelah login!</b></blockquote>"""
        
        await message.reply_text(result)
        
    except Exception as e:
        await message.reply_text(f"{ggl} <b>Error: {str(e)[:100]}</b>")

# ============================================
# COMMAND LIHAT DAFTAR VPS
# ============================================

@PY.UBOT("upcloudlist")
async def upcloud_list(client: Client, message: Message):
    ggl = await EMO.GAGAL(client)
    prs = await EMO.PROSES(client)
    
    if not upcloud_config.get("username"):
        await message.reply_text(f"{ggl} <b>Credentials belum diset!</b>")
        return
    
    processing = await message.reply_text(f"{prs} <b>Mengambil daftar VPS...</b>")
    
    data, status = await upcloud_request("GET", "server")
    
    if status == 200:
        servers = data.get("servers", {}).get("server", [])
        
        if not servers:
            await processing.edit_text("<b>📭 Belum ada VPS.</b>")
            return
        
        text = "<blockquote><b>📋 DAFTAR VPS UPCLOUD</b>\n\n"
        
        for s in servers:
            ip = s.get("ip_addresses", {}).get("ip_address", [{}])[0].get("address", "-")
            text += f"📛 <b>{s.get('title')}</b>\n"
            text += f"🆔 <code>{s.get('uuid')}</code> | {ip}\n"
            text += f"🔰 {s.get('state')} | {s.get('zone')}\n"
            text += f"━━━━━━━━━━━━━━━\n"
        
        text += f"\n📊 Total: {len(servers)} VPS</blockquote>"
        
        await processing.edit_text(text)
    else:
        await processing.edit_text(f"{ggl} <b>Gagal mengambil data!</b>")

# ============================================
# COMMAND DETAIL VPS
# ============================================

@PY.UBOT("upcloudinfo")
async def upcloud_info(client: Client, message: Message):
    ggl = await EMO.GAGAL(client)
    prs = await EMO.PROSES(client)
    
    if not upcloud_config.get("username"):
        await message.reply_text(f"{ggl} <b>Credentials belum diset!</b>")
        return
    
    args = message.text.split(maxsplit=1)
    if len(args) < 2:
        await message.reply_text(f"{ggl} <b>Masukkan UUID VPS!</b>\nContoh: .upcloudinfo 123e4567-e89b-12d3-a456-426614174000")
        return
    
    server_uuid = args[1].strip()
    
    processing = await message.reply_text(f"{prs} <b>Mengambil info VPS...</b>")
    
    data, status = await upcloud_request("GET", f"server/{server_uuid}")
    
    if status == 200:
        s = data.get("server", {})
        
        ip_addresses = s.get("ip_addresses", {}).get("ip_address", [])
        ip_public = "-"
        for ip in ip_addresses:
            if ip.get("access") == "public":
                ip_public = ip.get("address", "-")
                break
        
        text = f"""
<blockquote><b>📊 DETAIL VPS UPCLOUD</b>

📛 <b>Title:</b> {s.get('title', '-')}
🆔 <b>UUID:</b> <code>{s.get('uuid')}</code>
🔰 <b>State:</b> {s.get('state', '-')}
🌐 <b>IP:</b> {ip_public}
📍 <b>Zone:</b> {s.get('zone', '-')}
📊 <b>Plan:</b> {s.get('plan', '-')}
⚙️ <b>Core:</b> {s.get('core_number', '0')}
💾 <b>Memory:</b> {s.get('memory_amount', '0')} MB
💽 <b>Disk:</b> {s.get('storage_devices', {}).get('storage_device', [{}])[0].get('size', '0')} GB
🖼️ <b>OS:</b> {s.get('storage_devices', {}).get('storage_device', [{}])[0].get('title', '-')}
📅 <b>Created:</b> {s.get('created', '-')[:10]}</blockquote>"""
        
        await processing.edit_text(text)
    else:
        await processing.edit_text(f"{ggl} <b>VPS tidak ditemukan!</b>")

# ============================================
# COMMAND POWER MANAGEMENT
# ============================================

@PY.UBOT("upcloudstart")
async def upcloud_start(client: Client, message: Message):
    await upcloud_power_action(client, message, "start", "menghidupkan")

@PY.UBOT("upcloudstop")
async def upcloud_stop(client: Client, message: Message):
    await upcloud_power_action(client, message, "stop", "mematikan")

@PY.UBOT("upcloudreboot")
async def upcloud_reboot(client: Client, message: Message):
    await upcloud_power_action(client, message, "restart", "merestart")

async def upcloud_power_action(client: Client, message: Message, action: str, action_name: str):
    ggl = await EMO.GAGAL(client)
    prs = await EMO.PROSES(client)
    
    if not upcloud_config.get("username"):
        await message.reply_text(f"{ggl} <b>Credentials belum diset!</b>")
        return
    
    args = message.text.split(maxsplit=1)
    if len(args) < 2:
        await message.reply_text(f"{ggl} <b>Masukkan UUID VPS!</b>")
        return
    
    server_uuid = args[1].strip()
    
    processing = await message.reply_text(f"{prs} <b>{action_name.title()} VPS...</b>")
    
    # UpCloud pake POST dengan action
    data = {}
    _, status = await upcloud_request("POST", f"server/{server_uuid}/{action}", data)
    
    if status == 200 or status == 204:
        await processing.edit_text(f"<b>✅ VPS berhasil {action_name}!</b>")
    else:
        await processing.edit_text(f"{ggl} <b>Gagal {action_name} VPS!</b>")

# ============================================
# COMMAND DELETE VPS
# ============================================

@PY.UBOT("upclouddelete")
async def upcloud_delete(client: Client, message: Message):
    ggl = await EMO.GAGAL(client)
    prs = await EMO.PROSES(client)
    
    if not upcloud_config.get("username"):
        await message.reply_text(f"{ggl} <b>Credentials belum diset!</b>")
        return
    
    args = message.text.split(maxsplit=1)
    if len(args) < 2:
        await message.reply_text(f"{ggl} <b>Masukkan UUID VPS!</b>")
        return
    
    server_uuid = args[1].strip()
    
    # Konfirmasi
    confirm = await message.reply_text(
        f"⚠️ <b>Yakin hapus VPS {server_uuid[:8]}...?</b>\n"
        f"Ketik <code>ya</code> untuk konfirmasi."
    )
    
    try:
        resp = await client.wait_for_message(
            chat_id=message.chat.id,
            from_user_id=message.from_user.id,
            timeout=10
        )
        
        if resp and resp.text and resp.text.lower() == "ya":
            await confirm.edit_text(f"{prs} <b>Menghapus VPS...</b>")
            
            _, status = await upcloud_request("DELETE", f"server/{server_uuid}")
            
            if status == 204:
                await confirm.edit_text(f"<b>✅ VPS dihapus!</b>")
            else:
                await confirm.edit_text(f"{ggl} <b>Gagal menghapus!</b>")
        else:
            await confirm.edit_text("<b>❌ Dibatalkan</b>")
            
    except asyncio.TimeoutError:
        await confirm.edit_text("<b>⏱️ Timeout, dibatalkan</b>")

# ============================================
# COMMAND INFO AKUN
# ============================================

@PY.UBOT("upcloudaccount")
async def upcloud_account(client: Client, message: Message):
    ggl = await EMO.GAGAL(client)
    prs = await EMO.PROSES(client)
    
    if not upcloud_config.get("username"):
        await message.reply_text(f"{ggl} <b>Credentials belum diset!</b>")
        return
    
    processing = await message.reply_text(f"{prs} <b>Mengambil info akun...</b>")
    
    # Get account
    acc_data, acc_status = await upcloud_request("GET", "account")
    
    # Get servers count
    srv_data, srv_status = await upcloud_request("GET", "server")
    
    if acc_status == 200:
        acc = acc_data.get("account", {})
        email = acc.get("email", "-")
        credit = acc.get("credit", "0")
        
        server_count = 0
        if srv_status == 200:
            server_count = len(srv_data.get("servers", {}).get("server", []))
        
        text = f"""
<blockquote><b>📊 INFO AKUN UPCLOUD</b>

👤 <b>Username:</b> {upcloud_config.get('username')}
📧 <b>Email:</b> {email}
💰 <b>Credit:</b> €{credit}
📦 <b>VPS Aktif:</b> {server_count}</blockquote>"""
        
        await processing.edit_text(text)
    else:
        await processing.edit_text(f"{ggl} <b>Gagal ambil info akun!</b>")