from fansx import *
import aiohttp
import asyncio
import random
from urllib.parse import quote
from pyrogram.enums import ChatAction, ParseMode
from pyrogram.types import Message

__MODULE__ = "ᴅᴏᴜʏɪɴ sᴇᴀʀᴄʜ ᴠ2"
__HELP__ = """
<blockquote><b>🎵 DOUYIN SEARCH V2</b>

<b>⌲ Perintah:</b>
ᚗ <code>{0}douyinv2 [kata kunci]</code> - Cari video Douyin

<b>⌲ Contoh:</b>
<code>.douyinv2 Cina</code>
<code>.douyinv2 korea</code></blockquote>
"""

# ============================================
# KONFIGURASI
# ============================================
BASE_URL = "https://api.theresav.biz.id/search/douyin"
API_KEY = "UYGSg"  # API Key dari contoh

async def search_douyin(query: str):
    """Mencari video di Douyin"""
    try:
        encoded_query = quote(query)
        url = f"{BASE_URL}?q={encoded_query}&apikey={API_KEY}"
        
        async with aiohttp.ClientSession() as session:
            async with session.get(url, timeout=15) as response:
                if response.status == 200:
                    data = await response.json()
                    
                    if data.get("status") and data.get("result"):
                        return {
                            "success": True,
                            "results": data.get("result", [])
                        }
                    else:
                        return {"success": False, "error": "Tidak ada hasil"}
                else:
                    return {"success": False, "error": f"HTTP {response.status}"}
    except asyncio.TimeoutError:
        return {"success": False, "error": "Timeout"}
    except Exception as e:
        return {"success": False, "error": str(e)}

def format_number(num):
    """Format angka dengan ribuan"""
    try:
        return f"{int(num):,}".replace(",", ".")
    except:
        return str(num)

@PY.UBOT("douyinv2")
async def douyin_search_v2(client: Client, message: Message):
    ggl = await EMO.GAGAL(client)
    sks = await EMO.BERHASIL(client)
    prs = await EMO.PROSES(client)
    
    try:
        await client.send_chat_action(message.chat.id, ChatAction.TYPING)
        
        # Ambil kata kunci
        args = message.text.split(maxsplit=1)
        if len(args) < 2:
            await message.reply_text(
                f"<blockquote><b>❌ Masukkan kata kunci!</b>\n\n"
                f"<b>Contoh:</b>\n"
                f"<code>.douyinv2 Cina</code>\n"
                f"<code>.douyinv2 korea</code></blockquote>"
            )
            return
        
        query = args[1].strip()
        
        # Kirim pesan processing
        processing = await message.reply_text(f"{prs} <b>Mencari video '{query}' di Douyin...</b>")
        
        # Cari di Douyin
        result = await search_douyin(query)
        
        if not result.get("success") or not result.get("results"):
            await processing.edit_text(
                f"<blockquote><b>❌ TIDAK ADA HASIL</b>\n\n"
                f"Kata Kunci: {query}\n"
                f"Coba kata kunci lain.</blockquote>"
            )
            return
        
        results = result.get("results", [])
        
        # Pilih random 1 dari hasil
        selected = random.choice(results)
        
        rank = selected.get("rank", 0)
        description = selected.get("description", "Tidak ada deskripsi")
        author = selected.get("author", "Unknown")
        likes = format_number(selected.get("likes", 0))
        comments = format_number(selected.get("comments", 0))
        video_url = selected.get("video_url", "")
        aweme_id = selected.get("aweme_id", "")
        
        await processing.delete()
        
        # Kirim informasi
        caption = f"""
<blockquote><b>🎵 DOUYIN SEARCH V2</b>

📌 <b>Peringkat:</b> #{rank}
📝 <b>Deskripsi:</b> {description[:200]}{'...' if len(description) > 200 else ''}
👤 <b>Author:</b> {author}
❤️ <b>Likes:</b> {likes}
💬 <b>Komentar:</b> {comments}
🆔 <b>Aweme ID:</b> <code>{aweme_id}</code>

🔗 <b>Link Video:</b> {video_url}
⚡ <b>Powered by:</b> Ubot Premium Zyura</blockquote>"""
        
        await message.reply_text(caption)
        
    except Exception as e:
        await message.reply_text(f"{ggl} <b>Error: {str(e)[:100]}</b>")

