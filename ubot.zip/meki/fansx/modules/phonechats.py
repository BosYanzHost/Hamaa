from fansx import *
import aiohttp
import asyncio
import os
import random
from pyrogram.enums import ChatAction, ParseMode
from pyrogram.types import Message

__MODULE__ = "ɪᴩʜᴏɴᴇ ǫᴜᴏᴛᴇᴅ ᴄʜᴀᴛ"
__HELP__ = """
<blockquote><b>📱 IPHONE QUOTED CHAT</b>

<b>⌲ Perintah:</b>
ᚗ <code>{0}phonegc [teks]</code> - Buat stiker chat iPhone
ᚗ <code>{0}phonegc [teks] | [waktu] | [warna]</code> - Kustomisasi

<b>⌲ Contoh:</b>
<code>.phonegc Halo ges</code>
<code>.phonegc Apa kabar? | 11:02 | #272a2f</code></blockquote>
"""

# ============================================
# KONFIGURASI
# ============================================
phonegc_API = "https://anabot.my.id/api/maker/iqc"
API_KEY = "freeApikey"  # Bisa diganti nanti

# Default values
DEFAULT_CHAT_TIME = "11:02"
DEFAULT_STATUS_TIME = "17:01"
DEFAULT_BUBBLE_COLOR = "#272a2f"
DEFAULT_MENU_COLOR = "#272a2f" 
DEFAULT_TEXT_COLOR = "#FFFFFF"
DEFAULT_FONT = "Arial"
DEFAULT_SIGNAL = "Telkomsel"

async def create_phonegc_image(
    text, 
    chat_time=DEFAULT_CHAT_TIME, 
    status_time=DEFAULT_STATUS_TIME,
    bubble_color=DEFAULT_BUBBLE_COLOR,
    menu_color=DEFAULT_MENU_COLOR,
    text_color=DEFAULT_TEXT_COLOR,
    font_name=DEFAULT_FONT,
    signal_name=DEFAULT_SIGNAL
):
    """Buat gambar iPhone Quoted Chat"""
    
    # Encode semua parameter
    url = (f"{phonegc_API}?text={text}"
           f"&chatTime={chat_time}"
           f"&statusBarTime={status_time}"
           f"&bubbleColor={bubble_color}"
           f"&menuColor={menu_color}"
           f"&textColor={text_color}"
           f"&fontName={font_name}"
           f"&signalName={signal_name}"
           f"&apikey={API_KEY}")
    
    try:
        async with aiohttp.ClientSession() as session:
            async with session.get(url, timeout=30) as response:
                if response.status == 200:
                    # Cek content-type
                    content_type = response.headers.get("Content-Type", "")
                    
                    if "image" in content_type:
                        # Langsung gambar
                        return {
                            "success": True,
                            "image": await response.read(),
                            "direct": True
                        }
                    else:
                        # Mungkin JSON dengan URL gambar
                        try:
                            data = await response.json()
                            
                            # Cek berbagai format respons
                            if data.get("status") == "success" and data.get("result"):
                                img_url = data["result"]
                            elif data.get("image_url"):
                                img_url = data["image_url"]
                            elif data.get("url"):
                                img_url = data["url"]
                            else:
                                return {"success": False, "error": "Format respons tidak dikenali", "data": data}
                            
                            # Download gambar dari URL
                            async with session.get(img_url, timeout=15) as img_resp:
                                if img_resp.status == 200:
                                    return {
                                        "success": True,
                                        "image": await img_resp.read()
                                    }
                                else:
                                    return {"success": False, "error": f"Gagal download gambar: HTTP {img_resp.status}"}
                        except:
                            return {"success": False, "error": "API tidak mengembalikan gambar"}
                else:
                    return {"success": False, "error": f"HTTP {response.status}"}
    except asyncio.TimeoutError:
        return {"success": False, "error": "Timeout - server terlalu lambat"}
    except Exception as e:
        return {"success": False, "error": str(e)}

def parse_phonegc_args(args):
    """Parse argumen dengan format: teks | waktu | warna"""
    if len(args) == 1:
        return {
            "text": args[0],
            "chat_time": DEFAULT_CHAT_TIME,
            "status_time": DEFAULT_STATUS_TIME,
            "bubble_color": DEFAULT_BUBBLE_COLOR,
            "menu_color": DEFAULT_MENU_COLOR,
            "text_color": DEFAULT_TEXT_COLOR,
            "font": DEFAULT_FONT,
            "signal": DEFAULT_SIGNAL
        }
    
    # Format: teks | waktu | warna_bubble | warna_teks
    full_text = " ".join(args)
    parts = [p.strip() for p in full_text.split("|")]
    
    result = {
        "text": parts[0],
        "chat_time": DEFAULT_CHAT_TIME,
        "status_time": DEFAULT_STATUS_TIME,
        "bubble_color": DEFAULT_BUBBLE_COLOR,
        "menu_color": DEFAULT_MENU_COLOR,
        "text_color": DEFAULT_TEXT_COLOR,
        "font": DEFAULT_FONT,
        "signal": DEFAULT_SIGNAL
    }
    
    # Parse waktu (opsional)
    if len(parts) > 1:
        time_parts = parts[1].split("-")
        if len(time_parts) >= 1:
            result["chat_time"] = time_parts[0].strip()
        if len(time_parts) >= 2:
            result["status_time"] = time_parts[1].strip()
    
    # Parse warna (opsional)
    if len(parts) > 2:
        color_parts = parts[2].split("-")
        if len(color_parts) >= 1:
            result["bubble_color"] = color_parts[0].strip()
        if len(color_parts) >= 2:
            result["menu_color"] = color_parts[1].strip()
        if len(color_parts) >= 3:
            result["text_color"] = color_parts[2].strip()
    
    # Parse font dan signal (opsional)
    if len(parts) > 3:
        font_signal = parts[3].split("/")
        if len(font_signal) >= 1:
            result["font"] = font_signal[0].strip()
        if len(font_signal) >= 2:
            result["signal"] = font_signal[1].strip()
    
    return result

@PY.UBOT("phonegc")
async def phonegc_command(client: Client, message: Message):
    ggl = await EMO.GAGAL(client)
    sks = await EMO.BERHASIL(client)
    prs = await EMO.PROSES(client)
    
    # Parse argumen
    args = message.text.split()[1:]
    if not args:
        # Tampilkan help tanpa tombol
        help_text = f"""
<blockquote><b>Cara pakai:</b>
ᚗ <code>.phonegc [teks]</code>

<b>Contoh sederhana:</b>
<code>.phonegc Halo ges</code></blockquote>"""
        
        await message.reply_text(help_text)
        return
    
    parsed = parse_phonegc_args(args)
    
    try:
        await client.send_chat_action(message.chat.id, ChatAction.UPLOAD_PHOTO)
        
        processing = await message.reply_text(
            f"{prs} <b>Membuat iPhone chat...</b>\n"
            f"<code>{parsed['text'][:50]}{'...' if len(parsed['text']) > 50 else ''}</code>"
        )
        
        result = await create_phonegc_image(
            text=parsed['text'],
            chat_time=parsed['chat_time'],
            status_time=parsed['status_time'],
            bubble_color=parsed['bubble_color'],
            menu_color=parsed['menu_color'],
            text_color=parsed['text_color'],
            font_name=parsed['font'],
            signal_name=parsed['signal']
        )
        
        await processing.delete()
        
        if result.get("success") and result.get("image"):
            # Simpan gambar sementara
            file_path = f"phonegc_{message.from_user.id}_{random.randint(1000,9999)}.png"
            with open(file_path, "wb") as f:
                f.write(result["image"])
            
            # Buat caption dengan info
            caption = f"<blockquote><b>📱 IPHONE QUOTED CHAT</b>\n\n"
            caption += f"<b>💬 Teks:</b> {parsed['text'][:100]}{'...' if len(parsed['text']) > 100 else ''}\n"
            caption += f"<b>⏰ Waktu:</b> {parsed['chat_time']} - {parsed['status_time']}\n"
            caption += f"<b>🎨 Warna:</b> {parsed['bubble_color']} | {parsed['menu_color']} | {parsed['text_color']}\n"
            caption += f"<b>📋 Font:</b> {parsed['font']}\n"
            caption += f"<b>📶 Sinyal:</b> {parsed['signal']}\n"
            caption += f"\n⚡ Powered by: Ubot Premium Zyura</blockquote>"
            
            # Kirim gambar
            await client.send_photo(
                chat_id=message.chat.id,
                photo=file_path,
                caption=caption
            )
            
            # Hapus file
            if os.path.exists(file_path):
                os.remove(file_path)
            
        else:
            error_msg = result.get("error", "Unknown error")
            await message.reply_text(
                f"<blockquote><b>❌ GAGAL MEMBUAT GAMBAR</b>\n\n"
                f"<b>Error:</b> {error_msg}</blockquote>"
            )
        
    except Exception as e:
        await message.reply_text(f"{ggl} <b>Error: {str(e)[:100]}</b>")

@PY.UBOT("phonegcsetkey")
async def phonegc_setkey(client: Client, message: Message):
    """Set API key phonegc (khusus admin)"""
    ggl = await EMO.GAGAL(client)
    sks = await EMO.BERHASIL(client)
    
    # Cek admin (sesuaikan dengan sistem admin di base)
    # if not message.from_user.id in ADMIN_IDS:
    #     return await message.reply_text(f"{ggl} <b>Khusus admin!</b>")
    
    args = message.text.split()
    if len(args) < 2:
        await message.reply_text(
            f"<blockquote><b>⚠️ FORMAT SALAH</b>\n\n"
            f"<b>Cara pakai:</b> <code>.phonegcsetkey [apikey_baru]</code>\n"
            f"<b>Contoh:</b> <code>.phonegcsetkey apikey123</code></blockquote>"
        )
        return
    
    global API_KEY
    new_key = args[1].strip()
    API_KEY = new_key
    
    await message.reply_text(f"{sks} <b>API Key phonegc berhasil diupdate!</b>")