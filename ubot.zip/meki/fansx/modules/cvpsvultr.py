from fansx import *
import aiohttp
import asyncio
import random
import string
import json
import os
from datetime import datetime
from pyrogram.enums import ChatAction, ParseMode
from pyrogram.types import Message

__MODULE__ = "ᴠᴜʟᴛʀ ᴠᴘs"
__HELP__ = """
<blockquote><b>『 CREATE VPS VULTR 』</b>

<b>⌲ Setting API Key:</b>
ᚗ <code>{0}setvultr [api_key]</code> - Set Vultr API key

<b>⌲ Buat VPS (format):</b>
ᚗ <code>{0}vultr [size] [name] [region] [image]</code>

<b>⌲ Size:</b> 1gb, 2gb, 4gb, 8gb, 16gb, 32gb, 64gb, 96gb
<b>⌲ Region:</b> sgp (Singapore), nyc (New York), fra (Frankfurt)
<b>⌲ Image:</b> ubuntu20, ubuntu22, debian11, debian12, centos7

<b>⌲ Contoh:</b>
<code>.vultr 1gb vpsku sgp ubuntu22</code>
<code>.vultr 4gb database nyc ubuntu20</code>
<code>.vultr 2gb testing fra debian11</code>

<b>⌲ Manajemen:</b>
ᚗ <code>{0}vultrlist</code> - Lihat semua VPS
ᚗ <code>{0}vultrinfo [id]</code> - Detail VPS
ᚗ <code>{0}vultrstart [id]</code> - Start VPS
ᚗ <code>{0}vultrstop [id]</code> - Stop VPS
ᚗ <code>{0}vultrreboot [id]</code> - Reboot VPS
ᚗ <code>{0}vultrdelete [id]</code> - Hapus VPS

<b>⌲ Informasi:</b>
ᚗ <code>{0}vultrregions</code> - Daftar region
ᚗ <code>{0}vultrplans</code> - Daftar plan/size
ᚗ <code>{0}vultros</code> - Daftar OS image
ᚗ <code>{0}vultraccount</code> - Info akun</blockquote>
"""

# ============================================
# KONFIGURASI
# ============================================
VULTR_CONFIG_FILE = "vultr_config.json"

VULTR_API = "https://api.vultr.com/v2"

# Mapping size (Vultr plan IDs)
VULTR_SIZES = {
    "1gb": "vc2-1c-1gb",      # 1GB RAM, 1 vCPU
    "2gb": "vc2-1c-2gb",      # 2GB RAM, 1 vCPU
    "4gb": "vc2-2c-4gb",      # 4GB RAM, 2 vCPU
    "8gb": "vc2-4c-8gb",      # 8GB RAM, 4 vCPU
    "16gb": "vc2-8c-16gb",    # 16GB RAM, 8 vCPU
    "32gb": "vc2-16c-32gb",   # 32GB RAM, 16 vCPU
    "64gb": "vc2-24c-64gb",   # 64GB RAM, 24 vCPU
    "96gb": "vc2-32c-96gb",   # 96GB RAM, 32 vCPU
}

# Mapping size ke deskripsi
VULTR_SIZE_DESC = {
    "1gb": "1GB RAM, 1 vCPU, 25GB SSD",
    "2gb": "2GB RAM, 1 vCPU, 50GB SSD",
    "4gb": "4GB RAM, 2 vCPU, 80GB SSD",
    "8gb": "8GB RAM, 4 vCPU, 160GB SSD",
    "16gb": "16GB RAM, 8 vCPU, 320GB SSD",
    "32gb": "32GB RAM, 16 vCPU, 640GB SSD",
    "64gb": "64GB RAM, 24 vCPU, 1280GB SSD",
    "96gb": "96GB RAM, 32 vCPU, 1920GB SSD",
}

# Mapping image OS (Vultr OS IDs)
VULTR_IMAGES = {
    "ubuntu20": "215",  # Ubuntu 20.04 x64
    "ubuntu22": "216",  # Ubuntu 22.04 x64
    "debian11": "139",  # Debian 11 x64
    "debian12": "140",  # Debian 12 x64
    "centos7": "167",   # CentOS 7 x64
    "centos8": "168",   # CentOS 8 x64
    "rocky8": "362",    # Rocky Linux 8
    "rocky9": "363",    # Rocky Linux 9
    "alma8": "414",     # AlmaLinux 8
    "alma9": "415",     # AlmaLinux 9
    "windows2019": "197", # Windows 2019
    "windows2022": "199", # Windows 2022
}

# Mapping region (Vultr region IDs)
VULTR_REGIONS = {
    "sgp": "sgp",      # Singapore
    "nyc": "ewr",      # New Jersey (dekat New York)
    "lon": "lhr",      # London
    "fra": "fra",      # Frankfurt
    "ams": "ams",      # Amsterdam
    "par": "cdg",      # Paris
    "syd": "syd",      # Sydney
    "tok": "nrt",      # Tokyo
    "la": "lax",       # Los Angeles
    "chi": "ord",      # Chicago
    "atl": "atl",      # Atlanta
    "mia": "mia",      # Miami
    "sea": "sea",      # Seattle
    "tor": "yto",      # Toronto
}

# Reverse mapping untuk display
VULTR_REGION_NAMES = {
    "sgp": "Singapore",
    "ewr": "New Jersey (NYC)",
    "lhr": "London",
    "fra": "Frankfurt",
    "ams": "Amsterdam",
    "cdg": "Paris",
    "syd": "Sydney",
    "nrt": "Tokyo",
    "lax": "Los Angeles",
    "ord": "Chicago",
    "atl": "Atlanta",
    "mia": "Miami",
    "sea": "Seattle",
    "yto": "Toronto",
}

def load_vultr_config():
    """Load Vultr config dari file"""
    try:
        if os.path.exists(VULTR_CONFIG_FILE):
            with open(VULTR_CONFIG_FILE, 'r') as f:
                return json.load(f)
    except:
        pass
    return {"api_key": None}

def save_vultr_config(config):
    """Simpan Vultr config ke file"""
    try:
        with open(VULTR_CONFIG_FILE, 'w') as f:
            json.dump(config, f, indent=4)
        return True
    except:
        return False

# Load config
vultr_config = load_vultr_config()

def random_password(length=15):
    """Generate random password (Vultr butuh minimal 15 karakter)"""
    chars = string.ascii_letters + string.digits + "!@#$%^&*"
    return ''.join(random.choice(chars) for _ in range(length))

async def vultr_request(method, endpoint, data=None):
    """Request ke API Vultr"""
    
    api_key = vultr_config.get("api_key")
    if not api_key:
        return {"error": "API key belum diset!"}, 401
    
    url = f"{VULTR_API}/{endpoint}"
    headers = {
        "Content-Type": "application/json",
        "Authorization": f"Bearer {api_key}"
    }
    
    try:
        async with aiohttp.ClientSession() as session:
            if method == "GET":
                async with session.get(url, headers=headers, timeout=15) as resp:
                    return await resp.json(), resp.status
            elif method == "POST":
                async with session.post(url, headers=headers, json=data, timeout=60) as resp:
                    return await resp.json(), resp.status
            elif method == "DELETE":
                async with session.delete(url, headers=headers, timeout=15) as resp:
                    if resp.status == 204:
                        return {}, 204
                    return await resp.json(), resp.status
            elif method == "PATCH":
                async with session.patch(url, headers=headers, json=data, timeout=30) as resp:
                    return await resp.json(), resp.status
    except asyncio.TimeoutError:
        return {"error": "Timeout"}, 408
    except Exception as e:
        return {"error": str(e)}, 500

# ============================================
# COMMAND SETTING
# ============================================

@PY.UBOT("setvultr")
async def set_vultr_api(client: Client, message: Message):
    """Set Vultr API key"""
    ggl = await EMO.GAGAL(client)
    sks = await EMO.BERHASIL(client)
    
    try:
        args = message.text.split(maxsplit=1)
        if len(args) < 2:
            await message.reply_text(
                f"<blockquote><b>❌ Format: .setvultr [api_key]</b>\n\n"
                f"Ambil API key di:\n"
                f"https://my.vultr.com/settings/#settingsapi</blockquote>"
            )
            return
        
        api_key = args[1].strip()
        
        await message.reply_text(f"⏳ <b>Testing API key...</b>")
        
        # Test dengan get account
        data, status = await vultr_request("GET", "account")
        
        if status == 200:
            vultr_config["api_key"] = api_key
            save_vultr_config(vultr_config)
            
            account = data.get("account", {})
            email = account.get("email", "-")
            name = account.get("name", "-")
            balance = account.get("balance", "-")
            
            await message.reply_text(
                f"<blockquote><b>✅ API KEY VALID</b>\n\n"
                f"👤 <b>Name:</b> {name}\n"
                f"📧 <b>Email:</b> {email}\n"
                f"💰 <b>Balance:</b> ${balance}\n"
                f"🔑 <b>API Key:</b> <code>{api_key[:8]}...{api_key[-5:]}</code></blockquote>"
            )
        else:
            await message.reply_text(f"{ggl} <b>API key tidak valid!</b>")
            
    except Exception as e:
        await message.reply_text(f"{ggl} <b>Error: {str(e)[:100]}</b>")

# ============================================
# COMMAND BUAT VPS (FORMAT: size name region image)
# ============================================

@PY.UBOT("vultr")
async def create_vultr(client: Client, message: Message):
    ggl = await EMO.GAGAL(client)
    sks = await EMO.BERHASIL(client)
    prs = await EMO.PROSES(client)
    
    try:
        # Cek API key
        if not vultr_config.get("api_key"):
            await message.reply_text(
                f"{ggl} <b>API key belum diset!</b>\n"
                f"Gunakan .setvultr [api_key] dulu"
            )
            return
        
        # Parse args: size name region image
        args = message.text.split()
        if len(args) < 5:
            await message.reply_text(
                f"<blockquote><b>❌ Format: .vultr [size] [name] [region] [image]</b>\n\n"
                f"<b>Contoh:</b>\n"
                f"<code>.vultr 1gb vpsku sgp ubuntu22</code>\n"
                f"<code>.vultr 4gb database nyc ubuntu20</code>\n"
                f"<code>.vultr 2gb testing fra debian11</code>\n\n"
                f"<b>Size:</b> 1gb, 2gb, 4gb, 8gb, 16gb, 32gb, 64gb\n"
                f"<b>Region:</b> sgp, nyc, lon, fra, ams, syd, tok\n"
                f"<b>Image:</b> ubuntu20, ubuntu22, debian11, debian12, centos7</blockquote>"
            )
            return
        
        size_key = args[1].lower()
        name = args[2]
        region_key = args[3].lower()
        image_key = args[4].lower()
        
        # Validasi size
        if size_key not in VULTR_SIZES:
            sizes = ", ".join(VULTR_SIZES.keys())
            await message.reply_text(f"{ggl} <b>Size tidak valid!</b>\nPilih: {sizes}")
            return
        
        # Validasi region
        if region_key not in VULTR_REGIONS:
            regions = ", ".join(VULTR_REGIONS.keys())
            await message.reply_text(f"{ggl} <b>Region tidak valid!</b>\nPilih: {regions}")
            return
        
        # Validasi image
        if image_key not in VULTR_IMAGES:
            images = ", ".join(VULTR_IMAGES.keys())
            await message.reply_text(f"{ggl} <b>Image tidak valid!</b>\nPilih: {images}")
            return
        
        # Generate password
        password = random_password()
        
        # Data untuk create VPS
        vps_data = {
            "region": VULTR_REGIONS[region_key],
            "plan": VULTR_SIZES[size_key],
            "label": name,
            "hostname": name,
            "os_id": int(VULTR_IMAGES[image_key]),
            "enable_ipv6": True,
            "backups": "disabled",
            "user_data": f"""#!/bin/bash
hostnamectl set-hostname {name}
echo "root:{password}" | chpasswd
sed -i 's/PasswordAuthentication no/PasswordAuthentication yes/' /etc/ssh/sshd_config
systemctl restart sshd
""",
            "tags": [f"size-{size_key}", f"os-{image_key}"]
        }
        
        # Kirim processing
        region_display = VULTR_REGION_NAMES.get(VULTR_REGIONS[region_key], region_key)
        processing = await message.reply_text(
            f"{prs} <b>Membuat VPS Vultr...</b>\n"
            f"📛 Nama: {name}\n"
            f"📊 Size: {size_key} ({VULTR_SIZE_DESC[size_key]})\n"
            f"📍 Region: {region_display}\n"
            f"🖼️ OS: {image_key}"
        )
        
        # Request ke API
        response, status = await vultr_request("POST", "instances", vps_data)
        
        if status not in [200, 201, 202]:
            error_msg = response.get("error", "Unknown error")
            await processing.edit_text(f"{ggl} <b>Gagal membuat VPS!</b>\n{error_msg}")
            return
        
        instance = response.get("instance", {})
        instance_id = instance.get("id")
        
        await processing.edit_text(
            f"{prs} <b>VPS dibuat! Menunggu IP aktif (45 detik)...</b>"
        )
        
        # Tunggu 45 detik
        await asyncio.sleep(45)
        
        # Ambil info terbaru
        info, info_status = await vultr_request("GET", f"instances/{instance_id}")
        
        ip_address = "0.0.0.0"
        status_text = "active"
        
        if info_status == 200:
            instance_info = info.get("instance", {})
            ip_address = instance_info.get("main_ip", "0.0.0.0")
            status_text = instance_info.get("status", "active")
        
        await processing.delete()
        
        # Hasil
        result = f"""
<blockquote><b>✅ VPS VULTR BERHASIL DIBUAT</b>

📛 <b>Nama:</b> {name}
🆔 <b>ID:</b> <code>{instance_id}</code>
🌐 <b>IP:</b> <code>{ip_address}</code>
🔑 <b>Password:</b> <code>{password}</code>
📊 <b>Size:</b> {size_key} ({VULTR_SIZE_DESC[size_key]})
📍 <b>Region:</b> {region_display}
🖼️ <b>OS:</b> {image_key}
🔰 <b>Status:</b> {status_text}

📌 <b>SSH:</b> <code>ssh root@{ip_address}</code>
⚠️ <b>Ganti password setelah login!</b></blockquote>"""
        
        await message.reply_text(result)
        
    except Exception as e:
        await message.reply_text(f"{ggl} <b>Error: {str(e)[:100]}</b>")

# ============================================
# COMMAND LIHAT DAFTAR VPS
# ============================================

@PY.UBOT("vultrlist")
async def list_vultr(client: Client, message: Message):
    ggl = await EMO.GAGAL(client)
    prs = await EMO.PROSES(client)
    
    if not vultr_config.get("api_key"):
        await message.reply_text(f"{ggl} <b>API key belum diset!</b>")
        return
    
    processing = await message.reply_text(f"{prs} <b>Mengambil daftar VPS...</b>")
    
    data, status = await vultr_request("GET", "instances")
    
    if status == 200:
        instances = data.get("instances", [])
        
        if not instances:
            await processing.edit_text("<b>📭 Belum ada VPS.</b>")
            return
        
        text = "<blockquote><b>📋 DAFTAR VPS VULTR</b>\n\n"
        
        for inst in instances:
            text += f"📛 <b>{inst.get('label')}</b>\n"
            text += f"🆔 <code>{inst.get('id')}</code> | {inst.get('main_ip', '-')}\n"
            text += f"🔰 {inst.get('status')} | {inst.get('plan')} | {inst.get('region')}\n"
            text += f"━━━━━━━━━━━━━━━\n"
        
        text += f"\n📊 Total: {len(instances)} VPS</blockquote>"
        
        await processing.edit_text(text)
    else:
        await processing.edit_text(f"{ggl} <b>Gagal mengambil data!</b>")

# ============================================
# COMMAND DETAIL VPS
# ============================================

@PY.UBOT("vultrinfo")
async def vultr_info(client: Client, message: Message):
    ggl = await EMO.GAGAL(client)
    prs = await EMO.PROSES(client)
    
    if not vultr_config.get("api_key"):
        await message.reply_text(f"{ggl} <b>API key belum diset!</b>")
        return
    
    args = message.text.split(maxsplit=1)
    if len(args) < 2:
        await message.reply_text(f"{ggl} <b>Masukkan ID VPS!</b>\nContoh: .vultrinfo 12345678")
        return
    
    instance_id = args[1].strip()
    
    processing = await message.reply_text(f"{prs} <b>Mengambil info VPS...</b>")
    
    data, status = await vultr_request("GET", f"instances/{instance_id}")
    
    if status == 200:
        inst = data.get("instance", {})
        
        text = f"""
<blockquote><b>📊 DETAIL VPS VULTR</b>

📛 <b>Label:</b> {inst.get('label', '-')}
🆔 <b>ID:</b> <code>{inst.get('id')}</code>
🔰 <b>Status:</b> {inst.get('status', '-')}
🌐 <b>IP:</b> {inst.get('main_ip', '-')}
🌐 <b>IPv6:</b> {inst.get('v6_main_ip', '-')}
📍 <b>Region:</b> {inst.get('region', '-')}
📊 <b>Plan:</b> {inst.get('plan', '-')}
⚙️ <b>vCPUs:</b> {inst.get('vcpu_count', '0')}
💾 <b>RAM:</b> {inst.get('ram', '0')} MB
💽 <b>Disk:</b> {inst.get('disk', '0')} GB
🖼️ <b>OS:</b> {inst.get('os', '-')}
🔑 <b>User:</b> {inst.get('user_scheme', '-')}
📅 <b>Created:</b> {inst.get('date_created', '-')[:10]}</blockquote>"""
        
        await processing.edit_text(text)
    else:
        await processing.edit_text(f"{ggl} <b>VPS tidak ditemukan!</b>")

# ============================================
# COMMAND POWER MANAGEMENT
# ============================================

@PY.UBOT("vultrstart")
async def vultr_start(client: Client, message: Message):
    await vultr_power_action(client, message, "start", "menghidupkan")

@PY.UBOT("vultrstop")
async def vultr_stop(client: Client, message: Message):
    await vultr_power_action(client, message, "stop", "mematikan")

@PY.UBOT("vultrreboot")
async def vultr_reboot(client: Client, message: Message):
    await vultr_power_action(client, message, "reboot", "merestart")

async def vultr_power_action(client: Client, message: Message, action: str, action_name: str):
    ggl = await EMO.GAGAL(client)
    prs = await EMO.PROSES(client)
    
    if not vultr_config.get("api_key"):
        await message.reply_text(f"{ggl} <b>API key belum diset!</b>")
        return
    
    args = message.text.split(maxsplit=1)
    if len(args) < 2:
        await message.reply_text(f"{ggl} <b>Masukkan ID VPS!</b>")
        return
    
    instance_id = args[1].strip()
    
    processing = await message.reply_text(f"{prs} <b>{action_name.title()} VPS...</b>")
    
    # Vultr pakai POST dengan action tertentu
    data = {}
    _, status = await vultr_request("POST", f"instances/{instance_id}/{action}", data)
    
    if status == 204:
        await processing.edit_text(f"<b>✅ VPS berhasil {action_name}!</b>")
    else:
        await processing.edit_text(f"{ggl} <b>Gagal {action_name} VPS!</b>")

# ============================================
# COMMAND DELETE VPS
# ============================================

@PY.UBOT("vultrdelete")
async def vultr_delete(client: Client, message: Message):
    ggl = await EMO.GAGAL(client)
    prs = await EMO.PROSES(client)
    
    if not vultr_config.get("api_key"):
        await message.reply_text(f"{ggl} <b>API key belum diset!</b>")
        return
    
    args = message.text.split(maxsplit=1)
    if len(args) < 2:
        await message.reply_text(f"{ggl} <b>Masukkan ID VPS!</b>")
        return
    
    instance_id = args[1].strip()
    
    # Konfirmasi
    confirm = await message.reply_text(
        f"⚠️ <b>Yakin hapus VPS {instance_id}?</b>\n"
        f"Ketik <code>ya</code> untuk konfirmasi."
    )
    
    try:
        resp = await client.wait_for_message(
            chat_id=message.chat.id,
            from_user_id=message.from_user.id,
            timeout=10
        )
        
        if resp and resp.text and resp.text.lower() == "ya":
            await confirm.edit_text(f"{prs} <b>Menghapus VPS...</b>")
            
            _, status = await vultr_request("DELETE", f"instances/{instance_id}")
            
            if status == 204:
                await confirm.edit_text(f"<b>✅ VPS dihapus!</b>")
            else:
                await confirm.edit_text(f"{ggl} <b>Gagal menghapus!</b>")
        else:
            await confirm.edit_text("<b>❌ Dibatalkan</b>")
            
    except asyncio.TimeoutError:
        await confirm.edit_text("<b>⏱️ Timeout, dibatalkan</b>")

# ============================================
# COMMAND INFO AKUN
# ============================================

@PY.UBOT("vultraccount")
async def vultr_account(client: Client, message: Message):
    ggl = await EMO.GAGAL(client)
    prs = await EMO.PROSES(client)
    
    if not vultr_config.get("api_key"):
        await message.reply_text(f"{ggl} <b>API key belum diset!</b>")
        return
    
    processing = await message.reply_text(f"{prs} <b>Mengambil info akun...</b>")
    
    # Get account
    acc_data, acc_status = await vultr_request("GET", "account")
    
    # Get instances count
    inst_data, inst_status = await vultr_request("GET", "instances?per_page=1")
    
    if acc_status == 200:
        acc = acc_data.get("account", {})
        email = acc.get("email", "-")
        name = acc.get("name", "-")
        balance = acc.get("balance", "-")
        pending = acc.get("pending_charges", "-")
        
        instance_count = inst_data.get("meta", {}).get("total", 0) if inst_status == 200 else "?"
        
        text = f"""
<blockquote><b>📊 INFO AKUN VULTR</b>

👤 <b>Name:</b> {name}
📧 <b>Email:</b> {email}
💰 <b>Balance:</b> ${balance}
💳 <b>Pending:</b> ${pending}
📦 <b>VPS Aktif:</b> {instance_count}</blockquote>"""
        
        await processing.edit_text(text)
    else:
        await processing.edit_text(f"{ggl} <b>Gagal ambil info akun!</b>")

# ============================================
# COMMAND LIHAT REGIONS
# ============================================

@PY.UBOT("vultrregions")
async def vultr_regions(client: Client, message: Message):
    ggl = await EMO.GAGAL(client)
    prs = await EMO.PROSES(client)
    
    if not vultr_config.get("api_key"):
        await message.reply_text(f"{ggl} <b>API key belum diset!</b>")
        return
    
    processing = await message.reply_text(f"{prs} <b>Mengambil daftar region...</b>")
    
    data, status = await vultr_request("GET", "regions")
    
    if status == 200:
        regions = data.get("regions", [])
        
        text = "<blockquote><b>🌍 REGION VULTR</b>\n\n"
        
        for r in regions[:15]:
            if r.get("available"):
                text += f"• <code>{r.get('id')}</code> - {r.get('city')}, {r.get('country')}\n"
        
        text += "\n<b>Populer:</b> sgp, ewr, fra, lhr, syd</blockquote>"
        
        await processing.edit_text(text)
    else:
        await processing.edit_text(f"{ggl} <b>Gagal ambil region!</b>")

# ============================================
# COMMAND LIHAT PLANS
# ============================================

@PY.UBOT("vultrplans")
async def vultr_plans(client: Client, message: Message):
    text = "<blockquote><b>📊 PLAN VPS VULTR</b>\n\n"
    
    for size, desc in VULTR_SIZE_DESC.items():
        plan_id = VULTR_SIZES[size]
        text += f"• <code>.vultr {size} nama region image</code>\n"
        text += f"  {desc} ({plan_id})\n\n"
    
    text += "<b>Contoh:</b> <code>.vultr 1gb vpsku sgp ubuntu22</code></blockquote>"
    
    await message.reply_text(text)

# ============================================
# COMMAND LIHAT OS IMAGES
# ============================================

@PY.UBOT("vultros")
async def vultr_os(client: Client, message: Message):
    text = "<blockquote><b>🖼️ OS IMAGE VULTR</b>\n\n"
    
    os_list = [
        ("ubuntu22", "Ubuntu 22.04 LTS"),
        ("ubuntu20", "Ubuntu 20.04 LTS"),
        ("debian12", "Debian 12"),
        ("debian11", "Debian 11"),
        ("centos7", "CentOS 7"),
        ("rocky9", "Rocky Linux 9"),
        ("rocky8", "Rocky Linux 8"),
        ("alma9", "AlmaLinux 9"),
        ("alma8", "AlmaLinux 8"),
    ]
    
    for key, name in os_list:
        os_id = VULTR_IMAGES[key]
        text += f"• <code>{key}</code> - {name} (ID: {os_id})\n"
    
    text += "\n<b>Contoh:</b> <code>.vultr 1gb vpsku sgp ubuntu22</code></blockquote>"
    
    await message.reply_text(text)