from fansx import *
import random
import asyncio
import re
from pyrogram.enums import ChatAction
from pyrogram.types import Message

__MODULE__ = "ᴄᴇᴋ ᴊᴏᴅᴏʜ"
__HELP__ = """
<blockquote><b>『 CEK KECOCOKAN JODOH 』</b>

<b>⌲ Perintah:</b>
ᚗ <code>{0}jodoh [nama1] [nama2]</code> 
⊶ Mengecek kecocokan antara dua nama

<b>⌲ Bisa pake pemisah:</b>
• Spasi: <code>.jodoh Budi Ani</code>
• & : <code>.jodoh Budi & Ani</code>
• Koma: <code>.jodoh Budi, Ani</code>

<b>⌲ Contoh:</b>
<code>.jodoh Budi Ani</code>
<code>.jodoh Andi & Siti</code>
<code>.jodoh Rina, Joko</code></blockquote>
"""

def get_description(percent):
    """Mendapatkan deskripsi berdasarkan persentase kecocokan"""
    if percent >= 90:
        return "Jodoh banget! Langsung nikah aja! 💍"
    elif percent >= 70:
        return "Cocok banget! 💕"
    elif percent >= 50:
        return "Lumayan cocok~ 😊"
    elif percent >= 30:
        return "Hmm, perlu usaha lebih 🤔"
    else:
        return "Mungkin cari yang lain? 😅"

def parse_names(input_text):
    """Parse input untuk memisahkan dua nama"""
    # Coba split dengan & atau koma
    if '&' in input_text:
        parts = [p.strip() for p in input_text.split('&')]
    elif ',' in input_text:
        parts = [p.strip() for p in input_text.split(',')]
    else:
        # Split spasi, ambil 2 kata pertama
        words = input_text.split()
        if len(words) >= 2:
            parts = [words[0], words[1]]
        else:
            parts = []
    
    # Filter yang kosong
    return [p for p in parts if p]

@PY.UBOT("jodoh")
async def cek_jodoh(client: Client, message: Message):
    ggl = await EMO.GAGAL(client)
    sks = await EMO.BERHASIL(client)
    prs = await EMO.PROSES(client)
    
    try:
        await client.send_chat_action(message.chat.id, ChatAction.TYPING)
        
        # Ambil input
        args = message.text.split(maxsplit=1)
        if len(args) < 2:
            await message.reply_text(
                f"<blockquote><b>💕 CEK JODOH</b>\n\n"
                f"<b>Masukkan 2 nama!</b>\n\n"
                f"<b>Contoh:</b>\n"
                f"<code>.jodoh Budi Ani</code>\n"
                f"<code>.jodoh Andi & Siti</code>\n"
                f"<code>.jodoh Rina, Joko</code></blockquote>"
            )
            return
        
        input_text = args[1].strip()
        names = parse_names(input_text)
        
        if len(names) < 2:
            await message.reply_text(
                f"{ggl} <b>Masukkan 2 nama! Pisah dengan spasi, &, atau koma.</b>"
            )
            return
        
        nama1 = names[0]
        nama2 = names[1]
        
        # Generate random persentase kecocokan
        percent = random.randint(0, 100)
        desc = get_description(percent)
        
        # Buat progress bar visual dengan emoji hati
        bar_length = 20
        filled_length = int(bar_length * percent / 100)
        bar = '❤️' * filled_length + '💔' * (bar_length - filled_length)
        
        # Kirim pesan processing dulu (biar ada efek)
        processing = await message.reply_text(
            f"{prs} <b>Menghitung kecocokan {nama1} ❤️ {nama2}...</b>"
        )
        
        # Tunggu bentar biar keliatan prosesnya
        await asyncio.sleep(1)
        
        # Format pesan
        txt = f"""
<blockquote><b>💕 CEK KECOCOKAN JODOH</b>

<b>👤 {nama1}</b> ❤️ <b>{nama2}</b>

<b>📊 Tingkat Kecocokan:</b> <code>{percent}%</code>

<code>{bar}</code>

<b>💬 {desc}</b></blockquote>
"""
        
        await processing.edit_text(txt)
        
    except Exception as e:
        await message.reply_text(f"{ggl} <b>Error: {str(e)[:100]}</b>")

@PY.UBOT("cocok")
async def cocok_alias(client: Client, message: Message):
    """Alias untuk jodoh"""
    await cek_jodoh(client, message)

@PY.UBOT("love")
async def love_alias(client: Client, message: Message):
    """Alias untuk jodoh"""
    await cek_jodoh(client, message)

@PY.UBOT("match")
async def match_alias(client: Client, message: Message):
    """Alias untuk jodoh"""
    await cek_jodoh(client, message)

@PY.BOT("jodoh")
async def cek_jodoh_bot(client: Client, message: Message):
    """Handler untuk bot"""
    try:
        args = message.text.split(maxsplit=1)
        if len(args) < 2:
            await message.reply_text(
                "💕 *CEK JODOH*\n\n"
                "Masukkan 2 nama!\n\n"
                "Contoh: /jodoh Budi Ani\n"
                "/jodoh Andi & Siti\n"
                "/jodoh Rina, Joko"
            )
            return
        
        input_text = args[1].strip()
        names = parse_names(input_text)
        
        if len(names) < 2:
            await message.reply_text("❌ Masukkan 2 nama!")
            return
        
        nama1 = names[0]
        nama2 = names[1]
        
        percent = random.randint(0, 100)
        desc = get_description(percent)
        
        bar_length = 15
        filled_length = int(bar_length * percent / 100)
        bar = '❤️' * filled_length + '💔' * (bar_length - filled_length)
        
        txt = f"""
💕 *CEK KECOCOKAN JODOH*

👤 {nama1} ❤️ {nama2}

📊 Kecocokan: {percent}%

{bar}

💬 {desc}
"""
        await message.reply_text(txt)
        
    except Exception as e:
        await message.reply_text(f"❌ Error: {str(e)[:100]}")