from fansx import *
import requests
import aiohttp
import os
from pyrogram.enums import ChatAction, ParseMode
from pyrogram.types import Message

__MODULE__ = "ᴍᴜsɪᴄ ᴘʟᴀʏᴇʀ"
__HELP__ = """
<blockquote><b>『 MUSIC PLAYER 』</b>

<b>⌲ Perintah:</b>
ᚗ <code>{0}music1</code> - <code>{0}music65</code> 
⊶ Memutar musik dari koleksi

<b>⌲ Contoh:</b>
<code>.music1</code>
<code>.music25</code>
<code>.music50</code></blockquote>
"""

# Base URL untuk musik
MUSIC_BASE = "https://raw.githubusercontent.com/Rez4-3yz/Music-rd/master/music"

# Daftar musik dari music1 sampai music65
MUSIC_LIST = [f"music{i}" for i in range(1, 66)]

# Cache untuk menyimpan musik yang sudah di-download (opsional)
music_cache = {}

async def download_music(url):
    """Download musik dari URL"""
    try:
        async with aiohttp.ClientSession() as session:
            async with session.get(url, timeout=30) as response:
                if response.status == 200:
                    return await response.read()
    except Exception as e:
        print(f"Error download music: {e}")
    return None

# Generate handler untuk music1 - music65
for i in range(1, 66):
    music_name = f"music{i}"
    
    # Buat decorator dan fungsi secara dinamis
    exec(f"""
@PY.UBOT("{music_name}")
async def {music_name}_handler(client: Client, message: Message):
    await play_music(client, message, "{music_name}")
    """)

async def play_music(client: Client, message: Message, music_name: str):
    ggl = await EMO.GAGAL(client)
    sks = await EMO.BERHASIL(client)
    prs = await EMO.PROSES(client)
    
    try:
        await client.send_chat_action(message.chat.id, ChatAction.TYPING)
        
        # Cek apakah musik valid
        if music_name not in MUSIC_LIST:
            await message.reply_text(f"{ggl} <b>Musik '{music_name}' tidak ditemukan!</b>")
            return
        
        # URL musik
        music_url = f"{MUSIC_BASE}/{music_name}.mp3"
        
        # Kirim pesan processing
        processing = await message.reply_text(f"{prs} <b>Memutar {music_name}...</b>")
        
        # Download musik
        audio_data = await download_music(music_url)
        
        if audio_data:
            # Simpan sementara
            file_path = f"{music_name}_{message.from_user.id}.mp3"
            with open(file_path, 'wb') as f:
                f.write(audio_data)
            
            await processing.delete()
            
            # Kirim audio sebagai file (bukan voice note)
            await client.send_audio(
                chat_id=message.chat.id,
                audio=file_path,
                caption=f"<blockquote><b>🎵 {music_name}</b></blockquote>"
            )
            
            # Hapus file
            if os.path.exists(file_path):
                os.remove(file_path)
        else:
            await processing.edit_text(f"{ggl} <b>Gagal memuat musik!</b>")
        
    except Exception as e:
        await message.reply_text(f"{ggl} <b>Error: {str(e)[:100]}</b>")

@PY.UBOT("musiclist")
async def music_list(client: Client, message: Message):
    """Menampilkan daftar musik yang tersedia"""
    
    text = "<blockquote><b>📋 DAFTAR MUSIK</b>\n\n"
    
    # Tampilkan dalam beberapa baris (10 per baris)
    rows = [MUSIC_LIST[i:i+10] for i in range(0, len(MUSIC_LIST), 10)]
    for row in rows:
        text += " • " + ", ".join(row) + "\n"
    
    text += f"\n<b>📊 Total:</b> {len(MUSIC_LIST)} musik\n\n"
    text += "<b>💡 Cara pakai:</b>\n"
    text += "• <code>.music1</code>\n"
    text += "• <code>.music25</code>\n"
    text += "• <code>.music50</code></blockquote>"
    
    await message.reply_text(text)

@PY.UBOT("musicrange")
async def music_range(client: Client, message: Message):
    """Menampilkan musik berdasarkan range"""
    args = message.text.split()
    
    if len(args) < 3:
        await message.reply_text(
            f"<blockquote><b>❌ Format salah!</b>\n\n"
            f"<b>Contoh:</b>\n"
            f"<code>.musicrange 1 10</code> (menampilkan music1-music10)</blockquote>"
        )
        return
    
    try:
        start = int(args[1])
        end = int(args[2])
        
        if start < 1 or end > 65 or start > end:
            await message.reply_text(f"{ggl} <b>Range tidak valid! (1-65)</b>")
            return
        
        music_range = [f"music{i}" for i in range(start, end+1)]
        
        text = f"<blockquote><b>📋 MUSIK {start}-{end}</b>\n\n"
        text += " • " + ", ".join(music_range) + "\n\n"
        text += f"<b>📊 Total:</b> {len(music_range)} musik</blockquote>"
        
        await message.reply_text(text)
        
    except ValueError:
        await message.reply_text(f"{ggl} <b>Masukkan angka yang valid!</b>")

@PY.UBOT("musicsearch")
async def music_search(client: Client, message: Message):
    """Mencari musik berdasarkan keyword"""
    args = message.text.split(maxsplit=1)
    
    if len(args) < 2:
        await message.reply_text(
            f"<blockquote><b>❌ Masukkan keyword!</b>\n\n"
            f"<b>Contoh:</b>\n"
            f"<code>.musicsearch music</code></blockquote>"
        )
        return
    
    keyword = args[1].lower()
    
    # Cari musik yang mengandung keyword
    found = [m for m in MUSIC_LIST if keyword in m]
    
    if not found:
        await message.reply_text(f"{ggl} <b>Tidak ada musik dengan keyword '{keyword}'</b>")
        return
    
    text = f"<blockquote><b>📋 HASIL PENCARIAN: {keyword}</b>\n\n"
    text += " • " + ", ".join(found) + "\n\n"
    text += f"<b>📊 Ditemukan:</b> {len(found)} musik</blockquote>"
    
    await message.reply_text(text)

@PY.UBOT("musicrandom")
async def music_random(client: Client, message: Message):
    """Memutar musik secara random"""
    import random
    
    # Pilih musik random
    random_music = random.choice(MUSIC_LIST)
    
    await play_music(client, message, random_music)

@PY.UBOT("musicvo")
async def music_voice(client: Client, message: Message):
    """Memutar musik sebagai voice note"""
    args = message.text.split()
    
    if len(args) < 2:
        await message.reply_text(
            f"<blockquote><b>❌ Masukkan nama musik!</b>\n\n"
            f"<b>Contoh:</b>\n"
            f"<code>.musicvo music1</code></blockquote>"
        )
        return
    
    music_name = args[1]
    
    if music_name not in MUSIC_LIST:
        await message.reply_text(f"{ggl} <b>Musik '{music_name}' tidak ditemukan!</b>")
        return
    
    try:
        await client.send_chat_action(message.chat.id, ChatAction.TYPING)
        
        music_url = f"{MUSIC_BASE}/{music_name}.mp3"
        
        processing = await message.reply_text(f"{prs} <b>Memutar {music_name} sebagai voice...</b>")
        
        async with aiohttp.ClientSession() as session:
            async with session.get(music_url, timeout=30) as response:
                if response.status == 200:
                    audio_data = await response.read()
                    
                    file_path = f"{music_name}_voice_{message.from_user.id}.mp3"
                    with open(file_path, 'wb') as f:
                        f.write(audio_data)
                    
                    await processing.delete()
                    
                    # Kirim sebagai voice note (ptt=true)
                    await client.send_audio(
                        chat_id=message.chat.id,
                        audio=file_path,
                        caption=f"<blockquote><b>🎵 {music_name} (Voice)</b></blockquote>"
                    )
                    
                    if os.path.exists(file_path):
                        os.remove(file_path)
                else:
                    await processing.edit_text(f"{ggl} <b>Gagal memuat musik!</b>")
        
    except Exception as e:
        await message.reply_text(f"{ggl} <b>Error: {str(e)[:100]}</b>")

@PY.BOT("music1")
async def music_bot_handler(client: Client, message: Message):
    """Handler untuk bot"""
    music_name = message.text.split()[0].replace('/', '')
    await play_music_bot(client, message, music_name)

async def play_music_bot(client: Client, message: Message, music_name: str):
    try:
        if music_name not in MUSIC_LIST:
            await message.reply_text(f"❌ Musik '{music_name}' tidak ditemukan!")
            return
        
        music_url = f"{MUSIC_BASE}/{music_name}.mp3"
        
        processing = await message.reply_text(f"🔍 Memutar {music_name}...")
        
        async with aiohttp.ClientSession() as session:
            async with session.get(music_url, timeout=30) as response:
                if response.status == 200:
                    audio_data = await response.read()
                    
                    file_path = f"{music_name}_bot_{message.from_user.id}.mp3"
                    with open(file_path, 'wb') as f:
                        f.write(audio_data)
                    
                    await processing.delete()
                    
                    await client.send_audio(
                        chat_id=message.chat.id,
                        audio=file_path,
                        caption=f"🎵 {music_name}"
                    )
                    
                    if os.path.exists(file_path):
                        os.remove(file_path)
                else:
                    await processing.edit_text("❌ Gagal memuat musik!")
        
    except Exception as e:
        await message.reply_text(f"❌ Error: {str(e)[:100]}")