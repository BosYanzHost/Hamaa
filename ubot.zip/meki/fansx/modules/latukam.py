from fansx import *
import random
import requests
from pyrogram.enums import ChatAction, ParseMode
from pyrogram import filters
from pyrogram.types import Message

__MODULE__ = "ʟᴀᴛᴜᴋᴀᴍ ᴀɪ"
__HELP__ = """
<b>⦪ ʙᴀɴᴛᴜᴀɴ ᴜɴᴛᴜᴋ ʟᴀᴛᴜᴋᴀᴍ ᴀɪ ⦫</b>
<blockquote>⎆ perintah :
ᚗ <code>{0}latukam</code> text
⊶ AI yang rada toxic.
"""

@PY.UBOT("latukam")
@PY.TOP_CMD
async def chat_gpt(client, message):
    try:
        await client.send_chat_action(message.chat.id, ChatAction.TYPING)

        if len(message.command) < 2:
            await message.reply_text(
                "<emoji id=5019523782004441717>❌</emoji>mohon gunakan format\ncontoh : .latukam siapa kamu"
            )
        else:
            prs = await message.reply_text(f"<emoji id=6260400955498435049>🌎</emoji> latukam sedang mikir......")
            a = message.text.split(' ', 1)[1]
            
            # CUMA GANTI API INI DOANG
            response = requests.get(f'https://api.nvidiabotz.xyz/ai/blackbox?text={a}')

            try:
                data = response.json()
                
                # GANTI KEY RESPONSE NYA JUGA
                if data.get("status") and "reply" in data:
                    x = data["reply"]
                    
                    # Hapus bagian <think> kalo ada (biar bersih)
                    if "<think>" in x and "</think>" in x:
                        x = x.split("</think>")[-1].strip()
                    
                    await prs.edit(f"<blockquote>{x}</blockquote>")
                else:
                    await message.reply_text("No 'data' key found in the response.")
            except KeyError:
                await message.reply_text("Error accessing the response.")
    except Exception as e:
        await message.reply_text(f"{e}")