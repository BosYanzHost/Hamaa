import requests
import wget
import os
import random
from pyrogram import Client
from fansx import *

# Daftar API keys By Zyura (12 key)
API_KEYS = [
    "eIxUwMpn",
    "keoCFdc6",
    "bv7m372F",
    "iAiB9QKT",
    "JP7Cy8Y2",
    "GI4vPxYv",
    "HRPga9TN",
    "PDwqhVsj",
    "m8jpBeZR",
    "PXkxh5hw",
    "MFnlpM6A",
    "u299UiOF"
]

def get_random_apikey():
    """Mengambil API key secara random dari daftar"""
    return random.choice(API_KEYS)

__MODULE__ = "ᴘɪɴsᴇᴀʀᴄʜ"
__HELP__ = """
<blockquote><b>『 pinterest 』</b>

  <b>➢ ᴘᴇʀɪɴᴛᴀʜ:</b> <code>{0}pinsearch [kata kunci]</code> 
   <i>penjelasan:</i> mendownload media dari pencarian pinterest

📌 Contoh:
<code>.pinsearch asuna</code>
<code>.pinsearch kucing lucu</code></blockquote>
"""

@PY.UBOT("pinsearch")
async def pin(client, message):
    ggl = await EMO.GAGAL(client)
    sks = await EMO.BERHASIL(client)
    prs = await EMO.PROSES(client)
    
    jalan = await message.reply(f"{prs} Processing...")
    
    if len(message.command) < 2:
        return await jalan.edit(f"{ggl} Contoh: <code>.pinsearch asuna</code>")
    
    # Ambil kata kunci
    a = message.text.split(' ', 1)[1]
    chat_id = message.chat.id
    
    # Ambil API key random
    apikey = get_random_apikey()
    
    # Buat URL dengan API key random
    url = f"https://api.botcahx.eu.org/api/search/pinterest?text1={a}&apikey={apikey}"
    
    try:
        response = requests.get(url, timeout=10)
        
        if response.status_code == 200:
            data = response.json()
            
            # Cek apakah ada hasil
            if data.get('result') and len(data['result']) > 0:
                hasil = data['result']
                random_result = random.choice(hasil)
                
                caption = f"""
<emoji id=5841235769728962577>⭐</emoji> <b>Hasil Pencarian Pinterest</b>
📝 <b>Kata Kunci:</b> {a}
"""
                
                # Download gambar
                try:
                    photo_path = wget.download(random_result)
                    await client.send_photo(chat_id, caption=caption, photo=photo_path)
                    
                    # Hapus file setelah dikirim
                    if os.path.exists(photo_path):
                        os.remove(photo_path)
                    
                    await jalan.delete()
                except Exception as e:
                    await jalan.edit(f"{ggl} Gagal download gambar: {str(e)[:50]}")
            else:
                await jalan.edit(f"{ggl} Tidak ada gambar ditemukan untuk kata kunci '{a}'.")
        else:
            await jalan.edit(f"{ggl} Gagal mengambil data! HTTP {response.status_code}")
    
    except requests.exceptions.Timeout:
        await jalan.edit(f"{ggl} Timeout! Server sedang sibuk.")
    except requests.exceptions.ConnectionError:
        await jalan.edit(f"{ggl} Gagal terhubung ke server!")
    except requests.exceptions.RequestException as e:
        await jalan.edit(f"{ggl} Request failed: {e}")
    except Exception as e:
        await jalan.edit(f"{ggl} An error occurred: {str(e)[:100]}")

@PY.BOT("pinsearch")
async def pin_bot(client, message):
    if len(message.command) < 2:
        await message.reply_text("❌ Contoh: /pinsearch asuna")
        return
    
    a = message.text.split(' ', 1)[1]
    chat_id = message.chat.id
    
    jalan = await message.reply_text("⏳ Processing...")
    
    # Ambil API key random
    apikey = get_random_apikey()
    
    url = f"https://api.botcahx.eu.org/api/search/pinterest?text1={a}&apikey={apikey}"
    
    try:
        response = requests.get(url, timeout=10)
        
        if response.status_code == 200:
            data = response.json()
            
            if data.get('result') and len(data['result']) > 0:
                hasil = data['result']
                random_result = random.choice(hasil)
                
                caption = f"📌 {a}"
                
                photo_path = wget.download(random_result)
                await client.send_photo(chat_id, caption=caption, photo=photo_path)
                
                if os.path.exists(photo_path):
                    os.remove(photo_path)
                
                await jalan.delete()
            else:
                await jalan.edit_text(f"❌ Tidak ada gambar ditemukan untuk '{a}'.")
        else:
            await jalan.edit_text(f"❌ HTTP Error: {response.status_code}")
    
    except Exception as e:
        await jalan.edit_text(f"❌ Error: {str(e)[:100]}")