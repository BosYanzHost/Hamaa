from fansx import *
import requests
import aiohttp
import os
import asyncio
import textwrap
from io import BytesIO
from PIL import Image, ImageDraw, ImageFont, ImageFilter
from pyrogram.enums import ChatAction, ParseMode
from pyrogram.types import Message
import math

__MODULE__ = "ꜰᴀᴋᴇ ꜱᴛᴏʀʏ"
__HELP__ = """
<blockquote><b>『 FAKE INSTAGRAM STORY 』</b>

<b>⌲ Perintah:</b>
ᚗ <code>{0}fakestory username|teks1|teks2</code> 
⊶ Membuat fake Instagram story dengan 3 bagian

<b>⌲ Cara Pakai:</b>
1. Reply gambar dengan format <code>.fakestory nama|teks atas|teks bawah</code>

<b>⌲ Contoh:</b>
<code>.fakestory Misaki|Tersenyumlah|untuk menutupi kesedihan</code>
<code>.fakestory Alucard|Selamat malam|dunia maya</code></blockquote>
"""

# Default avatar (kalo gagal ambil foto profil)
DEFAULT_AVATAR_URL = "https://i.ibb.co/6bWvFpg/avatar.jpg"

# Ikon SVG dalam bentuk path (untuk digambar manual)
ICONS = {
    'heart': [(12, 21.35), (10.55, 20.03), (2, 8.5), (2, 5.42), (4.42, 3), (7.5, 3), 
              (9.24, 3.81), (10.5, 5.09), (11.76, 3.81), (13.5, 3), (16.58, 3), (19, 5.42), 
              (19, 8.5), (15.6, 14.86), (10.45, 19.54), (12, 21.35)],
    'comment': [(21.99, 4), (21.99, 2.9), (20.99, 2), (4, 2), (2.9, 2), (2, 2.9), 
                (2, 4), (2, 16), (2.9, 18), (4, 18), (18, 18), (22, 22), (21.99, 4)],
    'share': [(2.01, 21), (23, 12), (2.01, 3), (2, 10), (17, 12), (2, 14), (2.01, 21)],
    'options': [(12, 6), (13.1, 6), (14, 5.1), (14, 4), (14, 2.9), (13.1, 2), (12, 2), 
                (10.9, 2), (10, 2.9), (10, 4), (10, 5.1), (10.9, 6), (12, 6),
                (12, 14), (13.1, 14), (14, 13.1), (14, 12), (14, 10.9), (13.1, 10), 
                (12, 10), (10.9, 10), (10, 10.9), (10, 12), (10, 13.1), (10.9, 14), (12, 14),
                (12, 22), (13.1, 22), (14, 21.1), (14, 20), (14, 18.9), (13.1, 18), 
                (12, 18), (10.9, 18), (10, 18.9), (10, 20), (10, 21.1), (10.9, 22), (12, 22)]
}

class StoryCanvas:
    def __init__(self, width=720, height=1150):
        self.width = width
        self.height = height
        self.card_bg = '#121212'
        self.text_color = '#ffffff'
        self.corner_radius = 35
        
    def rounded_rectangle(self, draw, xy, radius, fill=None, outline=None):
        """Draw a rounded rectangle"""
        x1, y1, x2, y2 = xy
        draw.rectangle([x1 + radius, y1, x2 - radius, y2], fill=fill, outline=outline)
        draw.rectangle([x1, y1 + radius, x2, y2 - radius], fill=fill, outline=outline)
        draw.pieslice([x1, y1, x1 + radius*2, y1 + radius*2], 180, 270, fill=fill, outline=outline)
        draw.pieslice([x2 - radius*2, y1, x2, y1 + radius*2], 270, 360, fill=fill, outline=outline)
        draw.pieslice([x1, y2 - radius*2, x1 + radius*2, y2], 90, 180, fill=fill, outline=outline)
        draw.pieslice([x2 - radius*2, y2 - radius*2, x2, y2], 0, 90, fill=fill, outline=outline)
    
    def draw_icon(self, draw, icon_name, x, y, size=24, color='white'):
        """Draw simple icon (simplified version)"""
        if icon_name == 'heart':
            # Draw heart as simple shape
            draw.polygon([(x, y-8), (x-6, y-2), (x, y+6), (x+6, y-2)], fill=color)
        elif icon_name == 'comment':
            # Draw comment bubble
            draw.ellipse([x-8, y-8, x+8, y+8], outline=color, width=2)
        elif icon_name == 'share':
            # Draw share arrow
            draw.line([x-8, y-4, x+8, y+4], fill=color, width=2)
            draw.line([x+8, y+4, x+2, y-2], fill=color, width=2)
            draw.line([x+8, y+4, x+2, y+10], fill=color, width=2)
        elif icon_name == 'options':
            # Draw three dots
            draw.ellipse([x-2, y-10, x+2, y-6], fill=color)
            draw.ellipse([x-2, y-2, x+2, y+2], fill=color)
            draw.ellipse([x-2, y+6, x+2, y+10], fill=color)
    
    def wrap_text(self, text, font, max_width, draw):
        """Wrap text to fit max width"""
        words = text.split(' ')
        lines = []
        current_line = []
        
        for word in words:
            test_line = ' '.join(current_line + [word])
            bbox = draw.textbbox((0, 0), test_line, font=font)
            text_width = bbox[2] - bbox[0]
            
            if text_width <= max_width:
                current_line.append(word)
            else:
                if current_line:
                    lines.append(' '.join(current_line))
                current_line = [word]
        
        if current_line:
            lines.append(' '.join(current_line))
        
        return lines
    
    async def create(self, username, avatar_img, top_img, bottom_img, text1, text2):
        """Create the fake story image"""
        
        # Create canvas
        canvas = Image.new('RGB', (self.width, self.height), '#000000')
        draw = ImageDraw.Draw(canvas)
        
        # Load fonts
        try:
            font_small = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf", 18)
            font_bold = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf", 18)
            font_text = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf", 20)
        except:
            font_small = ImageFont.load_default()
            font_bold = ImageFont.load_default()
            font_text = ImageFont.load_default()
        
        # 1. Create blurred background
        # Resize images to cover canvas
        top_img_resized = top_img.resize((self.width, self.height//2), Image.Resampling.LANCZOS)
        bottom_img_resized = bottom_img.resize((self.width, self.height//2), Image.Resampling.LANCZOS)
        
        # Create blurred background
        bg = Image.new('RGB', (self.width, self.height))
        bg.paste(top_img_resized, (0, 0))
        bg.paste(bottom_img_resized, (0, self.height//2))
        bg = bg.filter(ImageFilter.GaussianBlur(radius=20))
        bg = bg.point(lambda p: p * 0.3)  # Darken
        
        canvas.paste(bg, (0, 0))
        
        # 2. Draw main card
        card_x = 25
        card_y = 60
        card_w = self.width - 50
        card_h = self.height - 120
        
        # Draw card background
        draw.rectangle([card_x, card_y, card_x + card_w, card_y + card_h], 
                       fill=self.card_bg, outline=None)
        
        # 3. Draw header with avatar
        header_height = 90
        avatar_size = 45
        avatar_x = card_x + 20
        avatar_y = card_y + 22
        
        # Draw circular avatar
        avatar_img_circular = avatar_img.resize((avatar_size, avatar_size), Image.Resampling.LANCZOS)
        
        # Create circular mask
        mask = Image.new('L', (avatar_size, avatar_size), 0)
        mask_draw = ImageDraw.Draw(mask)
        mask_draw.ellipse((0, 0, avatar_size, avatar_size), fill=255)
        
        # Apply mask
        avatar_output = Image.new('RGBA', (avatar_size, avatar_size), (0, 0, 0, 0))
        avatar_output.paste(avatar_img_circular, (0, 0), mask)
        
        canvas.paste(avatar_output, (avatar_x, avatar_y), avatar_output)
        
        # Draw username
        draw.text((card_x + 80, card_y + 45), username, font=font_bold, fill=self.text_color)
        
        # Draw options icon (three dots)
        self.draw_icon(draw, 'options', card_x + card_w - 40, card_y + 45, color=self.text_color)
        
        # 4. Draw content area
        content_height = card_h - header_height - 70  # - footer height
        image_height = content_height // 2
        
        # Top image
        top_img_resized = top_img.resize((card_w, image_height), Image.Resampling.LANCZOS)
        canvas.paste(top_img_resized, (card_x, card_y + header_height))
        
        # Text on top image
        if text1:
            lines = self.wrap_text(text1, font_text, card_w - 60, draw)
            text_y = card_y + header_height + image_height - 30 - (len(lines) * 24)
            for i, line in enumerate(lines):
                bbox = draw.textbbox((0, 0), line, font=font_text)
                text_width = bbox[2] - bbox[0]
                draw.text((card_x + (card_w - text_width) // 2, text_y + (i * 24)), 
                         line, font=font_text, fill=self.text_color)
        
        # Bottom image
        bottom_img_resized = bottom_img.resize((card_w, image_height), Image.Resampling.LANCZOS)
        canvas.paste(bottom_img_resized, (card_x, card_y + header_height + image_height))
        
        # Text on bottom image
        if text2:
            lines = self.wrap_text(text2, font_text, card_w - 60, draw)
            text_y = card_y + header_height + (image_height * 2) - 30 - (len(lines) * 24)
            for i, line in enumerate(lines):
                bbox = draw.textbbox((0, 0), line, font=font_text)
                text_width = bbox[2] - bbox[0]
                draw.text((card_x + (card_w - text_width) // 2, text_y + (i * 24)), 
                         line, font=font_text, fill=self.text_color)
        
        # 5. Draw footer icons
        icon_y = card_y + card_h - 35
        self.draw_icon(draw, 'heart', card_x + 40, icon_y, color=self.text_color)
        self.draw_icon(draw, 'comment', card_x + 100, icon_y, color=self.text_color)
        self.draw_icon(draw, 'share', card_x + 160, icon_y, color=self.text_color)
        
        # Save to bytes
        img_bytes = BytesIO()
        canvas.save(img_bytes, format='PNG')
        img_bytes.seek(0)
        
        return img_bytes

async def download_image(url):
    """Download image from URL"""
    async with aiohttp.ClientSession() as session:
        async with session.get(url) as resp:
            if resp.status == 200:
                return await resp.read()
    return None

async def get_profile_pic(client, user_id):
    """Get user's profile picture from Telegram"""
    try:
        photos = await client.get_chat_photos(user_id, limit=1)
        if photos and len(photos) > 0:
            file_path = await client.download_media(photos[0].file_id)
            with open(file_path, 'rb') as f:
                img_data = f.read()
            if os.path.exists(file_path):
                os.remove(file_path)
            return img_data
    except Exception as e:
        print(f"Error getting profile pic: {e}")
    
    # Fallback to default avatar
    resp = requests.get(DEFAULT_AVATAR_URL)
    if resp.status_code == 200:
        return resp.content
    return None

@PY.UBOT("fakestory")
async def fake_story(client: Client, message: Message):
    ggl = await EMO.GAGAL(client)
    sks = await EMO.BERHASIL(client)
    prs = await EMO.PROSES(client)
    
    try:
        await client.send_chat_action(message.chat.id, ChatAction.TYPING)
        
        # Parse input
        args = message.text.split(maxsplit=1)
        if len(args) < 2:
            await message.reply_text(
                f"<blockquote><b>📷 FAKE INSTAGRAM STORY</b>\n\n"
                f"<b>Cara pakai:</b>\n"
                f"Reply gambar dengan format:\n"
                f"<code>.fakestory username|teks1|teks2</code>\n\n"
                f"<b>Contoh:</b>\n"
                f"<code>.fakestory Misaki|Tersenyumlah|untuk menutupi kesedihan</code></blockquote>"
            )
            return
        
        input_text = args[1]
        parts = [p.strip() for p in input_text.split('|')]
        
        username = parts[0] if len(parts) > 0 else message.from_user.first_name or "User"
        text1 = parts[1] if len(parts) > 1 else ""
        text2 = parts[2] if len(parts) > 2 else ""
        
        # Cek apakah reply ke gambar
        if not message.reply_to_message or not message.reply_to_message.photo:
            await message.reply_text(
                f"{ggl} <b>Reply ke gambar untuk membuat fake story!</b>"
            )
            return
        
        # Download gambar dari reply
        processing = await message.reply_text(f"{prs} <b>Mendownload gambar...</b>")
        
        file_path = await message.reply_to_message.download()
        with open(file_path, 'rb') as f:
            image_data = f.read()
        
        if os.path.exists(file_path):
            os.remove(file_path)
        
        # Ambil foto profil user
        await processing.edit_text(f"{prs} <b>Mengambil foto profil...</b>")
        avatar_data = await get_profile_pic(client, message.from_user.id)
        
        if not avatar_data:
            await processing.edit_text(f"{ggl} <b>Gagal mengambil foto profil!</b>")
            return
        
        # Load images
        try:
            avatar_img = Image.open(BytesIO(avatar_data)).convert('RGB')
            top_img = Image.open(BytesIO(image_data)).convert('RGB')
            bottom_img = top_img.copy()  # Use same image for both
        except Exception as e:
            await processing.edit_text(f"{ggl} <b>Gagal memproses gambar: {str(e)[:50]}</b>")
            return
        
        # Create story
        await processing.edit_text(f"{prs} <b>Membuat fake story...</b>")
        
        canvas = StoryCanvas()
        result_img = await canvas.create(username, avatar_img, top_img, bottom_img, text1, text2)
        
        # Send result
        await client.send_photo(
            chat_id=message.chat.id,
            photo=result_img,
            caption=f"<blockquote><b>📷 FAKE INSTAGRAM STORY</b>\n\n"
                    f"👤 <b>Username:</b> {username}\n"
                    f"💬 <b>Teks 1:</b> {text1}\n"
                    f"💬 <b>Teks 2:</b> {text2}</blockquote>"
        )
        
        await processing.delete()
        
    except asyncio.TimeoutError:
        await message.reply_text(f"{ggl} <b>Timeout! Server sedang sibuk.</b>")
    except Exception as e:
        await message.reply_text(f"{ggl} <b>Error: {str(e)[:100]}</b>")

@PY.UBOT("fstory")
async def fstory_alias(client: Client, message: Message):
    """Alias untuk fakestory"""
    await fake_story(client, message)

@PY.UBOT("igstory")
async def igstory_alias(client: Client, message: Message):
    """Alias untuk fakestory"""
    await fake_story(client, message)

@PY.BOT("fakestory")
async def fake_story_bot(client: Client, message: Message):
    """Handler untuk bot"""
    try:
        args = message.text.split(maxsplit=1)
        if len(args) < 2:
            await message.reply_text(
                "📷 *FAKE INSTAGRAM STORY*\n\n"
                "Cara pakai:\n"
                "Reply gambar dengan: /fakestory username|teks1|teks2\n\n"
                "Contoh: /fakestory Misaki|Tersenyumlah|untuk menutupi kesedihan"
            )
            return
        
        input_text = args[1]
        parts = [p.strip() for p in input_text.split('|')]
        
        username = parts[0] if len(parts) > 0 else "User"
        text1 = parts[1] if len(parts) > 1 else ""
        text2 = parts[2] if len(parts) > 2 else ""
        
        if not message.reply_to_message or not message.reply_to_message.photo:
            await message.reply_text("❌ Reply ke gambar!")
            return
        
        processing = await message.reply_text("⏳ Memproses...")
        
        # Download gambar
        file_path = await message.reply_to_message.download()
        with open(file_path, 'rb') as f:
            image_data = f.read()
        
        if os.path.exists(file_path):
            os.remove(file_path)
        
        # Ambil avatar
        avatar_data = await get_profile_pic(client, message.from_user.id)
        
        if not avatar_data:
            await processing.edit_text("❌ Gagal ambil foto profil!")
            return
        
        # Load images
        avatar_img = Image.open(BytesIO(avatar_data)).convert('RGB')
        top_img = Image.open(BytesIO(image_data)).convert('RGB')
        bottom_img = top_img.copy()
        
        # Create story
        canvas = StoryCanvas()
        result_img = await canvas.create(username, avatar_img, top_img, bottom_img, text1, text2)
        
        # Send result
        await client.send_photo(
            chat_id=message.chat.id,
            photo=result_img,
            caption=f"📷 *Fake Story*\n👤 {username}"
        )
        
        await processing.delete()
        
    except Exception as e:
        await message.reply_text(f"❌ Error: {str(e)[:100]}")