from fansx import *
import requests
import aiohttp
import asyncio
from pyrogram.enums import ChatAction, ParseMode
from pyrogram.types import Message
from urllib.parse import quote

__MODULE__ = "ᴛʀᴀᴄᴋ ɪᴘ"
__HELP__ = """
<blockquote><b>『 TRACK IP ADDRESS 』</b>

<b>⌲ Perintah:</b>
ᚗ <code>{0}ip [alamat_ip]</code> 
⊶ Melacak lokasi dan informasi dari suatu IP address

<b>⌲ Contoh:</b>
<code>.ip 191.168.2.2</code>
<code>.ip 8.8.8.8</code>
<code>.ip 1.1.1.1</code></blockquote>
"""

# Base URL API
BASE_URL = "https://api-faa.my.id/faa/track-ip"

async def track_ip(ip_address):
    """Melacak IP address menggunakan API Faa"""
    try:
        async with aiohttp.ClientSession() as session:
            params = {"ip": ip_address}
            async with session.get(BASE_URL, params=params, timeout=15) as response:
                if response.status == 200:
                    data = await response.json()
                    return data
                return None
    except Exception as e:
        print(f"Error tracking IP: {e}")
        return None

def validate_ip(ip):
    """Validasi format IP address sederhana"""
    import re
    pattern = r'^(\d{1,3}\.){3}\d{1,3}$'
    return re.match(pattern, ip) is not None

@PY.UBOT("ip")
async def track_ip_command(client: Client, message: Message):
    ggl = await EMO.GAGAL(client)
    sks = await EMO.BERHASIL(client)
    prs = await EMO.PROSES(client)
    
    try:
        await client.send_chat_action(message.chat.id, ChatAction.TYPING)
        
        # Ambil IP dari argumen
        args = message.text.split(maxsplit=1)
        if len(args) < 2:
            await message.reply_text(
                f"<blockquote><b>❌ Masukkan alamat IP!</b>\n\n"
                f"<b>Contoh:</b>\n"
                f"<code>.ip 191.168.2.2</code>\n"
                f"<code>.ip 8.8.8.8</code></blockquote>"
            )
            return
        
        ip_address = args[1].strip()
        
        # Validasi IP sederhana
        if not validate_ip(ip_address):
            await message.reply_text(f"{ggl} <b>Format IP tidak valid!</b>")
            return
        
        # Kirim pesan processing
        processing = await message.reply_text(f"{prs} <b>Melacak IP {ip_address}...</b>")
        
        # Track IP
        data = await track_ip(ip_address)
        
        if data and data.get("status"):
            # Ambil data
            ip = data.get("ip", ip_address)
            negara = data.get("negara", "-")
            kode_negara = data.get("kode_negara", "-")
            bendera = data.get("bendera", "")
            ibu_kota = data.get("ibu_kota", "-")
            kota = data.get("kota", "-")
            isp = data.get("isp", "-")
            organisasi = data.get("organisasi", "-")
            lat = data.get("latitude", "-")
            lon = data.get("longitude", "-")
            maps = data.get("google_maps", "")
            
            # Format caption
            caption = f"""
<blockquote><b>🌍 TRACK IP ADDRESS</b>

<b>📍 IP Address:</b> <code>{ip}</code>
<b>🏳️ Negara:</b> {negara} ({kode_negara})
<b>🏛️ Ibu Kota:</b> {ibu_kota}
<b>🏙️ Kota:</b> {kota}
<b>📡 ISP:</b> {isp}
<b>🏢 Organisasi:</b> {organisasi}
<b>📊 Koordinat:</b> {lat}, {lon}

<b>🗺️ Google Maps:</b> <a href='{maps}'>Lihat Lokasi</a></blockquote>
"""
            
            await processing.delete()
            
            # Kirim dengan bendera kalo ada
            if bendera:
                try:
                    # Download bendera
                    async with aiohttp.ClientSession() as session:
                        async with session.get(bendera, timeout=10) as flag_resp:
                            if flag_resp.status == 200:
                                flag_data = await flag_resp.read()
                                flag_path = f"flag_{kode_negara}.png"
                                with open(flag_path, 'wb') as f:
                                    f.write(flag_data)
                                
                                # Kirim foto dengan caption
                                await client.send_photo(
                                    chat_id=message.chat.id,
                                    photo=flag_path,
                                    caption=caption
                                )
                                
                                # Hapus file
                                import os
                                if os.path.exists(flag_path):
                                    os.remove(flag_path)
                            else:
                                await message.reply_text(caption)
                except Exception as e:
                    print(f"Error sending flag: {e}")
                    await message.reply_text(caption)
            else:
                await message.reply_text(caption)
        else:
            await processing.edit_text(
                f"{ggl} <b>Gagal melacak IP {ip_address}!</b>\n"
                f"Pastikan IP valid dan dapat dijangkau."
            )
        
    except asyncio.TimeoutError:
        await message.reply_text(f"{ggl} <b>Timeout! Server sedang sibuk.</b>")
    except aiohttp.ClientError as e:
        await message.reply_text(f"{ggl} <b>Gagal terhubung ke server: {str(e)[:100]}</b>")
    except Exception as e:
        await message.reply_text(f"{ggl} <b>Error: {str(e)[:100]}</b>")

@PY.UBOT("trackip")
async def trackip_alias(client: Client, message: Message):
    """Alias untuk ip"""
    await track_ip_command(client, message)

@PY.UBOT("iplookup")
async def iplookup_alias(client: Client, message: Message):
    """Alias untuk ip"""
    await track_ip_command(client, message)

@PY.BOT("ip")
async def track_ip_bot(client: Client, message: Message):
    """Handler untuk bot"""
    try:
        args = message.text.split(maxsplit=1)
        if len(args) < 2:
            await message.reply_text(
                "❌ Masukkan alamat IP!\n"
                "Contoh: /ip 191.168.2.2"
            )
            return
        
        ip_address = args[1].strip()
        
        if not validate_ip(ip_address):
            await message.reply_text("❌ Format IP tidak valid!")
            return
        
        processing = await message.reply_text(f"🔍 Melacak IP {ip_address}...")
        
        data = await track_ip(ip_address)
        
        if data and data.get("status"):
            text = f"""
🌍 *TRACK IP ADDRESS*

📍 IP: {data.get('ip', ip_address)}
🏳️ Negara: {data.get('negara', '-')} ({data.get('kode_negara', '-')})
🏙️ Kota: {data.get('kota', '-')}
📡 ISP: {data.get('isp', '-')}
🏢 Organisasi: {data.get('organisasi', '-')}
📊 Koordinat: {data.get('latitude', '-')}, {data.get('longitude', '-')}

🗺️ Google Maps: {data.get('google_maps', '-')}
"""
            await processing.edit_text(text)
        else:
            await processing.edit_text(f"❌ Gagal melacak IP {ip_address}!")
        
    except Exception as e:
        await message.reply_text(f"❌ Error: {str(e)[:100]}")