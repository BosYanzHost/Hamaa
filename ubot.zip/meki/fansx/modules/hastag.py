from fansx import *
import aiohttp
import asyncio
from urllib.parse import quote
from pyrogram.enums import ChatAction, ParseMode
from pyrogram.types import Message

__MODULE__ = "ᴛɪᴋᴛᴏᴋ ʜᴀsʜᴛᴀɢ"
__HELP__ = """
<blockquote><b>📊 TIKTOK HASHTAG ANALYTICS</b>

<b>⌲ Perintah:</b>
ᚗ <code>{0}tthashtag [hashtag]</code> - Analisis hashtag
ᚗ <code>{0}tttrending</code> - Trending hashtag (by views)
ᚗ <code>{0}ttpopular</code> - Most popular hashtag

<b>⌲ Contoh:</b>
<code>.tthashtag Fyp</code>
<code>.tttrending</code>
<code>.ttpopular</code>

<b>⌲ Data diurutkan berdasarkan views terbanyak</b></blockquote>
"""

# ============================================
# KONFIGURASI
# ============================================
API_URL = "https://api.baguss.xyz/api/search/tthashtag"

def parse_number(num_str):
    """Parse string angka (Million/Billion/Trillion) ke float"""
    if not num_str:
        return 0
    
    num_str = str(num_str).replace(",", "").strip()
    
    if "Thousand" in num_str:
        return float(num_str.replace("Thousand", "").strip()) * 1000
    elif "Million" in num_str:
        return float(num_str.replace("Million", "").strip()) * 1000000
    elif "Billion" in num_str:
        return float(num_str.replace("Billion", "").strip()) * 1000000000
    elif "Trillion" in num_str:
        return float(num_str.replace("Trillion", "").strip()) * 1000000000000
    else:
        try:
            return float(num_str)
        except:
            return 0

def format_number(num_str):
    """Format angka dengan satuan"""
    return num_str if num_str else "0"

@PY.UBOT("tthashtag")
async def tiktok_hashtag(client: Client, message: Message):
    ggl = await EMO.GAGAL(client)
    prs = await EMO.PROSES(client)
    
    try:
        await client.send_chat_action(message.chat.id, ChatAction.TYPING)
        
        args = message.text.split(maxsplit=1)
        if len(args) < 2:
            await message.reply_text(
                f"<blockquote><b>❌ Masukkan hashtag!</b>\n\n"
                f"<b>Contoh:</b>\n"
                f"<code>.tthashtag Fyp</code>\n"
                f"<code>.tthashtag viral</code></blockquote>"
            )
            return
        
        query = args[1].strip()
        if not query.startswith('#'):
            search_query = f"#{query}"
        else:
            search_query = query
            query = query[1:]
        
        processing = await message.reply_text(f"{prs} <b>Menganalisis hashtag {search_query}...</b>")
        
        # Request ke API
        encoded_query = quote(query)
        url = f"{API_URL}?q={encoded_query}"
        
        async with aiohttp.ClientSession() as session:
            async with session.get(url, timeout=15) as response:
                if response.status != 200:
                    await processing.edit_text(f"{ggl} <b>Gagal terhubung ke API!</b>")
                    return
                
                data = await response.json()
                
                if not data.get("success") or not data.get("data"):
                    await processing.edit_text(f"{ggl} <b>Hashtag '{search_query}' tidak ditemukan!</b>")
                    return
                
                result = data["data"]
                
                # Ambil data report
                report = result.get("report", {})
                overall_posts = format_number(report.get("overallPosts", "0"))
                overall_views = format_number(report.get("overallViews", "0"))
                views_per_post = format_number(report.get("viewsPerPost", "0"))
                
                # Urutkan trending berdasarkan views
                trending = result.get("trending", [])
                trending_sorted = sorted(trending, 
                                       key=lambda x: parse_number(x.get("views", "0")), 
                                       reverse=True)[:5]
                
                # Urutkan related berdasarkan views per post
                related = result.get("related", [])
                # Hapus duplikat
                seen = set()
                unique_related = []
                for item in related:
                    if item["hashtag"] not in seen:
                        seen.add(item["hashtag"])
                        unique_related.append(item)
                
                related_sorted = sorted(unique_related,
                                      key=lambda x: parse_number(x.get("postViews", "0")),
                                      reverse=True)[:5]
                
                # Most popular (urutkan berdasarkan views dari trending)
                popular_hashtags = result.get("mostPopular", [])
                
                # Format response
                text = f"""
<blockquote><b>📊 TIKTOK HASHTAG ANALYTICS</b>

<b>🏷️ Hashtag:</b> {search_query}

<b>📈 STATISTIK</b>
• 📝 Total Postingan: {overall_posts}
• 👁️ Total Views: {overall_views}
• 📊 Views/Post: {views_per_post}

<b>🔥 TOP 5 TRENDING (BY VIEWS)</b>"""
                
                for i, tag in enumerate(trending_sorted, 1):
                    tag_name = tag.get("hashtag", "")
                    tag_posts = format_number(tag.get("posts", "0"))
                    tag_views = format_number(tag.get("views", "0"))
                    text += f"\n{i}. {tag_name}"
                    text += f"\n   📝 {tag_posts} | 👁️ {tag_views}"
                
                text += f"\n\n<b>🔗 TOP 5 TERKAIT (BY VIEWS/POST)</b>\n"
                
                for i, tag in enumerate(related_sorted, 1):
                    tag_name = tag.get("hashtag", "")
                    tag_posts = format_number(tag.get("posts", "0"))
                    tag_views = format_number(tag.get("postViews", "0"))
                    text += f"\n{i}. {tag_name}"
                    text += f"\n   📝 {tag_posts} | 👁️ {tag_views} per post"
                
                text += f"\n\n<b>⭐ POPULER</b>\n"
                text += ", ".join(popular_hashtags[:8])
                
                text += f"\n\n<i>Cek trending: .tttrending</i></blockquote>"
                
                await processing.delete()
                await message.reply_text(text)
        
    except Exception as e:
        await message.reply_text(f"{ggl} <b>Error: {str(e)[:100]}</b>")

@PY.UBOT("tttrending")
async def tiktok_trending(client: Client, message: Message):
    """Tampilkan trending hashtag diurutkan berdasarkan views"""
    ggl = await EMO.GAGAL(client)
    prs = await EMO.PROSES(client)
    
    try:
        await client.send_chat_action(message.chat.id, ChatAction.TYPING)
        
        processing = await message.reply_text(f"{prs} <b>Mengambil trending hashtag...</b>")
        
        # Request dengan keyword trending
        url = f"{API_URL}?q=trending"
        
        async with aiohttp.ClientSession() as session:
            async with session.get(url, timeout=15) as response:
                if response.status != 200:
                    await processing.edit_text(f"{ggl} <b>Gagal mengambil data trending!</b>")
                    return
                
                data = await response.json()
                
                if not data.get("success") or not data.get("data"):
                    await processing.edit_text(f"{ggl} <b>Data trending tidak ditemukan!</b>")
                    return
                
                result = data["data"]
                
                # Ambil trending hashtags
                trending = result.get("trending", [])
                
                # Urutkan berdasarkan views terbanyak
                trending_sorted = sorted(trending, 
                                       key=lambda x: parse_number(x.get("views", "0")), 
                                       reverse=True)[:10]
                
                # Most popular
                most_popular = result.get("mostPopular", [])[:10]
                
                text = f"""
<blockquote><b>🔥 TRENDING HASHTAG TIKTOK</b>
<b>📊 Diurutkan berdasarkan VIEWS TERBANYAK</b>

<b>📈 TOP 10 TRENDING</b>"""
                
                for i, tag in enumerate(trending_sorted, 1):
                    tag_name = tag.get("hashtag", "")
                    tag_posts = format_number(tag.get("posts", "0"))
                    tag_views = format_number(tag.get("views", "0"))
                    tag_ppv = format_number(tag.get("postViews", "0"))
                    text += f"\n{i}. {tag_name}"
                    text += f"\n   📝 {tag_posts} | 👁️ {tag_views} | 📊 {tag_ppv}/post"
                
                text += f"\n\n<b>⭐ MOST POPULAR</b>\n"
                text += ", ".join(most_popular)
                
                text += f"\n\n<i>Cek detail: .tthashtag [nama]</i></blockquote>"
                
                await processing.delete()
                await message.reply_text(text)
        
    except Exception as e:
        await message.reply_text(f"{ggl} <b>Error: {str(e)[:100]}</b>")

@PY.UBOT("ttpopular")
async def tiktok_popular(client: Client, message: Message):
    """Tampilkan popular hashtags"""
    ggl = await EMO.GAGAL(client)
    
    try:
        # Request dengan keyword trending
        url = f"{API_URL}?q=trending"
        
        async with aiohttp.ClientSession() as session:
            async with session.get(url, timeout=15) as response:
                if response.status != 200:
                    await message.reply_text(f"{ggl} <b>Gagal mengambil data popular!</b>")
                    return
                
                data = await response.json()
                
                if not data.get("success") or not data.get("data"):
                    await message.reply_text(f"{ggl} <b>Data tidak ditemukan!</b>")
                    return
                
                result = data["data"]
                
                # Most popular
                most_popular = result.get("mostPopular", [])
                second_most = result.get("secondMostLiked", [])
                
                text = f"""
<blockquote><b>⭐ POPULAR HASHTAG TIKTOK</b>

<b>🔥 MOST POPULAR:</b>
{', '.join(most_popular[:15])}

<b>❤️ SECOND MOST LIKED:</b>
{', '.join(second_most[:15])}

<i>Cek trending: .tttrending</i></blockquote>"""
                
                await message.reply_text(text)
        
    except Exception as e:
        await message.reply_text(f"{ggl} <b>Error: {str(e)[:100]}</b>")

@PY.UBOT("tiktokinfo")
async def tiktok_info(client: Client, message: Message):
    """Info fitur TikTok analytics"""
    
    text = """
<blockquote><b>📊 INFO TIKTOK HASHTAG ANALYTICS</b>

<b>Sumber:</b> api.baguss.xyz
<b>Update:</b> Real-time

<b>Fitur:</b>
• Analisis hashtag TikTok
• Statistik postingan & views
• Trending hashtag (by views)
• Hashtag terkait
• Most popular hashtags

<b>Cara pakai:</b>
• <code>.tthashtag [nama]</code> - Analisis hashtag
• <code>.tttrending</code> - Trending by views
• <code>.ttpopular</code> - Popular hashtags

<b>Contoh:</b>
<code>.tthashtag fyp</code>
<code>.tttrending</code></blockquote>"""
    
    await message.reply_text(text)