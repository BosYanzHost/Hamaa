from fansx import *
import aiohttp
import asyncio
import random
from urllib.parse import quote
from pyrogram.enums import ChatAction, ParseMode
from pyrogram.types import Message

__MODULE__ = "ʀᴀɴᴅᴏᴍ ᴘᴜɪsɪ"
__HELP__ = """
<blockquote><b>📝 RANDOM PUISI</b>

<b>⌲ Perintah:</b>
ᚗ <code>{0}randompuisi</code> - Buat puisi random
ᚗ <code>{0}puisi</code> - Buat puisi random

<b>⌲ Contoh:</b>
<code>.randompuisi</code>
<code>.puisi</code></blockquote>
"""

# ============================================
# KONFIGURASI
# ============================================
BASE_URL = "https://api.siputzx.my.id/api/ai/duckai"
MODEL = "gpt-4o-mini"

# System prompt khusus untuk puisi
SYSTEM_PROMPT = """Anda adalah seorang penyair terkenal Indonesia yang ahli menciptakan puisi yang indah dan menyentuh hati.
Tugas Anda adalah membuat puisi dengan ciri-ciri:
- Puisi bisa pendek (8-12 baris)
- Gunakan diksi yang indah dan puitis
- Tema bisa tentang cinta, alam, kehidupan, rindu, atau kesedihan (variasi)
- Gunakan gaya bahasa yang artistik
- Bisa berima atau tidak (terserah)

Berikan HANYA puisi saja, tanpa judul, tanpa penjelasan, tanpa kata "Puisi:", langsung teks puisinya."""

async def generate_poem():
    """Generate puisi dari Duck AI"""
    
    # Variasi tema biar gak monoton
    themes = [
        "cinta yang tulus",
        "keindahan alam",
        "makna kehidupan",
        "kerinduan",
        "kesedihan",
        "kebahagiaan",
        "persahabatan",
        "senja",
        "hujan",
        "bintang"
    ]
    theme = random.choice(themes)
    
    variations = [
        f"Buatkan puisi tentang {theme}",
        f"Ciptakan puisi indah tentang {theme}",
        f"Tulis puisi bertema {theme}",
        f"Buat puisi yang menyentuh hati tentang {theme}"
    ]
    user_message = random.choice(variations)
    
    # Encode parameter
    encoded_prompt = quote(SYSTEM_PROMPT)
    encoded_message = quote(user_message)
    
    url = f"{BASE_URL}?message={encoded_message}&model={MODEL}&systemPrompt={encoded_prompt}"
    
    try:
        async with aiohttp.ClientSession() as session:
            async with session.get(url, timeout=30) as response:
                if response.status == 200:
                    data = await response.json()
                    
                    if data.get("status") and data.get("data"):
                        message = data["data"].get("message", "")
                        return {
                            "success": True,
                            "puisi": message.strip(),
                            "tema": theme
                        }
                    else:
                        return {"success": False, "error": "Response tidak valid"}
                else:
                    return {"success": False, "error": f"HTTP {response.status}"}
    except asyncio.TimeoutError:
        return {"success": False, "error": "Timeout"}
    except Exception as e:
        return {"success": False, "error": str(e)}

def bersihkan_puisi(teks):
    """Bersihkan teks puisi dari hal-hal yang tidak perlu"""
    # Hapus kata "Puisi:" di awal
    teks = teks.replace("Puisi:", "").replace("puisi:", "").strip()
    
    # Hapus tanda kutip berlebih
    teks = teks.strip('"\'')
    
    # Hapus judul yang mungkin dibuat AI
    lines = teks.split('\n')
    if len(lines) > 1 and lines[0].isupper():
        # Baris pertama all caps mungkin judul, kita hapus
        lines = lines[1:]
        teks = '\n'.join(lines)
    
    return teks.strip()

# Database puisi cadangan (fallback)
PUISI_CADANGAN = [
    """Dalam hening malam aku berbisik
Menyebut nama yang selalu terkenang
Cinta ini tak pernah pudar meski waktu berlari
Kau tetap bersemayam dalam relung hati terdalam""",
    
    """Hujan rintik di kaca jendela
Mengiringi rindu yang tak bersuara
Kenangan bersamamu begitu indah bagai puisi
Namun kau pergi, entah ke mana lagi""",
    
    """Senja merekah di ufuk barat
Warna jingga melukis langit
Seperti hati yang sedang semangat
Menyambut masa depan yang indah""",
    
    """Daun gugur terbawa angin
Mengiringi langkahku yang sendiri
Meski kau tak lagi di sisi
Kenangan indah tetap abadi""",
    
    """Bintang bertabur di langit malam
Seperti jutaan harapan yang membara
Meski hidup kadang terasa kelam
Esok kan ada sinar mentari yang baru""",
    
    """Aku adalah debu di padang pasir
Kecil, hina, dan tak berdaya
Namun angin membawaku berkelana
Menemukan makna di setiap langkah""",
    
    """Bersamamu aku belajar
Bahwa cinta bukan hanya kata-kata
Tapi juga pengorbanan dan setia
Hingga maut memisahkan kita""",
    
    """Hari ini ku tatap cermin
Melihat diri yang semakin dewasa
Banyak luka yang telah kualami
Tapi juga banyak tawa bahagia"""
]

@PY.UBOT("randompuisi")
@PY.UBOT("puisi")
async def random_poem(client: Client, message: Message):
    ggl = await EMO.GAGAL(client)
    sks = await EMO.BERHASIL(client)
    prs = await EMO.PROSES(client)
    
    try:
        await client.send_chat_action(message.chat.id, ChatAction.TYPING)
        
        processing = await message.reply_text(f"{prs} <b>AI sedang merangkai puisi...</b>")
        
        # Generate puisi
        result = await generate_poem()
        
        await processing.delete()
        
        if result.get("success"):
            puisi = result["puisi"]
            tema = result.get("tema", "random")
            puisi = bersihkan_puisi(puisi)
            
            # Format output
            formatted = f"""
<blockquote><b>📝 PUISI</b>
<i>tema: {tema}</i>

{puisi}

⚡ <b>Powered by:</b> Ubot Premium Zyura</blockquote>"""
            
            await message.reply_text(formatted)
        else:
            # Fallback puisi manual
            puisi = random.choice(PUISI_CADANGAN)
            
            await message.reply_text(
                f"<blockquote><b>📝 PUISI</b>\n\n"
                f"{puisi}\n\n"
                f"⚡ <b>Cadangan</b></blockquote>"
            )
        
    except Exception as e:
        await message.reply_text(f"{ggl} <b>Error: {str(e)[:100]}</b>")

@PY.UBOT("puisicinta")
async def poem_cinta(client: Client, message: Message):
    """Puisi tema cinta khusus"""
    await generate_poem_with_theme(client, message, "cinta")

@PY.UBOT("puisialam")
async def poem_alam(client: Client, message: Message):
    """Puisi tema alam khusus"""
    await generate_poem_with_theme(client, message, "keindahan alam")

@PY.UBOT("puisirindu")
async def poem_rindu(client: Client, message: Message):
    """Puisi tema rindu khusus"""
    await generate_poem_with_theme(client, message, "kerinduan")

async def generate_poem_with_theme(client: Client, message: Message, theme: str):
    ggl = await EMO.GAGAL(client)
    prs = await EMO.PROSES(client)
    
    try:
        await client.send_chat_action(message.chat.id, ChatAction.TYPING)
        
        processing = await message.reply_text(f"{prs} <b>AI menulis puisi tentang {theme}...</b>")
        
        # Custom prompt dengan tema
        custom_prompt = SYSTEM_PROMPT.replace("Tema bisa tentang cinta, alam, kehidupan, rindu, atau kesedihan (variasi)", 
                                             f"Tema harus tentang {theme}")
        
        encoded_prompt = quote(custom_prompt)
        encoded_message = quote(f"Buatkan puisi tentang {theme}")
        
        url = f"{BASE_URL}?message={encoded_message}&model={MODEL}&systemPrompt={encoded_prompt}"
        
        async with aiohttp.ClientSession() as session:
            async with session.get(url, timeout=30) as response:
                if response.status == 200:
                    data = await response.json()
                    
                    if data.get("status") and data.get("data"):
                        puisi = data["data"].get("message", "")
                        puisi = bersihkan_puisi(puisi)
                        
                        await processing.delete()
                        
                        formatted = f"""
<blockquote><b>📝 PUISI</b>
<i>tema: {theme}</i>

{puisi}

⚡ <b>Powered by:</b> Ubot Premium Zyura</blockquote>"""
                        
                        await message.reply_text(formatted)
                    else:
                        await processing.edit_text(f"{ggl} Gagal membuat puisi")
                else:
                    await processing.edit_text(f"{ggl} HTTP Error: {response.status}")
        
    except Exception as e:
        await message.reply_text(f"{ggl} <b>Error: {str(e)[:100]}</b>")
