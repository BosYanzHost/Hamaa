from fansx import *
import random
import requests
from pyrogram.enums import ChatAction, ParseMode
from pyrogram import filters
from pyrogram.types import Message

__MODULE__ = "ᴏᴘᴇɴᴀɪ"
__HELP__ = """
<blockquote><b>Bantuan Untuk AI

perintah : <code>{0}aiku</code> [pertanyaan]
    buat pertanyaan contoh <code>{0}aiku</code> dimana letak Antartika

📌 Contoh:
<code>.aiku bagaimana cara membuat donat?</code>
<code>.aiku apa itu blackbox ai?</code></b></blockquote>
"""

# Base URL API
BASE_URL = "https://api.nvidiabotz.xyz/ai/blackbox"

@PY.UBOT("aiku")
@PY.TOP_CMD
async def chat_gpt(client, message):
    try:
        await client.send_chat_action(message.chat.id, ChatAction.TYPING)

        if len(message.command) < 2:
            await message.reply_text(
                "<emoji id=5019523782004441717>❌</emoji> mohon gunakan format\n"
                "contoh : <code>.aiku bagaimana cara membuat donat?</code>"
            )
            return

        # Kirim pesan processing
        prs = await message.reply_text(
            "<emoji id=6226405134004389590>🔍</emoji> <b>AI sedang berpikir...</b>"
        )
        
        # Ambil pertanyaan
        query = message.text.split(' ', 1)[1]
        
        # Buat request ke API
        params = {
            "text": query
        }
        
        response = requests.get(BASE_URL, params=params, timeout=15)

        try:
            data = response.json()
            
            # Cek status response
            if data.get("status") and "reply" in data:
                reply_text = data["reply"]
                
                # Hapus bagian <think> jika ada (opsional)
                if "<think>" in reply_text and "</think>" in reply_text:
                    # Extract bagian setelah </think>
                    parts = reply_text.split("</think>")
                    if len(parts) > 1:
                        reply_text = parts[1].strip()
                
                # Format pesan
                formatted_reply = f"""
<blockquote><b>🤖 JAWABAN AI</b>

{reply_text}

⚡ <b>Powered by:</b> Zyura AI | Ubot Premium Zyura</blockquote>"""
                
                await prs.edit(formatted_reply)
            else:
                await prs.edit(
                    "<emoji id=5019523782004441717>❌</emoji> <b>Gagal mendapatkan respons dari AI.</b>"
                )
                
        except KeyError:
            await prs.edit(
                "<emoji id=5019523782004441717>❌</emoji> <b>Error accessing the response.</b>"
            )
        except Exception as e:
            await prs.edit(
                f"<emoji id=5019523782004441717>❌</emoji> <b>Error: {str(e)[:100]}</b>"
            )
            
    except requests.exceptions.Timeout:
        await message.reply_text(
            "<emoji id=5019523782004441717>❌</emoji> <b>Timeout! Server sedang sibuk.</b>"
        )
    except requests.exceptions.ConnectionError:
        await message.reply_text(
            "<emoji id=5019523782004441717>❌</emoji> <b>Gagal terhubung ke server!</b>"
        )
    except Exception as e:
        await message.reply_text(
            f"<emoji id=5019523782004441717>❌</emoji> <b>Error: {str(e)[:100]}</b>"
        )

@PY.BOT("aiku")
async def chat_gpt_bot(client, message):
    try:
        await client.send_chat_action(message.chat.id, ChatAction.TYPING)

        if len(message.command) < 2:
            await message.reply_text(
                "❌ Gunakan format: /aiku [pertanyaan]\n"
                "Contoh: /aiku bagaimana cara membuat donat?"
            )
            return

        prs = await message.reply_text("🔍 AI sedang berpikir...")
        query = message.text.split(' ', 1)[1]
        
        params = {
            "text": query
        }
        
        response = requests.get(BASE_URL, params=params, timeout=15)

        try:
            data = response.json()
            
            if data.get("status") and "reply" in data:
                reply_text = data["reply"]
                
                # Hapus bagian <think> jika ada
                if "<think>" in reply_text and "</think>" in reply_text:
                    parts = reply_text.split("</think>")
                    if len(parts) > 1:
                        reply_text = parts[1].strip()
                
                await prs.edit(reply_text)
            else:
                await prs.edit("❌ Gagal mendapatkan respons dari AI.")
                
        except Exception as e:
            await prs.edit(f"❌ Error: {str(e)[:100]}")
            
    except Exception as e:
        await message.reply_text(f"❌ Error: {str(e)[:100]}")