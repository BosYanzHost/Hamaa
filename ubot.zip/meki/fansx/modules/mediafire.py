from pyrogram import Client, filters
import requests
import os
import mimetypes
import random
from fansx import *

# Daftar API keys By Zyura (12 key)
API_KEYS = [
    "eIxUwMpn",
    "keoCFdc6",
    "bv7m372F",
    "iAiB9QKT",
    "JP7Cy8Y2",
    "GI4vPxYv",
    "HRPga9TN",
    "PDwqhVsj",
    "m8jpBeZR",
    "PXkxh5hw",
    "MFnlpM6A",
    "u299UiOF"
]

def get_random_apikey():
    """Mengambil API key secara random dari daftar"""
    return random.choice(API_KEYS)

__MODULE__ = "ᴍᴇᴅɪᴀғɪʀᴇ"
__HELP__ = """
<b>✮ ʙᴀɴᴛᴜᴀɴ ᴜɴᴛᴜᴋ ᴍᴇᴅɪᴀғɪʀᴇ ✮</b>

<blockquote><b>perintah :
<code>{0}mf</code> [link]
Download link mediafire

📌 Contoh:
<code>.mf https://www.mediafire.com/file/xxxxx/file.zip</code></b></blockquote>
"""

@PY.UBOT("mediafire|mf")
async def mediafire_downloader(client, message):
    args = message.text.split(" ", 1)

    if len(args) < 2:
        await message.reply_text(
            "<emoji id=5215204871422093648>❌</emoji> Harap kirimkan URL Mediafire dengan format:\n"
            "<code>.mf https://www.mediafire.com/file/xxxxx/file.zip</code>", 
            quote=True
        )
        return

    mediafire_url = args[1]
    
    # Ambil API key random
    apikey = get_random_apikey()
    
    # Buat URL dengan API key random
    api_url = f"https://api.botcahx.eu.org/api/dowloader/mediafire?url={mediafire_url}&apikey={apikey}"

    # Kirim pesan processing
    processing_msg = await message.reply_text(
        f"<blockquote><b><emoji id=5215204871422093648>⏳</emoji> Memproses link Mediafire...</b>\n🔑 Key: <code>{apikey[:8]}...</code></blockquote>", 
        quote=True
    )

    try:
        response = requests.get(api_url, timeout=15)
        data = response.json()

        if data.get("status") and "result" in data:
            file_info = data["result"]
            filename = file_info.get("filename", "file_mediafire")
            filesize = file_info.get("filesize", "0 MB")
            file_url = file_info.get("url", "")

            if not file_url:
                await processing_msg.edit_text(
                    "<emoji id=5215204871422093648>❌</emoji> URL download tidak ditemukan!", 
                    quote=True
                )
                return

            downloading_msg = await processing_msg.edit_text(
                f"<blockquote><b><emoji id=5215204871422093648>📥</emoji> Mengunduh file...</b>\n"
                f"📂 <b>Nama:</b> {filename}\n"
                f"📦 <b>Ukuran:</b> {filesize}\n"
                f"🔑 <b>Key:</b> <code>{apikey[:8]}...</code></blockquote>", 
                quote=True
            )

            # Download file
            file_path = f"./{filename}"
            file_response = requests.get(file_url, stream=True, timeout=30)

            with open(file_path, "wb") as file:
                for chunk in file_response.iter_content(chunk_size=1024):
                    if chunk:
                        file.write(chunk)

            # Deteksi tipe file
            mime_type, _ = mimetypes.guess_type(file_path)
            
            caption = f"<blockquote><b>✅ File berhasil diunduh!</b>\n📂 <b>Nama:</b> <code>{filename}</code>\n📦 <b>Ukuran:</b> <code>{filesize}</code>\n🔑 <b>Key:</b> <code>{apikey[:8]}...</code></blockquote>"

            # Kirim file sesuai tipe
            if mime_type:
                if mime_type.startswith("image"):
                    await message.reply_photo(file_path, caption=caption, quote=True)
                elif mime_type.startswith("video"):
                    await message.reply_video(file_path, caption=caption, quote=True)
                elif mime_type.startswith("audio"):
                    await message.reply_audio(file_path, caption=caption, quote=True)
                else:
                    await message.reply_document(file_path, caption=caption, quote=True)
            else:
                await message.reply_document(file_path, caption=caption, quote=True)

            # Hapus file setelah dikirim
            if os.path.exists(file_path):
                os.remove(file_path)

            await downloading_msg.delete()
            
        else:
            await processing_msg.edit_text(
                f"<emoji id=5215204871422093648>❌</emoji> Gagal mendapatkan informasi file dari Mediafire.\n🔑 Key: <code>{apikey[:8]}...</code>", 
                quote=True
            )
            
    except requests.exceptions.Timeout:
        await processing_msg.edit_text(
            f"<emoji id=5215204871422093648>❌</emoji> Timeout! Server sedang sibuk.\n🔑 Key: <code>{apikey[:8]}...</code>", 
            quote=True
        )
    except requests.exceptions.ConnectionError:
        await processing_msg.edit_text(
            f"<emoji id=5215204871422093648>❌</emoji> Gagal terhubung ke server!\n🔑 Key: <code>{apikey[:8]}...</code>", 
            quote=True
        )
    except Exception as e:
        await processing_msg.edit_text(
            f"<emoji id=5215204871422093648>❌</emoji> Terjadi kesalahan:\n<code>{str(e)[:100]}</code>\n🔑 Key: <code>{apikey[:8]}...</code>", 
            quote=True
        )

@PY.BOT("mediafire")
async def mediafire_downloader_bot(client, message):
    args = message.text.split(" ", 1)

    if len(args) < 2:
        await message.reply_text(
            "❌ Gunakan: /mediafire [url]\n"
            "Contoh: /mediafire https://www.mediafire.com/file/xxxxx/file.zip"
        )
        return

    mediafire_url = args[1]
    apikey = get_random_apikey()
    
    api_url = f"https://api.botcahx.eu.org/api/dowloader/mediafire?url={mediafire_url}&apikey={apikey}"

    processing_msg = await message.reply_text(f"⏳ Processing... (Key: {apikey[:8]}...)")

    try:
        response = requests.get(api_url, timeout=15)
        data = response.json()

        if data.get("status") and "result" in data:
            file_info = data["result"]
            filename = file_info.get("filename", "file_mediafire")
            filesize = file_info.get("filesize", "0 MB")
            file_url = file_info.get("url", "")

            if not file_url:
                await processing_msg.edit_text("❌ URL download tidak ditemukan!")
                return

            await processing_msg.edit_text(f"📥 Downloading: {filename} ({filesize})")

            file_path = f"./{filename}"
            file_response = requests.get(file_url, stream=True, timeout=30)

            with open(file_path, "wb") as file:
                for chunk in file_response.iter_content(chunk_size=1024):
                    if chunk:
                        file.write(chunk)

            caption = f"✅ {filename}\n📦 {filesize}"

            await message.reply_document(file_path, caption=caption)

            if os.path.exists(file_path):
                os.remove(file_path)

            await processing_msg.delete()
            
        else:
            await processing_msg.edit_text("❌ Gagal mendapatkan informasi file!")
            
    except Exception as e:
        await processing_msg.edit_text(f"❌ Error: {str(e)[:100]}")