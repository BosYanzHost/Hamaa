from fansx import *
import aiohttp
import asyncio
import random
import os
from urllib.parse import quote
from pyrogram.enums import ChatAction
from pyrogram.types import Message

__MODULE__ = "ɢᴏᴏɢʟᴇ ɪᴍᴀɢᴇ"
__HELP__ = """
<blockquote><b>🔍 GOOGLE IMAGE SEARCH</b>

<b>⌲ Perintah:</b>
ᚗ <code>{0}image [kata kunci]</code> - Cari gambar
ᚗ <code>{0}img [kata kunci]</code> - Singkatan

<b>⌲ Contoh:</b>
<code>.image cewek</code>
<code>.img pemandangan</code>
<code>.image kucing lucu</code></blockquote>
"""

# ============================================
# KONFIGURASI
# ============================================
BASE_URL = "https://api-faa.my.id/faa/google-image"

async def search_images(query: str):
    """Mencari gambar dari API"""
    try:
        encoded_query = quote(query)
        url = f"{BASE_URL}?query={encoded_query}"
        
        async with aiohttp.ClientSession() as session:
            async with session.get(url, timeout=15) as response:
                if response.status == 200:
                    data = await response.json()
                    
                    if data.get("status") and data.get("result"):
                        images = data["result"]
                        return {
                            "success": True,
                            "images": images,
                            "total": len(images)
                        }
                    else:
                        return {
                            "success": False,
                            "error": "Response tidak valid"
                        }
                else:
                    return {
                        "success": False,
                        "error": f"HTTP {response.status}"
                    }
    except asyncio.TimeoutError:
        return {"success": False, "error": "Timeout"}
    except Exception as e:
        return {"success": False, "error": str(e)}

@PY.UBOT("image")
@PY.UBOT("img")
async def image_search(client: Client, message: Message):
    ggl = await EMO.GAGAL(client)
    sks = await EMO.BERHASIL(client)
    prs = await EMO.PROSES(client)
    
    try:
        await client.send_chat_action(message.chat.id, ChatAction.TYPING)
        
        # Ambil kata kunci
        args = message.text.split(maxsplit=1)
        if len(args) < 2:
            await message.reply_text(
                f"<blockquote><b>❌ Masukkan kata kunci!</b>\n\n"
                f"<b>Contoh:</b>\n"
                f"<code>.image cewek</code>\n"
                f"<code>.img pemandangan</code></blockquote>"
            )
            return
        
        query = args[1].strip()
        
        # Kirim pesan processing
        processing = await message.reply_text(f"{prs} <b>Mencari gambar untuk: {query}...</b>")
        
        # Cari gambar
        result = await search_images(query)
        
        if result.get("success") and result.get("images"):
            images = result["images"]
            total = result.get("total", len(images))
            
            # Pilih gambar random
            selected = random.choice(images)
            
            await processing.delete()
            
            # Coba kirim gambar
            try:
                await client.send_photo(
                    chat_id=message.chat.id,
                    photo=selected,
                    caption=f"<blockquote><b>🔍 GOOGLE IMAGE</b>\n\n"
                            f"📌 <b>Kata Kunci:</b> {query}\n"
                            f"📊 <b>Total:</b> {total} gambar\n\n"
                            f"⚡ <b>Powered by:</b> Ubot Premium Zyura</blockquote>"
                )
            except Exception as e:
                # Jika gagal kirim gambar, kirim link saja
                await message.reply_text(
                    f"<blockquote><b>🔍 GOOGLE IMAGE</b>\n\n"
                    f"📌 <b>Kata Kunci:</b> {query}\n"
                    f"📊 <b>Total:</b> {total} gambar\n\n"
                    f"🔗 <b>Link Gambar:</b>\n<code>{selected}</code>\n\n"
                    f"⚠️ Gagal mengirim gambar, silakan buka link manual.</blockquote>"
                )
        else:
            error_msg = result.get("error", "Unknown error")
            await processing.edit_text(
                f"<blockquote><b>❌ GAGAL MENCARI GAMBAR</b>\n\n"
                f"Kata Kunci: {query}\n"
                f"Error: {error_msg}</blockquote>"
            )
        
    except Exception as e:
        await message.reply_text(f"{ggl} <b>Error: {str(e)[:100]}</b>")

@PY.UBOT("imagemulti")
async def image_multi(client: Client, message: Message):
    """Cari gambar dan kirim 5 gambar sekaligus"""
    ggl = await EMO.GAGAL(client)
    prs = await EMO.PROSES(client)
    
    try:
        await client.send_chat_action(message.chat.id, ChatAction.UPLOAD_PHOTO)
        
        args = message.text.split(maxsplit=1)
        if len(args) < 2:
            await message.reply_text("❌ Masukkan kata kunci!\nContoh: .imagemulti cewek")
            return
        
        query = args[1].strip()
        
        processing = await message.reply_text(f"{prs} <b>Mencari gambar untuk: {query}...</b>")
        
        result = await search_images(query)
        
        if result.get("success") and result.get("images"):
            images = result["images"]
            
            # Kirim 5 gambar pertama
            sent = 0
            for i, img_url in enumerate(images[:5]):
                try:
                    await client.send_photo(
                        chat_id=message.chat.id,
                        photo=img_url,
                        caption=f"<b>📸 Gambar #{i+1}</b>"
                    )
                    sent += 1
                    await asyncio.sleep(1)  # Delay biar gak flood
                except Exception as e:
                    print(f"Gagal kirim gambar {i+1}: {e}")
            
            await processing.delete()
            
            await message.reply_text(
                f"<blockquote><b>✅ BERHASIL MENGIRIM {sent} GAMBAR</b>\n\n"
                f"📌 Kata Kunci: {query}\n"
                f"📊 Total ditemukan: {len(images)} gambar</blockquote>"
            )
        else:
            await processing.edit_text(f"{ggl} <b>Gagal mencari gambar!</b>")
        
    except Exception as e:
        await message.reply_text(f"{ggl} <b>Error: {str(e)[:100]}</b>")

