from fansx import *
import aiohttp
import asyncio
import random
from urllib.parse import quote
from pyrogram.enums import ChatAction, ParseMode
from pyrogram.types import Message

__MODULE__ = "ʙɪʟɪʙɪʟɪ sᴇᴀʀᴄʜ"
__HELP__ = """
<blockquote><b>📺 BILIBILI SEARCH</b>

<b>⌲ Perintah:</b>
ᚗ <code>{0}bili [kata kunci]</code> - Cari video (ambil yang terpopuler)
ᚗ <code>{0}bilibili [kata kunci]</code> - Alias

<b>⌲ Contoh:</b>
<code>.bili Naruto</code>
<code>.bilibili anime</code></blockquote>
"""

# ============================================
# KONFIGURASI
# ============================================
BASE_URL = "https://api.theresav.biz.id/search/bstation"
API_KEY = "UYGSg"  # API Key dari contoh

async def search_bilibili(query: str):
    """Mencari video di Bilibili"""
    try:
        encoded_query = quote(query)
        url = f"{BASE_URL}?q={encoded_query}&apikey={API_KEY}"
        
        async with aiohttp.ClientSession() as session:
            async with session.get(url, timeout=15) as response:
                if response.status == 200:
                    data = await response.json()
                    
                    if data.get("status") and data.get("result"):
                        return {
                            "success": True,
                            "results": data.get("result", [])
                        }
                    else:
                        return {"success": False, "error": "Tidak ada hasil"}
                else:
                    return {"success": False, "error": f"HTTP {response.status}"}
    except asyncio.TimeoutError:
        return {"success": False, "error": "Timeout"}
    except Exception as e:
        return {"success": False, "error": str(e)}

def parse_views(views_str):
    """Parse views dari string (· 7.1K Ditonton) ke angka"""
    try:
        # Ambil angka dari string
        import re
        numbers = re.findall(r'[\d.]+', views_str)
        if not numbers:
            return 0
        
        num_str = numbers[0]
        
        # Deteksi satuan (K, M)
        if 'K' in views_str:
            return int(float(num_str) * 1000)
        elif 'M' in views_str:
            return int(float(num_str) * 1000000)
        else:
            return int(float(num_str))
    except:
        return 0

def format_views(views_str):
    """Format views untuk ditampilkan"""
    # Hapus titik di depan
    return views_str.replace('·', '').strip()

def format_duration(duration):
    """Format durasi agar lebih rapi"""
    return duration.replace('·', '').strip()

@PY.UBOT("bili")
@PY.UBOT("bilibili")
async def bilibili_search(client: Client, message: Message):
    ggl = await EMO.GAGAL(client)
    sks = await EMO.BERHASIL(client)
    prs = await EMO.PROSES(client)
    
    try:
        await client.send_chat_action(message.chat.id, ChatAction.TYPING)
        
        # Ambil kata kunci
        args = message.text.split(maxsplit=1)
        if len(args) < 2:
            await message.reply_text(
                f"<blockquote><b>❌ Masukkan kata kunci!</b>\n\n"
                f"<b>Contoh:</b>\n"
                f"<code>.bili Naruto</code>\n"
                f"<code>.bilibili anime</code></blockquote>"
            )
            return
        
        query = args[1].strip()
        
        # Kirim pesan processing
        processing = await message.reply_text(f"{prs} <b>Mencari video '{query}' di Bilibili...</b>")
        
        # Cari di Bilibili
        result = await search_bilibili(query)
        
        if not result.get("success") or not result.get("results"):
            await processing.edit_text(
                f"<blockquote><b>❌ TIDAK ADA HASIL</b>\n\n"
                f"Kata Kunci: {query}\n"
                f"Coba kata kunci lain.</blockquote>"
            )
            return
        
        results = result.get("results", [])
        
        # Hitung views untuk setiap video
        for video in results:
            views_str = video.get("views", "0 Ditonton")
            video["views_num"] = parse_views(views_str)
        
        # Urutkan berdasarkan views terbanyak
        sorted_results = sorted(results, key=lambda x: x.get("views_num", 0), reverse=True)
        
        # Ambil yang paling populer
        top_video = sorted_results[0]
        
        title = top_video.get("title", "Tidak ada judul")
        url = top_video.get("url", "")
        thumbnail = top_video.get("thumbnail", "")
        duration = format_duration(top_video.get("duration", "?"))
        uploader = top_video.get("uploader", "Unknown")
        uploader_url = top_video.get("uploaderUrl", "")
        views = format_views(top_video.get("views", "0 Ditonton"))
        views_num = top_video.get("views_num", 0)
        
        await processing.delete()
        
        # Kirim informasi
        caption = f"""
<blockquote><b>📺 BILIBILI VIDEO TERPOPULER</b>

📌 <b>Judul:</b> {title[:200]}{'...' if len(title) > 200 else ''}
👤 <b>Uploader:</b> <a href='{uploader_url}'>{uploader}</a>
⏱️ <b>Durasi:</b> {duration}
👁️ <b>Views:</b> {views}
📊 <b>Peringkat:</b> #1 dari {len(results)} video

🔗 <b>Link:</b> <a href='{url}'>Tonton di Bilibili</a>
⚡ <b>Powered by:</b> Ubot Premium Zyura</blockquote>"""
        
        # Coba kirim thumbnail
        if thumbnail:
            try:
                await client.send_photo(
                    chat_id=message.chat.id,
                    photo=thumbnail,
                    caption=caption
                )
                return
            except:
                pass
        
        # Fallback kirim teks
        await message.reply_text(caption)
        
    except Exception as e:
        await message.reply_text(f"{ggl} <b>Error: {str(e)[:100]}</b>")

@PY.UBOT("bilitop")
async def bilibili_top(client: Client, message: Message):
    """Tampilkan top 5 video Bilibili"""
    ggl = await EMO.GAGAL(client)
    prs = await EMO.PROSES(client)
    
    try:
        args = message.text.split(maxsplit=1)
        query = args[1].strip() if len(args) > 1 else "anime"
        
        processing = await message.reply_text(f"{prs} <b>Mencari top video '{query}'...</b>")
        
        result = await search_bilibili(query)
        
        if not result.get("success") or not result.get("results"):
            await processing.edit_text(f"{ggl} Tidak ada hasil")
            return
        
        results = result.get("results", [])
        
        # Hitung views
        for video in results:
            views_str = video.get("views", "0 Ditonton")
            video["views_num"] = parse_views(views_str)
        
        # Urutkan berdasarkan views
        sorted_results = sorted(results, key=lambda x: x.get("views_num", 0), reverse=True)[:5]
        
        text = f"<blockquote><b>📺 TOP 5 VIDEO BILIBILI</b>\n\n📌 Kata Kunci: {query}\n\n"
        
        for i, video in enumerate(sorted_results, 1):
            title = video.get("title", "")[:50]
            uploader = video.get("uploader", "Unknown")
            views = format_views(video.get("views", "0"))
            text += f"{i}. {title}...\n   👤 {uploader} | 👁️ {views}\n\n"
        
        text += "</blockquote>"
        
        await processing.edit_text(text)
        
    except Exception as e:
        await message.reply_text(f"{ggl} <b>Error: {str(e)[:100]}</b>")

