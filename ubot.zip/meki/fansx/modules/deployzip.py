from fansx import *
import aiohttp
import asyncio
import os
import zipfile
import random
import string
import json
import base64
import shutil
from pathlib import Path
from pyrogram.enums import ChatAction, ParseMode
from pyrogram.types import Message

__MODULE__ = "ᴅᴇᴘʟᴏʏ ᴢɪᴘ"
__HELP__ = """
<blockquote><b>📦 DEPLOY ZIP FILE TO VERCEL</b>

<b>⌲ Perintah:</b>
ᚗ <code>{0}settoken [token]</code> - Set Vercel token
ᚗ <code>{0}deployzip [nama_project]</code> - Reply file ZIP untuk di deploy

<b>⌲ Contoh:</b>
<code>.setverceltoken xxxxxxx</code>
<code>.deployzip mywebsite</code> (reply ke file ZIP)</blockquote>
"""

# ============================================
# KONFIGURASI
# ============================================
VERCEL_CONFIG_FILE = "vercel_configs.json"
MAX_FILE_SIZE = 50 * 1024 * 1024  # 50MB
CHUNK_SIZE = 8192
VERCEL_API = "https://api.vercel.com"

def load_config():
    """Load Vercel config"""
    try:
        if os.path.exists(VERCEL_CONFIG_FILE):
            with open(VERCEL_CONFIG_FILE, 'r') as f:
                return json.load(f)
    except:
        pass
    return {"token": None}

def save_config(config):
    """Save Vercel config"""
    try:
        with open(VERCEL_CONFIG_FILE, 'w') as f:
            json.dump(config, f, indent=4)
        return True
    except:
        return False

config = load_config()

# ============================================
# FUNGSI SETTING TOKEN
# ============================================

@PY.UBOT("settoken")
async def set_vercel_token(client: Client, message: Message):
    ggl = await EMO.GAGAL(client)
    sks = await EMO.BERHASIL(client)
    
    try:
        args = message.text.split(maxsplit=1)
        if len(args) < 2:
            await message.reply_text(
                f"<blockquote><b>❌ Format: .settoken [token]</b>\n\n"
                f"Ambil token di: https://vercel.com/account/tokens</blockquote>"
            )
            return
        
        token = args[1].strip()
        
        # Test token
        async with aiohttp.ClientSession() as session:
            headers = {"Authorization": f"Bearer {token}"}
            async with session.get(f"{VERCEL_API}/v2/user", headers=headers, timeout=10) as resp:
                if resp.status == 200:
                    data = await resp.json()
                    user = data.get("user", {})
                    config["token"] = token
                    save_config(config)
                    
                    await message.reply_text(
                        f"<blockquote><b>✅ TOKEN VALID</b>\n\n"
                        f"👤 Name: {user.get('name', '-')}\n"
                        f"📧 Email: {user.get('email', '-')}\n"
                        f"🔑 Token: <code>{token[:10]}...{token[-5:]}</code></blockquote>"
                    )
                else:
                    await message.reply_text(f"{ggl} Token tidak valid!")
        
    except Exception as e:
        await message.reply_text(f"{ggl} Error: {str(e)[:100]}")

# ============================================
# FUNGSI DEPLOY ZIP
# ============================================

async def read_zip_file(file_path):
    """Baca file ZIP dan return dictionary {filename: content} dalam base64"""
    files = {}
    total_size = 0
    
    try:
        with zipfile.ZipFile(file_path, 'r') as zip_ref:
            # Extract ke temporary folder
            extract_dir = f"temp_{random.randint(1000,9999)}"
            zip_ref.extractall(extract_dir)
            
            # Baca semua file
            for root, dirs, filenames in os.walk(extract_dir):
                for filename in filenames:
                    full_path = os.path.join(root, filename)
                    rel_path = os.path.relpath(full_path, extract_dir)
                    
                    # Hitung total size
                    file_size = os.path.getsize(full_path)
                    total_size += file_size
                    
                    # Skip file terlalu besar (>1MB per file)
                    if file_size > 1024 * 1024:
                        print(f"Skip {rel_path} - terlalu besar ({file_size} bytes)")
                        continue
                    
                    # Baca file sebagai base64
                    with open(full_path, 'rb') as f:
                        content = f.read()
                        content_b64 = base64.b64encode(content).decode('utf-8')
                        files[rel_path] = content_b64
            
            # Bersihkan temporary folder
            shutil.rmtree(extract_dir)
        
        return {
            "success": True,
            "files": files,
            "total_files": len(files),
            "total_size": total_size
        }
    except zipfile.BadZipFile:
        return {"success": False, "error": "File ZIP rusak atau tidak valid"}
    except Exception as e:
        return {"success": False, "error": str(e)}

async def deploy_to_vercel(token, project_name, files_dict):
    """Deploy files ke Vercel"""
    
    headers = {
        "Authorization": f"Bearer {token}",
        "Content-Type": "application/json"
    }
    
    async with aiohttp.ClientSession() as session:
        # 1. Cek apakah project sudah ada
        async with session.get(f"{VERCEL_API}/v9/projects/{project_name}", 
                              headers=headers) as resp:
            if resp.status == 404:
                # Buat project baru
                project_data = {
                    "name": project_name,
                    "framework": None
                }
                async with session.post(f"{VERCEL_API}/v9/projects",
                                       headers=headers,
                                       json=project_data) as create_resp:
                    if create_resp.status not in [200, 201]:
                        text = await create_resp.text()
                        return {"success": False, "error": f"Gagal buat project: {create_resp.status}"}
        
        # 2. Siapkan files untuk deployment
        files_list = []
        for file_path, content_b64 in files_dict.items():
            files_list.append({
                "file": file_path,
                "data": content_b64,
                "encoding": "base64"
            })
        
        # 3. Buat deployment
        deploy_data = {
            "name": project_name,
            "files": files_list,
            "projectSettings": {
                "framework": None,
                "buildCommand": None,
                "outputDirectory": None,
                "installCommand": None,
                "devCommand": None
            }
        }
        
        async with session.post(f"{VERCEL_API}/v13/deployments",
                               headers=headers,
                               json=deploy_data) as resp:
            if resp.status in [200, 201]:
                data = await resp.json()
                deployment_url = data.get('url', f"{project_name}.vercel.app")
                return {
                    "success": True,
                    "url": f"https://{deployment_url}",
                    "deployment_id": data.get('id'),
                    "deployment_url": deployment_url
                }
            else:
                text = await resp.text()
                try:
                    error_data = await resp.json()
                    error_msg = error_data.get('error', {}).get('message', text)
                except:
                    error_msg = text
                return {"success": False, "error": error_msg[:200]}

def format_size(size_bytes):
    """Format ukuran file"""
    for unit in ['B', 'KB', 'MB', 'GB']:
        if size_bytes < 1024.0:
            return f"{size_bytes:.1f} {unit}"
        size_bytes /= 1024.0
    return f"{size_bytes:.1f} GB"

@PY.UBOT("deployzip")
async def deploy_zip_file(client: Client, message: Message):
    ggl = await EMO.GAGAL(client)
    sks = await EMO.BERHASIL(client)
    prs = await EMO.PROSES(client)
    
    try:
        await client.send_chat_action(message.chat.id, ChatAction.TYPING)
        
        # Cek token
        token = config.get("token")
        if not token:
            await message.reply_text(
                f"<blockquote><b>❌ Token belum diset!</b>\n\n"
                f"Gunakan <code>.settoken [token]</code> dulu.</blockquote>"
            )
            return
        
        # Ambil nama project
        args = message.text.split(maxsplit=1)
        if len(args) < 2:
            await message.reply_text(
                f"<blockquote><b>❌ Masukkan nama project!</b>\n\n"
                f"<b>Contoh:</b>\n"
                f"<code>.deployzip mywebsite</code> (reply ke file ZIP)</blockquote>"
            )
            return
        
        project_name = args[1].strip().lower().replace(' ', '-')
        
        # Validasi nama project
        if not project_name.replace('-', '').isalnum():
            await message.reply_text(f"{ggl} Nama project hanya boleh huruf, angka, dan strip!")
            return
        
        # Cek apakah reply ke file
        if not message.reply_to_message or not message.reply_to_message.document:
            await message.reply_text(
                f"<blockquote><b>❌ Reply ke file ZIP!</b>\n\n"
                f"<b>Contoh:</b>\n"
                f"<code>.deployzip mywebsite</code> (reply ke file ZIP)</blockquote>"
            )
            return
        
        doc = message.reply_to_message.document
        
        # Cek apakah file ZIP
        if not doc.file_name.lower().endswith('.zip'):
            await message.reply_text(f"{ggl} File harus berekstensi .zip!")
            return
        
        # Cek ukuran file
        if doc.file_size > MAX_FILE_SIZE:
            await message.reply_text(f"{ggl} File terlalu besar! Maksimal 50MB.")
            return
        
        # Download file
        processing = await message.reply_text(f"{prs} Mendownload file ZIP...")
        
        file_path = await message.reply_to_message.download()
        
        # Baca isi ZIP
        await processing.edit_text(f"{prs} Membaca file ZIP...")
        
        zip_result = await read_zip_file(file_path)
        
        # Hapus file ZIP
        if os.path.exists(file_path):
            os.remove(file_path)
        
        if not zip_result.get("success"):
            await processing.edit_text(f"{ggl} {zip_result.get('error', 'Gagal baca ZIP')}")
            return
        
        files = zip_result["files"]
        total_files = zip_result["total_files"]
        total_size = zip_result["total_size"]
        
        if total_files == 0:
            await processing.edit_text(f"{ggl} File ZIP kosong atau semua file terlalu besar!")
            return
        
        await processing.edit_text(
            f"{prs} Mendeploy ke Vercel...\n"
            f"📦 {total_files} files | {format_size(total_size)}"
        )
        
        # Deploy ke Vercel
        deploy_result = await deploy_to_vercel(token, project_name, files)
        
        if deploy_result.get("success"):
            url = deploy_result["url"]
            
            await processing.delete()
            
            await message.reply_text(
                f"<blockquote><b>✅ DEPLOY BERHASIL!</b>\n\n"
                f"📦 <b>Project:</b> {project_name}\n"
                f"📊 <b>Files:</b> {total_files}\n"
                f"💾 <b>Size:</b> {format_size(total_size)}\n"
                f"🔗 <b>URL:</b> <a href='{url}'>{url}</a>\n\n"
                f"⚡ <b>Powered by:</b> Ubot Premium Zyura</blockquote>"
            )
        else:
            await processing.edit_text(
                f"<blockquote><b>❌ DEPLOY GAGAL</b>\n\n"
                f"Error: {deploy_result.get('error')}</blockquote>"
            )
        
    except Exception as e:
        await message.reply_text(f"{ggl} Error: {str(e)[:100]}")

