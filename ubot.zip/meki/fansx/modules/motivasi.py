from fansx import *
import aiohttp
import asyncio
import random
from urllib.parse import quote
from pyrogram.enums import ChatAction, ParseMode
from pyrogram.types import Message

__MODULE__ = "ᴋᴀᴛᴀ ᴍᴏᴛɪᴠᴀsɪ"
__HELP__ = """
<blockquote><b>💪 KATA KATA MOTIVASI</b>

<b>⌲ Perintah:</b>
ᚗ <code>{0}motivasi</code> - Kata motivasi random
ᚗ <code>{0}quotes</code> - Quotes motivasi random

<b>⌲ Contoh:</b>
<code>.motivasi</code>
<code>.quotes</code></blockquote>
"""

# ============================================
# KONFIGURASI
# ============================================
BASE_URL = "https://api.siputzx.my.id/api/ai/duckai"
MODEL = "gpt-4o-mini"

# System prompt khusus untuk kata motivasi
SYSTEM_PROMPT = """Anda adalah seorang motivator terkenal yang ahli memberikan kata-kata bijak dan inspiratif.
Tugas Anda adalah membuat quotes motivasi singkat (1-2 kalimat) yang menyentuh hati dan membangkitkan semangat.
Quotes harus orisinal, tidak klise, dan bisa:
- Memotivasi untuk meraih mimpi
- Menguatkan saat gagal
- Mengingatkan tentang potensi diri
- Memberi semangat di pagi hari
- Menenangkan di saat sedih

Berikan HANYA quotesnya saja, tanpa tanda kutip, tanpa penjelasan, tanpa nama penulis."""

# Database quotes cadangan (fallback)
QUOTES_CADANGAN = [
    "Kegagalan adalah guru terbaik, selama kamu mau belajar darinya.",
    "Mimpi tidak akan menjadi kenyataan jika kamu hanya diam dan berpangku tangan.",
    "Setiap langkah kecil yang kamu ambil hari ini adalah fondasi untuk kesuksesan esok.",
    "Jangan takut melangkah lambat, yang penting jangan pernah berhenti.",
    "Kamu lebih kuat dari yang kamu kira, lebih berani dari yang kamu bayangkan.",
    "Hari ini adalah kesempatan baru untuk menjadi versi terbaik dirimu.",
    "Rintangan bukan untuk menghalangi, tapi untuk menguji seberapa besar keinginanmu.",
    "Sukses bukan tentang seberapa cepat kamu sampai, tapi tentang seberapa banyak kamu belajar selama perjalanan.",
    "Jangan bandingkan dirimu dengan orang lain, karena setiap orang punya waktunya masing-masing.",
    "Percayalah pada proses, meskipun terkadang terasa lambat.",
    "Kesuksesan dimulai dari keyakinan bahwa kamu bisa melakukannya.",
    "Jangan pernah menyerah, karena di ujung perjuangan selalu ada hasil yang manis.",
    "Hidup ini seperti sepeda, harus terus bergerak agar tidak jatuh.",
    "Apa yang kamu tanam hari ini, akan kamu tuai di masa depan.",
    "Keberanian bukan tentang tidak takut, tapi tentang melangkah meskipun takut."
]

async def generate_motivation():
    """Generate kata motivasi dari Duck AI"""
    
    # Variasi tema biar gak monoton
    themes = [
        "semangat pagi",
        "keberhasilan",
        "kegagalan",
        "mimpi",
        "perjuangan",
        "kesabaran",
        "percaya diri",
        "masa depan"
    ]
    theme = random.choice(themes)
    
    variations = [
        f"Buatkan quotes motivasi tentang {theme}",
        f"Kata bijak tentang {theme} yang inspiratif",
        f"Quotes motivasi singkat tentang {theme}",
        f"Kata motivasi yang membangkitkan semangat tentang {theme}"
    ]
    user_message = random.choice(variations)
    
    # Encode parameter
    encoded_prompt = quote(SYSTEM_PROMPT)
    encoded_message = quote(user_message)
    
    url = f"{BASE_URL}?message={encoded_message}&model={MODEL}&systemPrompt={encoded_prompt}"
    
    try:
        async with aiohttp.ClientSession() as session:
            async with session.get(url, timeout=30) as response:
                if response.status == 200:
                    data = await response.json()
                    
                    if data.get("status") and data.get("data"):
                        message = data["data"].get("message", "")
                        return {
                            "success": True,
                            "quote": message.strip(),
                            "theme": theme
                        }
                    else:
                        return {"success": False, "error": "Response tidak valid"}
                else:
                    return {"success": False, "error": f"HTTP {response.status}"}
    except asyncio.TimeoutError:
        return {"success": False, "error": "Timeout"}
    except Exception as e:
        return {"success": False, "error": str(e)}

def bersihkan_quote(teks):
    """Bersihkan teks quote dari hal-hal yang tidak perlu"""
    # Hapus tanda kutip di awal/akhir
    teks = teks.strip('"\'')
    
    # Hapus kata "Quote:" atau "Motivasi:" di awal
    teks = teks.replace("Quote:", "").replace("quote:", "").replace("Motivasi:", "").replace("motivasi:", "").strip()
    
    # Hapus nama penulis yang mungkin ditambahkan AI
    if " - " in teks:
        teks = teks.split(" - ")[0].strip()
    
    return teks

@PY.UBOT("motivasi")
@PY.UBOT("quotes")
async def random_motivation(client: Client, message: Message):
    ggl = await EMO.GAGAL(client)
    sks = await EMO.BERHASIL(client)
    prs = await EMO.PROSES(client)
    
    try:
        await client.send_chat_action(message.chat.id, ChatAction.TYPING)
        
        processing = await message.reply_text(f"{prs} <b>Mencari kata motivasi...</b>")
        
        # Generate quote
        result = await generate_motivation()
        
        await processing.delete()
        
        if result.get("success"):
            quote = result["quote"]
            theme = result.get("theme", "motivasi")
            quote = bersihkan_quote(quote)
            
            # Format output
            formatted = f"""
<blockquote><b>💪 KATA MOTIVASI</b>
<i>✨ {theme}</i>

“{quote}”

⚡ <b>Powered by:</b> Ubot Premium Zyura</blockquote>"""
            
            await message.reply_text(formatted)
        else:
            # Fallback ke quotes cadangan
            quote = random.choice(QUOTES_CADANGAN)
            
            formatted = f"""
<blockquote><b>💪 KATA MOTIVASI</b>

“{quote}”

⚡ <b>Powered by:</b> Ubot Premium Zyura</blockquote>"""
            
            await message.reply_text(formatted)
        
    except Exception as e:
        await message.reply_text(f"{ggl} <b>Error: {str(e)[:100]}</b>")

@PY.UBOT("motivasipagi")
async def motivasi_pagi(client: Client, message: Message):
    """Kata motivasi khusus pagi hari"""
    await generate_motivation_with_theme(client, message, "semangat pagi")

@PY.UBOT("motivasimalam")
async def motivasi_malam(client: Client, message: Message):
    """Kata motivasi khusus malam hari"""
    await generate_motivation_with_theme(client, message, "ketenangan malam")

@PY.UBOT("motivasigagal")
async def motivasi_gagal(client: Client, message: Message):
    """Kata motivasi untuk yang sedang gagal"""
    await generate_motivation_with_theme(client, message, "bangkit dari kegagalan")

async def generate_motivation_with_theme(client: Client, message: Message, theme: str):
    ggl = await EMO.GAGAL(client)
    prs = await EMO.PROSES(client)
    
    try:
        await client.send_chat_action(message.chat.id, ChatAction.TYPING)
        
        processing = await message.reply_text(f"{prs} <b>Mencari motivasi tentang {theme}...</b>")
        
        # Custom prompt dengan tema
        custom_prompt = SYSTEM_PROMPT
        user_message = f"Buatkan quotes motivasi tentang {theme}"
        
        encoded_prompt = quote(custom_prompt)
        encoded_message = quote(user_message)
        
        url = f"{BASE_URL}?message={encoded_message}&model={MODEL}&systemPrompt={encoded_prompt}"
        
        async with aiohttp.ClientSession() as session:
            async with session.get(url, timeout=30) as response:
                if response.status == 200:
                    data = await response.json()
                    
                    if data.get("status") and data.get("data"):
                        quote = data["data"].get("message", "")
                        quote = bersihkan_quote(quote)
                        
                        await processing.delete()
                        
                        formatted = f"""
<blockquote><b>💪 KATA MOTIVASI</b>
<i>✨ {theme}</i>

“{quote}”

⚡ <b>Powered by:</b> Ubot Premium Zyura</blockquote>"""
                        
                        await message.reply_text(formatted)
                    else:
                        await processing.edit_text(f"{ggl} Gagal membuat motivasi")
                else:
                    await processing.edit_text(f"{ggl} HTTP Error: {response.status}")
        
    except Exception as e:
        await message.reply_text(f"{ggl} <b>Error: {str(e)[:100]}</b>")
