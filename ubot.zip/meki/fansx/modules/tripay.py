from fansx import *
import aiohttp
import asyncio
import hashlib
import hmac
import json
import os
import random
import string
from datetime import datetime, timedelta
from urllib.parse import urlencode
from pyrogram.enums import ChatAction, ParseMode
from pyrogram.types import Message

__MODULE__ = "ᴛʀɪᴘᴀʏ ǫʀɪs"
__HELP__ = """
<blockquote><b>💳 QRIS PAYMENT (TRIPAY)</b>

<b>⌲ Perintah:</b>
ᚗ <code>{0}settripay [api_key] [private_key] [merchant_code]</code> - Set konfigurasi Tripay
ᚗ <code>{0}qrispay  [jumlah] [deskripsi]</code> - Buat pembayaran QRIS
ᚗ <code>{0}cektripay [ref]</code> - Cek status pembayaran

<b>⌲ Contoh:</b>
<code>.settripay DEPOSIT... xxxxxxx T1234</code>
<code>.qrispay  50000 Beli VPS</code>
<code>.cektripay INV12345</code></blockquote>
"""

# ============================================
# KONFIGURASI
# ============================================
TRIPAY_CONFIG_FILE = "tripay_config.json"
TRIPAY_API = "https://tripay.co.id/api"

def load_config():
    """Load Tripay config"""
    try:
        if os.path.exists(TRIPAY_CONFIG_FILE):
            with open(TRIPAY_CONFIG_FILE, 'r') as f:
                return json.load(f)
    except:
        pass
    return {"api_key": None, "private_key": None, "merchant_code": None}

def save_config(config):
    """Save Tripay config"""
    try:
        with open(TRIPAY_CONFIG_FILE, 'w') as f:
            json.dump(config, f, indent=4)
        return True
    except:
        return False

config = load_config()

# Database sementara transaksi
transactions = {}

def generate_merchant_ref():
    """Generate merchant reference"""
    timestamp = datetime.now().strftime("%Y%m%d%H%M%S")
    random_str = ''.join(random.choices(string.ascii_uppercase + string.digits, k=6))
    return f"INV{timestamp}{random_str}"

async def create_invoice(amount, description, user_id, username):
    """Buat invoice Tripay"""
    
    if not config.get("api_key"):
        return {"success": False, "error": "API Key belum diset"}
    
    merchant_ref = generate_merchant_ref()
    
    data = {
        "method": "QRIS",
        "merchant_ref": merchant_ref,
        "amount": amount,
        "customer_name": username or f"User{user_id}",
        "customer_email": f"{user_id}@telegram.user",
        "customer_phone": "081234567890",
        "order_items": [
            {
                "name": description,
                "price": amount,
                "quantity": 1
            }
        ],
        "return_url": "https://t.me/MyUbotpremium_bot",
        "expired_time": int((datetime.now() + timedelta(hours=24)).timestamp())
    }
    
    headers = {
        "Authorization": f"Bearer {config['api_key']}",
        "Content-Type": "application/json"
    }
    
    try:
        async with aiohttp.ClientSession() as session:
            async with session.post(f"{TRIPAY_API}/transaction/create", 
                                   headers=headers, 
                                   json=data,
                                   timeout=30) as resp:
                if resp.status == 200:
                    result = await resp.json()
                    
                    if result.get("success"):
                        transaction = result.get("data", {})
                        
                        # Simpan transaksi
                        transactions[merchant_ref] = {
                            "ref": merchant_ref,
                            "amount": amount,
                            "description": description,
                            "user_id": user_id,
                            "username": username,
                            "status": "PENDING",
                            "qr_url": transaction.get("qr_url"),
                            "qr_string": transaction.get("qr_string"),
                            "created_at": datetime.now().isoformat(),
                            "expired_at": transaction.get("expired_at")
                        }
                        
                        return {
                            "success": True,
                            "merchant_ref": merchant_ref,
                            "qr_url": transaction.get("qr_url"),
                            "qr_string": transaction.get("qr_string"),
                            "amount": amount,
                            "expired_at": transaction.get("expired_at")
                        }
                    else:
                        return {"success": False, "error": result.get("message", "Unknown error")}
                else:
                    error_text = await resp.text()
                    return {"success": False, "error": f"HTTP {resp.status}: {error_text[:100]}"}
    except asyncio.TimeoutError:
        return {"success": False, "error": "Timeout"}
    except Exception as e:
        return {"success": False, "error": str(e)}

async def check_transaction(merchant_ref):
    """Cek status transaksi"""
    
    if not config.get("api_key"):
        return {"success": False, "error": "API Key belum diset"}
    
    headers = {
        "Authorization": f"Bearer {config['api_key']}"
    }
    
    params = {
        "reference": merchant_ref
    }
    
    try:
        async with aiohttp.ClientSession() as session:
            url = f"{TRIPAY_API}/transaction/detail?{urlencode(params)}"
            async with session.get(url, headers=headers, timeout=30) as resp:
                if resp.status == 200:
                    result = await resp.json()
                    
                    if result.get("success"):
                        transaction = result.get("data", {})
                        
                        # Update status di database lokal
                        if merchant_ref in transactions:
                            transactions[merchant_ref]["status"] = transaction.get("status", "UNKNOWN")
                        
                        return {
                            "success": True,
                            "reference": merchant_ref,
                            "status": transaction.get("status"),
                            "amount": transaction.get("amount"),
                            "paid_at": transaction.get("paid_at")
                        }
                    else:
                        return {"success": False, "error": result.get("message", "Unknown error")}
                else:
                    return {"success": False, "error": f"HTTP {resp.status}"}
    except Exception as e:
        return {"success": False, "error": str(e)}

# ============================================
# COMMAND SETTING
# ============================================

@PY.UBOT("settripay")
async def set_tripay_config(client: Client, message: Message):
    ggl = await EMO.GAGAL(client)
    sks = await EMO.BERHASIL(client)
    
    try:
        args = message.text.split()
        if len(args) < 4:
            await message.reply_text(
                f"<blockquote><b>❌ Format: .settripay [api_key] [private_key] [merchant_code]</b>\n\n"
                f"Dapatkan API Key di dashboard Tripay</blockquote>"
            )
            return
        
        api_key = args[1]
        private_key = args[2]
        merchant_code = args[3]
        
        config["api_key"] = api_key
        config["private_key"] = private_key
        config["merchant_code"] = merchant_code
        save_config(config)
        
        await message.reply_text(
            f"<blockquote><b>✅ TRIPAY CONFIG SAVED</b>\n\n"
            f"🔑 API Key: <code>{api_key[:10]}...{api_key[-5:]}</code>\n"
            f"🔏 Private Key: <code>{private_key[:10]}...{private_key[-5:]}</code>\n"
            f"🏢 Merchant Code: {merchant_code}</blockquote>"
        )
        
    except Exception as e:
        await message.reply_text(f"{ggl} Error: {str(e)[:100]}")

# ============================================
# COMMAND QRIS
# ============================================

@PY.UBOT("qrispay")
async def create_qris_payment(client: Client, message: Message):
    ggl = await EMO.GAGAL(client)
    sks = await EMO.BERHASIL(client)
    prs = await EMO.PROSES(client)
    
    try:
        await client.send_chat_action(message.chat.id, ChatAction.TYPING)
        
        # Cek config
        if not config.get("api_key"):
            await message.reply_text(
                f"<blockquote><b>❌ Tripay belum dikonfigurasi!</b>\n\n"
                f"Gunakan <code>.settripay [api_key] [private_key] [merchant_code]</code></blockquote>"
            )
            return
        
        # Parse args
        args = message.text.split()
        if len(args) < 3:
            await message.reply_text(
                f"<blockquote><b>❌ Format: .qrispay  [jumlah] [deskripsi]</b>\n\n"
                f"<b>Contoh:</b>\n"
                f"<code>.qrispay  50000 Beli VPS 1GB</code>\n"
                f"<code>.qrispay  100000 Donasi</code></blockquote>"
            )
            return
        
        try:
            amount = int(args[1])
            if amount < 10000:
                await message.reply_text(f"{ggl} Minimal pembayaran Rp10.000!")
                return
        except ValueError:
            await message.reply_text(f"{ggl} Jumlah harus angka!")
            return
        
        description = " ".join(args[2:]) if len(args) > 2 else "Pembayaran via QRIS"
        
        # Kirim processing
        processing = await message.reply_text(f"{prs} Membuat invoice pembayaran...")
        
        # Create invoice
        user = message.from_user
        username = user.username or user.first_name
        
        result = await create_invoice(amount, description, user.id, username)
        
        if result.get("success"):
            merchant_ref = result["merchant_ref"]
            qr_url = result.get("qr_url")
            qr_string = result.get("qr_string")
            expired_at = result.get("expired_at")
            
            # Format waktu expired
            if expired_at:
                expired_dt = datetime.fromtimestamp(expired_at)
                expired_str = expired_dt.strftime("%d/%m/%Y %H:%M:%S")
            else:
                expired_str = "24 jam"
            
            await processing.delete()
            
            # Coba kirim QR code sebagai gambar
            if qr_url:
                try:
                    await client.send_photo(
                        chat_id=message.chat.id,
                        photo=qr_url,
                        caption=f"""
<blockquote><b>💳 QRIS PAYMENT</b>

💰 <b>Jumlah:</b> Rp{amount:,}
📝 <b>Deskripsi:</b> {description}
🆔 <b>Ref:</b> <code>{merchant_ref}</code>
⏰ <b>Expired:</b> {expired_str}

📌 Scan QR code di atas untuk membayar
📌 Cek status: <code>.cektripay {merchant_ref}</code></blockquote>"""
                    )
                    return
                except:
                    pass
            
            # Fallback ke teks
            await message.reply_text(
                f"""
<blockquote><b>💳 QRIS PAYMENT</b>

💰 <b>Jumlah:</b> Rp{amount:,}
📝 <b>Deskripsi:</b> {description}
🆔 <b>Ref:</b> <code>{merchant_ref}</code>
⏰ <b>Expired:</b> {expired_str}
🔗 <b>QR String:</b> <code>{qr_string[:50]}...</code>

📌 Cek status: <code>.cektripay {merchant_ref}</code></blockquote>"""
            )
        else:
            await processing.edit_text(
                f"<blockquote><b>❌ GAGAL MEMBUAT INVOICE</b>\n\n"
                f"Error: {result.get('error', 'Unknown error')}</blockquote>"
            )
        
    except Exception as e:
        await message.reply_text(f"{ggl} Error: {str(e)[:100]}")

@PY.UBOT("cektripay")
async def check_payment_status(client: Client, message: Message):
    ggl = await EMO.GAGAL(client)
    prs = await EMO.PROSES(client)
    
    try:
        args = message.text.split()
        if len(args) < 2:
            await message.reply_text(f"{ggl} Masukkan reference! Contoh: .cektripay INV12345")
            return
        
        ref = args[1]
        
        processing = await message.reply_text(f"{prs} Mengecek status pembayaran...")
        
        # Cek di database lokal dulu
        if ref in transactions:
            trans = transactions[ref]
            status = trans["status"]
            
            if status == "PAID":
                await processing.edit_text(
                    f"<blockquote><b>✅ STATUS: PAID</b>\n\n"
                    f"💰 Rp{trans['amount']:,}\n"
                    f"📝 {trans['description']}\n"
                    f"✅ Pembayaran berhasil!</blockquote>"
                )
                return
        
        # Cek ke Tripay API
        result = await check_transaction(ref)
        
        if result.get("success"):
            status = result.get("status")
            amount = result.get("amount", 0)
            paid_at = result.get("paid_at", "")
            
            status_emoji = {
                "PAID": "✅",
                "PENDING": "⏳",
                "FAILED": "❌",
                "EXPIRED": "⌛"
            }.get(status, "❓")
            
            status_text = f"""
<blockquote><b>{status_emoji} STATUS PEMBAYARAN</b>

🆔 <b>Ref:</b> <code>{ref}</code>
💰 <b>Jumlah:</b> Rp{amount:,}
📊 <b>Status:</b> {status}"""
            
            if paid_at:
                status_text += f"\n⏰ <b>Dibayar:</b> {paid_at}"
            
            status_text += "</blockquote>"
            
            await processing.edit_text(status_text)
        else:
            await processing.edit_text(
                f"<blockquote><b>❌ GAGAL CEK STATUS</b>\n\n"
                f"Error: {result.get('error', 'Unknown error')}</blockquote>"
            )
        
    except Exception as e:
        await message.reply_text(f"{ggl} Error: {str(e)[:100]}")

