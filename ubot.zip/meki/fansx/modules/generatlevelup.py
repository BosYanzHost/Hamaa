from fansx import *
import aiohttp
import asyncio
import os
import random
from urllib.parse import quote
from pyrogram.enums import ChatAction, ParseMode
from pyrogram.types import Message

__MODULE__ = "ʟᴇᴠᴇʟ-ᴜᴘ ᴄᴀʀᴅ"
__HELP__ = """
<blockquote><b>📈 LEVEL-UP CARD GENERATOR</b>

<b>⌲ Perintah:</b>
ᚗ <code>{0}levelup [nama]|[dari_level]|[ke_level]</code> - Format sederhana
ᚗ <code>{0}levelup [nama]|[dari_level]|[ke_level]|[background]|[avatar]</code> - Format lengkap

<b>⌲ Parameter:</b>
• <code>nama</code> - Nama user (wajib)
• <code>dari_level</code> - Level sebelumnya (wajib, angka)
• <code>ke_level</code> - Level baru (wajib, angka)
• <code>background</code> - URL gambar background (opsional)
• <code>avatar</code> - URL foto profil (opsional)

<b>⌲ Contoh:</b>
<code>.levelup putu|0|1</code>
<code>.levelup putu|0|1|https://i.ibb.co.com/2jMjYXK/IMG-20250103-WA0469.jpg|https://avatars.githubusercontent.com/u/159487561?v=4</code></blockquote>
"""

# ============================================
# KONFIGURASI
# ============================================
BASE_URL = "https://api.siputzx.my.id/api/canvas/level-up"

# Default background dan avatar jika tidak disediakan
DEFAULT_BACKGROUND = "https://i.ibb.co.com/2jMjYXK/IMG-20250103-WA0469.jpg"
DEFAULT_AVATAR = "https://avatars.githubusercontent.com/u/159487561?v=4"

async def generate_levelup_card(name: str, from_level: str, to_level: str, background_url: str = None, avatar_url: str = None):
    """Generate level-up card dari API"""
    try:
        # Gunakan default jika tidak ada
        if not background_url:
            background_url = DEFAULT_BACKGROUND
        if not avatar_url:
            avatar_url = DEFAULT_AVATAR
        
        # Build URL dengan parameter
        params = {
            "backgroundURL": quote(background_url, safe=''),
            "avatarURL": quote(avatar_url, safe=''),
            "fromLevel": str(from_level),
            "toLevel": str(to_level),
            "name": quote(name)
        }
        
        # Build query string
        query_parts = []
        for key, value in params.items():
            query_parts.append(f"{key}={value}")
        
        url = f"{BASE_URL}?{'&'.join(query_parts)}"
        
        # Download gambar
        async with aiohttp.ClientSession() as session:
            async with session.get(url, timeout=30) as response:
                if response.status == 200:
                    return await response.read()
                else:
                    print(f"HTTP Error: {response.status}")
    except Exception as e:
        print(f"Error generate level-up card: {e}")
    return None

def parse_input(input_text):
    """Parse input dari user dengan format | separator"""
    parts = [p.strip() for p in input_text.split('|')]
    
    data = {
        "name": "",
        "from_level": "",
        "to_level": "",
        "background_url": None,
        "avatar_url": None
    }
    
    if len(parts) >= 1:
        data["name"] = parts[0]
    if len(parts) >= 2:
        data["from_level"] = parts[1]
    if len(parts) >= 3:
        data["to_level"] = parts[2]
    if len(parts) >= 4:
        data["background_url"] = parts[3]
    if len(parts) >= 5:
        data["avatar_url"] = parts[4]
    
    return data

@PY.UBOT("levelup")
async def levelup_card(client: Client, message: Message):
    ggl = await EMO.GAGAL(client)
    sks = await EMO.BERHASIL(client)
    prs = await EMO.PROSES(client)
    
    try:
        await client.send_chat_action(message.chat.id, ChatAction.UPLOAD_PHOTO)
        
        # Cek apakah command tanpa argumen
        if len(message.text.split()) == 1:
            await message.reply_text(
                f"<blockquote><b>📈 LEVEL-UP CARD GENERATOR</b>\n\n"
                f"<b>Format sederhana:</b>\n"
                f"<code>.levelup nama|dari_level|ke_level</code>\n\n"
                f"<b>Format lengkap:</b>\n"
                f"<code>.levelup nama|dari_level|ke_level|background|avatar</code>\n\n"
                f"<b>Contoh sederhana:</b>\n"
                f"<code>.levelup putu|0|1</code>\n\n"
                f"<b>Contoh lengkap:</b>\n"
                f"<code>.levelup putu|0|1|https://i.ibb.co.com/2jMjYXK/IMG-20250103-WA0469.jpg|https://avatars.githubusercontent.com/u/159487561?v=4</code>\n\n"
                f"<b>Default background & avatar akan digunakan jika tidak disediakan</b></blockquote>"
            )
            return
        
        args = message.text.split(maxsplit=1)
        input_data = args[1]
        
        # Parse data
        data = parse_input(input_data)
        
        # Validasi data wajib
        if not data["name"]:
            await message.reply_text(f"{ggl} <b>Nama user tidak boleh kosong!</b>")
            return
        if not data["from_level"]:
            await message.reply_text(f"{ggl} <b>Level sebelumnya tidak boleh kosong!</b>")
            return
        if not data["to_level"]:
            await message.reply_text(f"{ggl} <b>Level baru tidak boleh kosong!</b>")
            return
        
        # Validasi level (harus angka)
        try:
            int(data["from_level"])
            int(data["to_level"])
        except ValueError:
            await message.reply_text(f"{ggl} <b>Level harus berupa angka!</b>")
            return
        
        # Kirim processing
        processing = await message.reply_text(
            f"{prs} <b>Membuat level-up card...</b>\n"
            f"👤 Nama: {data['name']}\n"
            f"📊 Level: {data['from_level']} ➜ {data['to_level']}"
        )
        
        # Generate gambar
        image_data = await generate_levelup_card(
            data["name"],
            data["from_level"],
            data["to_level"],
            data["background_url"],
            data["avatar_url"]
        )
        
        if not image_data:
            await processing.edit_text(f"{ggl} <b>Gagal membuat level-up card!</b>")
            return
        
        # Simpan sementara
        file_path = f"levelup_{message.from_user.id}_{random.randint(1000,9999)}.jpg"
        with open(file_path, 'wb') as f:
            f.write(image_data)
        
        await processing.delete()
        
        # Kirim foto
        await client.send_photo(
            chat_id=message.chat.id,
            photo=file_path,
            caption=f"<blockquote><b>📈 LEVEL-UP!</b>\n\n"
                    f"👤 <b>User:</b> {data['name']}\n"
                    f"📊 <b>Level:</b> {data['from_level']} ➜ {data['to_level']}</blockquote>"
        )
        
        # Hapus file
        import os
        if os.path.exists(file_path):
            os.remove(file_path)
        
    except Exception as e:
        await message.reply_text(f"{ggl} <b>Error: {str(e)[:100]}</b>")

