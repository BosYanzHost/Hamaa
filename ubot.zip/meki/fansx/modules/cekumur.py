from fansx import *
import random
import asyncio
from pyrogram.enums import ChatAction
from pyrogram.types import Message

__MODULE__ = "ᴄᴇᴋ ᴜᴍᴜʀ ᴍᴇɴᴛᴀʟ"
__HELP__ = """
<blockquote><b>『 CEK UMUR MENTAL 』</b>

<b>⌲ Perintah:</b>
ᚗ <code>{0}mental [nama]</code> 
⊶ Mengecek umur mental seseorang (versi lucu)

<b>⌲ Contoh:</b>
<code>.mental</code> (untuk cek diri sendiri)
<code>.mental Budi</code> (untuk cek orang lain)
<code>.mental @username</code></blockquote>
"""

def get_description(age):
    """Mendapatkan deskripsi berdasarkan umur mental"""
    if age >= 60:
        return "Bijaksana seperti orang tua! 🧓"
    elif age >= 40:
        return "Dewasa dan matang~ 🧑"
    elif age >= 20:
        return "Jiwa muda! 🧒"
    else:
        return "Masih seperti anak kecil~ 👶"

@PY.UBOT("mental")
async def cek_mental(client: Client, message: Message):
    ggl = await EMO.GAGAL(client)
    sks = await EMO.BERHASIL(client)
    prs = await EMO.PROSES(client)
    
    try:
        await client.send_chat_action(message.chat.id, ChatAction.TYPING)
        
        # Ambil nama dari input atau reply
        nama = "Kamu"
        
        # Cek apakah reply ke user
        if message.reply_to_message and message.reply_to_message.from_user:
            user = message.reply_to_message.from_user
            nama = user.first_name
            if user.last_name:
                nama += f" {user.last_name}"
        
        # Cek dari argumen
        args = message.text.split(maxsplit=1)
        if len(args) > 1:
            input_nama = args[1].strip()
            
            # Cek apakah mention @username
            if input_nama.startswith('@'):
                try:
                    user = await client.get_users(input_nama)
                    nama = user.first_name
                    if user.last_name:
                        nama += f" {user.last_name}"
                except:
                    nama = input_nama
            else:
                nama = input_nama
        
        # Jika tidak ada input dan tidak reply, pakai nama sender
        elif nama == "Kamu":
            nama = message.from_user.first_name
            if message.from_user.last_name:
                nama += f" {message.from_user.last_name}"
        
        # Generate random umur mental (5-85 tahun)
        mental_age = random.randint(5, 85)
        desc = get_description(mental_age)
        
        # Buat progress bar visual
        bar_length = 20
        # Mapping umur 5-85 ke 0-100% untuk progress bar
        percent = int((mental_age - 5) * 100 / 80)  # 5->0%, 85->100%
        filled_length = int(bar_length * percent / 100)
        
        # Pilih emoji berdasarkan umur mental
        if mental_age >= 60:
            bar_emoji = '🧓'
            empty_emoji = '👶'
        elif mental_age >= 40:
            bar_emoji = '🧑'
            empty_emoji = '👶'
        elif mental_age >= 20:
            bar_emoji = '🧒'
            empty_emoji = '🧓'
        else:
            bar_emoji = '👶'
            empty_emoji = '🧓'
        
        bar = bar_emoji * filled_length + empty_emoji * (bar_length - filled_length)
        
        # Kirim pesan processing dulu (biar ada efek)
        processing = await message.reply_text(f"{prs} <b>Mengukur umur mental {nama}...</b>")
        
        # Tunggu bentar biar keliatan prosesnya
        await asyncio.sleep(1)
        
        # Format pesan
        txt = f"""
<blockquote><b>🎂 CEK UMUR MENTAL</b>

<b>👤 Nama:</b> <code>{nama}</code>
<b>📊 Umur Mental:</b> <code>{mental_age} Tahun</code>

<code>{bar}</code>

<b>💬 {desc}</b></blockquote>
"""
        
        await processing.edit_text(txt)
        
    except Exception as e:
        await message.reply_text(f"{ggl} <b>Error: {str(e)[:100]}</b>")

@PY.UBOT("umurmental")
async def umurmental_alias(client: Client, message: Message):
    """Alias untuk mental"""
    await cek_mental(client, message)

@PY.UBOT("cekmental")
async def cek_mental_alias(client: Client, message: Message):
    """Alias untuk mental"""
    await cek_mental(client, message)

@PY.UBOT("mentalage")
async def mentalage_alias(client: Client, message: Message):
    """Alias untuk mental"""
    await cek_mental(client, message)

@PY.BOT("mental")
async def cek_mental_bot(client: Client, message: Message):
    """Handler untuk bot"""
    try:
        nama = "Kamu"
        
        if message.reply_to_message and message.reply_to_message.from_user:
            user = message.reply_to_message.from_user
            nama = user.first_name
            if user.last_name:
                nama += f" {user.last_name}"
        
        args = message.text.split(maxsplit=1)
        if len(args) > 1:
            input_nama = args[1].strip()
            if input_nama.startswith('@'):
                try:
                    user = await client.get_users(input_nama)
                    nama = user.first_name
                    if user.last_name:
                        nama += f" {user.last_name}"
                except:
                    nama = input_nama
            else:
                nama = input_nama
        
        # Generate random umur mental (5-85 tahun)
        mental_age = random.randint(5, 85)
        desc = get_description(mental_age)
        
        # Buat progress bar sederhana
        bar_length = 15
        percent = int((mental_age - 5) * 100 / 80)
        filled_length = int(bar_length * percent / 100)
        
        if mental_age >= 60:
            bar = '🧓' * filled_length + '👶' * (bar_length - filled_length)
        elif mental_age >= 40:
            bar = '🧑' * filled_length + '👶' * (bar_length - filled_length)
        elif mental_age >= 20:
            bar = '🧒' * filled_length + '🧓' * (bar_length - filled_length)
        else:
            bar = '👶' * filled_length + '🧓' * (bar_length - filled_length)
        
        txt = f"""
🎂 *CEK UMUR MENTAL*

👤 Nama: {nama}
📊 Umur Mental: {mental_age} Tahun

{bar}

💬 {desc}
"""
        await message.reply_text(txt)
        
    except Exception as e:
        await message.reply_text(f"❌ Error: {str(e)[:100]}")