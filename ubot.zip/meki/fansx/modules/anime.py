from fansx import *
import random
import requests
from pyrogram.enums import *
from pyrogram import *
from pyrogram.types import *
from io import BytesIO

__MODULE__ = "ᴀɴɪᴍᴇ"
__HELP__ = """
<blockquote><b>『 ʙᴀɴᴛᴜᴀɴ ᴀɴɪᴍᴇ 』</b>

<b>⌲ ᴘᴇʀɪɴᴛᴀʜ:</b> <code>{0}anime [query]</code>

<b>Query:</b> <b>keneki</b>,
    <b>megumin</b>,
    <b>yotsuba</b>,
    <b>shinomiya</b>,
    <b>yumeko</b>,
    <b>tsunade</b>,
    <b>kagura</b>,
    <b>madara</b>,
    <b>itachi</b>,
    <b>akira</b>,
    <b>toukachan</b>,
    <b>cicho</b>,
    <b>sasuke</b></blockquote>
"""

# Daftar API keys
API_KEYS = [
    "eIxUwMpn",
    "keoCFdc6",
    "bv7m372F",
    "iAiB9QKT",
    "JP7Cy8Y2",
    "GI4vPxYv",
    "HRPga9TN",
    "PDwqhVsj",
    "m8jpBeZR",
    "PXkxh5hw",
    "MFnlpM6A",
    "u299UiOF"
    
]
def get_random_apikey():
    """Mengambil API key secara random dari daftar"""
    return random.choice(API_KEYS)

# Base URL tanpa apikey
BASE_URL = "https://api.botcahx.eu.org/api/anime/"

# Daftar query yang tersedia
QUERIES = [
    "keneki",
    "megumin",
    "yotsuba",
    "shinomiya",
    "yumeko",
    "tsunade",
    "kagura",
    "madara",
    "itachi",
    "akira",
    "toukachan",
    "chiho",  # Note: di URLS sebelumnya pake chiho bukan cicho
    "sasuke"
]

@PY.UBOT("anime")
@PY.TOP_CMD
async def _(client, message):
    # Extract query from message
    query = message.text.split()[1].lower() if len(message.text.split()) > 1 else None
    
    # Mapping untuk query yang mungkin typo
    query_mapping = {
        "cicho": "chiho",  # Jika user ketik cicho, mapping ke chiho
        "keneki": "keneki",
        "megumin": "megumin",
        "yotsuba": "yotsuba",
        "shinomiya": "shinomiya",
        "yumeko": "yumeko",
        "tsunade": "tsunade",
        "kagura": "kagura",
        "madara": "madara",
        "itachi": "itachi",
        "akira": "akira",
        "toukachan": "toukachan",
        "sasuke": "sasuke"
    }
    
    # Cek apakah query ada di mapping
    if query not in query_mapping:
        valid_queries = ", ".join(query_mapping.keys())
        await message.reply(f"Query tidak valid. Gunakan salah satu dari: {valid_queries}.")
        return

    # Ambil query yang benar dari mapping
    actual_query = query_mapping[query]
    
    processing_msg = await message.reply("Processing Kingz...")
    
    try:
        await client.send_chat_action(message.chat.id, ChatAction.UPLOAD_PHOTO)
        
        # Ambil API key secara random
        apikey = get_random_apikey()
        
        # Coba dengan API key pertama, jika gagal coba dengan yang lain
        success = False
        for attempt in range(3):  # Coba maksimal 3 kali dengan key berbeda
            try:
                # Buat URL dengan apikey random
                url = f"{BASE_URL}{actual_query}?apikey={apikey}"
                
                response = requests.get(url)
                
                if response.status_code == 200:
                    # Cek apakah response berupa gambar (bukan JSON error)
                    content_type = response.headers.get('content-type', '')
                    if 'image' in content_type:
                        photo = BytesIO(response.content)
                        photo.name = f'{actual_query}.jpg'
                        
                        await client.send_photo(message.chat.id, photo)
                        await processing_msg.delete()
                        success = True
                        break
                    else:
                        # Jika response bukan gambar, coba dengan key lain
                        apikey = get_random_apikey()
                        continue
                else:
                    # Jika status code error, coba dengan key lain
                    apikey = get_random_apikey()
                    continue
                    
            except Exception as e:
                # Jika error, coba dengan key lain
                apikey = get_random_apikey()
                continue
        
        if not success:
            await processing_msg.edit_text("❌ Gagal mengambil gambar anime setelah beberapa percobaan. Silakan coba lagi nanti.")
            
    except Exception as e:
        await processing_msg.edit_text(f"❌ Error: {e}")