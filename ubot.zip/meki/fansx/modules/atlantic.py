from fansx import *
import aiohttp
import asyncio
import random
import string
import time
import base64
import json
import os
from datetime import datetime, timedelta
from urllib.parse import urlencode
from pyrogram.enums import ChatAction, ParseMode
from pyrogram.types import Message

__MODULE__ = "ᴀᴛʟᴀɴᴛɪᴄ ʜ2ʜ"
__HELP__ = """
<blockquote><b>💳 ATLANTIC H2H PAYMENT</b>

<b>⌲ Perintah:</b>
ᚗ <code>{0}setatlantic [api_key]</code> - Set API Key Atlantic
ᚗ <code>{0}atsaldo</code> - Cek saldo akun
ᚗ <code>{0}atprofile</code> - Info profil lengkap
ᚗ <code>{0}athistory [limit]</code> - Riwayat transaksi
ᚗ <code>{0}qrisatlan [jumlah] [produk]</code> - Buat QRIS payment
ᚗ <code>{0}transfer [jumlah] [bank] [no_rek] [nama]</code> - Transfer ke rekening
ᚗ <code>{0}cekatlantic [id]</code> - Cek status transaksi

<b>⌲ Contoh:</b>
<code>.setatlantic xxxxxxx</code>
<code>.atsaldo</code>
<code>.atprofile</code>
<code>.athistory 10</code>
<code>.qrisatlan 50000 VPS 1GB</code>
<code>.transfer 50000 bca 123456789 John Doe</code>
<code>.cekatlantic TRX12345</code></blockquote>
"""

# ============================================
# KONFIGURASI
# ============================================
ATLANTIC_CONFIG_FILE = "atlantic_config.json"
ATLANTIC_API = "https://atlantich2h.com"

def load_config():
    """Load Atlantic config"""
    try:
        if os.path.exists(ATLANTIC_CONFIG_FILE):
            with open(ATLANTIC_CONFIG_FILE, 'r') as f:
                return json.load(f)
    except:
        pass
    return {"api_key": None}

def save_config(config):
    """Save Atlantic config"""
    try:
        with open(ATLANTIC_CONFIG_FILE, 'w') as f:
            json.dump(config, f, indent=4)
        return True
    except:
        return False

config = load_config()

# Database sementara
transactions = {}
withdrawals = {}

def generate_reff_id():
    """Generate reference ID"""
    timestamp = int(time.time() * 1000)
    random_str = ''.join(random.choices(string.ascii_uppercase + string.digits, k=9))
    return f"wd_{timestamp}_{random_str}"

def generate_trx_id():
    """Generate transaction ID"""
    timestamp = int(time.time() * 1000)
    random_str = ''.join(random.choices(string.ascii_uppercase + string.digits, k=6))
    return f"TRX-{timestamp}-{random_str}"

def to_rupiah(amount):
    """Format angka ke Rupiah"""
    try:
        return f"Rp{int(amount):,}".replace(",", ".")
    except:
        return f"Rp{amount}"

def format_date(timestamp):
    """Format timestamp ke tanggal"""
    try:
        dt = datetime.fromtimestamp(timestamp)
        return dt.strftime("%d/%m/%Y %H:%M")
    except:
        return str(timestamp)

# ============================================
# FUNGSI CEK PROFIL & SALDO
# ============================================

async def get_profile(api_key):
    """Cek profil akun Atlantic"""
    try:
        data = {
            "api_key": api_key
        }
        
        async with aiohttp.ClientSession() as session:
            async with session.post(
                f"{ATLANTIC_API}/profile/info",
                data=data,
                headers={"Content-Type": "application/x-www-form-urlencoded"},
                timeout=15
            ) as resp:
                if resp.status == 200:
                    result = await resp.json()
                    return {"success": True, "data": result.get("data", {})}
                else:
                    return {"success": False, "error": f"HTTP {resp.status}"}
    except Exception as e:
        return {"success": False, "error": str(e)}

async def get_balance(api_key):
    """Cek saldo akun Atlantic"""
    try:
        data = {
            "api_key": api_key
        }
        
        async with aiohttp.ClientSession() as session:
            async with session.post(
                f"{ATLANTIC_API}/profile/balance",
                data=data,
                headers={"Content-Type": "application/x-www-form-urlencoded"},
                timeout=15
            ) as resp:
                if resp.status == 200:
                    result = await resp.json()
                    return {"success": True, "data": result.get("data", {})}
                else:
                    return {"success": False, "error": f"HTTP {resp.status}"}
    except Exception as e:
        return {"success": False, "error": str(e)}

async def get_transaction_history(api_key, limit=10):
    """Cek riwayat transaksi"""
    try:
        data = {
            "api_key": api_key,
            "limit": limit
        }
        
        async with aiohttp.ClientSession() as session:
            async with session.post(
                f"{ATLANTIC_API}/profile/history",
                data=data,
                headers={"Content-Type": "application/x-www-form-urlencoded"},
                timeout=15
            ) as resp:
                if resp.status == 200:
                    result = await resp.json()
                    return {"success": True, "data": result.get("data", [])}
                else:
                    return {"success": False, "error": f"HTTP {resp.status}"}
    except Exception as e:
        return {"success": False, "error": str(e)}

# ============================================
# FUNGSI QRIS
# ============================================

async def download_qris_image(url):
    """Download QRIS image dari URL"""
    try:
        if not url or not url.startswith('http'):
            return None
        
        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
            'Referer': 'https://atlantich2h.com/'
        }
        
        async with aiohttp.ClientSession() as session:
            async with session.get(url, headers=headers, timeout=15) as resp:
                if resp.status == 200:
                    return await resp.read()
    except Exception as e:
        print(f"Download QRIS error: {e}")
    return None

async def trigger_instant_check(trx_id, api_key):
    """Trigger instant check untuk deposit"""
    try:
        data = {
            "api_key": api_key,
            "id": str(trx_id),
            "action": "true"
        }
        
        async with aiohttp.ClientSession() as session:
            async with session.post(
                f"{ATLANTIC_API}/deposit/instant",
                data=data,
                timeout=5
            ) as resp:
                print(f"Instant check triggered for {trx_id}")
    except:
        pass

async def create_qris(amount, api_key):
    """Buat QRIS payment via Atlantic"""
    try:
        reff_id = generate_trx_id()
        
        data = {
            "api_key": api_key,
            "reff_id": reff_id,
            "nominal": amount,
            "type": "ewallet",
            "metode": "QRIS"
        }
        
        async with aiohttp.ClientSession() as session:
            async with session.post(
                f"{ATLANTIC_API}/deposit/create",
                data=data,
                headers={"Content-Type": "application/x-www-form-urlencoded"},
                timeout=30
            ) as resp:
                if resp.status == 200:
                    result = await resp.json()
                    
                    if result.get("data"):
                        d = result["data"]
                        return {
                            "success": True,
                            "id": d.get("id"),
                            "reff_id": reff_id,
                            "amount": amount,
                            "qr_image": d.get("qr_image", ""),
                            "qr_string": d.get("qr_string", ""),
                            "expired_at": d.get("expired_at")
                        }
                    else:
                        return {"success": False, "error": "Response tidak valid"}
                else:
                    return {"success": False, "error": f"HTTP {resp.status}"}
    except Exception as e:
        return {"success": False, "error": str(e)}

async def check_qris_status(trx_id, amount, api_key):
    """Cek status QRIS payment"""
    try:
        data = {
            "api_key": api_key,
            "id": str(trx_id)
        }
        
        async with aiohttp.ClientSession() as session:
            async with session.post(
                f"{ATLANTIC_API}/deposit/status",
                data=data,
                headers={"Content-Type": "application/x-www-form-urlencoded"},
                timeout=15
            ) as resp:
                if resp.status == 200:
                    result = await resp.json()
                    
                    if result.get("data"):
                        status = result["data"].get("status", "").lower()
                        
                        if status == "success":
                            return {"success": True, "status": "PAID"}
                        elif status == "processing":
                            await trigger_instant_check(trx_id, api_key)
                            return {"success": True, "status": "PROCESSING"}
                        else:
                            return {"success": True, "status": "PENDING"}
                    else:
                        return {"success": False, "error": "Response tidak valid"}
                else:
                    return {"success": False, "error": f"HTTP {resp.status}"}
    except Exception as e:
        return {"success": False, "error": str(e)}

# ============================================
# FUNGSI TRANSFER/WITHDRAW
# ============================================

async def create_transfer(amount, bank_code, account_number, account_name, api_key, note=""):
    """Buat transfer/withdraw via Atlantic"""
    try:
        reff_id = generate_reff_id()
        
        if not note:
            note = "Withdraw Saldo Bot"
        
        data = {
            "api_key": api_key,
            "ref_id": reff_id,
            "kode_bank": bank_code,
            "nomor_akun": account_number,
            "nama_pemilik": account_name,
            "nominal": amount,
            "email": "bot@telegram.com",
            "phone": account_number,
            "note": note
        }
        
        async with aiohttp.ClientSession() as session:
            async with session.post(
                f"{ATLANTIC_API}/transfer/create",
                data=data,
                headers={"Content-Type": "application/x-www-form-urlencoded"},
                timeout=30
            ) as resp:
                if resp.status == 200:
                    result = await resp.json()
                    
                    return {
                        "success": True,
                        "data": result,
                        "reff_id": reff_id
                    }
                else:
                    return {"success": False, "error": f"HTTP {resp.status}"}
    except Exception as e:
        return {"success": False, "error": str(e)}

async def check_transfer_status(transfer_id, api_key):
    """Cek status transfer"""
    try:
        data = {
            "api_key": api_key,
            "id": str(transfer_id)
        }
        
        async with aiohttp.ClientSession() as session:
            async with session.post(
                f"{ATLANTIC_API}/transfer/status",
                data=data,
                headers={"Content-Type": "application/x-www-form-urlencoded"},
                timeout=15
            ) as resp:
                if resp.status == 200:
                    result = await resp.json()
                    return {"success": True, "data": result}
                else:
                    return {"success": False, "error": f"HTTP {resp.status}"}
    except Exception as e:
        return {"success": False, "error": str(e)}

# ============================================
# COMMAND SETTING
# ============================================

@PY.UBOT("setatlantic")
async def set_atlantic_key(client: Client, message: Message):
    ggl = await EMO.GAGAL(client)
    sks = await EMO.BERHASIL(client)
    
    try:
        args = message.text.split(maxsplit=1)
        if len(args) < 2:
            await message.reply_text(
                f"<blockquote><b>❌ Format: .setatlantic [api_key]</b>\n\n"
                f"Dapatkan API Key dari Atlantic H2H</blockquote>"
            )
            return
        
        api_key = args[1].strip()
        
        # Test API Key dengan cek profile
        test = await get_profile(api_key)
        
        if test.get("success"):
            config["api_key"] = api_key
            save_config(config)
            
            await message.reply_text(
                f"<blockquote><b>✅ ATLANTIC CONFIG SAVED</b>\n\n"
                f"🔑 API Key: <code>{api_key[:10]}...{api_key[-5:]}</code></blockquote>"
            )
        else:
            await message.reply_text(f"{ggl} API Key tidak valid!")
        
    except Exception as e:
        await message.reply_text(f"{ggl} Error: {str(e)[:100]}")

# ============================================
# COMMAND CEK PROFIL & SALDO
# ============================================

@PY.UBOT("atsaldo")
async def check_balance(client: Client, message: Message):
    ggl = await EMO.GAGAL(client)
    prs = await EMO.PROSES(client)
    
    try:
        api_key = config.get("api_key")
        if not api_key:
            await message.reply_text(
                f"<blockquote><b>❌ API Key belum diset!</b>\n\n"
                f"Gunakan <code>.setatlantic [api_key]</code></blockquote>"
            )
            return
        
        processing = await message.reply_text(f"{prs} Mengecek saldo...")
        
        result = await get_balance(api_key)
        
        if result.get("success"):
            data = result.get("data", {})
            
            balance = data.get("balance", 0)
            pending = data.get("pending", 0)
            total_deposit = data.get("total_deposit", 0)
            total_withdraw = data.get("total_withdraw", 0)
            
            await processing.edit_text(
                f"""
<blockquote><b>💰 SALDO ATLANTIC H2H</b>

💵 <b>Saldo Tersedia:</b> {to_rupiah(balance)}
⏳ <b>Saldo Pending:</b> {to_rupiah(pending)}
📊 <b>Total Deposit:</b> {to_rupiah(total_deposit)}
💸 <b>Total Withdraw:</b> {to_rupiah(total_withdraw)}</blockquote>"""
            )
        else:
            await processing.edit_text(
                f"<blockquote><b>❌ GAGAL CEK SALDO</b>\n\n"
                f"Error: {result.get('error', 'Unknown error')}</blockquote>"
            )
        
    except Exception as e:
        await message.reply_text(f"{ggl} Error: {str(e)[:100]}")

@PY.UBOT("atprofile")
async def check_profile(client: Client, message: Message):
    ggl = await EMO.GAGAL(client)
    prs = await EMO.PROSES(client)
    
    try:
        api_key = config.get("api_key")
        if not api_key:
            await message.reply_text(
                f"<blockquote><b>❌ API Key belum diset!</b>\n\n"
                f"Gunakan <code>.setatlantic [api_key]</code></blockquote>"
            )
            return
        
        processing = await message.reply_text(f"{prs} Mengambil data profil...")
        
        result = await get_profile(api_key)
        
        if result.get("success"):
            data = result.get("data", {})
            
            merchant_id = data.get("merchant_id", "-")
            merchant_name = data.get("merchant_name", "-")
            email = data.get("email", "-")
            phone = data.get("phone", "-")
            status = data.get("status", "-")
            join_date = format_date(data.get("join_date", 0))
            
            status_emoji = "✅" if status == "active" else "❌"
            
            await processing.edit_text(
                f"""
<blockquote><b>👤 PROFIL ATLANTIC H2H</b>

🆔 <b>Merchant ID:</b> <code>{merchant_id}</code>
🏢 <b>Nama:</b> {merchant_name}
📧 <b>Email:</b> {email}
📱 <b>Phone:</b> {phone}
📊 <b>Status:</b> {status_emoji} {status}
📅 <b>Join Date:</b> {join_date}</blockquote>"""
            )
        else:
            await processing.edit_text(
                f"<blockquote><b>❌ GAGAL AMBIL PROFIL</b>\n\n"
                f"Error: {result.get('error', 'Unknown error')}</blockquote>"
            )
        
    except Exception as e:
        await message.reply_text(f"{ggl} Error: {str(e)[:100]}")

@PY.UBOT("athistory")
async def check_history(client: Client, message: Message):
    ggl = await EMO.GAGAL(client)
    prs = await EMO.PROSES(client)
    
    try:
        api_key = config.get("api_key")
        if not api_key:
            await message.reply_text(
                f"<blockquote><b>❌ API Key belum diset!</b>\n\n"
                f"Gunakan <code>.setatlantic [api_key]</code></blockquote>"
            )
            return
        
        args = message.text.split()
        limit = 10
        if len(args) > 1:
            try:
                limit = int(args[1])
                if limit > 50:
                    limit = 50
            except:
                pass
        
        processing = await message.reply_text(f"{prs} Mengambil riwayat transaksi...")
        
        result = await get_transaction_history(api_key, limit)
        
        if result.get("success"):
            transactions = result.get("data", [])
            
            if not transactions:
                await processing.edit_text("<blockquote><b>📭 Tidak ada riwayat transaksi</b></blockquote>")
                return
            
            text = f"<blockquote><b>📋 RIWAYAT TRANSAKSI ({len(transactions)})</b>\n\n"
            
            for i, trx in enumerate(transactions[:limit], 1):
                trx_id = trx.get("id", "-")
                trx_type = trx.get("type", "-")
                amount = trx.get("amount", 0)
                status = trx.get("status", "-")
                date = format_date(trx.get("date", 0))
                
                # Emoji untuk tipe
                type_emoji = "💰" if trx_type == "deposit" else "💸"
                status_emoji = "✅" if status == "success" else "⏳" if status == "pending" else "❌"
                
                text += f"{type_emoji} <b>{trx_id[:15]}...</b>\n"
                text += f"   {to_rupiah(amount)} | {status_emoji} {status}\n"
                text += f"   🕐 {date}\n\n"
            
            text += "</blockquote>"
            
            await processing.edit_text(text)
        else:
            await processing.edit_text(
                f"<blockquote><b>❌ GAGAL AMBIL RIWAYAT</b>\n\n"
                f"Error: {result.get('error', 'Unknown error')}</blockquote>"
            )
        
    except Exception as e:
        await message.reply_text(f"{ggl} Error: {str(e)[:100]}")

# ============================================
# COMMAND QRIS
# ============================================

@PY.UBOT("qrisatlan")
async def create_qris_payment(client: Client, message: Message):
    ggl = await EMO.GAGAL(client)
    sks = await EMO.BERHASIL(client)
    prs = await EMO.PROSES(client)
    
    try:
        await client.send_chat_action(message.chat.id, ChatAction.TYPING)
        
        # Cek API Key
        api_key = config.get("api_key")
        if not api_key:
            await message.reply_text(
                f"<blockquote><b>❌ API Key belum diset!</b>\n\n"
                f"Gunakan <code>.setatlantic [api_key]</code></blockquote>"
            )
            return
        
        # Parse args
        args = message.text.split()
        if len(args) < 3:
            await message.reply_text(
                f"<blockquote><b>❌ Format: .qris [jumlah] [produk]</b>\n\n"
                f"<b>Contoh:</b>\n"
                f"<code>.qrisatlan 50000 VPS 1GB</code></blockquote>"
            )
            return
        
        try:
            amount = int(args[1])
            if amount < 10000:
                await message.reply_text(f"{ggl} Minimal pembayaran Rp10.000!")
                return
        except ValueError:
            await message.reply_text(f"{ggl} Jumlah harus angka!")
            return
        
        product = " ".join(args[2:])
        
        processing = await message.reply_text(f"{prs} Membuat QRIS payment...")
        
        # Create QRIS
        result = await create_qris(amount, api_key)
        
        if result.get("success"):
            trx_id = result.get("id")
            reff_id = result.get("reff_id")
            qr_image_url = result.get("qr_image")
            qr_string = result.get("qr_string")
            expired_at = result.get("expired_at")
            
            # Simpan transaksi
            transactions[trx_id] = {
                "id": trx_id,
                "reff_id": reff_id,
                "amount": amount,
                "product": product,
                "status": "PENDING",
                "user_id": message.from_user.id,
                "created_at": datetime.now().isoformat()
            }
            
            await processing.delete()
            
            # Download QR image
            qr_image = await download_qris_image(qr_image_url)
            
            if qr_image:
                # Kirim sebagai foto
                file_path = f"qris_{trx_id}.jpg"
                with open(file_path, "wb") as f:
                    f.write(qr_image)
                
                await client.send_photo(
                    chat_id=message.chat.id,
                    photo=file_path,
                    caption=f"""
<blockquote><b>💳 QRIS PAYMENT</b>

💰 <b>Jumlah:</b> {to_rupiah(amount)}
📦 <b>Produk:</b> {product}
🆔 <b>ID:</b> <code>{trx_id}</code>
⏰ <b>Expired:</b> 24 jam

📌 Scan QR code untuk membayar
📌 Cek status: <code>.cekatlantic {trx_id}</code></blockquote>"""
                )
                
                if os.path.exists(file_path):
                    os.remove(file_path)
            else:
                # Fallback ke teks
                await message.reply_text(
                    f"""
<blockquote><b>💳 QRIS PAYMENT</b>

💰 <b>Jumlah:</b> {to_rupiah(amount)}
📦 <b>Produk:</b> {product}
🆔 <b>ID:</b> <code>{trx_id}</code>
🔗 <b>QR String:</b> <code>{qr_string[:50]}...</code>
⏰ <b>Expired:</b> 24 jam

📌 Scan QR code untuk membayar
📌 Cek status: <code>.cekatlantic {trx_id}</code></blockquote>"""
                )
        else:
            await processing.edit_text(
                f"<blockquote><b>❌ GAGAL MEMBUAT QRIS</b>\n\n"
                f"Error: {result.get('error', 'Unknown error')}</blockquote>"
            )
        
    except Exception as e:
        await message.reply_text(f"{ggl} Error: {str(e)[:100]}")

# ============================================
# COMMAND TRANSFER
# ============================================

@PY.UBOT("transfer")
async def create_transfer_command(client: Client, message: Message):
    ggl = await EMO.GAGAL(client)
    sks = await EMO.BERHASIL(client)
    prs = await EMO.PROSES(client)
    
    try:
        await client.send_chat_action(message.chat.id, ChatAction.TYPING)
        
        # Cek API Key
        api_key = config.get("api_key")
        if not api_key:
            await message.reply_text(
                f"<blockquote><b>❌ API Key belum diset!</b>\n\n"
                f"Gunakan <code>.setatlantic [api_key]</code></blockquote>"
            )
            return
        
        # Parse args: .transfer 50000 bca 123456789 "John Doe"
        args = message.text.split(maxsplit=4)
        if len(args) < 5:
            await message.reply_text(
                f"<blockquote><b>❌ Format: .transfer [jumlah] [bank] [no_rek] [nama]</b>\n\n"
                f"<b>Contoh:</b>\n"
                f"<code>.transfer 50000 bca 123456789 John Doe</code></blockquote>"
            )
            return
        
        try:
            amount = int(args[1])
            if amount < 10000:
                await message.reply_text(f"{ggl} Minimal transfer Rp10.000!")
                return
        except ValueError:
            await message.reply_text(f"{ggl} Jumlah harus angka!")
            return
        
        bank_code = args[2].upper()
        account_number = args[3]
        account_name = args[4].strip()
        
        processing = await message.reply_text(f"{prs} Memproses transfer...")
        
        # Create transfer
        result = await create_transfer(
            amount, bank_code, account_number, account_name, api_key
        )
        
        if result.get("success"):
            data = result.get("data", {})
            reff_id = result.get("reff_id")
            
            # Simpan withdrawal
            withdrawals[reff_id] = {
                "reff_id": reff_id,
                "amount": amount,
                "bank": bank_code,
                "account_number": account_number,
                "account_name": account_name,
                "status": data.get("status", "PROCESSING"),
                "user_id": message.from_user.id,
                "created_at": datetime.now().isoformat()
            }
            
            await processing.delete()
            
            await message.reply_text(
                f"""
<blockquote><b>💰 TRANSFER BERHASIL</b>

💰 <b>Jumlah:</b> {to_rupiah(amount)}
🏦 <b>Bank:</b> {bank_code}
📱 <b>No Rek:</b> {account_number}
👤 <b>Nama:</b> {account_name}
🆔 <b>Ref:</b> <code>{reff_id}</code>

⏳ Status: PROCESSING
📌 Cek status: <code>.cekatlantic {reff_id}</code></blockquote>"""
            )
        else:
            await processing.edit_text(
                f"<blockquote><b>❌ GAGAL TRANSFER</b>\n\n"
                f"Error: {result.get('error', 'Unknown error')}</blockquote>"
            )
        
    except Exception as e:
        await message.reply_text(f"{ggl} Error: {str(e)[:100]}")

# ============================================
# COMMAND CEK STATUS
# ============================================

@PY.UBOT("cekatlantic")
async def check_atlantic_status(client: Client, message: Message):
    ggl = await EMO.GAGAL(client)
    prs = await EMO.PROSES(client)
    
    try:
        args = message.text.split(maxsplit=1)
        if len(args) < 2:
            await message.reply_text(f"{ggl} Masukkan ID transaksi!")
            return
        
        trx_id = args[1].strip()
        
        processing = await message.reply_text(f"{prs} Mengecek status...")
        
        # Cek di database QRIS dulu
        if trx_id in transactions:
            amount = transactions[trx_id]["amount"]
            
            # Cek status ke API
            result = await check_qris_status(trx_id, amount, config["api_key"])
            
            if result.get("success"):
                status = result.get("status", "UNKNOWN")
                
                if status == "PAID":
                    transactions[trx_id]["status"] = "PAID"
                    await processing.edit_text(
                        f"<blockquote><b>✅ PEMBAYARAN BERHASIL</b>\n\n"
                        f"🆔 ID: <code>{trx_id}</code>\n"
                        f"💰 Jumlah: {to_rupiah(amount)}</blockquote>"
                    )
                elif status == "PROCESSING":
                    await processing.edit_text(
                        f"<blockquote><b>⏳ SEDANG DIPROSES</b>\n\n"
                        f"🆔 ID: <code>{trx_id}</code>\n"
                        f"💰 Jumlah: {to_rupiah(amount)}\n\n"
                        f"Silakan cek lagi nanti.</blockquote>"
                    )
                else:
                    await processing.edit_text(
                        f"<blockquote><b>⏳ MENUNGGU PEMBAYARAN</b>\n\n"
                        f"🆔 ID: <code>{trx_id}</code>\n"
                        f"💰 Jumlah: {to_rupiah(amount)}</blockquote>"
                    )
            else:
                await processing.edit_text(
                    f"<blockquote><b>❌ GAGAL CEK STATUS</b>\n\n"
                    f"Error: {result.get('error', 'Unknown error')}</blockquote>"
                )
        
        # Cek di database withdrawal
        elif trx_id in withdrawals:
            amount = withdrawals[trx_id]["amount"]
            
            # Cek status transfer
            result = await check_transfer_status(trx_id, config["api_key"])
            
            if result.get("success"):
                data = result.get("data", {})
                status = data.get("status", "UNKNOWN")
                
                withdrawals[trx_id]["status"] = status
                
                await processing.edit_text(
                    f"<blockquote><b>📊 STATUS TRANSFER</b>\n\n"
                    f"🆔 Ref: <code>{trx_id}</code>\n"
                    f"💰 Jumlah: {to_rupiah(amount)}\n"
                    f"📊 Status: {status}</blockquote>"
                )
            else:
                await processing.edit_text(
                    f"<blockquote><b>❌ GAGAL CEK STATUS</b>\n\n"
                    f"Error: {result.get('error', 'Unknown error')}</blockquote>"
                )
        else:
            await processing.edit_text(
                f"<blockquote><b>❌ TRANSAKSI TIDAK DITEMUKAN</b>\n\n"
                f"ID: <code>{trx_id}</code></blockquote>"
            )
        
    except Exception as e:
        await message.reply_text(f"{ggl} Error: {str(e)[:100]}")

