from fansx import *
import requests
import aiohttp
import os
from pyrogram.enums import ChatAction
from pyrogram.types import Message
from urllib.parse import quote

__MODULE__ = "ꜰᴀᴋᴇꜱᴛᴏʀʏ ᴠ2"
__HELP__ = """
<blockquote><b>『 FAKE STORY V2 』</b>

<b>⌲ Perintah:</b>
ᚗ <code>{0}fsv2 [username]|[caption]</code> 
⊶ Membuat fake story dengan avatar custom

<b>⌲ Cara Pakai:</b>
1. Reply ke foto dengan format <code>.fsv2 username|caption</code>
2. Kirim foto + caption <code>.fsv2 username|caption</code>

<b>⌲ Contoh:</b>
<code>.fsv2 juicee90y|amel cantik</code></blockquote>
"""

# Base URL API (TANPA APIKEY)
BASE_URL = "https://api.deline.web.id/maker/fakestory"

async def upload_to_tmpfiles(file_path):
    """Upload gambar ke tmpfiles.org"""
    try:
        async with aiohttp.ClientSession() as session:
            data = aiohttp.FormData()
            data.add_field('file', 
                          open(file_path, 'rb'),
                          filename='image.jpg',
                          content_type='image/jpeg')
            
            async with session.post('https://tmpfiles.org/api/v1/upload', data=data, timeout=30) as resp:
                if resp.status == 200:
                    result = await resp.json()
                    if result.get('data') and result['data'].get('url'):
                        # Convert URL ke format download
                        url = result['data']['url']
                        download_url = url.replace('tmpfiles.org/', 'tmpfiles.org/dl/')
                        return download_url
    except Exception as e:
        print(f"Upload error: {e}")
    return None

@PY.UBOT("fsv2")
async def fake_story_v2(client: Client, message: Message):
    ggl = await EMO.GAGAL(client)
    sks = await EMO.BERHASIL(client)
    prs = await EMO.PROSES(client)
    
    try:
        await client.send_chat_action(message.chat.id, ChatAction.TYPING)
        
        # Ambil input
        args = message.text.split(maxsplit=1)
        if len(args) < 2:
            await message.reply_text(
                f"<blockquote><b>❌ FORMAT FAKESTORY V2</b>\n\n"
                f"<b>Cara pakai:</b>\n"
                f"1. Reply ke foto + ketik <code>.fsv2 username|caption</code>\n"
                f"2. Kirim foto + caption <code>.fsv2 username|caption</code>\n\n"
                f"<b>Contoh:</b>\n"
                f"<code>.fsv2 juicee90y|amel cantik</code></blockquote>"
            )
            return
        
        input_text = args[1]
        
        # Parse username dan caption
        if '|' in input_text:
            parts = input_text.split('|', 1)
            username = parts[0].strip()
            caption = parts[1].strip()
        else:
            # Kalo ga pake |, anggap semua sebagai caption, username default
            username = message.from_user.username or "user"
            caption = input_text
        
        # Cek apakah ada gambar
        file_path = None
        avatar_url = None
        
        # Cek reply ke gambar
        if message.reply_to_message:
            if message.reply_to_message.photo:
                file_path = await message.reply_to_message.download()
            elif message.reply_to_message.sticker:
                file_path = await message.reply_to_message.download()
            elif message.reply_to_message.document and message.reply_to_message.document.mime_type.startswith('image/'):
                file_path = await message.reply_to_message.download()
        
        # Cek kalo pesan itu sendiri ada gambar
        elif message.photo:
            file_path = await message.download()
        
        if not file_path:
            await message.reply_text(
                f"{ggl} <b>Reply ke gambar atau kirim gambar untuk dijadikan avatar!</b>"
            )
            return
        
        # Upload gambar ke server
        processing = await message.reply_text(f"{prs} <b>Mengupload avatar...</b>")
        avatar_url = await upload_to_tmpfiles(file_path)
        
        # Hapus file lokal
        if os.path.exists(file_path):
            os.remove(file_path)
        
        if not avatar_url:
            await processing.edit_text(f"{ggl} <b>Gagal upload gambar!</b>")
            return
        
        # Request ke API
        await processing.edit_text(f"{prs} <b>Membuat fake story...</b>")
        
        params = {
            "username": username,
            "caption": caption,
            "avatar": avatar_url
        }
        
        # Encode parameters
        query_string = '&'.join([f"{k}={quote(str(v))}" for k, v in params.items()])
        full_url = f"{BASE_URL}?{query_string}"
        
        try:
            async with aiohttp.ClientSession() as session:
                async with session.get(full_url, timeout=30) as resp:
                    if resp.status == 200:
                        # Cek tipe konten
                        content_type = resp.headers.get('Content-Type', '')
                        
                        if 'image' in content_type:
                            # Langsung gambar
                            image_data = await resp.read()
                            result_path = f"fstory_v2_{message.from_user.id}.jpg"
                            
                            with open(result_path, 'wb') as f:
                                f.write(image_data)
                            
                            await processing.delete()
                            
                            await client.send_photo(
                                chat_id=message.chat.id,
                                photo=result_path,
                                caption=f"<blockquote><b>📱 FAKE STORY V2</b>\n\n👤 @{username}\n💬 {caption}</blockquote>"
                            )
                            
                            if os.path.exists(result_path):
                                os.remove(result_path)
                        else:
                            # Kalo bukan gambar, mungkin error
                            error_text = await resp.text()
                            await processing.edit_text(f"{ggl} <b>API Error: {error_text[:100]}</b>")
                    else:
                        await processing.edit_text(f"{ggl} <b>HTTP Error: {resp.status}</b>")
                        
        except Exception as e:
            await processing.edit_text(f"{ggl} <b>Error: {str(e)[:100]}</b>")
        
    except Exception as e:
        await message.reply_text(f"{ggl} <b>Error: {str(e)[:100]}</b>")

@PY.UBOT("fakestory2")
async def fakestory2_alias(client: Client, message: Message):
    """Alias untuk fsv2"""
    await fake_story_v2(client, message)