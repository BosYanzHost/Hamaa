from fansx import *
import random
import requests
from pyrogram.enums import ChatAction, ParseMode
from pyrogram import filters
from pyrogram.types import Message

__MODULE__ = "sɪᴍɪ ᴀɪ"
__HELP__ = """
<blockquote><b>Bantuan Untuk simi ai

perintah : <code>{0}simi</code> [pesan]
    dapat mengobrol, tapi agak toxic

📌 Contoh:
<code>{0}simi hai</code>
<code>{0}simi apa kabar</code>
<code>{0}simi kamu siapa</code></b></blockquote>
"""

# Daftar API keys By Zyura (12 key)
API_KEYS = [
    "eIxUwMpn",
    "keoCFdc6",
    "bv7m372F",
    "iAiB9QKT",
    "JP7Cy8Y2",
    "GI4vPxYv",
    "HRPga9TN",
    "PDwqhVsj",
    "m8jpBeZR",
    "PXkxh5hw",
    "MFnlpM6A",
    "u299UiOF"
]

def get_random_apikey():
    """Mengambil API key secara random dari daftar"""
    return random.choice(API_KEYS)

# Base URL API
BASE_URL = "https://api.botcahx.eu.org/api/search/simsimi"

@PY.UBOT("simi")
@PY.TOP_CMD
async def simi_chat(client, message):
    try:
        await client.send_chat_action(message.chat.id, ChatAction.TYPING)

        if len(message.command) < 2:
            await message.reply_text(
                "<emoji id=5019523782004441717>❌</emoji> mohon gunakan format\n"
                "contoh : <code>.simi hai</code>"
            )
            return

        prs = await message.reply_text(f"<emoji id=5319230516929502602>🔍</emoji> Simi sedang mengetik...")
        query = message.text.split(' ', 1)[1]
        
        # Coba dengan beberapa API key
        success = False
        used_keys = set()  # Untuk melacak key yang sudah dicoba
        max_attempts = min(3, len(API_KEYS))  # Maksimal 3 percobaan
        
        for attempt in range(max_attempts):
            # Ambil API key yang belum dicoba
            available_keys = [key for key in API_KEYS if key not in used_keys]
            if not available_keys:
                break
                
            apikey = random.choice(available_keys)
            used_keys.add(apikey)
            
            try:
                # Buat URL dengan parameter
                params = {
                    "query": query,
                    "apikey": apikey
                }
                
                # Request ke API dengan timeout
                response = requests.get(BASE_URL, params=params, timeout=10)
                
                if response.status_code == 200:
                    json_response = response.json()
                    
                    # Cek struktur response dari botcahx
                    if json_response.get("status") and "result" in json_response:
                        x = json_response["result"]
                        
                        # Format pesan dengan key yang digunakan
                        reply_text = f"<blockquote>{x}</blockquote>\n"
                        reply_text += f"<blockquote><b>🔑 Key:</b> <code>{apikey[:8]}...</code></blockquote>"
                        
                        await prs.edit(reply_text)
                        success = True
                        break
                    elif "result" in json_response:
                        x = json_response["result"]
                        reply_text = f"<blockquote>{x}</blockquote>\n"
                        reply_text += f"<blockquote><b>🔑 Key:</b> <code>{apikey[:8]}...</code></blockquote>"
                        
                        await prs.edit(reply_text)
                        success = True
                        break
                    else:
                        # Jika format tidak sesuai, coba dengan key lain
                        continue
                else:
                    # Jika status code error, coba dengan key lain
                    continue
                    
            except requests.exceptions.Timeout:
                # Timeout, coba dengan key lain
                continue
            except requests.exceptions.ConnectionError:
                # Connection error, coba dengan key lain
                continue
            except Exception as e:
                # Error lain, coba dengan key lain
                continue
        
        if not success:
            await prs.edit(
                "<emoji id=5019523782004441717>❌</emoji> Maaf, Simi sedang sibuk.\n"
                "Silakan coba lagi nanti."
            )
            
    except Exception as e:
        await message.reply_text(f"❌ Error: {str(e)[:100]}")

@PY.BOT("simi")
async def simi_chat_bot(client, message):
    try:
        await client.send_chat_action(message.chat.id, ChatAction.TYPING)

        if len(message.command) < 2:
            await message.reply_text(
                "<emoji id=5019523782004441717>❌</emoji> mohon gunakan format\n"
                "contoh : <code>/simi hai</code>"
            )
            return

        prs = await message.reply_text(f"<emoji id=5319230516929502602>🔍</emoji> Simi sedang mengetik...")
        query = message.text.split(' ', 1)[1]
        
        # Coba dengan beberapa API key
        success = False
        used_keys = set()
        max_attempts = min(3, len(API_KEYS))
        
        for attempt in range(max_attempts):
            available_keys = [key for key in API_KEYS if key not in used_keys]
            if not available_keys:
                break
                
            apikey = random.choice(available_keys)
            used_keys.add(apikey)
            
            try:
                params = {
                    "query": query,
                    "apikey": apikey
                }
                
                response = requests.get(BASE_URL, params=params, timeout=10)
                
                if response.status_code == 200:
                    json_response = response.json()
                    
                    if json_response.get("status") and "result" in json_response:
                        x = json_response["result"]
                        reply_text = f"<blockquote>{x}</blockquote>"
                        
                        await prs.edit(reply_text)
                        success = True
                        break
                    elif "result" in json_response:
                        x = json_response["result"]
                        reply_text = f"<blockquote>{x}</blockquote>"
                        
                        await prs.edit(reply_text)
                        success = True
                        break
                    else:
                        continue
                else:
                    continue
                    
            except Exception:
                continue
        
        if not success:
            await prs.edit(
                "<emoji id=5019523782004441717>❌</emoji> Maaf, Simi sedang sibuk."
            )
            
    except Exception as e:
        await message.reply_text(f"❌ Error: {str(e)[:100]}")