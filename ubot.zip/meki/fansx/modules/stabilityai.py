import os
import requests
import random
from fansx import *

__MODULE__ = "sᴛᴀʙɪʟɪᴛʏ ᴀɪ"
__HELP__ = """
📚 <b>sᴛᴀʙɪʟɪᴛʏ ᴀɪ Commands</b>

<blockquote><b>🚦 Perintah : <code>{0}stabilityai [prompt]</code>
🦠 Penjelasan : Membuat gambar dengan AI (Txt2Img)

📝 Style yang tersedia:
• anime
• realistic
• cartoon
• fantasy
• cyberpunk
• oil_painting
• watercolor
• sketch
• pixel_art
• cinematic

📌 Contoh:
<code>{0}stabilityai cewek</code> (default style: realistic)
<code>{0}stabilityai cewek anime</code> (dengan style anime)
<code>{0}stabilityai kucing realistic</code> (dengan style realistic)</b></blockquote>
"""

# Base URL API
BASE_URL = "https://api.enzoxavier.biz.id/api/txt2img"

# Daftar style yang tersedia
STYLES = [
    "anime",
    "realistic",
    "cartoon",
    "fantasy",
    "cyberpunk",
    "oil_painting",
    "watercolor",
    "sketch",
    "pixel_art",
    "cinematic"
]

def parse_prompt(text):
    """
    Memisahkan prompt dan style dari input user
    """
    words = text.split()
    
    # Cek apakah kata terakhir adalah style yang valid
    if words and words[-1].lower() in STYLES:
        style = words[-1].lower()
        prompt = " ".join(words[:-1])
    else:
        style = "realistic"  # default style
        prompt = text
    
    return prompt, style

def fetch_image(prompt, style):
    """
    Fungsi untuk mengambil gambar dari API enzoxavier
    """
    params = {
        "prompt": prompt,
        "style": style
    }
    
    try:
        print(f"Mencoba generate: prompt='{prompt}', style='{style}'")
        response = requests.get(BASE_URL, params=params, timeout=45)
        
        if response.status_code == 200:
            data = response.json()
            
            if data.get("status") == 200 and data.get("url"):
                # Download gambar dari URL
                img_url = data["url"]
                print(f"Download gambar dari: {img_url}")
                
                img_response = requests.get(img_url, timeout=30)
                if img_response.status_code == 200:
                    return img_response.content
                else:
                    print(f"Gagal download gambar: HTTP {img_response.status_code}")
                    return None
            else:
                print(f"Response tidak valid: {data}")
                return None
        else:
            print(f"HTTP Error: {response.status_code}")
            return None
            
    except requests.exceptions.Timeout:
        print("Timeout error")
        return None
    except requests.exceptions.ConnectionError:
        print("Connection error")
        return None
    except Exception as e:
        print(f"Error: {str(e)}")
        return None

@PY.UBOT("stabilityai")
async def stabilityai_command(client, message):
    args = message.text.split(" ", 1)
    if len(args) < 2:
        style_list = ", ".join(STYLES)
        await message.reply_text(
            f"<blockquote><b>❌ Gunakan perintah:</b> <code>.stabilityai [prompt] [style]</code>\n\n"
            f"<b>Contoh:</b>\n"
            f"<code>.stabilityai cewek</code> (style: realistic)\n"
            f"<code>.stabilityai cewek anime</code>\n"
            f"<code>.stabilityai kucing realistic</code>\n\n"
            f"<b>Style yang tersedia:</b>\n"
            f"{style_list}</blockquote>"
        )
        return

    # Parse input
    user_input = args[1]
    prompt, style = parse_prompt(user_input)
    
    # Kirim pesan processing
    processing = await message.reply_text(
        f"<blockquote><b>🎨 Stability AI sedang menggambar...</b>\n\n"
        f"📝 <b>Prompt:</b> <code>{prompt[:50]}{'...' if len(prompt) > 50 else ''}</code>\n"
        f"🎭 <b>Style:</b> <code>{style}</code>\n"
        f"⏳ Mohon tunggu ±45 detik</blockquote>"
    )

    # Generate gambar
    image_content = fetch_image(prompt, style)
    
    if image_content:
        # Simpan gambar ke file temporary
        temp_file = f"stability_{random.randint(1000,9999)}.jpg"
        with open(temp_file, "wb") as f:
            f.write(image_content)
            
        # Buat caption
        caption = f"""
<blockquote><b>✅ STABILITY AI GENERATOR</b>

📝 <b>Prompt:</b> <code>{prompt[:100]}{'...' if len(prompt) > 100 else ''}</code>
🎭 <b>Style:</b> <code>{style}</code>
⚡ <b>Powered by:</b> Ubot Premium Zyura</blockquote>
"""
        
        # Kirim gambar
        await client.send_photo(
            chat_id=message.chat.id,
            photo=temp_file,
            caption=caption
        )
        
        # Hapus file temporary
        if os.path.exists(temp_file):
            os.remove(temp_file)
        
        await processing.delete()
        
    else:
        await processing.edit_text(
            "<blockquote><b>❌ Gagal membuat gambar!</b>\n\n"
            "🔴 Kemungkinan penyebab:\n"
            "• Server sedang sibuk\n"
            "• Prompt tidak sesuai\n"
            "• Style tidak tersedia\n\n"
            "🔄 Silakan coba lagi nanti dengan prompt berbeda.</blockquote>"
        )

@PY.BOT("stabilityai")
async def stabilityai_command_bot(client, message):
    args = message.text.split(" ", 1)
    if len(args) < 2:
        style_list = ", ".join(STYLES)
        await message.reply_text(
            f"❌ Gunakan: /stabilityai [prompt] [style]\n\n"
            f"Style: {style_list}"
        )
        return

    # Parse input
    user_input = args[1]
    prompt, style = parse_prompt(user_input)
    
    processing = await message.reply_text(f"🎨 Generating: {prompt[:30]}... (style: {style})")

    # Generate gambar
    image_content = fetch_image(prompt, style)
    
    if image_content:
        temp_file = f"stability_{random.randint(1000,9999)}.jpg"
        with open(temp_file, "wb") as f:
            f.write(image_content)
        
        await client.send_photo(
            chat_id=message.chat.id,
            photo=temp_file,
            caption=f"<b>Prompt:</b> {prompt[:100]}\n<b>Style:</b> {style}"
        )
        
        os.remove(temp_file)
        await processing.delete()
    else:
        await processing.edit_text("❌ Gagal membuat gambar")