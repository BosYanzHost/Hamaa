from fansx import *
import aiohttp
import asyncio
import os
import random
from pyrogram.enums import ChatAction, ParseMode
from pyrogram.types import Message

__MODULE__ = "ʙʏᴘᴀss ᴄɪᴛʏ"
__HELP__ = """
<blockquote><b>🔓 BYPASS CITY LINK</b>

<b>⌲ Perintah:</b>
ᚗ <code>{0}bypass [url]</code> - Bypass link City
ᚗ <code>{0}bpc [url]</code> - Singkatan

<b>⌲ Contoh:</b>
<code>.bypass https://rumahotp.com</code>
<code>.bpc https://short.cm/xxx</code></blockquote>
"""

# ============================================
# KONFIGURASI
# ============================================
BYPASS_API = "https://anabot.my.id/api/tools/bypassCity"
API_KEY = "freeApikey"  # Bisa diganti nanti

async def bypass_city_url(target_url):
    """Bypass link City"""
    url = f"{BYPASS_API}?url={target_url}&apikey={API_KEY}"
    
    try:
        async with aiohttp.ClientSession() as session:
            async with session.get(url, timeout=30) as response:
                if response.status == 200:
                    data = await response.json()
                    
                    # Cek format respons
                    if data.get("status") == "success" and data.get("result"):
                        return {
                            "success": True,
                            "original_url": data.get("original_url"),
                            "result": data.get("result"),
                            "message": data.get("message", "Berhasil bypass")
                        }
                    elif data.get("result"):
                        # Format alternatif
                        return {
                            "success": True,
                            "result": data.get("result"),
                            "message": data.get("message", "Berhasil bypass")
                        }
                    else:
                        return {
                            "success": False,
                            "error": "Format respons tidak dikenali",
                            "data": data
                        }
                else:
                    return {"success": False, "error": f"HTTP {response.status}"}
    except asyncio.TimeoutError:
        return {"success": False, "error": "Timeout - server terlalu lambat"}
    except Exception as e:
        return {"success": False, "error": str(e)}

@PY.UBOT("bypass")
@PY.UBOT("bpc")
async def bypass_command(client: Client, message: Message):
    ggl = await EMO.GAGAL(client)
    sks = await EMO.BERHASIL(client)
    prs = await EMO.PROSES(client)
    
    # Parse URL dari argumen
    args = message.text.split()
    if len(args) < 2:
        await message.reply_text(
            f"<blockquote><b>⚠️ FORMAT SALAH</b>\n\n"
            f"<b>Cara pakai:</b> <code>.bypass [url]</code>\n"
            f"<b>Contoh:</b> <code>.bypass https://rumahotp.com</code>\n\n"
            f"<b>Atau pake singkatan:</b>\n"
            f"<code>.bpc https://short.cm/xxx</code></blockquote>"
        )
        return
    
    target_url = args[1].strip()
    
    # Validasi URL simple
    if not target_url.startswith(('http://', 'https://')):
        target_url = 'https://' + target_url
    
    try:
        await client.send_chat_action(message.chat.id, ChatAction.TYPING)
        
        processing = await message.reply_text(f"{prs} <b>Membypass link...</b>\n<code>{target_url}</code>")
        
        result = await bypass_city_url(target_url)
        
        await processing.delete()
        
        if result.get("success"):
            result_url = result.get("result") or result.get("original_url")
            
            # Format pesan sukses
            text = f"<blockquote><b>BYPASS BERHASIL ✅</b>\n\n"
            text += f"<b>📥 Link asli:</b>\n<code>{target_url}</code>\n\n"
            text += f"<b>📤 Hasil bypass:</b>\n<code>{result_url}</code>\n\n"
            
            if result.get("message"):
                text += f"<b>ℹ️ Info:</b> {result['message']}\n"
            
            text += f"\n⚡ Powered by: Ubot Premium Zyura</blockquote>"
            
            await message.reply_text(text)
            
            # Kirim pesan sukses singkat juga
            await message.reply_text(f"{sks} <b>Berhasil bypass link!</b>")
            
        else:
            error_msg = result.get("error", "Unknown error")
            await message.reply_text(
                f"<blockquote><b>❌ GAGAL BYPASS</b>\n\n"
                f"<b>Link:</b> <code>{target_url}</code>\n"
                f"<b>Error:</b> {error_msg}</blockquote>"
            )
        
    except Exception as e:
        await message.reply_text(f"{ggl} <b>Error: {str(e)[:100]}</b>")

@PY.UBOT("bypasssetkey")
async def bypass_setkey(client: Client, message: Message):
    """Set API key bypass (khusus admin)"""
    ggl = await EMO.GAGAL(client)
    sks = await EMO.BERHASIL(client)
    
    # Cek admin (sesuaikan dengan sistem admin di base)
    # if not message.from_user.id in ADMIN_IDS:
    #     return await message.reply_text(f"{ggl} <b>Khusus admin!</b>")
    
    args = message.text.split()
    if len(args) < 2:
        await message.reply_text(
            f"<blockquote><b>⚠️ FORMAT SALAH</b>\n\n"
            f"<b>Cara pakai:</b> <code>.bypasssetkey [apikey_baru]</code>\n"
            f"<b>Contoh:</b> <code>.bypasssetkey apikey123</code></blockquote>"
        )
        return
    
    global API_KEY
    new_key = args[1].strip()
    API_KEY = new_key
    
    await message.reply_text(f"{sks} <b>API Key bypass berhasil diupdate!</b>")