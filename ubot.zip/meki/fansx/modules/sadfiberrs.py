from fansx import *
import requests
import aiohttp
import os
import random
from pyrogram.enums import ChatAction, ParseMode
from pyrogram.types import Message

__MODULE__ = "sᴀᴅ ᴍᴜsɪᴄ"
__HELP__ = """
<blockquote><b>『 SAD MUSIC PLAYER 』</b>

<b>⌲ Perintah:</b>
ᚗ <code>{0}sad1</code> - <code>{0}sad55</code> 
⊶ Memutar musik sedih

<b>⌲ Contoh:</b>
<code>.sad1</code>
<code>.sad25</code>
<code>.sad50</code></blockquote>
"""

# Base URL untuk musik sedih
SAD_MUSIC_BASE = "https://raw.githubusercontent.com/Leoo7z/Music/main/sad-music"

# Daftar musik sedih dari sad1 sampai sad55
SAD_MUSIC_LIST = [f"sad{i}" for i in range(1, 56)]

async def download_sad_music(url):
    """Download musik sedih dari URL"""
    try:
        async with aiohttp.ClientSession() as session:
            async with session.get(url, timeout=30) as response:
                if response.status == 200:
                    return await response.read()
    except Exception as e:
        print(f"Error download sad music: {e}")
    return None

# Generate handler untuk sad1 - sad55
for i in range(1, 56):
    music_name = f"sad{i}"
    
    # Buat decorator dan fungsi secara dinamis
    exec(f"""
@PY.UBOT("{music_name}")
async def {music_name}_handler(client: Client, message: Message):
    await play_sad_music(client, message, "{music_name}")
    """)

async def play_sad_music(client: Client, message: Message, music_name: str):
    ggl = await EMO.GAGAL(client)
    sks = await EMO.BERHASIL(client)
    prs = await EMO.PROSES(client)
    
    try:
        await client.send_chat_action(message.chat.id, ChatAction.TYPING)
        
        # Cek apakah musik valid
        if music_name not in SAD_MUSIC_LIST:
            await message.reply_text(f"{ggl} <b>Musik '{music_name}' tidak ditemukan!</b>")
            return
        
        # URL musik sedih
        music_url = f"{SAD_MUSIC_BASE}/{music_name}.mp3"
        
        # Kirim pesan processing
        processing = await message.reply_text(f"{prs} <b>Memutar {music_name}...</b>")
        
        # Kirim langsung dari URL (tanpa download) biar lebih cepat
        try:
            await processing.delete()
            
            # Kirim audio langsung dari URL
            await client.send_audio(
                chat_id=message.chat.id,
                audio=music_url,
                caption=f"<blockquote><b>😢 {music_name}</b></blockquote>"
            )
        except Exception as e:
            # Fallback: download dulu kalo gagal
            audio_data = await download_sad_music(music_url)
            
            if audio_data:
                file_path = f"{music_name}_{message.from_user.id}.mp3"
                with open(file_path, 'wb') as f:
                    f.write(audio_data)
                
                await client.send_audio(
                    chat_id=message.chat.id,
                    audio=file_path,
                    caption=f"<blockquote><b>😢 {music_name}</b></blockquote>"
                )
                
                if os.path.exists(file_path):
                    os.remove(file_path)
            else:
                await message.reply_text(f"{ggl} <b>Gagal memuat musik!</b>")
        
    except Exception as e:
        await message.reply_text(f"{ggl} <b>Error: {str(e)[:100]}</b>")

@PY.UBOT("sadlist")
async def sad_music_list(client: Client, message: Message):
    """Menampilkan daftar musik sedih yang tersedia"""
    
    text = "<blockquote><b>📋 DAFTAR SAD MUSIC</b>\n\n"
    
    # Tampilkan dalam beberapa baris (10 per baris)
    rows = [SAD_MUSIC_LIST[i:i+10] for i in range(0, len(SAD_MUSIC_LIST), 10)]
    for row in rows:
        text += " • " + ", ".join(row) + "\n"
    
    text += f"\n<b>📊 Total:</b> {len(SAD_MUSIC_LIST)} musik\n\n"
    text += "<b>💡 Cara pakai:</b>\n"
    text += "• <code>.sad1</code>\n"
    text += "• <code>.sad25</code>\n"
    text += "• <code>.sad50</code></blockquote>"
    
    await message.reply_text(text)

@PY.UBOT("sadrange")
async def sad_music_range(client: Client, message: Message):
    """Menampilkan musik sedih berdasarkan range"""
    args = message.text.split()
    
    if len(args) < 3:
        await message.reply_text(
            f"<blockquote><b>❌ Format salah!</b>\n\n"
            f"<b>Contoh:</b>\n"
            f"<code>.sadrange 1 10</code> (menampilkan sad1-sad10)</blockquote>"
        )
        return
    
    try:
        start = int(args[1])
        end = int(args[2])
        
        if start < 1 or end > 55 or start > end:
            await message.reply_text(f"{ggl} <b>Range tidak valid! (1-55)</b>")
            return
        
        music_range = [f"sad{i}" for i in range(start, end+1)]
        
        text = f"<blockquote><b>📋 SAD MUSIC {start}-{end}</b>\n\n"
        text += " • " + ", ".join(music_range) + "\n\n"
        text += f"<b>📊 Total:</b> {len(music_range)} musik</blockquote>"
        
        await message.reply_text(text)
        
    except ValueError:
        await message.reply_text(f"{ggl} <b>Masukkan angka yang valid!</b>")

@PY.UBOT("sadsearch")
async def sad_music_search(client: Client, message: Message):
    """Mencari musik sedih berdasarkan keyword"""
    args = message.text.split(maxsplit=1)
    
    if len(args) < 2:
        await message.reply_text(
            f"<blockquote><b>❌ Masukkan keyword!</b>\n\n"
            f"<b>Contoh:</b>\n"
            f"<code>.sadsearch sad1</code></blockquote>"
        )
        return
    
    keyword = args[1].lower()
    
    # Cari musik yang mengandung keyword
    found = [m for m in SAD_MUSIC_LIST if keyword in m]
    
    if not found:
        await message.reply_text(f"{ggl} <b>Tidak ada musik dengan keyword '{keyword}'</b>")
        return
    
    text = f"<blockquote><b>📋 HASIL PENCARIAN: {keyword}</b>\n\n"
    text += " • " + ", ".join(found) + "\n\n"
    text += f"<b>📊 Ditemukan:</b> {len(found)} musik</blockquote>"
    
    await message.reply_text(text)

@PY.UBOT("sadrandom")
async def sad_music_random(client: Client, message: Message):
    """Memutar musik sedih secara random"""
    import random
    
    # Pilih musik random
    random_music = random.choice(SAD_MUSIC_LIST)
    
    await play_sad_music(client, message, random_music)

@PY.UBOT("sadplay")
async def sad_music_play(client: Client, message: Message):
    """Memutar musik sedih berdasarkan nomor"""
    args = message.text.split()
    
    if len(args) < 2:
        await message.reply_text(
            f"<blockquote><b>❌ Masukkan nomor musik!</b>\n\n"
            f"<b>Contoh:</b>\n"
            f"<code>.sadplay 25</code> (memutar sad25)</blockquote>"
        )
        return
    
    try:
        num = int(args[1])
        if num < 1 or num > 55:
            await message.reply_text(f"{ggl} <b>Nomor harus antara 1-55!</b>")
            return
        
        music_name = f"sad{num}"
        await play_sad_music(client, message, music_name)
        
    except ValueError:
        await message.reply_text(f"{ggl} <b>Masukkan angka yang valid!</b>")

@PY.BOT("sad1")
async def sad_music_bot_handler(client: Client, message: Message):
    """Handler untuk bot"""
    music_name = message.text.split()[0].replace('/', '')
    await play_sad_music_bot(client, message, music_name)

async def play_sad_music_bot(client: Client, message: Message, music_name: str):
    try:
        if music_name not in SAD_MUSIC_LIST:
            await message.reply_text(f"❌ Musik '{music_name}' tidak ditemukan!")
            return
        
        music_url = f"{SAD_MUSIC_BASE}/{music_name}.mp3"
        
        processing = await message.reply_text(f"🔍 Memutar {music_name}...")
        
        await processing.delete()
        
        await client.send_audio(
            chat_id=message.chat.id,
            audio=music_url,
            caption=f"😢 {music_name}"
        )
        
    except Exception as e:
        await message.reply_text(f"❌ Error: {str(e)[:100]}")