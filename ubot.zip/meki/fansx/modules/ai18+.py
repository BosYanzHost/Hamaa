from fansx import *
import requests
import aiohttp
import asyncio
from pyrogram.enums import ChatAction, ParseMode
from pyrogram.types import Message
from urllib.parse import quote

__MODULE__ = "ᴀɪ ʜʏᴘᴇʀ"
__HELP__ = """
<blockquote><b>『 AI HYPER 』</b>

<b>⌲ Perintah:</b>
ᚗ <code>{0}hyper [pertanyaan]</code> 
⊶ Bertanya dengan AI mode hyper (21++)

<b>⌲ Contoh:</b>
<code>.hyper apa itu ai?</code>
<code>.hyper jelaskan tentang coding</code>
<code>.hyper manga sange</code></blockquote>
"""

# Base URL API (TANPA APIKEY)
BASE_URL = "https://api-faa.my.id/faa/ai-hyper"

async def call_hyper_api(query, retry_count=0, max_retries=2):
    """Panggil API Hyper dengan retry"""
    
    params = {"text": query}
    
    print(f"🔄 Mencoba API Hyper (percobaan ke-{retry_count + 1})...")
    
    try:
        async with aiohttp.ClientSession() as session:
            async with session.get(BASE_URL, params=params, timeout=30) as response:
                if response.status == 200:
                    data = await response.json()
                    
                    if data.get("status") and data.get("result"):
                        return {
                            'success': True,
                            'result': data['result'],
                            'mode': data.get('mode', 'Hyper 21++')
                        }
                    else:
                        error_msg = data.get('result', 'Unknown error')
                        raise Exception(error_msg)
                else:
                    raise Exception(f"HTTP {response.status}")
                    
    except Exception as e:
        if retry_count < max_retries - 1:
            print(f"❌ Percobaan {retry_count + 1} gagal: {e}")
            await asyncio.sleep(2)
            return await call_hyper_api(query, retry_count + 1, max_retries)
        
        return {
            'success': False,
            'error': str(e)
        }

@PY.UBOT("hyper")
async def hyper_ai(client: Client, message: Message):
    ggl = await EMO.GAGAL(client)
    sks = await EMO.BERHASIL(client)
    prs = await EMO.PROSES(client)
    
    try:
        await client.send_chat_action(message.chat.id, ChatAction.TYPING)
        
        # Ambil query
        args = message.text.split(maxsplit=1)
        if len(args) < 2:
            await message.reply_text(
                f"<blockquote><b>❌ Masukkan pertanyaan!</b>\n\n"
                f"<b>Contoh:</b>\n"
                f"<code>.hyper apa itu ai?</code>\n"
                f"<code>.hyper manga sange</code></blockquote>"
            )
            return
        
        query = args[1].strip()
        
        # Kirim pesan processing
        processing = await message.reply_text(f"{prs} <b>AI Hyper sedang berpikir...</b>")
        
        # Panggil API
        result = await call_hyper_api(query)
        
        if result.get('success'):
            await processing.delete()
            
            # Format pesan
            response_text = result['result']
            mode = result.get('mode', 'Hyper 21++')
            
            # Kirim hasil
            await message.reply_text(
                f"<blockquote><b>🤖 {mode}</b>\n\n"
                f"{response_text}\n\n"
                f"⚡ <b>Powered by:</b> Ubot Premium Zyura | API-Faa</blockquote>"
            )
        else:
            error_msg = result.get('error', 'Unknown error')
            
            # Handle khusus untuk konten dewasa
            if "tidak dapat membantu" in error_msg.lower():
                await processing.edit_text(
                    f"{ggl} <b>Maaf, AI tidak dapat menjawab pertanyaan tersebut.</b>\n\n"
                    f"💡 Coba dengan pertanyaan yang lebih umum."
                )
            else:
                await processing.edit_text(
                    f"{ggl} <b>Gagal mendapatkan respons!</b>\n\n"
                    f"Error: {error_msg}"
                )
        
    except asyncio.TimeoutError:
        await message.reply_text(f"{ggl} <b>Timeout! Server sedang sibuk.</b>")
    except aiohttp.ClientError as e:
        await message.reply_text(f"{ggl} <b>Gagal terhubung ke server: {str(e)[:100]}</b>")
    except Exception as e:
        await message.reply_text(f"{ggl} <b>Error: {str(e)[:100]}</b>")

@PY.UBOT("aihyper")
async def aihyper_alias(client: Client, message: Message):
    """Alias untuk hyper"""
    await hyper_ai(client, message)

@PY.BOT("hyper")
async def hyper_ai_bot(client: Client, message: Message):
    """Handler untuk bot"""
    try:
        args = message.text.split(maxsplit=1)
        if len(args) < 2:
            await message.reply_text(
                "❌ Masukkan pertanyaan!\n"
                "Contoh: /hyper apa itu ai?"
            )
            return
        
        query = args[1].strip()
        
        processing = await message.reply_text("🔍 AI Hyper sedang berpikir...")
        
        result = await call_hyper_api(query)
        
        await processing.delete()
        
        if result.get('success'):
            await message.reply_text(result['result'])
        else:
            await message.reply_text(f"❌ Gagal: {result.get('error', 'Unknown error')}")
        
    except Exception as e:
        await message.reply_text(f"❌ Error: {str(e)[:100]}")