from fansx import *
import random
import requests
from pyrogram.enums import ChatAction, ParseMode
from pyrogram import filters
from pyrogram.types import Message

__MODULE__ = "ᴀɪ"
__HELP__ = """
<blockquote><b>「Bantuan Untuk AI」

⪩ Perintah : <code>{0}ai</code>
   ↝fitur untuk menu ai
   
⪩ Example : <code>{0}ai</code> halo</b></blockquote>
"""

API_KEYS = [

    "eIxUwMpn",
    "keoCFdc6",
    "bv7m372F",
    "iAiB9QKT",
    "JP7Cy8Y2",
    "GI4vPxYv",
    "HRPga9TN",
    "PDwqhVsj",
    "m8jpBeZR",
    "PXkxh5hw",
    "MFnlpM6A",
    "u299UiOF"
    
]

def get_random_apikey():
    """Mengambil API key secara random dari daftar"""
    return random.choice(API_KEYS)

@PY.UBOT("ai")
@PY.TOP_CMD
async def chat_gpt(client, message):
    try:
        await client.send_chat_action(message.chat.id, ChatAction.TYPING)

        if len(message.command) < 2:
            await message.reply_text(
                "<emoji id=5019523782004441717>❌</emoji>mohon gunakan format\ncontoh : .ai halo"
            )
        else:
            prs = await message.reply_text(f"<emoji id=6226405134004389590>🔍</emoji>proccesing....")
            a = message.text.split(' ', 1)[1]
            
            # Ambil API key secara random
            apikey = get_random_apikey()
            
            # Coba dengan API key pertama, jika gagal coba dengan yang lain
            for i in range(3):  # Coba maksimal 3 kali dengan key berbeda
                try:
                    response = requests.get(f'https://api.botcahx.eu.org/api/search/openai-chat?text={a}&apikey={apikey}')
                    
                    if response.status_code == 200:
                        json_response = response.json()
                        if "message" in json_response:
                            x = json_response["message"]                  
                            await prs.edit(f"<blockquote>{x}</blockquote>")
                            return
                        else:
                            # Jika key tidak valid, ganti dengan yang lain
                            apikey = get_random_apikey()
                            continue
                    else:
                        apikey = get_random_apikey()
                        continue
                        
                except Exception as e:
                    apikey = get_random_apikey()
                    continue
            
            # Jika semua percobaan gagal
            await prs.edit("<emoji id=5019523782004441717>❌</emoji>Maaf, sedang mengalami kendala. Silakan coba lagi nanti.")
            
    except Exception as e:
        await message.reply_text(f"{e}")
        
        
@PY.BOT("ai")
async def chat_gpt(client, message):
    try:
        await client.send_chat_action(message.chat.id, ChatAction.TYPING)

        if len(message.command) < 2:
            await message.reply_text(
                "<emoji id=5019523782004441717>❌</emoji>Gunakan perintah /ai sejarah Indonesia contoh untuk mananyakan!!"
            )
        else:
            prs = await message.reply_text(f"<emoji id=6226405134004389590>🔍</emoji>proccesing....")
            a = message.text.split(' ', 1)[1]
            
            # Ambil API key secara random
            apikey = get_random_apikey()
            
            # Coba dengan API key pertama, jika gagal coba dengan yang lain
            for i in range(3):  # Coba maksimal 3 kali dengan key berbeda
                try:
                    response = requests.get(f'https://api.botcahx.eu.org/api/search/openai-chat?text={a}&apikey={apikey}')
                    
                    if response.status_code == 200:
                        json_response = response.json()
                        if "message" in json_response:
                            x = json_response["message"]                  
                            await prs.edit(f"<blockquote>{x}</blockquote>")
                            return
                        else:
                            # Jika key tidak valid, ganti dengan yang lain
                            apikey = get_random_apikey()
                            continue
                    else:
                        apikey = get_random_apikey()
                        continue
                        
                except Exception as e:
                    apikey = get_random_apikey()
                    continue
            
            # Jika semua percobaan gagal
            await prs.edit("<emoji id=5019523782004441717>❌</emoji>Maaf, sedang mengalami kendala. Silakan coba lagi nanti.")
            
    except Exception as e:
        await message.reply_text(f"{e}")