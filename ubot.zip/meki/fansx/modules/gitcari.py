from fansx import *
import aiohttp
import asyncio
import random
import os
import zipfile
import shutil
from urllib.parse import quote
from pyrogram.enums import ChatAction, ParseMode
from pyrogram.types import Message

__MODULE__ = "ɢɪᴛʜᴜʙ sᴇᴀʀᴄʜ"
__HELP__ = """
<blockquote><b>🐙 GITHUB REPOSITORY SEARCH</b>

<b>⌲ Perintah:</b>
ᚗ <code>{0}gitcari [nama repo]</code> - Cari repository di GitHub

<b>⌲ Contoh:</b>
<code>.gitcari telegram bot</code>
<code>.gitcari machine learning</code>
<code>.gitcari discord.py</code></blockquote>
"""

# ============================================
# KONFIGURASI
# ============================================
GITHUB_API = "https://api.github.com/search/repositories"

async def search_repositories(query):
    """Mencari repository di GitHub"""
    try:
        headers = {
            "Accept": "application/vnd.github.v3+json",
            "User-Agent": "Mozilla/5.0 (compatible; TelegramBot)"
        }
        
        params = {
            "q": query,
            "sort": "stars",
            "order": "desc",
            "per_page": 30
        }
        
        async with aiohttp.ClientSession() as session:
            async with session.get(GITHUB_API, headers=headers, params=params, timeout=15) as response:
                if response.status == 200:
                    data = await response.json()
                    return {
                        "success": True,
                        "total": data.get("total_count", 0),
                        "items": data.get("items", [])
                    }
                else:
                    return {
                        "success": False,
                        "error": f"HTTP {response.status}"
                    }
    except asyncio.TimeoutError:
        return {"success": False, "error": "Timeout"}
    except Exception as e:
        return {"success": False, "error": str(e)}

async def download_repo(repo_url, repo_name):
    """Download repository sebagai ZIP"""
    try:
        # GitHub archive URL
        zip_url = f"{repo_url}/archive/refs/heads/main.zip"
        
        # Coba branch main dulu
        async with aiohttp.ClientSession() as session:
            async with session.get(zip_url, timeout=60) as response:
                if response.status == 200:
                    zip_data = await response.read()
                    
                    # Simpan ZIP sementara
                    zip_file = f"{repo_name}_{random.randint(1000,9999)}.zip"
                    with open(zip_file, "wb") as f:
                        f.write(zip_data)
                    
                    return {
                        "success": True,
                        "file": zip_file,
                        "size": len(zip_data)
                    }
                else:
                    # Coba branch master
                    zip_url = f"{repo_url}/archive/refs/heads/master.zip"
                    async with session.get(zip_url, timeout=60) as response2:
                        if response2.status == 200:
                            zip_data = await response2.read()
                            zip_file = f"{repo_name}_{random.randint(1000,9999)}.zip"
                            with open(zip_file, "wb") as f:
                                f.write(zip_data)
                            return {
                                "success": True,
                                "file": zip_file,
                                "size": len(zip_data)
                            }
                        else:
                            return {"success": False, "error": "Tidak bisa download repository"}
    except Exception as e:
        return {"success": False, "error": str(e)}

async def upload_to_catbox(file_path):
    """Upload file ke catbox.moe"""
    try:
        async with aiohttp.ClientSession() as session:
            data = aiohttp.FormData()
            data.add_field('fileToUpload', 
                          open(file_path, 'rb'),
                          filename=os.path.basename(file_path),
                          content_type='application/zip')
            data.add_field('reqtype', 'fileupload')
            
            async with session.post('https://catbox.moe/user/api.php', data=data, timeout=60) as resp:
                if resp.status == 200:
                    url = await resp.text()
                    return url.strip()
    except Exception as e:
        print(f"Catbox upload error: {e}")
    return None

def format_size(size_bytes):
    """Format ukuran file"""
    for unit in ['B', 'KB', 'MB', 'GB']:
        if size_bytes < 1024.0:
            return f"{size_bytes:.1f} {unit}"
        size_bytes /= 1024.0
    return f"{size_bytes:.1f} GB"

@PY.UBOT("gitcari")
async def github_search(client: Client, message: Message):
    ggl = await EMO.GAGAL(client)
    sks = await EMO.BERHASIL(client)
    prs = await EMO.PROSES(client)
    
    try:
        await client.send_chat_action(message.chat.id, ChatAction.TYPING)
        
        # Ambil query
        args = message.text.split(maxsplit=1)
        if len(args) < 2:
            await message.reply_text(
                f"<blockquote><b>❌ Masukkan nama repository!</b>\n\n"
                f"<b>Contoh:</b>\n"
                f"<code>.gitcari telegram bot</code>\n"
                f"<code>.gitcari machine learning</code></blockquote>"
            )
            return
        
        query = args[1].strip()
        
        # Kirim pesan processing
        processing = await message.reply_text(f"{prs} <b>Mencari repository '{query}' di GitHub...</b>")
        
        # Cari repository
        result = await search_repositories(query)
        
        if not result.get("success"):
            await processing.edit_text(f"{ggl} <b>Gagal mencari: {result.get('error')}</b>")
            return
        
        items = result.get("items", [])
        total = result.get("total", 0)
        
        if not items:
            await processing.edit_text(f"{ggl} <b>Tidak ada repository ditemukan untuk '{query}'</b>")
            return
        
        # Pilih random repository
        repo = random.choice(items)
        
        repo_name = repo.get("name", "unknown")
        repo_full = repo.get("full_name", "unknown")
        repo_url = repo.get("html_url", "")
        repo_desc = repo.get("description", "Tidak ada deskripsi")
        repo_stars = repo.get("stargazers_count", 0)
        repo_forks = repo.get("forks_count", 0)
        repo_lang = repo.get("language", "Tidak diketahui")
        repo_owner = repo.get("owner", {}).get("login", "unknown")
        
        await processing.edit_text(
            f"{prs} <b>Repository dipilih:</b> {repo_full}\n"
            f"⭐ {repo_stars} stars | 🍴 {repo_forks} forks\n"
            f"{prs} <b>Mendownload repository...</b>"
        )
        
        # Download repository
        download_result = await download_repo(repo_url, repo_name)
        
        if not download_result.get("success"):
            await processing.edit_text(f"{ggl} <b>Gagal download: {download_result.get('error')}</b>")
            return
        
        zip_file = download_result["file"]
        file_size = download_result["size"]
        
        await processing.edit_text(f"{prs} <b>Mengupload ke catbox.moe...</b>")
        
        # Upload ke catbox
        download_url = await upload_to_catbox(zip_file)
        
        # Hapus file ZIP
        if os.path.exists(zip_file):
            os.remove(zip_file)
        
        if not download_url:
            await processing.edit_text(f"{ggl} <b>Gagal upload ke catbox!</b>")
            return
        
        await processing.delete()
        
        # Format output
        size_formatted = format_size(file_size)
        short_desc = repo_desc[:200] + "..." if len(repo_desc) > 200 else repo_desc
        
        result_text = f"""
<blockquote><b>🐙 GITHUB REPOSITORY</b>

📌 <b>Nama:</b> <a href='{repo_url}'>{repo_full}</a>
👤 <b>Owner:</b> {repo_owner}
⭐ <b>Stars:</b> {repo_stars:,}
🍴 <b>Forks:</b> {repo_forks:,}
🔤 <b>Language:</b> {repo_lang}
📝 <b>Deskripsi:</b> {short_desc}

📦 <b>Download:</b> <a href='{download_url}'>ZIP Archive</a>
📊 <b>Ukuran:</b> {size_formatted}

⚡ <b>Powered by:</b> Ubot Premium Zyura</blockquote>"""
        
        await message.reply_text(result_text)
        
    except Exception as e:
        await message.reply_text(f"{ggl} <b>Error: {str(e)[:100]}</b>")

