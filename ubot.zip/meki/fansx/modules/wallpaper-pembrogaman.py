from fansx import *
import aiohttp
import asyncio
import random
import os
from pyrogram.enums import ChatAction
from pyrogram.types import Message

__MODULE__ = "ᴡᴀʟʟᴘᴀᴘᴇʀ ᴘʀᴏɢʀᴀᴍɪɴɢ"
__HELP__ = """
<blockquote><b>🖥️ WALLPAPER PROGRAMMING</b>

<b>⌲ Perintah:</b>
ᚗ <code>{0}wallpaper</code> - Ambil random wallpaper programming
ᚗ <code>{0}wp</code> - Singkatan

<b>⌲ Contoh:</b>
<code>.wallpaper</code>
<code>.wp</code></blockquote>
"""

# ============================================
# DAFTAR API KEYS
# ============================================
API_KEYS = [
    "eIxUwMpn",
    "keoCFdc6",
    "bv7m372F",
    "iAiB9QKT",
    "JP7Cy8Y2",
    "GI4vPxYv",
    "HRPga9TN",
    "PDwqhVsj",
    "m8jpBeZR",
    "PXkxh5hw",
    "MFnlpM6A",
    "u299UiOF",
    "vQs76jBD"
]

# Base URL
BASE_URL = "https://api.botcahx.eu.org/api/wallpaper/programing"

def get_random_apikey():
    """Mengambil API key random"""
    return random.choice(API_KEYS)

async def get_wallpaper():
    """Ambil wallpaper dari API"""
    apikey = get_random_apikey()
    url = f"{BASE_URL}?apikey={apikey}"
    
    try:
        async with aiohttp.ClientSession() as session:
            async with session.get(url, timeout=15) as response:
                if response.status == 200:
                    # Cek content-type
                    content_type = response.headers.get("Content-Type", "")
                    
                    if "image" in content_type:
                        # Jika langsung gambar
                        return {
                            "success": True,
                            "image": await response.read(),
                            "api_key": apikey
                        }
                    else:
                        # Jika bukan gambar, mungkin error
                        return {
                            "success": False,
                            "error": "API tidak mengembalikan gambar",
                            "api_key": apikey
                        }
                else:
                    return {
                        "success": False,
                        "error": f"HTTP {response.status}",
                        "api_key": apikey
                    }
    except asyncio.TimeoutError:
        return {"success": False, "error": "Timeout", "api_key": apikey}
    except Exception as e:
        return {"success": False, "error": str(e), "api_key": apikey}

@PY.UBOT("wallpaper")
@PY.UBOT("wp")
async def wallpaper_command(client: Client, message: Message):
    ggl = await EMO.GAGAL(client)
    sks = await EMO.BERHASIL(client)
    prs = await EMO.PROSES(client)
    
    try:
        await client.send_chat_action(message.chat.id, ChatAction.UPLOAD_PHOTO)
        
        processing = await message.reply_text(f"{prs} <b>Mencari wallpaper programming...</b>")
        
        # Coba dengan beberapa key jika gagal
        max_attempts = 3
        result = None
        
        for attempt in range(max_attempts):
            result = await get_wallpaper()
            if result.get("success"):
                break
            await asyncio.sleep(1)
        
        if result and result.get("success") and result.get("image"):
            # Simpan gambar sementara
            file_path = f"wp_prog_{message.from_user.id}_{random.randint(1000,9999)}.jpg"
            with open(file_path, "wb") as f:
                f.write(result["image"])
            
            await processing.delete()
            
            # Kirim gambar
            await client.send_photo(
                chat_id=message.chat.id,
                photo=file_path,
                caption=f"<blockquote><b>🖥️ WALLPAPER PROGRAMMING</b></blockquote>"
            )
            
            # Hapus file
            if os.path.exists(file_path):
                os.remove(file_path)
        else:
            error_msg = result.get("error", "Unknown error") if result else "Gagal setelah 3 percobaan"
            api_key = result.get("api_key", "?") if result else "?"
            
            await processing.edit_text(
                f"<blockquote><b>❌ GAGAL MENGAMBIL WALLPAPER</b>\n\n"
                f"Error: {error_msg}\n"
                f"💡 Coba lagi nanti.</blockquote>"
            )
        
    except Exception as e:
        await message.reply_text(f"{ggl} <b>Error: {str(e)[:100]}</b>")
