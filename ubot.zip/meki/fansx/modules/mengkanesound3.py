from fansx import *
import requests
import aiohttp
import os
import random
from pyrogram.enums import ChatAction, ParseMode
from pyrogram.types import Message

__MODULE__ = "ᴍᴀɴɢᴋᴀɴᴇ ᴠ3"
__HELP__ = """
<blockquote><b>『 SOUND EFFECTS MANGKANE V3 』</b>

<b>⌲ Perintah:</b>
ᚗ <code>{0}mangkane27</code> - <code>{0}mangkane54</code> 
⊶ Memutar sound effect manga V3

<b>⌲ Contoh:</b>
<code>.mangkane27</code>
<code>.mangkane30</code>
<code>.mangkane40 thumb</code> (dengan thumbnail)</blockquote>
"""

# URL base untuk berbagai sound
MANGAKANE_BASE = "https://raw.githubusercontent.com/hyuura/Rest-Sound/main/HyuuraKane"
MANGAKANE_BASE2 = "https://raw.githubusercontent.com/aisyah-rest/mangkane/main/mangkanenya"

# Thumbnail default
DEFAULT_THUMB = "https://telegra.ph/file/48b67f699cfa231e4d5c2.jpg"

# URL group bot
GROUPBOT_URL = "https://t.me/ubot_premium_zyura"  # Ganti dengan link group lo

# Daftar sound mangkane 27-54
SOUNDS = {}

# Generate mangkane 27-54
for i in range(27, 55):
    sound_name = f"mangkane{i}"
    # Pilih base URL berdasarkan nomor (semua > 24, pake base2)
    url = f"{MANGAKANE_BASE2}/mangkane{i}.mp3"
    
    SOUNDS[sound_name] = {"url": url, "thumb": DEFAULT_THUMB}

async def download_audio(url):
    """Download audio dari URL"""
    try:
        async with aiohttp.ClientSession() as session:
            async with session.get(url, timeout=15) as response:
                if response.status == 200:
                    return await response.read()
    except Exception as e:
        print(f"Error download audio: {e}")
    return None

@PY.UBOT("mangkane27")
@PY.UBOT("mangkane28")
@PY.UBOT("mangkane29")
@PY.UBOT("mangkane30")
@PY.UBOT("mangkane31")
@PY.UBOT("mangkane32")
@PY.UBOT("mangkane33")
@PY.UBOT("mangkane34")
@PY.UBOT("mangkane35")
@PY.UBOT("mangkane36")
@PY.UBOT("mangkane37")
@PY.UBOT("mangkane38")
@PY.UBOT("mangkane39")
@PY.UBOT("mangkane40")
@PY.UBOT("mangkane41")
@PY.UBOT("mangkane42")
@PY.UBOT("mangkane43")
@PY.UBOT("mangkane44")
@PY.UBOT("mangkane45")
@PY.UBOT("mangkane46")
@PY.UBOT("mangkane47")
@PY.UBOT("mangkane48")
@PY.UBOT("mangkane49")
@PY.UBOT("mangkane50")
@PY.UBOT("mangkane51")
@PY.UBOT("mangkane52")
@PY.UBOT("mangkane53")
@PY.UBOT("mangkane54")
async def mangkane_handler(client: Client, message: Message):
    await play_sound(client, message, message.command[0])

async def play_sound(client: Client, message: Message, sound_name: str):
    ggl = await EMO.GAGAL(client)
    sks = await EMO.BERHASIL(client)
    prs = await EMO.PROSES(client)
    
    try:
        await client.send_chat_action(message.chat.id, ChatAction.TYPING)
        
        # Cek apakah sound tersedia
        if sound_name not in SOUNDS:
            await message.reply_text(f"{ggl} <b>Sound '{sound_name}' tidak ditemukan!</b>")
            return
        
        sound_info = SOUNDS[sound_name]
        sound_url = sound_info["url"]
        thumb_url = sound_info["thumb"]
        
        # Cek apakah user minta thumbnail (pake argumen 'thumb')
        args = message.text.split()
        use_thumb = len(args) > 1 and args[1].lower() == 'thumb'
        
        # Kirim pesan processing
        processing = await message.reply_text(f"{prs} <b>Memutar {sound_name}...</b>")
        
        # Download audio
        audio_data = await download_audio(sound_url)
        
        if audio_data:
            # Simpan sementara
            file_path = f"{sound_name}_{message.from_user.id}.mp3"
            with open(file_path, 'wb') as f:
                f.write(audio_data)
            
            await processing.delete()
            
            if use_thumb:
                # Kirim dengan thumbnail external
                try:
                    # Download thumbnail
                    async with aiohttp.ClientSession() as session:
                        async with session.get(thumb_url, timeout=10) as thumb_resp:
                            if thumb_resp.status == 200:
                                thumb_data = await thumb_resp.read()
                                
                                # Kirim audio dengan thumbnail
                                await client.send_audio(
                                    chat_id=message.chat.id,
                                    audio=file_path,
                                    title=f"🎵 {sound_name}",
                                    performer="Mangkane V3",
                                    thumb=thumb_data,
                                    caption=f"<blockquote><b>🎵 {sound_name}</b></blockquote>"
                                )
                            else:
                                # Fallback kalo thumbnail gagal
                                await client.send_audio(
                                    chat_id=message.chat.id,
                                    audio=file_path,
                                    caption=f"<blockquote><b>🎵 {sound_name}</b></blockquote>"
                                )
                except Exception as e:
                    print(f"Error sending with thumb: {e}")
                    await client.send_audio(
                        chat_id=message.chat.id,
                        audio=file_path,
                        caption=f"<blockquote><b>🎵 {sound_name}</b></blockquote>"
                    )
            else:
                # Kirim audio biasa
                await client.send_audio(
                    chat_id=message.chat.id,
                    audio=file_path,
                    caption=f"<blockquote><b>🎵 {sound_name}</b></blockquote>"
                )
            
            # Hapus file
            if os.path.exists(file_path):
                os.remove(file_path)
        else:
            await processing.edit_text(f"{ggl} <b>Gagal memuat audio!</b>")
        
    except Exception as e:
        await message.reply_text(f"{ggl} <b>Error: {str(e)[:100]}</b>")

@PY.UBOT("mangkanelist3")
async def mangkane_list_v3(client: Client, message: Message):
    """Menampilkan daftar sound mangkane V3 yang tersedia"""
    
    # Ambil semua sound mangkane 27-54
    mangkane_sounds = list(SOUNDS.keys())
    
    text = "<blockquote><b>📋 DAFTAR SOUND MANGKANE V3</b>\n\n"
    
    # Tampilkan dalam beberapa baris
    rows = [mangkane_sounds[i:i+6] for i in range(0, len(mangkane_sounds), 6)]
    for row in rows:
        text += " • " + ", ".join(row) + "\n"
    
    text += f"\n<b>📊 Total:</b> {len(mangkane_sounds)} sound\n\n"
    text += "<b>💡 Cara pakai:</b>\n"
    text += "• <code>.mangkane27</code> (tanpa thumb)\n"
    text += "• <code>.mangkane27 thumb</code> (dengan thumb)</blockquote>"
    
    await message.reply_text(text)

@PY.UBOT("mangkaneall")
async def mangkane_all(client: Client, message: Message):
    """Menampilkan semua daftar sound mangkane dari V1, V2, V3"""
    
    # Kategorikan berdasarkan range
    v1_sounds = [f"mangkane{i}" for i in range(1, 10)]
    v2_sounds = [f"mangkane{i}" for i in range(10, 27)]
    v3_sounds = [f"mangkane{i}" for i in range(27, 55)]
    
    text = "<blockquote><b>📋 DAFTAR SEMUA SOUND MANGKANE</b>\n\n"
    
    text += "<b>🎵 Mangkane V1 (1-9):</b>\n"
    text += " • " + ", ".join(v1_sounds) + "\n\n"
    
    text += "<b>🎵 Mangkane V2 (10-26):</b>\n"
    # Tampilkan V2 dalam beberapa baris
    v2_rows = [v2_sounds[i:i+6] for i in range(0, len(v2_sounds), 6)]
    for row in v2_rows:
        text += " • " + ", ".join(row) + "\n"
    text += "\n"
    
    text += "<b>🎵 Mangkane V3 (27-54):</b>\n"
    # Tampilkan V3 dalam beberapa baris
    v3_rows = [v3_sounds[i:i+6] for i in range(0, len(v3_sounds), 6)]
    for row in v3_rows:
        text += " • " + ", ".join(row) + "\n"
    
    text += f"\n<b>📊 Total:</b> {len(v1_sounds) + len(v2_sounds) + len(v3_sounds)} sound\n\n"
    text += "<b>💡 Cara pakai:</b>\n"
    text += "• <code>.mangkane1</code> (tanpa thumb)\n"
    text += "• <code>.mangkane15 thumb</code> (dengan thumb)</blockquote>"
    
    await message.reply_text(text)

@PY.BOT("mangkane27")
async def mangkane_bot_handler(client: Client, message: Message):
    """Handler untuk bot"""
    sound_name = message.text.split()[0].replace('/', '')
    await play_sound_bot(client, message, sound_name)

async def play_sound_bot(client: Client, message: Message, sound_name: str):
    try:
        if sound_name not in SOUNDS:
            await message.reply_text(f"❌ Sound '{sound_name}' tidak ditemukan!")
            return
        
        sound_info = SOUNDS[sound_name]
        sound_url = sound_info["url"]
        
        processing = await message.reply_text(f"🔍 Memutar {sound_name}...")
        
        audio_data = await download_audio(sound_url)
        
        if audio_data:
            file_path = f"{sound_name}_bot_{message.from_user.id}.mp3"
            with open(file_path, 'wb') as f:
                f.write(audio_data)
            
            await processing.delete()
            
            await client.send_audio(
                chat_id=message.chat.id,
                audio=file_path,
                caption=f"🎵 {sound_name}"
            )
            
            if os.path.exists(file_path):
                os.remove(file_path)
        else:
            await processing.edit_text("❌ Gagal memuat audio!")
        
    except Exception as e:
        await message.reply_text(f"❌ Error: {str(e)[:100]}")