from fansx import *
import aiohttp
import asyncio
import random
import json
import os
from datetime import datetime
from pyrogram.enums import ChatAction, ParseMode
from pyrogram.types import Message

__MODULE__ = "ᴛᴇʙᴀᴋ sᴜʀᴀʜ"
__HELP__ = """
<blockquote><b>🕌 GAME: TEBAK SURAH</b>

<b>⌲ Perintah:</b>
ᚗ <code>{0}tebaksurah</code> - Mulai game baru
ᚗ <code>{0}ts</code> - Mulai game (singkatan)
ᚗ <code>{0}jawabs [jawaban]</code> - Jawab tebakan surat
ᚗ <code>{0}skips</code> - Lewati pertanyaan
ᚗ <code>{0}skors</code> - Lihat papan peringkat

<b>⌲ Cara main:</b>
1. Ketik <code>.tebaksurah</code> untuk mulai
2. Bot kirim audio potongan ayat
3. Dengarkan dan tebak nama suratnya
4. Ketik <code>.jawabs [jawaban]</code>
5. Bot kasih tau bener atau salah
6. Dapet skor kalo bener!

<b>⌲ Contoh:</b>
<code>.tebaksurah</code>
<code>.jawabs Az-Zukhruf</code>
<code>.jawabs Abasa</code></blockquote>
"""

# ============================================
# KONFIGURASI
# ============================================
API_URL = "https://api.deline.web.id/game/tebaksurah"

# Database untuk menyimpan state game per user
game_sessions = {}
leaderboard = {}

async def get_question():
    """Ambil soal dari API"""
    try:
        async with aiohttp.ClientSession() as session:
            async with session.get(API_URL, timeout=10) as response:
                if response.status == 200:
                    data = await response.json()
                    if data.get("status") and data.get("result"):
                        result = data["result"]
                        surah = result.get("surah", {})
                        return {
                            "audio_url": result.get("audio", ""),
                            "surah_number": surah.get("number", 0),
                            "surah_name": surah.get("name", ""),
                            "surah_english": surah.get("englishName", "").lower(),
                            "surah_translation": surah.get("englishNameTranslation", "").lower(),
                            "ayah_number": result.get("numberInSurah", 0),
                            "edition": result.get("edition", {}).get("englishName", "")
                        }
    except Exception as e:
        print(f"Error get question: {e}")
    return None

def normalize_answer(answer):
    """Normalisasi jawaban"""
    return " ".join(answer.lower().split())

@PY.UBOT("tebaksurah")
@PY.UBOT("ts")
async def start_game(client: Client, message: Message):
    ggl = await EMO.GAGAL(client)
    prs = await EMO.PROSES(client)
    
    user_id = message.from_user.id
    user_name = message.from_user.first_name
    
    try:
        await client.send_chat_action(message.chat.id, ChatAction.TYPING)
        
        processing = await message.reply_text(f"{prs} <b>Menyiapkan potongan ayat...</b>")
        
        question_data = await get_question()
        
        if not question_data:
            await processing.edit_text(f"{ggl} <b>Gagal mengambil soal!</b>")
            return
        
        audio_url = question_data["audio_url"]
        surah_name = question_data["surah_name"]
        surah_english = question_data["surah_english"]
        surah_translation = question_data["surah_translation"]
        ayah_number = question_data["ayah_number"]
        edition = question_data["edition"]
        
        # Simpan sesi game
        game_sessions[user_id] = {
            "audio_url": audio_url,
            "surah_name": surah_name,
            "surah_english": surah_english,
            "surah_translation": surah_translation,
            "ayah_number": ayah_number,
            "edition": edition,
            "start_time": datetime.now(),
            "attempts": 0
        }
        
        await processing.delete()
        
        # Kirim audio
        await client.send_audio(
            chat_id=message.chat.id,
            audio=audio_url,
            caption=f"<blockquote><b>🕌 TEBAK SURAH</b>\n\n"
                    f"🔊 Dengarkan potongan ayat ini\n"
                    f"📖 Qari: {edition}\n"
                    f"📝 Ayat ke: {ayah_number}\n\n"
                    f"<b>Jawab:</b> <code>.jawabs [nama surat]</code>\n"
                    f"<b>Lewati:</b> <code>.skips</code></blockquote>"
        )
        
    except Exception as e:
        await message.reply_text(f"{ggl} <b>Error: {str(e)[:100]}</b>")

@PY.UBOT("jawabs")
async def answer_game(client: Client, message: Message):
    ggl = await EMO.GAGAL(client)
    sks = await EMO.BERHASIL(client)
    
    user_id = message.from_user.id
    user_name = message.from_user.first_name
    
    try:
        if user_id not in game_sessions:
            await message.reply_text(
                f"{ggl} <b>Ketik .tebaksurah dulu!</b>"
            )
            return
        
        args = message.text.split(maxsplit=1)
        if len(args) < 2:
            await message.reply_text(
                f"{ggl} <b>Contoh: .jawabs Az-Zukhruf</b>"
            )
            return
        
        user_answer = normalize_answer(args[1])
        surah_english = game_sessions[user_id]["surah_english"]
        surah_translation = game_sessions[user_id]["surah_translation"]
        attempts = game_sessions[user_id]["attempts"] + 1
        game_sessions[user_id]["attempts"] = attempts
        
        # Cek jawaban
        is_correct = False
        if user_answer == surah_english:
            is_correct = True
        elif user_answer == surah_translation:
            is_correct = True
        elif surah_english in user_answer or user_answer in surah_english:
            is_correct = True
        
        if is_correct:
            # Skor berdasarkan kesempatan
            score = max(10 - (attempts - 1) * 2, 1)
            
            # Update leaderboard
            if user_id in leaderboard:
                leaderboard[user_id]["score"] += score
                leaderboard[user_id]["correct"] += 1
            else:
                leaderboard[user_id] = {
                    "name": user_name,
                    "score": score,
                    "correct": 1,
                    "total": 0
                }
            
            leaderboard[user_id]["total"] = leaderboard[user_id].get("total", 0) + 1
            
            # Ambil nama surat untuk ditampilkan
            surah_name_display = game_sessions[user_id]["surah_name"]
            
            del game_sessions[user_id]
            
            await message.reply_text(
                f"<blockquote><b>✅ BENAR!</b>\n\n"
                f"📖 Surat: <b>{surah_name_display}</b>\n"
                f"⭐ Skor: +{score}\n"
                f"🏆 Total: {leaderboard[user_id]['score']}\n"
                f"📈 Benar: {leaderboard[user_id]['correct']}/{leaderboard[user_id]['total']}\n\n"
                f"Main lagi: <code>.tebaksurah</code></blockquote>"
            )
        else:
            if attempts >= 3:
                surah_name_display = game_sessions[user_id]["surah_name"]
                await message.reply_text(
                    f"<blockquote><b>❌ GAME OVER</b>\n\n"
                    f"📖 Surat: <b>{surah_name_display}</b>\n\n"
                    f"Main lagi: <code>.tebaksurah</code></blockquote>"
                )
                
                # Update total tapi ga dapet skor
                if user_id in leaderboard:
                    leaderboard[user_id]["total"] = leaderboard[user_id].get("total", 0) + 1
                else:
                    leaderboard[user_id] = {
                        "name": user_name,
                        "score": 0,
                        "correct": 0,
                        "total": 1
                    }
                
                del game_sessions[user_id]
            else:
                await message.reply_text(
                    f"<blockquote><b>❌ SALAH</b>\n\n"
                    f"📝 Percobaan: {attempts}/3\n\n"
                    f"Coba lagi: <code>.jawabs [nama surat]</code></blockquote>"
                )
        
    except Exception as e:
        await message.reply_text(f"{ggl} <b>Error: {str(e)[:100]}</b>")

@PY.UBOT("skips")
async def skip_question(client: Client, message: Message):
    ggl = await EMO.GAGAL(client)
    
    user_id = message.from_user.id
    user_name = message.from_user.first_name
    
    if user_id in game_sessions:
        surah_name_display = game_sessions[user_id]["surah_name"]
        
        # Update total tapi ga dapet skor
        if user_id in leaderboard:
            leaderboard[user_id]["total"] = leaderboard[user_id].get("total", 0) + 1
        else:
            leaderboard[user_id] = {
                "name": user_name,
                "score": 0,
                "correct": 0,
                "total": 1
            }
        
        await message.reply_text(
            f"<blockquote><b>⏭️ SKIP</b>\n\n"
            f"📖 Surat: <b>{surah_name_display}</b>\n\n"
            f"Main baru: <code>.tebaksurah</code></blockquote>"
        )
        del game_sessions[user_id]
    else:
        await message.reply_text(f"{ggl} <b>Belum mulai game!</b>")

@PY.UBOT("skors")
async def show_leaderboard(client: Client, message: Message):
    """Tampilkan papan peringkat tebak surat"""
    
    if not leaderboard:
        await message.reply_text(
            "<blockquote><b>🏆 LEADERBOARD TEBAK SURAH</b>\n\n"
            "Belum ada skor. Ayo main <code>.tebaksurah</code> dulu!</blockquote>"
        )
        return
    
    # Urutkan berdasarkan skor tertinggi
    sorted_users = sorted(leaderboard.items(), key=lambda x: x[1]["score"], reverse=True)
    
    text = "<blockquote><b>🏆 LEADERBOARD TEBAK SURAH</b>\n\n"
    
    for i, (user_id, data) in enumerate(sorted_users[:10], 1):
        medal = "🥇" if i == 1 else "🥈" if i == 2 else "🥉" if i == 3 else f"{i}."
        
        # Hitung akurasi
        if data["total"] > 0:
            accuracy = (data["correct"] / data["total"]) * 100
        else:
            accuracy = 0
            
        text += f"{medal} <b>{data['name']}</b>\n"
        text += f"   ⭐ {data['score']} poin | 📊 {accuracy:.1f}%\n"
    
    text += "\nMain: <code>.tebaksurah</code></blockquote>"
    
    await message.reply_text(text)

@PY.UBOT("infos")
async def game_info(client: Client, message: Message):
    """Info tentang game tebak surat"""
    
    text = """
<blockquote><b>🕌 INFO GAME TEBAK SURAH</b>

<b>Cara main:</b>
• <code>.tebaksurah</code> - Mulai game
• <code>.jawabs [jawaban]</code> - Jawab tebakan
• <code>.skips</code> - Lewati soal
• <code>.skors</code> - Lihat peringkat

<b>Aturan:</b>
• 3x kesempatan menjawab per soal
• Skor berkurang jika salah menjawab
• Makin cepat jawab, makin tinggi skor
• Jawaban tidak case sensitive
• Bisa pakai nama Inggris atau Arab

<b>Skor:</b>
• Percobaan 1: +10 poin
• Percobaan 2: +8 poin
• Percobaan 3: +6 poin
• Salah 3x: 0 poin</blockquote>"""
    
    await message.reply_text(text)