from fansx import *
import requests
import aiohttp
import os
import asyncio
from pyrogram.enums import ChatAction, ParseMode
from pyrogram.types import Message
from urllib.parse import quote

__MODULE__ = "ꜰᴀᴋᴇ ᴅɪsᴄᴏʀᴅ"
__HELP__ = """
<blockquote><b>『 FAKE DISCORD CHAT 』</b>

<b>⌲ Perintah:</b>
ᚗ <code>{0}fakediscord [nama]|[pesan]</code> 
⊶ Membuat chat Discord palsu dengan foto profil

<b>⌲ Format:</b>
<code>nama|pesan</code>

<b>⌲ Cara Pakai:</b>
1. Kirim foto + caption <code>.fakediscord Misaki|Hai aku discord user</code>
2. Atau reply foto dengan <code>.fakediscord Misaki|Hai aku discord user</code>

<b>⌲ Contoh:</b>
<code>.fakediscord Misaki|Halo teman-teman</code>
<code>.fakediscord Bot|Selamat datang di server</code></blockquote>
"""

# Base URL API
API_URL = "https://zelapioffciall.koyeb.app/canvas/fakediscord"

async def upload_to_tmpfiles(file_path):
    """Upload gambar ke tmpfiles.org"""
    try:
        async with aiohttp.ClientSession() as session:
            data = aiohttp.FormData()
            data.add_field('file', 
                          open(file_path, 'rb'),
                          filename='image.jpg',
                          content_type='image/jpeg')
            
            async with session.post('https://tmpfiles.org/api/v1/upload', data=data, timeout=30) as resp:
                if resp.status == 200:
                    result = await resp.json()
                    if result.get('data') and result['data'].get('url'):
                        # Convert URL ke format download
                        url = result['data']['url']
                        download_url = url.replace('tmpfiles.org/', 'tmpfiles.org/dl/')
                        return download_url
    except Exception as e:
        print(f"Upload error: {e}")
    return None

@PY.UBOT("fakediscord")
async def fake_discord(client: Client, message: Message):
    ggl = await EMO.GAGAL(client)
    sks = await EMO.BERHASIL(client)
    prs = await EMO.PROSES(client)
    
    try:
        await client.send_chat_action(message.chat.id, ChatAction.TYPING)
        
        # Ambil input teks
        args = message.text.split(maxsplit=1)
        if len(args) < 2:
            await message.reply_text(
                f"<blockquote><b>💬 FAKE DISCORD CHAT</b>\n\n"
                f"<b>Cara pakai:</b>\n"
                f"1. Kirim foto + caption <code>.fakediscord Nama|Pesan</code>\n"
                f"2. Reply foto dengan <code>.fakediscord Nama|Pesan</code>\n\n"
                f"<b>Contoh:</b>\n"
                f"<code>.fakediscord Misaki|Halo teman-teman</code></blockquote>"
            )
            return
        
        input_text = args[1]
        
        # Parse input dengan format "nama|pesan"
        parts = [p.strip() for p in input_text.split('|', 1)]
        
        if len(parts) < 2 or not parts[0] or not parts[1]:
            await message.reply_text(
                f"{ggl} <b>Format salah! Gunakan: nama|pesan</b>\n"
                f"Contoh: <code>.fakediscord Misaki|Halo teman-teman</code>"
            )
            return
        
        name = parts[0]
        text = parts[1]
        
        # Cek apakah ada gambar
        buffer = None
        has_image = False
        file_path = None
        
        # Cek reply ke gambar
        if message.reply_to_message:
            if message.reply_to_message.photo:
                has_image = True
                file_path = await message.reply_to_message.download()
            elif message.reply_to_message.sticker:
                has_image = True
                file_path = await message.reply_to_message.download()
            elif message.reply_to_message.document and message.reply_to_message.document.mime_type.startswith('image/'):
                has_image = True
                file_path = await message.reply_to_message.download()
        
        # Cek kalo pesan itu sendiri ada gambar
        elif message.photo:
            has_image = True
            file_path = await message.download()
        
        if not has_image or not file_path:
            await message.reply_text(
                f"{ggl} <b>Kirim atau reply gambar untuk dijadikan avatar!</b>"
            )
            return
        
        # Kirim pesan processing
        processing = await message.reply_text(f"{prs} <b>Membuat Fake Discord Chat...</b>")
        
        try:
            # Upload gambar ke tmpfiles
            await processing.edit_text(f"{prs} <b>Mengupload gambar ke server...</b>")
            image_url = await upload_to_tmpfiles(file_path)
            
            if not image_url:
                await processing.edit_text(f"{ggl} <b>Gagal upload gambar!</b>")
                return
            
            # Hapus file lokal
            if os.path.exists(file_path):
                os.remove(file_path)
            
            # Build URL API
            await processing.edit_text(f"{prs} <b>Menggenerate Discord chat...</b>")
            
            params = {
                'name': name,
                'text': text,
                'url': image_url
            }
            
            # Encode parameters
            query_string = '&'.join([f"{k}={quote(str(v))}" for k, v in params.items()])
            full_url = f"{API_URL}?{query_string}"
            
            # Download hasil gambar
            async with aiohttp.ClientSession() as session:
                async with session.get(full_url, timeout=60) as resp:
                    if resp.status == 200:
                        image_data = await resp.read()
                        
                        # Simpan sementara
                        result_path = f"fakediscord_{message.from_user.id}.jpg"
                        with open(result_path, 'wb') as f:
                            f.write(image_data)
                        
                        # Kirim gambar hasil
                        await client.send_photo(
                            chat_id=message.chat.id,
                            photo=result_path,
                            caption=f"<blockquote><b>💬 FAKE DISCORD CHAT</b>\n\n"
                                    f"👤 <b>Nama:</b> {name}\n"
                                    f"💬 <b>Pesan:</b> {text}</blockquote>"
                        )
                        
                        # Hapus file hasil
                        if os.path.exists(result_path):
                            os.remove(result_path)
                        
                        await processing.delete()
                    else:
                        await processing.edit_text(f"{ggl} <b>Gagal membuat Discord chat! HTTP {resp.status}</b>")
                        
        except Exception as e:
            # Hapus file lokal kalo ada error
            if file_path and os.path.exists(file_path):
                os.remove(file_path)
            raise e
        
    except asyncio.TimeoutError:
        await message.reply_text(f"{ggl} <b>Timeout! Server sedang sibuk.</b>")
    except aiohttp.ClientError as e:
        await message.reply_text(f"{ggl} <b>Gagal terhubung ke server! {str(e)[:50]}</b>")
    except Exception as e:
        await message.reply_text(f"{ggl} <b>Error: {str(e)[:100]}</b>")

@PY.UBOT("fd")
async def fake_discord_short(client: Client, message: Message):
    """Alias pendek untuk fakediscord"""
    await fake_discord(client, message)

@PY.BOT("fakediscord")
async def fake_discord_bot(client: Client, message: Message):
    """Handler untuk bot"""
    try:
        args = message.text.split(maxsplit=1)
        if len(args) < 2:
            await message.reply_text(
                "💬 *FAKE DISCORD CHAT*\n\n"
                "Cara pakai:\n"
                "1. Reply foto dengan /fakediscord Nama|Pesan\n"
                "2. Kirim foto + caption /fakediscord Nama|Pesan\n\n"
                "Contoh: /fakediscord Misaki|Halo teman-teman"
            )
            return
        
        input_text = args[1]
        parts = [p.strip() for p in input_text.split('|', 1)]
        
        if len(parts) < 2:
            await message.reply_text("❌ Format: Nama|Pesan")
            return
        
        name, text = parts[0], parts[1]
        
        # Cek apakah ada gambar
        file_path = None
        has_image = False
        
        if message.reply_to_message and message.reply_to_message.photo:
            has_image = True
            file_path = await message.reply_to_message.download()
        elif message.photo:
            has_image = True
            file_path = await message.download()
        
        if not has_image:
            await message.reply_text("❌ Kirim atau reply gambar!")
            return
        
        processing = await message.reply_text("⏳ Membuat Fake Discord...")
        
        try:
            # Upload gambar
            image_url = await upload_to_tmpfiles(file_path)
            
            if not image_url:
                await processing.edit_text("❌ Gagal upload gambar!")
                return
            
            if os.path.exists(file_path):
                os.remove(file_path)
            
            # Generate Discord chat
            params = {'name': name, 'text': text, 'url': image_url}
            query_string = '&'.join([f"{k}={quote(str(v))}" for k, v in params.items()])
            full_url = f"{API_URL}?{query_string}"
            
            async with aiohttp.ClientSession() as session:
                async with session.get(full_url, timeout=60) as resp:
                    if resp.status == 200:
                        image_data = await resp.read()
                        result_path = f"fd_bot_{message.from_user.id}.jpg"
                        
                        with open(result_path, 'wb') as f:
                            f.write(image_data)
                        
                        await client.send_photo(
                            chat_id=message.chat.id,
                            photo=result_path,
                            caption=f"💬 *Fake Discord*\n👤 {name}\n💬 {text}"
                        )
                        
                        if os.path.exists(result_path):
                            os.remove(result_path)
                        
                        await processing.delete()
                    else:
                        await processing.edit_text(f"❌ Gagal: HTTP {resp.status}")
                        
        except Exception as e:
            if file_path and os.path.exists(file_path):
                os.remove(file_path)
            await processing.edit_text(f"❌ Error: {str(e)[:100]}")
            
    except Exception as e:
        await message.reply_text(f"❌ Error: {str(e)[:100]}")