from fansx import *
import random
import asyncio
from pyrogram.enums import ChatAction
from pyrogram.types import Message

__MODULE__ = "ᴄᴇᴋ ᴋᴇᴘʀɪʙᴀᴅɪᴀɴ"
__HELP__ = """
<blockquote><b>『 CEK KEPRIBADIAN MBTI 』</b>

<b>⌲ Perintah:</b>
ᚗ <code>{0}mbti [nama]</code> 
⊶ Mengecek tipe kepribadian MBTI secara random

<b>⌲ Contoh:</b>
<code>.mbti</code> (untuk cek diri sendiri)
<code>.mbti Budi</code> (untuk cek orang lain)
<code>.mbti @username</code></blockquote>
"""

# Daftar kepribadian MBTI
PERSONALITIES = [
    {'type': 'INTJ', 'title': 'The Architect', 'desc': 'Visioner, strategis, dan independen'},
    {'type': 'INTP', 'title': 'The Logician', 'desc': 'Analitis, inovatif, dan ingin tahu'},
    {'type': 'ENTJ', 'title': 'The Commander', 'desc': 'Tegas, ambisius, dan pemimpin alami'},
    {'type': 'ENTP', 'title': 'The Debater', 'desc': 'Cerdas, penasaran, dan suka tantangan'},
    {'type': 'INFJ', 'title': 'The Advocate', 'desc': 'Idealis, bijaksana, dan penuh empati'},
    {'type': 'INFP', 'title': 'The Mediator', 'desc': 'Kreatif, idealis, dan setia'},
    {'type': 'ENFJ', 'title': 'The Protagonist', 'desc': 'Karismatik, inspiratif, dan peduli'},
    {'type': 'ENFP', 'title': 'The Campaigner', 'desc': 'Antusias, kreatif, dan sosial'},
    {'type': 'ISTJ', 'title': 'The Logistician', 'desc': 'Bertanggung jawab, praktis, dan teliti'},
    {'type': 'ISFJ', 'title': 'The Defender', 'desc': 'Setia, suportif, dan reliable'},
    {'type': 'ESTJ', 'title': 'The Executive', 'desc': 'Terorganisir, tegas, dan tradisional'},
    {'type': 'ESFJ', 'title': 'The Consul', 'desc': 'Peduli, sosial, dan loyal'},
    {'type': 'ISTP', 'title': 'The Virtuoso', 'desc': 'Fleksibel, observan, dan praktis'},
    {'type': 'ISFP', 'title': 'The Adventurer', 'desc': 'Artistik, sensitif, dan spontan'},
    {'type': 'ESTP', 'title': 'The Entrepreneur', 'desc': 'Energik, perceptive, dan berani'},
    {'type': 'ESFP', 'title': 'The Entertainer', 'desc': 'Spontan, energik, dan fun'}
]

@PY.UBOT("mbti")
async def cek_mbti(client: Client, message: Message):
    ggl = await EMO.GAGAL(client)
    sks = await EMO.BERHASIL(client)
    prs = await EMO.PROSES(client)
    
    try:
        await client.send_chat_action(message.chat.id, ChatAction.TYPING)
        
        # Ambil nama dari input atau reply
        nama = "Kamu"
        
        # Cek apakah reply ke user
        if message.reply_to_message and message.reply_to_message.from_user:
            user = message.reply_to_message.from_user
            nama = user.first_name
            if user.last_name:
                nama += f" {user.last_name}"
        
        # Cek dari argumen
        args = message.text.split(maxsplit=1)
        if len(args) > 1:
            input_nama = args[1].strip()
            
            # Cek apakah mention @username
            if input_nama.startswith('@'):
                try:
                    user = await client.get_users(input_nama)
                    nama = user.first_name
                    if user.last_name:
                        nama += f" {user.last_name}"
                except:
                    nama = input_nama
            else:
                nama = input_nama
        
        # Jika tidak ada input dan tidak reply, pakai nama sender
        elif nama == "Kamu":
            nama = message.from_user.first_name
            if message.from_user.last_name:
                nama += f" {message.from_user.last_name}"
        
        # Pilih kepribadian secara random
        personality = random.choice(PERSONALITIES)
        
        # Kirim pesan processing dulu (biar ada efek)
        processing = await message.reply_text(f"{prs} <b>Menganalisis kepribadian {nama}...</b>")
        
        # Tunggu bentar biar keliatan prosesnya
        await asyncio.sleep(1)
        
        # Format pesan
        txt = f"""
<blockquote><b>🧠 CEK KEPRIBADIAN MBTI</b>

<b>👤 Nama:</b> <code>{nama}</code>
<b>🎭 Tipe:</b> <code>{personality['type']}</code> - {personality['title']}
<b>📝 Karakter:</b> {personality['desc']}</blockquote>
"""
        
        await processing.edit_text(txt)
        
    except Exception as e:
        await message.reply_text(f"{ggl} <b>Error: {str(e)[:100]}</b>")

@PY.UBOT("kepribadian")
async def kepribadian_alias(client: Client, message: Message):
    """Alias untuk mbti"""
    await cek_mbti(client, message)

@PY.UBOT("personality")
async def personality_alias(client: Client, message: Message):
    """Alias untuk mbti"""
    await cek_mbti(client, message)

@PY.UBOT("cekmbti")
async def cek_mbti_alias(client: Client, message: Message):
    """Alias untuk mbti"""
    await cek_mbti(client, message)

@PY.BOT("mbti")
async def cek_mbti_bot(client: Client, message: Message):
    """Handler untuk bot"""
    try:
        nama = "Kamu"
        
        if message.reply_to_message and message.reply_to_message.from_user:
            user = message.reply_to_message.from_user
            nama = user.first_name
            if user.last_name:
                nama += f" {user.last_name}"
        
        args = message.text.split(maxsplit=1)
        if len(args) > 1:
            input_nama = args[1].strip()
            if input_nama.startswith('@'):
                try:
                    user = await client.get_users(input_nama)
                    nama = user.first_name
                    if user.last_name:
                        nama += f" {user.last_name}"
                except:
                    nama = input_nama
            else:
                nama = input_nama
        
        # Pilih kepribadian secara random
        personality = random.choice(PERSONALITIES)
        
        txt = f"""
🧠 *CEK KEPRIBADIAN MBTI*

👤 Nama: {nama}
🎭 Tipe: {personality['type']} - {personality['title']}
📝 Karakter: {personality['desc']}
"""
        await message.reply_text(txt)
        
    except Exception as e:
        await message.reply_text(f"❌ Error: {str(e)[:100]}")