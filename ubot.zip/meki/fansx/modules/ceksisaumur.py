from fansx import *
import random
import asyncio
from pyrogram.enums import ChatAction
from pyrogram.types import Message

__MODULE__ = "ᴄᴇᴋ sɪsᴀ ᴜᴍᴜʀ"
__HELP__ = """
<blockquote><b>『 CEK SISA UMUR 』</b>

<b>⌲ Perintah:</b>
ᚗ <code>{0}sisaumur [nama]</code> 
⊶ Mengecek sisa umur random seseorang (versi lucu)

<b>⌲ Contoh:</b>
<code>.sisaumur</code> (untuk cek diri sendiri)
<code>.sisaumur Budi</code> (untuk cek orang lain)
<code>.sisaumur @username</code></blockquote>
"""

def get_description(tahun):
    """Mendapatkan deskripsi berdasarkan sisa tahun"""
    if tahun > 80:
        return "Panjang umur banget! 🎉"
    elif tahun > 60:
        return "Lumayan panjang~ ✨"
    elif tahun > 40:
        return "Cukup lah ya 😊"
    else:
        return "Jaga kesehatan ya! 🙏"

@PY.UBOT("sisaumur")
async def cek_sisaumur(client: Client, message: Message):
    ggl = await EMO.GAGAL(client)
    sks = await EMO.BERHASIL(client)
    prs = await EMO.PROSES(client)
    
    try:
        await client.send_chat_action(message.chat.id, ChatAction.TYPING)
        
        # Ambil nama dari input atau reply
        nama = "Kamu"
        
        # Cek apakah reply ke user
        if message.reply_to_message and message.reply_to_message.from_user:
            user = message.reply_to_message.from_user
            nama = user.first_name
            if user.last_name:
                nama += f" {user.last_name}"
        
        # Cek dari argumen
        args = message.text.split(maxsplit=1)
        if len(args) > 1:
            input_nama = args[1].strip()
            
            # Cek apakah mention @username
            if input_nama.startswith('@'):
                try:
                    user = await client.get_users(input_nama)
                    nama = user.first_name
                    if user.last_name:
                        nama += f" {user.last_name}"
                except:
                    nama = input_nama
            else:
                nama = input_nama
        
        # Jika tidak ada input dan tidak reply, pakai nama sender
        elif nama == "Kamu":
            nama = message.from_user.first_name
            if message.from_user.last_name:
                nama += f" {message.from_user.last_name}"
        
        # Generate random sisa umur
        tahun = random.randint(20, 100)
        bulan = random.randint(0, 11)
        hari = random.randint(0, 29)
        
        desc = get_description(tahun)
        
        # Buat progress bar visual
        bar_length = 20
        # Mapping tahun 20-100 ke 0-100% untuk progress bar
        percent = int((tahun - 20) * 100 / 80)  # 20->0%, 100->100%
        filled_length = int(bar_length * percent / 100)
        bar = '⏳' * filled_length + '⌛' * (bar_length - filled_length)
        
        # Kirim pesan processing dulu (biar ada efek)
        processing = await message.reply_text(f"{prs} <b>Menghitung sisa umur {nama}...</b>")
        
        # Tunggu bentar biar keliatan prosesnya
        await asyncio.sleep(1)
        
        # Format pesan
        txt = f"""
<blockquote><b>⏳ CEK SISA UMUR</b>

<b>👤 Nama:</b> <code>{nama}</code>
<b>📅 Sisa Umur:</b> <code>{tahun} tahun {bulan} bulan {hari} hari</code>

<code>{bar}</code>

<b>💬 {desc}</b></blockquote>
"""
        
        await processing.edit_text(txt)
        
    except Exception as e:
        await message.reply_text(f"{ggl} <b>Error: {str(e)[:100]}</b>")

@PY.UBOT("umur")
async def umur_alias(client: Client, message: Message):
    """Alias untuk sisaumur"""
    await cek_sisaumur(client, message)

@PY.UBOT("ceksisa")
async def cek_sisa_alias(client: Client, message: Message):
    """Alias untuk sisaumur"""
    await cek_sisaumur(client, message)

@PY.UBOT("lifespan")
async def lifespan_alias(client: Client, message: Message):
    """Alias untuk sisaumur"""
    await cek_sisaumur(client, message)

@PY.BOT("sisaumur")
async def cek_sisaumur_bot(client: Client, message: Message):
    """Handler untuk bot"""
    try:
        nama = "Kamu"
        
        if message.reply_to_message and message.reply_to_message.from_user:
            user = message.reply_to_message.from_user
            nama = user.first_name
            if user.last_name:
                nama += f" {user.last_name}"
        
        args = message.text.split(maxsplit=1)
        if len(args) > 1:
            input_nama = args[1].strip()
            if input_nama.startswith('@'):
                try:
                    user = await client.get_users(input_nama)
                    nama = user.first_name
                    if user.last_name:
                        nama += f" {user.last_name}"
                except:
                    nama = input_nama
            else:
                nama = input_nama
        
        # Generate random sisa umur
        tahun = random.randint(20, 100)
        bulan = random.randint(0, 11)
        hari = random.randint(0, 29)
        desc = get_description(tahun)
        
        # Buat progress bar sederhana
        bar_length = 15
        percent = int((tahun - 20) * 100 / 80)
        filled_length = int(bar_length * percent / 100)
        bar = '⏳' * filled_length + '⌛' * (bar_length - filled_length)
        
        txt = f"""
⏳ *CEK SISA UMUR*

👤 Nama: {nama}
📅 Sisa Umur: {tahun} tahun {bulan} bulan {hari} hari

{bar}

💬 {desc}
"""
        await message.reply_text(txt)
        
    except Exception as e:
        await message.reply_text(f"❌ Error: {str(e)[:100]}")