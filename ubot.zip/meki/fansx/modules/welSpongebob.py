from fansx import *
import aiohttp
import asyncio
import os
import random
from pyrogram.enums import ChatAction, ParseMode
from pyrogram.types import Message
from pyrogram.types import InlineKeyboardMarkup, InlineKeyboardButton

__MODULE__ = "sᴘᴏɴɢᴇʙᴏʙ ᴡᴇʟᴄᴏᴍᴇ"
__HELP__ = """
<blockquote><b>🧽 SPONGEBOB WELCOME CANVAS</b>

<b>⌲ Perintah:</b>
ᚗ <code>{0}spongebob [nama]</code> - Buat welcome card Spongebob
ᚗ <code>{0}sbob [nama]</code> - Singkatan

<b>⌲ Contoh:</b>
<code>.spongebob Najmy</code>
<code>.sbob Najmy | Member | Grup Ku</code></blockquote>
"""

# ============================================
# KONFIGURASI
# ============================================
SBOB_API = "https://anabot.my.id/api/canvas/spongebob"
API_KEY = "freeApikey"  # Bisa diganti nanti

# Default values
DEFAULT_ROLE = "Member"
DEFAULT_GROUP = "My Group"

async def create_spongebob_welcome(image_url, name, role=DEFAULT_ROLE, group_name=DEFAULT_GROUP):
    """Buat gambar welcome Spongebob"""
    
    # Encode semua parameter
    url = (f"{SBOB_API}?image={image_url}"
           f"&name={name}"
           f"&role={role}"
           f"&groupName={group_name}"
           f"&apikey={API_KEY}")
    
    try:
        async with aiohttp.ClientSession() as session:
            async with session.get(url, timeout=30) as response:
                if response.status == 200:
                    # Cek content-type
                    content_type = response.headers.get("Content-Type", "")
                    
                    if "image" in content_type:
                        # Langsung gambar
                        return {
                            "success": True,
                            "image": await response.read(),
                            "direct": True
                        }
                    else:
                        # Mungkin JSON dengan URL gambar
                        try:
                            data = await response.json()
                            
                            # Cek berbagai format respons
                            if data.get("status") == "success" and data.get("result"):
                                img_url = data["result"]
                            elif data.get("image_url"):
                                img_url = data["image_url"]
                            elif data.get("url"):
                                img_url = data["url"]
                            else:
                                return {"success": False, "error": "Format respons tidak dikenali", "data": data}
                            
                            # Download gambar dari URL
                            async with session.get(img_url, timeout=15) as img_resp:
                                if img_resp.status == 200:
                                    return {
                                        "success": True,
                                        "image": await img_resp.read()
                                    }
                                else:
                                    return {"success": False, "error": f"Gagal download gambar: HTTP {img_resp.status}"}
                        except:
                            return {"success": False, "error": "API tidak mengembalikan gambar"}
                else:
                    return {"success": False, "error": f"HTTP {response.status}"}
    except asyncio.TimeoutError:
        return {"success": False, "error": "Timeout - server terlalu lambat"}
    except Exception as e:
        return {"success": False, "error": str(e)}

def parse_spongebob_args(args, user_full_name):
    """Parse argumen dengan format: nama | role | group"""
    if not args:
        return {
            "name": user_full_name,
            "role": DEFAULT_ROLE,
            "group": DEFAULT_GROUP
        }
    
    # Format: nama | role | group
    full_text = " ".join(args)
    parts = [p.strip() for p in full_text.split("|")]
    
    result = {
        "name": user_full_name,
        "role": DEFAULT_ROLE,
        "group": DEFAULT_GROUP
    }
    
    # Parse nama
    if len(parts) >= 1 and parts[0]:
        result["name"] = parts[0]
    
    # Parse role
    if len(parts) >= 2 and parts[1]:
        result["role"] = parts[1]
    
    # Parse group
    if len(parts) >= 3 and parts[2]:
        result["group"] = parts[2]
    
    return result

@PY.UBOT("spongebob")
@PY.UBOT("sbob")
async def spongebob_command(client: Client, message: Message):
    ggl = await EMO.GAGAL(client)
    sks = await EMO.BERHASIL(client)
    prs = await EMO.PROSES(client)
    
    # Parse argumen
    args = message.text.split()[1:]
    
    # Dapatkan info user
    user = message.from_user
    user_name = user.first_name or ""
    if user.last_name:
        user_name += f" {user.last_name}"
    
    # Dapatkan foto profil user
    user_photo = None
    try:
        photos = await client.get_chat_photos(user.id, limit=1)
        if photos:
            user_photo = photos[0].file_id
        else:
            # Fallback ke default image
            user_photo = "https://picsum.photos/200"
    except:
        user_photo = "https://picsum.photos/200"
    
    # Parse argumen
    parsed = parse_spongebob_args(args, user_name)
    
    # Cek apakah user reply ke pesan
    reply_to = message.reply_to_message
    if reply_to and reply_to.from_user:
        target_user = reply_to.from_user
        target_name = target_user.first_name or ""
        if target_user.last_name:
            target_name += f" {target_user.last_name}"
        
        # Ganti dengan data user yang direply
        parsed["name"] = target_name
        
        # Coba ambil foto user yang direply
        try:
            target_photos = await client.get_chat_photos(target_user.id, limit=1)
            if target_photos:
                user_photo = target_photos[0].file_id
        except:
            pass
    
    if not args:
        # Tampilkan help tanpa tombol
        help_text = f"""
<blockquote><b>Cara pakai:</b>
ᚗ <code>.spongebob [nama]</code>
ᚗ <code>.spongebob [nama] | [role] | [group]</code>

<b>Contoh sederhana:</b>
<code>.spongebob {user_name}</code>
<code>.sbob {user_name}</code>

<b>Contoh lengkap:</b>
<code>.spongebob {user_name} | Admin | Grup Anime</code>
<code>.sbob {user_name} | Member | My Group</code>

<b>📌 Fitur:</b>
• Auto ambil foto profil
• Bisa reply ke user lain
• Kustom role dan nama grup

<b>✨ Tips:</b>
Reply ke pesan orang lain buat buatin welcome card buat dia!</blockquote>"""
        
        await message.reply_text(help_text)
        return
    
    try:
        await client.send_chat_action(message.chat.id, ChatAction.UPLOAD_PHOTO)
        
        processing = await message.reply_text(
            f"{prs} <b>Membuat welcome card Spongebob...</b>\n"
            f"<b>Untuk:</b> {parsed['name']}"
        )
        
        # Dapatkan URL foto
        if user_photo and not user_photo.startswith("http"):
            # Kalau file_id, download dulu dan upload ke tempat penyimpanan sementara
            # TAPI karena ribet, kita pake foto default aja dulu
            # Atau bisa pake layanan upload sementara
            photo_url = "https://picsum.photos/200"
        else:
            photo_url = user_photo
        
        # Buat welcome card
        result = await create_spongebob_welcome(
            image_url=photo_url,
            name=parsed['name'],
            role=parsed['role'],
            group_name=parsed['group']
        )
        
        await processing.delete()
        
        if result.get("success") and result.get("image"):
            # Simpan gambar sementara
            file_path = f"spongebob_{message.from_user.id}_{random.randint(1000,9999)}.png"
            with open(file_path, "wb") as f:
                f.write(result["image"])
            
            # Buat caption dengan info
            caption = f"<blockquote><b>🧽 WELCOME SPONGEBOB</b>\n\n"
            caption += f"<b>👤 Nama:</b> {parsed['name']}\n"
            caption += f"<b>📌 Role:</b> {parsed['role']}\n"
            caption += f"<b>👥 Grup:</b> {parsed['group']}\n"
            caption += f"\n⚡ Powered by: Ubot Premium Zyura</blockquote>"
            
            # Kirim gambar
            await client.send_photo(
                chat_id=message.chat.id,
                photo=file_path,
                caption=caption
            )
            
            # Hapus file
            if os.path.exists(file_path):
                os.remove(file_path)
            
        else:
            error_msg = result.get("error", "Unknown error")
            await message.reply_text(
                f"<blockquote><b>❌ GAGAL MEMBUAT GAMBAR</b>\n\n"
                f"<b>Error:</b> {error_msg}</blockquote>"
            )
        
    except Exception as e:
        await message.reply_text(f"{ggl} <b>Error: {str(e)[:100]}</b>")

