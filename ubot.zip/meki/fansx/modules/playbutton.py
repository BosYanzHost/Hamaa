import os
import random
from fansx import *
import requests

# Daftar API keys By Zyura (12 key)
API_KEYS = [
    "eIxUwMpn",
    "keoCFdc6",
    "bv7m372F",
    "iAiB9QKT",
    "JP7Cy8Y2",
    "GI4vPxYv",
    "HRPga9TN",
    "PDwqhVsj",
    "m8jpBeZR",
    "PXkxh5hw",
    "MFnlpM6A",
    "u299UiOF"
]

def get_random_apikey():
    """Mengambil API key secara random dari daftar"""
    return random.choice(API_KEYS)

__MODULE__ = "ᴘʟᴀʏʙᴜᴛᴛᴏɴ"
__HELP__ = """
<b>⦪ ʙᴀɴᴛᴜᴀɴ ᴜɴᴛᴜᴋ ᴘʟᴀʏʙᴜᴛᴛᴏɴ ⦫</b>
<blockquote><b>
⎆ ᴘᴇʀɪɴᴛᴀʜ :
ᚗ <code>{0}ytgold</code>
⊷ untuk membuat gold playbutton youtube

ᚗ <code>{0}ytsilver</code>
⊷ untuk membuat silver playbutton youtube

ᚗ <code>{0}iggold</code>
⊷ untuk membuat gold playbutton instagram

ᚗ <code>{0}igsilver</code>
⊷ untuk membuat silver playbutton instagram

ᚗ <code>{0}fbgold</code>
⊷ untuk membuat gold playbutton facebook

ᚗ <code>{0}fbsilver</code>
⊷ untuk membuat silver playbutton facebook

ᚗ <code>{0}twtgold</code>
⊷ untuk membuat gold playbutton twitter

ᚗ <code>{0}twtsilver</code>
⊷ untuk membuat silver playbutton twitter
</b></blockquote>
"""

# TWITTER SILVER
def tweet(text):
    url = "https://api.botcahx.eu.org/api/ephoto/twtsilverbutton"
    apikey = get_random_apikey()
    params = {
        "text": text,
        "apikey": apikey
    }   
    try:
        response = requests.get(url, params=params)
        response.raise_for_status()
        
        if response.headers.get("Content-Type", "").startswith("image/"):
            return response.content
        else:
            return None
    except requests.exceptions.RequestException:
        return None

# TWITTER GOLD
def tweets(text):
    url = "https://api.botcahx.eu.org/api/ephoto/twtgoldbutton"
    apikey = get_random_apikey()
    params = {
        "text": text,
        "apikey": apikey
    }   
    try:
        response = requests.get(url, params=params)
        response.raise_for_status()
        
        if response.headers.get("Content-Type", "").startswith("image/"):
            return response.content
        else:
            return None
    except requests.exceptions.RequestException:
        return None        

# FACEBOOK SILVER
def fb(text):
    url = "https://api.botcahx.eu.org/api/ephoto/fbsilverbutton"
    apikey = get_random_apikey()
    params = {
        "text": text,
        "apikey": apikey
    }   
    try:
        response = requests.get(url, params=params)
        response.raise_for_status()
        
        if response.headers.get("Content-Type", "").startswith("image/"):
            return response.content
        else:
            return None
    except requests.exceptions.RequestException:
        return None

# FACEBOOK GOLD
def fbs(text):
    url = "https://api.botcahx.eu.org/api/ephoto/fbgoldbutton"
    apikey = get_random_apikey()
    params = {
        "text": text,
        "apikey": apikey
    }   
    try:
        response = requests.get(url, params=params)
        response.raise_for_status()
        
        if response.headers.get("Content-Type", "").startswith("image/"):
            return response.content
        else:
            return None
    except requests.exceptions.RequestException:
        return None

# YOUTUBE SILVER
def robott(text):
    url = "https://api.botcahx.eu.org/api/ephoto/ytsilverbutton"
    apikey = get_random_apikey()
    params = {
        "text": text,
        "apikey": apikey
    }   
    try:
        response = requests.get(url, params=params)
        response.raise_for_status()
        
        if response.headers.get("Content-Type", "").startswith("image/"):
            return response.content
        else:
            return None
    except requests.exceptions.RequestException:
        return None

# INSTAGRAM SILVER
def robottt(text):
    url = "https://api.botcahx.eu.org/api/ephoto/igsilverbutton"
    apikey = get_random_apikey()
    params = {
        "text": text,
        "apikey": apikey
    }   
    try:
        response = requests.get(url, params=params)
        response.raise_for_status()
        
        if response.headers.get("Content-Type", "").startswith("image/"):
            return response.content
        else:
            return None
    except requests.exceptions.RequestException:
        return None

# INSTAGRAM GOLD
def robotttg(text):
    url = "https://api.botcahx.eu.org/api/ephoto/iggoldbutton"
    apikey = get_random_apikey()
    params = {
        "text": text,
        "apikey": apikey
    }   
    try:
        response = requests.get(url, params=params)
        response.raise_for_status()
        
        if response.headers.get("Content-Type", "").startswith("image/"):
            return response.content
        else:
            return None
    except requests.exceptions.RequestException:
        return None                    

# YOUTUBE GOLD
def horor(text):
    url = "https://api.botcahx.eu.org/api/ephoto/ytgoldbutton"
    apikey = get_random_apikey()
    params = {
        "text": text,
        "apikey": apikey
    }                       
    try:
        response = requests.get(url, params=params)
        response.raise_for_status()
        
        if response.headers.get("Content-Type", "").startswith("image/"):
            return response.content
        else:
            return None
    except requests.exceptions.RequestException:
        return None

# YOUTUBE GOLD        
@PY.UBOT("ytgold")
async def ytgold_handler(client, message):
    args = message.text.split(" ", 1)
    if len(args) < 2:
        await message.reply_text("contoh : .ytgold cukiii")
        return

    request_text = args[1]
    await message.reply_text("sedang memproses, mohon tunggu...")

    image_content = horor(request_text)
    if image_content:
        temp_file = "img.jpg"
        with open(temp_file, "wb") as f:
            f.write(image_content)

        await message.reply_photo(photo=temp_file)
        os.remove(temp_file)
    else:
        await message.reply_text("apikey sedang bermasalah")
                              
# YOUTUBE SILVER
@PY.UBOT("ytsilver")
async def ytsilver_handler(client, message):
    args = message.text.split(" ", 1)
    if len(args) < 2:
        await message.reply_text("contoh : .ytsilver cukiii")
        return

    request_text = args[1]
    await message.reply_text("sedang memproses, mohon tunggu...")

    image_content = robott(request_text)
    if image_content:
        temp_file = "img.jpg"
        with open(temp_file, "wb") as f:
            f.write(image_content)

        await message.reply_photo(photo=temp_file)
        os.remove(temp_file)
    else:
        await message.reply_text("apikey sedang bermasalah")
  
# INSTAGRAM GOLD                                
@PY.UBOT("iggold")
async def iggold_handler(client, message):
    args = message.text.split(" ", 1)
    if len(args) < 2:
        await message.reply_text("contoh : .iggold cukiii")
        return

    request_text = args[1]
    await message.reply_text("sedang memproses, mohon tunggu...")

    image_content = robotttg(request_text)
    if image_content:
        temp_file = "img.jpg"
        with open(temp_file, "wb") as f:
            f.write(image_content)

        await message.reply_photo(photo=temp_file)
        os.remove(temp_file)
    else:
        await message.reply_text("apikey sedang bermasalah")
                                  
# INSTAGRAM SILVER
@PY.UBOT("igsilver")
async def igsilver_handler(client, message):
    args = message.text.split(" ", 1)
    if len(args) < 2:
        await message.reply_text("contoh : .igsilver cukiii")
        return

    request_text = args[1]
    await message.reply_text("sedang memproses, mohon tunggu...")

    image_content = robottt(request_text)
    if image_content:
        temp_file = "img.jpg"
        with open(temp_file, "wb") as f:
            f.write(image_content)

        await message.reply_photo(photo=temp_file)
        os.remove(temp_file)
    else:
        await message.reply_text("apikey sedang bermasalah")

# FACEBOOK SILVER                                   
@PY.UBOT("fbsilver")
async def fbsilver_handler(client, message):
    args = message.text.split(" ", 1)
    if len(args) < 2:
        await message.reply_text("contoh : .fbsilver cukiii")
        return

    request_text = args[1]
    await message.reply_text("sedang memproses, mohon tunggu...")

    image_content = fb(request_text)
    if image_content:
        temp_file = "img.jpg"
        with open(temp_file, "wb") as f:
            f.write(image_content)

        await message.reply_photo(photo=temp_file)
        os.remove(temp_file)
    else:
        await message.reply_text("apikey sedang bermasalah")

# FACEBOOK GOLD
@PY.UBOT("fbgold")
async def fbgold_handler(client, message):
    args = message.text.split(" ", 1)
    if len(args) < 2:
        await message.reply_text("contoh : .fbgold cukiii")
        return

    request_text = args[1]
    await message.reply_text("sedang memproses, mohon tunggu...")

    image_content = fbs(request_text)
    if image_content:
        temp_file = "img.jpg"
        with open(temp_file, "wb") as f:
            f.write(image_content)

        await message.reply_photo(photo=temp_file)
        os.remove(temp_file)
    else:
        await message.reply_text("apikey sedang bermasalah")

# TWITTER SILVER
@PY.UBOT("twtsilver")
async def twtsilver_handler(client, message):
    args = message.text.split(" ", 1)
    if len(args) < 2:
        await message.reply_text("contoh : .twtsilver cukiii")
        return

    request_text = args[1]
    await message.reply_text("sedang memproses, mohon tunggu...")

    image_content = tweet(request_text)
    if image_content:
        temp_file = "img.jpg"
        with open(temp_file, "wb") as f:
            f.write(image_content)

        await message.reply_photo(photo=temp_file)
        os.remove(temp_file)
    else:
        await message.reply_text("apikey sedang bermasalah")

# TWITTER GOLD
@PY.UBOT("twtgold")
async def twtgold_handler(client, message):
    args = message.text.split(" ", 1)
    if len(args) < 2:
        await message.reply_text("contoh : .twtgold cukiii")
        return

    request_text = args[1]
    await message.reply_text("sedang memproses, mohon tunggu...")

    image_content = tweets(request_text)
    if image_content:
        temp_file = "img.jpg"
        with open(temp_file, "wb") as f:
            f.write(image_content)

        await message.reply_photo(photo=temp_file)
        os.remove(temp_file)
    else:
        await message.reply_text("apikey sedang bermasalah")