import requests
import wget
import os
import random
from pyrogram import Client
from fansx import *

__MODULE__ = "sᴛᴀʟᴋɢʜ"
__HELP__ = """
<blockquote><b>Bantuan Untuk Stalk GH

Perintah : <code>{0}stalkgh [username]</code> 
    Untuk Stalk Github Menggunakan Username
    
Contoh:
<code>{0}stalkgh torvalds</code> - Stalk akun Linus Torvalds
<code>{0}stalkgh moonton</code> - Stalk akun Moonton</b></blockquote>
"""

# Daftar API keys By Zyura
API_KEYS = [
    "eIxUwMpn",
    "keoCFdc6",
    "bv7m372F",
    "iAiB9QKT",
    "JP7Cy8Y2",
    "GI4vPxYv",
    "HRPga9TN",
    "PDwqhVsj",
    "m8jpBeZR",
    "PXkxh5hw",
    "MFnlpM6A",
    "u299UiOF"
]

def get_random_apikey():
    """Mengambil API key secara random dari daftar"""
    return random.choice(API_KEYS)

def get_github_avatar(username):
    """Mendapatkan avatar GitHub langsung dari GitHub"""
    return f"https://github.com/{username}.png"

@PY.UBOT("stalkgh")
async def stalkgh(client, message):
    ggl = await EMO.GAGAL(client)
    sks = await EMO.BERHASIL(client)
    prs = await EMO.PROSES(client)
    
    jalan = await message.reply(f"{prs} Processing...")
    
    if len(message.command) < 2:
        return await jalan.edit(
            f"{ggl} <b>Gunakan format:</b>\n"
            f"<code>.stalkgh [username]</code>\n\n"
            f"<b>Contoh:</b>\n"
            f"<code>.stalkgh torvalds</code>"
        )
    
    username = message.command[1]
    chat_id = message.chat.id
    
    # Coba dengan beberapa API key
    success = False
    used_keys = set()
    max_attempts = min(3, len(API_KEYS))
    
    for attempt in range(max_attempts):
        available_keys = [key for key in API_KEYS if key not in used_keys]
        if not available_keys:
            break
            
        apikey = random.choice(available_keys)
        used_keys.add(apikey)
        
        # URL API dengan key random
        url = f"https://api.betabotz.eu.org/api/stalk/github?username={username}&apikey={apikey}"
        
        try:
            response = requests.get(url, timeout=10)
            
            if response.status_code == 200:
                data = response.json()
                
                # Cek struktur response
                if data.get('result') and data['result'].get('user') and len(data['result']['user']) > 0:
                    result = data['result']['user']
                    
                    # Ambil data dengan aman
                    name = result.get('name', 'Tidak ada nama')
                    username_gh = result.get('username', username)
                    followers = result.get('followers', 0)
                    following = result.get('following', 0)
                    bio = result.get('bio', 'Tidak ada bio')
                    id_user = result.get('idUser', 'Tidak ada ID')
                    public_repos = result.get('public_repos', 0)
                    created_at = result.get('created_at', 'Tidak diketahui')
                    
                    # Format angka
                    try:
                        followers = f"{int(followers):,}"
                        following = f"{int(following):,}"
                        public_repos = f"{int(public_repos):,}"
                    except:
                        pass
                    
                    # Buat caption
                    caption = f"""
<blockquote><b>🔍 GITHUB STALK</b>

👤 <b>Nama:</b> <code>{name}</code>
🔰 <b>Username:</b> <code>{username_gh}</code>
🆔 <b>ID:</b> <code>{id_user}</code>
📦 <b>Public Repos:</b> <code>{public_repos}</code>
👥 <b>Followers:</b> <code>{followers}</code>
🫂 <b>Following:</b> <code>{following}</code>
📝 <b>Bio:</b> <i>{bio[:100]}{'...' if len(bio) > 100 else ''}</i>
📅 <b>Joined:</b> <code>{created_at[:10] if created_at != 'Tidak diketahui' else created_at}</code>

🔑 <b>Key:</b> <code>{apikey[:8]}...</code>
⚡ <b>Powered by:</b> Ubot Premium Zyura</blockquote>
"""
                    
                    # Ambil avatar dari GitHub langsung
                    avatar_url = get_github_avatar(username)
                    
                    # Download avatar
                    try:
                        photo_path = wget.download(avatar_url)
                        
                        # Kirim foto dengan caption
                        await client.send_photo(
                            chat_id,
                            photo=photo_path,
                            caption=caption
                        )
                        
                        # Hapus file avatar
                        if os.path.exists(photo_path):
                            os.remove(photo_path)
                            
                    except Exception as e:
                        # Jika gagal download avatar, kirim tanpa foto
                        await client.send_message(
                            chat_id,
                            caption
                        )
                    
                    await jalan.delete()
                    success = True
                    break
                    
                else:
                    # Jika data tidak ditemukan, coba dengan key lain
                    continue
            else:
                # Jika status code error, coba dengan key lain
                continue
                
        except requests.exceptions.Timeout:
            continue
        except requests.exceptions.ConnectionError:
            continue
        except Exception as e:
            print(f"Error attempt {attempt+1}: {str(e)}")
            continue
    
    if not success:
        await jalan.edit(
            f"{ggl} <b>Gagal mengambil data GitHub!</b>\n\n"
            f"🔴 Kemungkinan penyebab:\n"
            f"• Username <code>{username}</code> tidak ditemukan\n"
            f"• API key habis limit\n"
            f"• Server sedang sibuk\n\n"
            f"🔄 Silakan coba lagi nanti dengan username lain."
        )

@PY.BOT("stalkgh")
async def stalkgh_bot(client, message):
    ggl = "❌"
    prs = "⏳"
    
    jalan = await message.reply(f"{prs} Processing...")
    
    if len(message.command) < 2:
        return await jalan.edit(
            f"{ggl} <b>Gunakan format:</b>\n"
            f"<code>/stalkgh [username]</code>\n\n"
            f"<b>Contoh:</b>\n"
            f"<code>/stalkgh torvalds</code>"
        )
    
    username = message.command[1]
    chat_id = message.chat.id
    
    # Coba dengan beberapa API key
    success = False
    used_keys = set()
    max_attempts = min(3, len(API_KEYS))
    
    for attempt in range(max_attempts):
        available_keys = [key for key in API_KEYS if key not in used_keys]
        if not available_keys:
            break
            
        apikey = random.choice(available_keys)
        used_keys.add(apikey)
        
        url = f"https://api.betabotz.eu.org/api/stalk/github?username={username}&apikey={apikey}"
        
        try:
            response = requests.get(url, timeout=10)
            
            if response.status_code == 200:
                data = response.json()
                
                if data.get('result') and data['result'].get('user') and len(data['result']['user']) > 0:
                    result = data['result']['user']
                    
                    name = result.get('name', 'Tidak ada nama')
                    username_gh = result.get('username', username)
                    followers = result.get('followers', 0)
                    following = result.get('following', 0)
                    bio = result.get('bio', 'Tidak ada bio')
                    id_user = result.get('idUser', 'Tidak ada ID')
                    public_repos = result.get('public_repos', 0)
                    created_at = result.get('created_at', 'Tidak diketahui')
                    
                    try:
                        followers = f"{int(followers):,}"
                        following = f"{int(following):,}"
                        public_repos = f"{int(public_repos):,}"
                    except:
                        pass
                    
                    caption = f"""
<blockquote><b>🔍 GITHUB STALK</b>

👤 <b>Nama:</b> <code>{name}</code>
🔰 <b>Username:</b> <code>{username_gh}</code>
🆔 <b>ID:</b> <code>{id_user}</code>
📦 <b>Public Repos:</b> <code>{public_repos}</code>
👥 <b>Followers:</b> <code>{followers}</code>
🫂 <b>Following:</b> <code>{following}</code>
📝 <b>Bio:</b> <i>{bio[:100]}{'...' if len(bio) > 100 else ''}</i>
📅 <b>Joined:</b> <code>{created_at[:10] if created_at != 'Tidak diketahui' else created_at}</code>

⚡ <b>Powered by:</b> Ubot Premium Zyura</blockquote>
"""
                    
                    # Ambil avatar dari GitHub langsung
                    avatar_url = get_github_avatar(username)
                    
                    try:
                        photo_path = wget.download(avatar_url)
                        
                        await client.send_photo(
                            chat_id,
                            photo=photo_path,
                            caption=caption
                        )
                        
                        if os.path.exists(photo_path):
                            os.remove(photo_path)
                            
                    except Exception:
                        await client.send_message(
                            chat_id,
                            caption
                        )
                    
                    await jalan.delete()
                    success = True
                    break
                    
                else:
                    continue
            else:
                continue
                
        except Exception:
            continue
    
    if not success:
        await jalan.edit(
            f"{ggl} <b>Gagal mengambil data GitHub!</b>\n\n"
            f"Username <code>{username}</code> mungkin tidak ditemukan."
        )