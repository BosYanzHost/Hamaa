from fansx import *
import aiohttp
import asyncio
import os
import random
from pyrogram.enums import ChatAction, ParseMode
from pyrogram.types import Message

__MODULE__ = "ᴛᴏ ᴄᴀʀᴛᴏᴏɴ"
__HELP__ = """
<blockquote><b>⌲ Perintah:</b>
ᚗ <code>{0}tocartoon</code> - Balas ke gambar
ᚗ <code>{0}tocartoon [link]</code> - Pakai link gambar

<b>⌲ Contoh:</b>
<code>.tocartoon</code> (sambil reply gambar)
<code>.tocartoon https://files.catbox.moe/gke22r.jpg</code></blockquote>
"""

# ============================================
# KONFIGURASI
# ============================================
TOCARTOON_API = "https://rynekoo-api.hf.space/style.changer/cartoon"

async def convert_to_cartoon(image_url):
    """Ubah gambar jadi gaya kartun"""
    
    # Encode parameter
    url = f"{TOCARTOON_API}?imageUrl={image_url}"
    
    try:
        async with aiohttp.ClientSession() as session:
            async with session.get(url, timeout=60) as response:  # Timeout lebih lama karena proses gambar
                if response.status == 200:
                    data = await response.json()
                    
                    if data.get("success") and data.get("result"):
                        result_url = data["result"]
                        response_time = data.get("responseTime", "Unknown")
                        
                        # Download gambar hasil
                        async with session.get(result_url, timeout=30) as img_resp:
                            if img_resp.status == 200:
                                return {
                                    "success": True,
                                    "image": await img_resp.read(),
                                    "result_url": result_url,
                                    "response_time": response_time
                                }
                            else:
                                # Kalo gagal download, kasih URL nya aja
                                return {
                                    "success": True,
                                    "image": None,
                                    "result_url": result_url,
                                    "response_time": response_time
                                }
                    else:
                        return {"success": False, "error": "API mengembalikan format tidak dikenal"}
                else:
                    return {"success": False, "error": f"HTTP {response.status}"}
    except asyncio.TimeoutError:
        return {"success": False, "error": "Timeout - server terlalu lama merespon"}
    except Exception as e:
        return {"success": False, "error": str(e)}

def extract_image_url(message):
    """Ekstrak URL gambar dari pesan"""
    # Cek dari reply
    if message.reply_to_message and message.reply_to_message.photo:
        return "reply_photo"
    
    # Cek dari teks
    args = message.text.split()
    if len(args) > 1:
        url = args[1].strip()
        if url.startswith(('http://', 'https://')):
            # Cek apakah URL gambar
            img_extensions = ['.jpg', '.jpeg', '.png', '.gif', '.webp', '.bmp']
            if any(ext in url.lower() for ext in img_extensions):
                return url
    
    return None

@PY.UBOT("tocartoon")
async def tocartoon_command(client: Client, message: Message):
    ggl = await EMO.GAGAL(client)
    sks = await EMO.BERHASIL(client)
    prs = await EMO.PROSES(client)
    
    # Ekstrak URL gambar
    image_url = extract_image_url(message)
    
    if not image_url:
        # Tampilkan help
        help_text = f"""
<blockquote><b>Cara pakai:</b>
1. <b>Reply ke gambar:</b>
   <code>.tocartoon</code> (sambil reply gambar)

2. <b>Pakai link gambar:</b>
   <code>.tocartoon [link_gambar]</code>

<b>Contoh:</b>
<code>.tocartoon</code> (reply foto)
<code>.tocartoon https://files.catbox.moe/gke22r.jpg</code>

<b>📌 Fitur:</b>
• Ubah foto/gambar jadi gaya kartun
• Hasil keren ala kartun animasi
• Proses ±5-10 detik

<b>💡 Tips:</b>
• Pakai foto dengan wajah yang jelas
• Hasil lebih bagus kalo gambarnya nggak terlalu gelap</blockquote>"""
        
        await message.reply_text(help_text)
        return
    
    try:
        await client.send_chat_action(message.chat.id, ChatAction.UPLOAD_PHOTO)
        
        processing = await message.reply_text(
            f"{prs} <b>Mengubah gambar jadi kartun...</b>\n"
            f"<i>Proses ±5-10 detik, harap sabar...</i>"
        )
        
        # Kalo dari reply, download dulu fotonya
        if image_url == "reply_photo":
            # Untuk sekarang, kita kasih info dulu
            await processing.edit_text(
                f"{prs} <b>Fitur upload foto dari reply masih dalam pengembangan...</b>\n"
                f"<i>Gunakan link gambar dulu ya!</i>"
            )
            await asyncio.sleep(2)
            await processing.delete()
            return
        
        # Convert gambar
        result = await convert_to_cartoon(image_url)
        
        await processing.delete()
        
        if result.get("success"):
            if result.get("image"):
                # Simpan gambar sementara
                file_path = f"tocartoon_{message.from_user.id}_{random.randint(1000,9999)}.png"
                with open(file_path, "wb") as f:
                    f.write(result["image"])
                
                # Buat caption
                response_time = result.get("response_time", "Unknown")
                caption = f"<blockquote><b>⏱️ Waktu:</b> {response_time}\n"
                caption += f"\n⚡ Powered by: Ubot Premium Zyura</blockquote>"
                
                # Kirim gambar
                await client.send_photo(
                    chat_id=message.chat.id,
                    photo=file_path,
                    caption=caption
                )
                
                # Hapus file
                if os.path.exists(file_path):
                    os.remove(file_path)
                
            else:
                # Kalo gagal download, kasih URL nya
                result_url = result.get("result_url")
                response_time = result.get("response_time", "Unknown")
                
                await message.reply_text(
                    f"<blockquote><b>✅ Berhasil dikonversi!</b>\n"
                    f"<b>⏱️ Waktu:</b> {response_time}\n\n"
                    f"<b>🔗 Link hasil:</b>\n<code>{result_url}</code>\n\n"
                    f"⚡ Powered by: Ubot Premium Zyura</blockquote>"
                )
            
        else:
            error_msg = result.get("error", "Unknown error")
            await message.reply_text(
                f"<blockquote><b>❌ GAGAL MENGUBAH GAMBAR</b>\n\n"
                f"<b>Error:</b> {error_msg}</blockquote>"
            )
        
    except Exception as e:
        await message.reply_text(f"{ggl} <b>Error: {str(e)[:100]}</b>")

