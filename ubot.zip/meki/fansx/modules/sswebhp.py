import os
import datetime
import requests
import random
from fansx import *

__MODULE__ = "ss ᴡᴇʙ ʜᴘ"
__HELP__ = """
<b>⦪ ʙᴀɴᴛᴜᴀɴ ᴜɴᴛᴜᴋ ss ᴡᴇʙ ʜᴘ ⦫</b>

<blockquote><b>⎆ ᴘᴇʀɪɴᴛᴀʜ :
ᚗ <code>{0}sshp</code> [link]

⌭ ᴘᴇɴᴊᴇʟᴀsᴀɴ:
ᚗ untuk screenshot website dengan mode HP/Handphone

📌 Contoh:
<code>{0}sshp google.com</code>
<code>{0}sshp https://rumahotp.com</code></b></blockquote>
"""

# Base URL API YanzHost (sama seperti sswebtablet)
BASE_URL = "https://yanzapii.vercel.app/tools/ssweb"

def get_ssweb_image(url):
    """
    Mengambil screenshot website dari API YanzHost
    (Mode HP - menggunakan parameter device/mobile)
    """
    # Parameter untuk API
    params = {
        "apikey": "ynz",
        "url": url
        # Catatan: API ini mungkin menggunakan mode default (bisa tablet/hp)
        # Jika ada parameter device, bisa ditambahkan di sini
    }
    
    try:
        print(f"Request screenshot HP untuk: {url}")
        response = requests.get(BASE_URL, params=params, timeout=30)
        
        if response.status_code == 200:
            data = response.json()
            
            if data.get("status") and data.get("result"):
                # Ambil URL gambar dari response
                img_url = data["result"]
                print(f"URL gambar: {img_url}")
                
                # Download gambar
                img_response = requests.get(img_url, timeout=30)
                
                if img_response.status_code == 200:
                    # Cek apakah response berupa gambar
                    content_type = img_response.headers.get("Content-Type", "")
                    if content_type.startswith("image/"):
                        return img_response.content
                    else:
                        print(f"Bukan gambar: {content_type}")
                        return None
                else:
                    print(f"Gagal download gambar: HTTP {img_response.status_code}")
                    return None
            else:
                print("Response tidak valid:", data)
                return None
        else:
            print(f"HTTP Error: {response.status_code}")
            return None
            
    except requests.exceptions.Timeout:
        print("Timeout error")
        return None
    except requests.exceptions.ConnectionError:
        print("Connection error")
        return None
    except Exception as e:
        print(f"Error: {str(e)}")
        return None

@PY.UBOT("sshp")
async def screenshot_handler(client, message):
    args = message.text.split(maxsplit=1)
    if len(args) < 2:
        await message.reply_text(
            "<blockquote><b>❌ MANA URL NYA!</b>\n\n"
            "<b>Contoh penggunaan:</b>\n"
            "<code>.sshp google.com</code>\n"
            "<code>.sshp https://rumahotp.com</code></blockquote>"
        )
        return

    # Ambil URL dan pastikan formatnya benar
    url = args[1].strip()
    if not url.startswith(("http://", "https://")):
        url = "https://" + url

    # Kirim pesan processing
    processing = await message.reply_text(
        f"<blockquote><b>📱 MEMPROSES SCREENSHOT HANDPHONE</b>\n\n"
        f"🔗 <b>URL:</b> <code>{url[:50]}{'...' if len(url) > 50 else ''}</code>\n"
        f"⏳ Mohon tunggu...</blockquote>"
    )

    # Ambil screenshot
    image_data = get_ssweb_image(url)
    
    if image_data:
        # Simpan gambar ke file temporary
        timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
        filepath = f"ss_hp_{timestamp}.jpg"
        
        with open(filepath, "wb") as file:
            file.write(image_data)

        # Kirim gambar
        await client.send_photo(
            chat_id=message.chat.id,
            photo=filepath,
            caption=f"<blockquote><b>✅ SCREENSHOT HANDPHONE BERHASIL</b>\n\n"
                    f"🔗 <b>URL:</b> <code>{url}</code>\n"
                    f"📱 <b>Mode:</b> Handphone/Mobile\n"
                    f"⚡ <b>Powered by:</b> Ubot Premium Zyura</blockquote>"
        )
        
        # Hapus file temporary
        if os.path.exists(filepath):
            os.remove(filepath)
        
        await processing.delete()
        
    else:
        await processing.edit_text(
            "<blockquote><b>❌ GAGAL MENGAMBIL SCREENSHOT!</b>\n\n"
            "🔴 Kemungkinan penyebab:\n"
            "• URL tidak valid atau tidak dapat diakses\n"
            "• Website memblokir bot/security verification\n"
            "• Server API sedang sibuk\n\n"
            "🔄 Silakan coba lagi dengan URL yang berbeda.</blockquote>"
        )

@PY.BOT("sshp")
async def screenshot_handler_bot(client, message):
    args = message.text.split(maxsplit=1)
    if len(args) < 2:
        await message.reply_text(
            "❌ Gunakan: /sshp [url]\n"
            "Contoh: /sshp google.com"
        )
        return

    url = args[1].strip()
    if not url.startswith(("http://", "https://")):
        url = "https://" + url

    processing = await message.reply_text(f"📱 Processing screenshot HP: {url}")

    image_data = get_ssweb_image(url)
    
    if image_data:
        timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
        filepath = f"ss_hp_{timestamp}.jpg"
        
        with open(filepath, "wb") as file:
            file.write(image_data)

        await client.send_photo(
            chat_id=message.chat.id,
            photo=filepath,
            caption=f"✅ Screenshot HP: {url}"
        )
        
        os.remove(filepath)
        await processing.delete()
    else:
        await processing.edit_text("❌ Gagal mengambil screenshot")