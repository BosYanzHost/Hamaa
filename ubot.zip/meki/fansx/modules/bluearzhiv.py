from fansx import *
import aiohttp
import asyncio
import os
import random
from pyrogram.enums import ChatAction, ParseMode
from pyrogram.types import Message

__MODULE__ = "ʙʟᴜᴇ ᴀʀᴄʜɪᴠᴇ"
__HELP__ = """
<blockquote><b>🎮 BLUE ARCHIVE RANDOM IMAGE</b>

<b>⌲ Perintah:</b>
ᚗ <code>{0}bluearchive</code> - Ambil random gambar Blue Archive
ᚗ <code>{0}blue</code> - Singkatan

<b>⌲ Contoh:</b>
<code>.bluearchive</code>
<code>.blue</code></blockquote>
"""

# ============================================
# KONFIGURASI
# ============================================
API_URL = "https://api.theresav.biz.id/image/bluearchive"
API_KEY = "UYGSg"

async def get_bluearchive_image():
    """Ambil random gambar Blue Archive dari API"""
    url = f"{API_URL}?apikey={API_KEY}"
    
    try:
        async with aiohttp.ClientSession() as session:
            async with session.get(url, timeout=15) as response:
                if response.status == 200:
                    # Cek content-type
                    content_type = response.headers.get("Content-Type", "")
                    
                    if "image" in content_type:
                        # Langsung gambar
                        return {
                            "success": True,
                            "image": await response.read()
                        }
                    else:
                        # Mungkin JSON dengan URL
                        try:
                            data = await response.json()
                            if data.get("status") and data.get("url"):
                                img_url = data["url"]
                                # Download dari URL
                                async with session.get(img_url, timeout=15) as img_resp:
                                    if img_resp.status == 200:
                                        return {
                                            "success": True,
                                            "image": await img_resp.read()
                                        }
                        except:
                            pass
                        
                        return {
                            "success": False,
                            "error": "API tidak mengembalikan gambar"
                        }
                else:
                    return {"success": False, "error": f"HTTP {response.status}"}
    except asyncio.TimeoutError:
        return {"success": False, "error": "Timeout"}
    except Exception as e:
        return {"success": False, "error": str(e)}

@PY.UBOT("bluearchive")
@PY.UBOT("blue")
async def bluearchive_command(client: Client, message: Message):
    ggl = await EMO.GAGAL(client)
    sks = await EMO.BERHASIL(client)
    prs = await EMO.PROSES(client)
    
    try:
        await client.send_chat_action(message.chat.id, ChatAction.UPLOAD_PHOTO)
        
        processing = await message.reply_text(f"{prs} <b>Mencari gambar Blue Archive...</b>")
        
        result = await get_bluearchive_image()
        
        await processing.delete()
        
        if result.get("success") and result.get("image"):
            # Simpan gambar sementara
            file_path = f"bluearchive_{message.from_user.id}_{random.randint(1000,9999)}.jpg"
            with open(file_path, "wb") as f:
                f.write(result["image"])
            
            # Kirim gambar
            await client.send_photo(
                chat_id=message.chat.id,
                photo=file_path,
                caption="<blockquote><b>🎮 BLUE ARCHIVE</b>\n\n⚡ <b>Powered by:</b> Ubot Premium Zyura</blockquote>"
            )
            
            # Hapus file
            if os.path.exists(file_path):
                os.remove(file_path)
        else:
            error_msg = result.get("error", "Unknown error")
            await message.reply_text(
                f"<blockquote><b>❌ GAGAL MENGAMBIL GAMBAR</b>\n\n"
                f"Error: {error_msg}</blockquote>"
            )
        
    except Exception as e:
        await message.reply_text(f"{ggl} <b>Error: {str(e)[:100]}</b>")

