from fansx import *
import random
import requests
from pyrogram.enums import *
from pyrogram import *
from pyrogram.types import *
from io import BytesIO

__MODULE__ = "ᴀɴɪᴍᴇ 2"
__HELP__ = """
<b>⦪ ʙᴀɴᴛᴜᴀɴ ᴜɴᴛᴜᴋ ᴀɴɪᴍᴇ 2 ⦫</b>
<blockquote>
⎆ perintah :
ᚗ <code>{0}anime</code> Query
⊶ buat pertanyaan contoh <code>{0}ask</code> dimana letak Antartika

<b>ᚗ Query:</b>
    <i>⊶ keneki</i>,
    <i>⊶ megumin</i>,
    <i>⊶ yotsuba</i>,
    <i>⊶ shinomiya</i>,
    <i>⊶ yumeko</i>,
    <i>⊶ tsunade</i>,
    <i>⊶ kagura</i>,
    <i>⊶ madara</i>,
    <i>⊶ itachi</i>,
    <i>⊶ akira</i>,
    <i>⊶ toukachan</i>,
    <i>⊶ cicho</i>,
    <i>⊶ sasuke</i></blockquote>
"""

# Daftar API keys By Zyura kalau exp buat sendiri yah🗿
API_KEYS = [

    "eIxUwMpn",
    "keoCFdc6",
    "bv7m372F",
    "iAiB9QKT",
    "JP7Cy8Y2",
    "GI4vPxYv",
    "HRPga9TN",
    "PDwqhVsj",
    "m8jpBeZR",
    "PXkxh5hw",
    "MFnlpM6A",
    "u299UiOF"
    
]

def get_random_apikey():
    """Mengambil API key secara random dari daftar"""
    return random.choice(API_KEYS)

# Base URL tanpa apikey
BASE_URL = "https://api.botcahx.eu.org/api/anime/"

# Daftar query dengan mapping yang benar
QUERY_MAPPING = {
    "keneki": "keneki",
    "megumin": "megumin",
    "yotsuba": "yotsuba",
    "shinomiya": "shinomiya",
    "yumeko": "yumeko",
    "tsunade": "tsunade",
    "kagura": "kagura",
    "madara": "madara",
    "itachi": "itachi",
    "akira": "akira",
    "toukachan": "toukachan",
    "cicho": "chiho",  # Mapping cicho ke chiho
    "sasuke": "sasuke"
}

# Pesan error jika query tidak valid
INVALID_QUERY_MSG = "Query tidak valid. Gunakan salah satu dari: {}"

@PY.UBOT("anime")
@PY.TOP_CMD
async def _(client, message):
    # Extract query from message
    query = message.text.split()[1].lower() if len(message.text.split()) > 1 else None
    
    if not query:
        valid_queries = ", ".join(QUERY_MAPPING.keys())
        await message.reply(f"❌ Mohon masukkan query.\n{INVALID_QUERY_MSG.format(valid_queries)}")
        return
    
    if query not in QUERY_MAPPING:
        valid_queries = ", ".join(QUERY_MAPPING.keys())
        await message.reply(INVALID_QUERY_MSG.format(valid_queries))
        return

    # Ambil query yang benar dari mapping
    actual_query = QUERY_MAPPING[query]
    
    processing_msg = await message.reply("⏳ Processing....")
    
    try:
        await client.send_chat_action(message.chat.id, ChatAction.UPLOAD_PHOTO)
        
        # Coba dengan beberapa API key
        success = False
        used_keys = set()  # Untuk melacak key yang sudah dicoba
        max_attempts = min(3, len(API_KEYS))  # Maksimal 3 percobaan atau sebanyak jumlah key
        
        for attempt in range(max_attempts):
            # Ambil API key yang belum dicoba
            available_keys = [key for key in API_KEYS if key not in used_keys]
            if not available_keys:
                break
                
            apikey = random.choice(available_keys)
            used_keys.add(apikey)
            
            try:
                # Buat URL dengan apikey random
                url = f"{BASE_URL}{actual_query}?apikey={apikey}"
                
                # Set timeout untuk mencegah request terlalu lama
                response = requests.get(url, timeout=10)
                
                if response.status_code == 200:
                    # Cek apakah response berupa gambar
                    content_type = response.headers.get('content-type', '').lower()
                    
                    if 'image' in content_type:
                        photo = BytesIO(response.content)
                        photo.name = f'{actual_query}.jpg'
                        
                        await client.send_photo(message.chat.id, photo)
                        await processing_msg.delete()
                        success = True
                        break
                    else:
                        # Jika response bukan gambar, coba dengan key lain
                        continue
                else:
                    # Jika status code error, coba dengan key lain
                    continue
                    
            except requests.exceptions.Timeout:
                # Timeout, coba dengan key lain
                continue
            except requests.exceptions.ConnectionError:
                # Connection error, coba dengan key lain
                continue
            except Exception as e:
                # Error lain, coba dengan key lain
                continue
        
        if not success:
            await processing_msg.edit_text(
                "❌ Gagal mengambil gambar anime setelah beberapa percobaan.\n"
                "Silakan coba lagi nanti atau gunakan query lain."
            )
            
    except Exception as e:
        await processing_msg.edit_text(f"❌ Terjadi kesalahan: {str(e)[:100]}")  # Batasi panjang pesan error