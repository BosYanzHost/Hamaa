import os
import requests
import random
from fansx import *

# Daftar API keys By Zyura kalau exp buat sendiri yah🗿
API_KEYS = [
    "eIxUwMpn",
    "keoCFdc6",
    "bv7m372F",
    "iAiB9QKT",
    "JP7Cy8Y2",
    "GI4vPxYv",
    "HRPga9TN",
    "PDwqhVsj",
    "m8jpBeZR",
    "PXkxh5hw",
    "MFnlpM6A",
    "u299UiOF"
]

def get_random_apikey():
    """Mengambil API key secara random dari daftar"""
    return random.choice(API_KEYS)

__MODULE__ = "ʏᴛsᴇᴀʀᴄʜ"
__HELP__ = """
📚 <b>Ytsearch Commands</b>

<blockquote><b>🚦 Perintah : <code>{0}ytsearch</code>
🦠 Penjelasan : Mencari video di YouTube berdasarkan kata kunci.</b></blockquote>
"""

def fetch_youtube(api_url, query):
    """
    Fungsi untuk mengambil hasil pencarian dari API YouTube dengan random API key
    """
    # Ambil API key random
    apikey = get_random_apikey()
    
    params = {"query": query, "apikey": apikey}
    try:
        response = requests.get(api_url, params=params, timeout=10)
        response.raise_for_status()

        # Memeriksa apakah respons berisi hasil pencarian
        data = response.json()
        if data.get("status") and "result" in data:
            return data["result"], apikey
        else:
            print("Tidak ada hasil pencarian dalam response:", data)
            return None, apikey
    except requests.exceptions.Timeout:
        print("Timeout error")
        return None, apikey
    except requests.exceptions.RequestException as e:
        print(f"Error fetching YouTube results: {e}")
        return None, apikey

async def process_youtube_command(client, message, api_url, command_name):
    """
    Fungsi umum untuk menangani perintah pencarian YouTube
    """
    args = message.text.split(" ", 1)
    if len(args) < 2:
        await message.reply_text(
            f"<blockquote><b>❌ Gunakan perintah:</b> <code>.{command_name} [kata kunci]</code>\n\n"
            f"<b>Contoh:</b> <code>.{command_name} lucu</code></blockquote>"
        )
        return

    query = args[1]
    processing = await message.reply_text(
        "<blockquote><b>🔍 Sedang mencari di YouTube, mohon tunggu...</b></blockquote>"
    )

    # Coba dengan beberapa API key jika gagal
    results = None
    used_key = None
    max_attempts = 3
    
    for attempt in range(max_attempts):
        results, used_key = fetch_youtube(api_url, query)
        if results:
            break
    
    if results:
        # Mengirimkan hasil pencarian sebagai daftar
        response_text = (
            "<blockquote><b>📹 HASIL PENCARIAN YOUTUBE</b>\n\n"
            f"<b>🔎 Query:</b> <code>{query}</code>\n"
            f"<b>📊 Total:</b> {len(results)} video ditemukan\n\n"
        )
        
        # Menampilkan hingga 5 hasil saja
        for idx, result in enumerate(results[:5], start=1):
            title = result.get("title", "Tidak ada judul")
            link = result.get("url", "Tidak ada link")
            duration = result.get("duration", "Tidak diketahui")
            views = result.get("views", "Tidak diketahui")
            uploaded = result.get("uploaded", "Tidak diketahui")
            
            # Format views
            try:
                views_num = int(views.replace(',', ''))
                if views_num >= 1000000:
                    views_formatted = f"{views_num/1000000:.1f}M"
                elif views_num >= 1000:
                    views_formatted = f"{views_num/1000:.1f}K"
                else:
                    views_formatted = str(views_num)
            except:
                views_formatted = views
            
            response_text += (
                f"<b>{idx}. {title}</b>\n"
                f"┣ ⏱️ <b>Durasi:</b> {duration}\n"
                f"┣ 👁️ <b>Views:</b> {views_formatted}\n"
                f"┣ 📅 <b>Upload:</b> {uploaded}\n"
                f"┗ 🔗 <b>Link:</b> <a href='{link}'>Tonton Video</a>\n\n"
            )
        
        response_text += f"<b>🔑 Key:</b> <code>{used_key[:8]}...</code></blockquote>"
        
        await processing.edit_text(
            response_text, 
            disable_web_page_preview=True
        )
    else:
        await processing.edit_text(
            "<blockquote><b>❌ Gagal mencari video setelah beberapa percobaan.</b>\n\n"
            "🔴 Kemungkinan penyebab:\n"
            "• API key habis limit\n"
            "• Server sedang sibuk\n"
            "• Kata kunci tidak ditemukan\n\n"
            "🔄 Silakan coba lagi nanti dengan kata kunci berbeda.</blockquote>"
        )

# Handler untuk perintah ytsearch
@PY.UBOT("ytsearch")
async def youtube_command(client, message):
    api_url = "https://api.botcahx.eu.org/api/search/yts"
    await process_youtube_command(client, message, api_url, "ytsearch")

# Handler untuk bot (perintah dengan /)
@PY.BOT("ytsearch")
async def youtube_command_bot(client, message):
    api_url = "https://api.botcahx.eu.org/api/search/yts"
    
    args = message.text.split(" ", 1)
    if len(args) < 2:
        await message.reply_text(
            f"<blockquote><b>❌ Gunakan perintah:</b> <code>/ytsearch [kata kunci]</code>\n\n"
            f"<b>Contoh:</b> <code>/ytsearch lucu</code></blockquote>"
        )
        return

    query = args[1]
    processing = await message.reply_text(
        "<blockquote><b>🔍 Sedang mencari di YouTube, mohon tunggu...</b></blockquote>"
    )

    # Coba dengan beberapa API key jika gagal
    results = None
    used_key = None
    max_attempts = 3
    
    for attempt in range(max_attempts):
        results, used_key = fetch_youtube(api_url, query)
        if results:
            break
    
    if results:
        response_text = (
            "<blockquote><b>📹 HASIL PENCARIAN YOUTUBE</b>\n\n"
            f"<b>🔎 Query:</b> <code>{query}</code>\n"
            f"<b>📊 Total:</b> {len(results)} video ditemukan\n\n"
        )
        
        for idx, result in enumerate(results[:5], start=1):
            title = result.get("title", "Tidak ada judul")
            link = result.get("url", "Tidak ada link")
            duration = result.get("duration", "Tidak diketahui")
            views = result.get("views", "Tidak diketahui")
            uploaded = result.get("uploaded", "Tidak diketahui")
            
            # Format views
            try:
                views_num = int(views.replace(',', ''))
                if views_num >= 1000000:
                    views_formatted = f"{views_num/1000000:.1f}M"
                elif views_num >= 1000:
                    views_formatted = f"{views_num/1000:.1f}K"
                else:
                    views_formatted = str(views_num)
            except:
                views_formatted = views
            
            response_text += (
                f"<b>{idx}. {title}</b>\n"
                f"┣ ⏱️ <b>Durasi:</b> {duration}\n"
                f"┣ 👁️ <b>Views:</b> {views_formatted}\n"
                f"┣ 📅 <b>Upload:</b> {uploaded}\n"
                f"┗ 🔗 <b>Link:</b> <a href='{link}'>Tonton Video</a>\n\n"
            )
        
        response_text += f"<b>🔑 Key:</b> <code>{used_key[:8]}...</code></blockquote>"
        
        await processing.edit_text(
            response_text, 
            disable_web_page_preview=True
        )
    else:
        await processing.edit_text(
            "<blockquote><b>❌ Gagal mencari video setelah beberapa percobaan.</b>\n\n"
            "🔄 Silakan coba lagi nanti dengan kata kunci berbeda.</blockquote>"
        )