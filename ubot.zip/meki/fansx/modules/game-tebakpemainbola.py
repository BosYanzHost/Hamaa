from fansx import *
import aiohttp
import asyncio
import random
import json
import os
from datetime import datetime
from pyrogram.enums import ChatAction, ParseMode
from pyrogram.types import Message

__MODULE__ = "ᴛᴇʙᴀᴋ ᴘᴇᴍᴀɪɴ ʙᴏʟᴀ"
__HELP__ = """
<blockquote><b>⚽ GAME: TEBAK PEMAIN BOLA</b>

<b>⌲ Perintah:</b>
ᚗ <code>{0}tebakbola</code> - Mulai game baru
ᚗ <code>{0}tb</code> - Mulai game (singkatan)
ᚗ <code>{0}jawabb [jawaban]</code> - Jawab tebakan
ᚗ <code>{0}skipb</code> - Lewati pertanyaan
ᚗ <code>{0}skorb</code> - Lihat papan peringkat

<b>⌲ Cara main:</b>
1. Ketik <code>.tebakbola</code> untuk mulai
2. Bot kasih clue tentang pemain bola
3. Tebak nama pemainnya
4. Ketik <code>.jawabb [jawaban]</code>
5. Bot kasih tau bener atau salah
6. Dapet skor kalo bener!

<b>⌲ Contoh:</b>
<code>.tebakbola</code>
<code>.jawabb Lautaro Martínez</code>
<code>.jawabb Alisson Becker</code></blockquote>
"""

# ============================================
# KONFIGURASI
# ============================================
API_URL = "https://api.deline.web.id/game/tebakpemainbola"

# Database untuk menyimpan state game per user
game_sessions = {}
leaderboard = {}

async def get_question():
    """Ambil soal dari API"""
    try:
        async with aiohttp.ClientSession() as session:
            async with session.get(API_URL, timeout=10) as response:
                if response.status == 200:
                    data = await response.json()
                    if data.get("status") and data.get("result"):
                        result = data["result"]
                        return {
                            "question": result.get("soal", ""),
                            "answer": result.get("jawaban", "").strip().lower(),
                            "description": result.get("deskripsi", "")
                        }
    except Exception as e:
        print(f"Error get question: {e}")
    return None

def normalize_answer(answer):
    """Normalisasi jawaban"""
    return " ".join(answer.lower().split())

@PY.UBOT("tebakbola")
@PY.UBOT("tb")
async def start_game(client: Client, message: Message):
    ggl = await EMO.GAGAL(client)
    prs = await EMO.PROSES(client)
    
    user_id = message.from_user.id
    user_name = message.from_user.first_name
    
    try:
        await client.send_chat_action(message.chat.id, ChatAction.TYPING)
        
        processing = await message.reply_text(f"{prs} <b>Menyiapkan tebakan pemain bola...</b>")
        
        question_data = await get_question()
        
        if not question_data:
            await processing.edit_text(f"{ggl} <b>Gagal mengambil soal!</b>")
            return
        
        question = question_data["question"]
        answer = question_data["answer"]
        description = question_data["description"]
        
        game_sessions[user_id] = {
            "question": question,
            "answer": answer,
            "description": description,
            "start_time": datetime.now(),
            "attempts": 0
        }
        
        await processing.delete()
        
        await message.reply_text(
            f"<blockquote><b>⚽ TEBAK PEMAIN BOLA</b>\n\n"
            f"<b>Clue:</b>\n<code>{question}</code>\n\n"
            f"<b>Jawab:</b> <code>.jawabb [nama pemain]</code>\n"
            f"<b>Lewati:</b> <code>.skipb</code></blockquote>"
        )
        
    except Exception as e:
        await message.reply_text(f"{ggl} <b>Error: {str(e)[:100]}</b>")

@PY.UBOT("jawabb")
async def answer_game(client: Client, message: Message):
    ggl = await EMO.GAGAL(client)
    sks = await EMO.BERHASIL(client)
    
    user_id = message.from_user.id
    user_name = message.from_user.first_name
    
    try:
        if user_id not in game_sessions:
            await message.reply_text(
                f"{ggl} <b>Ketik .tebakbola dulu!</b>"
            )
            return
        
        args = message.text.split(maxsplit=1)
        if len(args) < 2:
            await message.reply_text(
                f"{ggl} <b>Contoh: .jawabb Lautaro Martínez</b>"
            )
            return
        
        user_answer = normalize_answer(args[1])
        correct_answer = game_sessions[user_id]["answer"]
        attempts = game_sessions[user_id]["attempts"] + 1
        game_sessions[user_id]["attempts"] = attempts
        question = game_sessions[user_id]["question"]
        description = game_sessions[user_id]["description"]
        
        # Cek jawaban (bisa exact match atau kata kunci)
        is_correct = False
        if user_answer == correct_answer:
            is_correct = True
        elif len(user_answer) > 3 and user_answer in correct_answer:
            is_correct = True
        elif len(correct_answer) > 3 and correct_answer in user_answer:
            is_correct = True
        
        if is_correct:
            # Skor berdasarkan kesempatan
            score = max(10 - (attempts - 1) * 2, 1)
            
            # Update leaderboard
            if user_id in leaderboard:
                leaderboard[user_id]["score"] += score
                leaderboard[user_id]["correct"] += 1
            else:
                leaderboard[user_id] = {
                    "name": user_name,
                    "score": score,
                    "correct": 1,
                    "total": 0
                }
            
            leaderboard[user_id]["total"] = leaderboard[user_id].get("total", 0) + 1
            
            # Format jawaban untuk ditampilkan (title case)
            answer_display = correct_answer.title()
            
            del game_sessions[user_id]
            
            await message.reply_text(
                f"<blockquote><b>✅ BENAR!</b>\n\n"
                f"<b>⚽ Pemain:</b> {answer_display}\n"
                f"<b>📋 Deskripsi:</b> {description}\n\n"
                f"⭐ Skor: +{score}\n"
                f"🏆 Total: {leaderboard[user_id]['score']}\n"
                f"📈 Benar: {leaderboard[user_id]['correct']}/{leaderboard[user_id]['total']}\n\n"
                f"Main lagi: <code>.tebakbola</code></blockquote>"
            )
        else:
            if attempts >= 3:
                answer_display = correct_answer.title()
                await message.reply_text(
                    f"<blockquote><b>❌ GAME OVER</b>\n\n"
                    f"<b>⚽ Pemain:</b> {answer_display}\n"
                    f"<b>📋 Deskripsi:</b> {description}\n\n"
                    f"Main lagi: <code>.tebakbola</code></blockquote>"
                )
                
                # Update total tapi ga dapet skor
                if user_id in leaderboard:
                    leaderboard[user_id]["total"] = leaderboard[user_id].get("total", 0) + 1
                else:
                    leaderboard[user_id] = {
                        "name": user_name,
                        "score": 0,
                        "correct": 0,
                        "total": 1
                    }
                
                del game_sessions[user_id]
            else:
                await message.reply_text(
                    f"<blockquote><b>❌ SALAH</b>\n\n"
                    f"📝 Percobaan: {attempts}/3\n\n"
                    f"Coba lagi: <code>.jawabb [nama pemain]</code></blockquote>"
                )
        
    except Exception as e:
        await message.reply_text(f"{ggl} <b>Error: {str(e)[:100]}</b>")

@PY.UBOT("skipb")
async def skip_question(client: Client, message: Message):
    ggl = await EMO.GAGAL(client)
    
    user_id = message.from_user.id
    user_name = message.from_user.first_name
    
    if user_id in game_sessions:
        correct_answer = game_sessions[user_id]["answer"]
        description = game_sessions[user_id]["description"]
        answer_display = correct_answer.title()
        
        # Update total tapi ga dapet skor
        if user_id in leaderboard:
            leaderboard[user_id]["total"] = leaderboard[user_id].get("total", 0) + 1
        else:
            leaderboard[user_id] = {
                "name": user_name,
                "score": 0,
                "correct": 0,
                "total": 1
            }
        
        await message.reply_text(
            f"<blockquote><b>⏭️ SKIP</b>\n\n"
            f"<b>⚽ Pemain:</b> {answer_display}\n"
            f"<b>📋 Deskripsi:</b> {description}\n\n"
            f"Main baru: <code>.tebakbola</code></blockquote>"
        )
        del game_sessions[user_id]
    else:
        await message.reply_text(f"{ggl} <b>Belum mulai game!</b>")

@PY.UBOT("skorb")
async def show_leaderboard(client: Client, message: Message):
    """Tampilkan papan peringkat tebak pemain bola"""
    
    if not leaderboard:
        await message.reply_text(
            "<blockquote><b>🏆 LEADERBOARD TEBAK PEMAIN BOLA</b>\n\n"
            "Belum ada skor. Ayo main <code>.tebakbola</code> dulu!</blockquote>"
        )
        return
    
    # Urutkan berdasarkan skor tertinggi
    sorted_users = sorted(leaderboard.items(), key=lambda x: x[1]["score"], reverse=True)
    
    text = "<blockquote><b>🏆 LEADERBOARD TEBAK PEMAIN BOLA</b>\n\n"
    
    for i, (user_id, data) in enumerate(sorted_users[:10], 1):
        medal = "🥇" if i == 1 else "🥈" if i == 2 else "🥉" if i == 3 else f"{i}."
        
        # Hitung akurasi
        if data["total"] > 0:
            accuracy = (data["correct"] / data["total"]) * 100
        else:
            accuracy = 0
            
        text += f"{medal} <b>{data['name']}</b>\n"
        text += f"   ⭐ {data['score']} poin | 📊 {accuracy:.1f}%\n"
    
    text += "\nMain: <code>.tebakbola</code></blockquote>"
    
    await message.reply_text(text)

@PY.UBOT("infob")
async def game_info(client: Client, message: Message):
    """Info tentang game tebak pemain bola"""
    
    text = """
<blockquote><b>⚽ INFO GAME TEBAK PEMAIN BOLA</b>

<b>Cara main:</b>
• <code>.tebakbola</code> - Mulai game
• <code>.jawabb [jawaban]</code> - Jawab tebakan
• <code>.skipb</code> - Lewati soal
• <code>.skorb</code> - Lihat peringkat

<b>Aturan:</b>
• 3x kesempatan menjawab per soal
• Skor berkurang jika salah menjawab
• Makin cepat jawab, makin tinggi skor
• Jawaban tidak case sensitive
• Bisa pakai nama depan atau belakang

<b>Skor:</b>
• Percobaan 1: +10 poin
• Percobaan 2: +8 poin
• Percobaan 3: +6 poin
• Salah 3x: 0 poin</blockquote>"""
    
    await message.reply_text(text)