from fansx import *
import random
import asyncio
from pyrogram.enums import ChatAction
from pyrogram.types import Message

__MODULE__ = "ᴄᴇᴋ ᴘɪɴᴛᴀʀ"
__HELP__ = """
<blockquote><b>『 CEK TINGKAT KEPINTARAN 』</b>

<b>⌲ Perintah:</b>
ᚗ <code>{0}iq [nama]</code> 
⊶ Mengecek skor IQ random seseorang (versi lucu)

<b>⌲ Contoh:</b>
<code>.iq</code> (untuk cek diri sendiri)
<code>.iq Budi</code> (untuk cek orang lain)
<code>.iq @username</code></blockquote>
"""

def get_description(iq):
    """Mendapatkan deskripsi berdasarkan skor IQ"""
    if iq >= 150:
        return "JENIUS! Einstein level! 🧠✨"
    elif iq >= 130:
        return "Sangat cerdas! 🎓"
    elif iq >= 110:
        return "Di atas rata-rata! 👍"
    elif iq >= 90:
        return "Normal, rata-rata 😊"
    else:
        return "Tetap semangat belajar! 📚"

@PY.UBOT("iq")
async def cek_iq(client: Client, message: Message):
    ggl = await EMO.GAGAL(client)
    sks = await EMO.BERHASIL(client)
    prs = await EMO.PROSES(client)
    
    try:
        await client.send_chat_action(message.chat.id, ChatAction.TYPING)
        
        # Ambil nama dari input atau reply
        nama = "Kamu"
        
        # Cek apakah reply ke user
        if message.reply_to_message and message.reply_to_message.from_user:
            user = message.reply_to_message.from_user
            nama = user.first_name
            if user.last_name:
                nama += f" {user.last_name}"
        
        # Cek dari argumen
        args = message.text.split(maxsplit=1)
        if len(args) > 1:
            input_nama = args[1].strip()
            
            # Cek apakah mention @username
            if input_nama.startswith('@'):
                try:
                    user = await client.get_users(input_nama)
                    nama = user.first_name
                    if user.last_name:
                        nama += f" {user.last_name}"
                except:
                    nama = input_nama
            else:
                nama = input_nama
        
        # Jika tidak ada input dan tidak reply, pakai nama sender
        elif nama == "Kamu":
            nama = message.from_user.first_name
            if message.from_user.last_name:
                nama += f" {message.from_user.last_name}"
        
        # Generate random IQ (70-170)
        iq = random.randint(70, 170)
        desc = get_description(iq)
        
        # Buat progress bar visual
        bar_length = 20
        # IQ range 70-170, kita mapping ke 0-100% untuk progress bar
        iq_percent = int((iq - 70) * 100 / 100)  # 70->0%, 170->100%
        filled_length = int(bar_length * iq_percent / 100)
        bar = '🧠' * filled_length + '📚' * (bar_length - filled_length)
        
        # Kirim pesan processing dulu (biar ada efek)
        processing = await message.reply_text(f"{prs} <b>Mengukur tingkat kepintaran {nama}...</b>")
        
        # Tunggu bentar biar keliatan prosesnya
        await asyncio.sleep(1)
        
        # Format pesan
        txt = f"""
<blockquote><b>🧠 CEK TINGKAT KEPINTARAN</b>

<b>👤 Nama:</b> <code>{nama}</code>
<b>📊 Skor IQ:</b> <code>{iq}</code>

<code>{bar}</code>

<b>💬 {desc}</b></blockquote>
"""
        
        await processing.edit_text(txt)
        
    except Exception as e:
        await message.reply_text(f"{ggl} <b>Error: {str(e)[:100]}</b>")

@PY.UBOT("pintar")
async def pintar_alias(client: Client, message: Message):
    """Alias untuk iq"""
    await cek_iq(client, message)

@PY.UBOT("cekiq")
async def cek_iq_alias(client: Client, message: Message):
    """Alias untuk iq"""
    await cek_iq(client, message)

@PY.UBOT("smart")
async def smart_alias(client: Client, message: Message):
    """Alias untuk iq"""
    await cek_iq(client, message)

@PY.BOT("iq")
async def cek_iq_bot(client: Client, message: Message):
    """Handler untuk bot"""
    try:
        nama = "Kamu"
        
        if message.reply_to_message and message.reply_to_message.from_user:
            user = message.reply_to_message.from_user
            nama = user.first_name
            if user.last_name:
                nama += f" {user.last_name}"
        
        args = message.text.split(maxsplit=1)
        if len(args) > 1:
            input_nama = args[1].strip()
            if input_nama.startswith('@'):
                try:
                    user = await client.get_users(input_nama)
                    nama = user.first_name
                    if user.last_name:
                        nama += f" {user.last_name}"
                except:
                    nama = input_nama
            else:
                nama = input_nama
        
        # Generate random IQ (70-170)
        iq = random.randint(70, 170)
        desc = get_description(iq)
        
        # Buat progress bar sederhana
        bar_length = 15
        iq_percent = int((iq - 70) * 100 / 100)
        filled_length = int(bar_length * iq_percent / 100)
        bar = '🧠' * filled_length + '📚' * (bar_length - filled_length)
        
        txt = f"""
🧠 *CEK TINGKAT KEPINTARAN*

👤 Nama: {nama}
📊 Skor IQ: {iq}

{bar}

💬 {desc}
"""
        await message.reply_text(txt)
        
    except Exception as e:
        await message.reply_text(f"❌ Error: {str(e)[:100]}")