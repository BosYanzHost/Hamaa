from fansx import *
import aiohttp
import asyncio
import random
import os
from pyrogram.enums import ChatAction
from pyrogram.types import Message

__MODULE__ = "ᴅᴀʀᴋ ᴊᴏᴋᴇs"
__HELP__ = """
<blockquote><b>🕳️ DARK JOKES</b>

<b>⌲ Perintah:</b>
ᚗ <code>{0}darkjokes</code> - Ambil random dark jokes
ᚗ <code>{0}dark</code> - Singkatan

<b>⌲ Contoh:</b>
<code>.darkjokes</code>
<code>.dark</code></blockquote>
"""

# ============================================
# DAFTAR API KEYS (13 KEY)
# ============================================
API_KEYS = [
    "eIxUwMpn",
    "keoCFdc6",
    "bv7m372F",
    "iAiB9QKT",
    "JP7Cy8Y2",
    "GI4vPxYv",
    "HRPga9TN",
    "PDwqhVsj",
    "m8jpBeZR",
    "PXkxh5hw",
    "MFnlpM6A",
    "u299UiOF",
    "vQs76jBD"
]

# Base URL
BASE_URL = "https://api.botcahx.eu.org/api/random/darkjokes"

def get_random_apikey():
    """Mengambil API key random dari daftar"""
    return random.choice(API_KEYS)

async def get_dark_jokes(retry_count=0, max_retries=3):
    """Ambil dark jokes dari API dengan retry"""
    
    api_key = get_random_apikey()
    url = f"{BASE_URL}?apikey={api_key}"
    
    print(f"🔄 Mencoba dengan key {api_key[:8]}... (percobaan ke-{retry_count + 1})")
    
    try:
        async with aiohttp.ClientSession() as session:
            async with session.get(url, timeout=15) as response:
                if response.status == 200:
                    # Cek content-type
                    content_type = response.headers.get("Content-Type", "").lower()
                    
                    if "image" in content_type:
                        # Jika langsung gambar
                        return {
                            "success": True,
                            "type": "image",
                            "content": await response.read(),
                            "api_key": api_key
                        }
                    else:
                        # Mungkin JSON response
                        try:
                            data = await response.json()
                            if data.get("status") and data.get("result"):
                                # Jika result adalah URL gambar
                                img_url = data["result"]
                                if isinstance(img_url, str) and (img_url.startswith("http")):
                                    # Download gambar dari URL
                                    async with session.get(img_url, timeout=15) as img_resp:
                                        if img_resp.status == 200:
                                            return {
                                                "success": True,
                                                "type": "image",
                                                "content": await img_resp.read(),
                                                "api_key": api_key
                                            }
                                else:
                                    # Jika result adalah teks
                                    return {
                                        "success": True,
                                        "type": "text",
                                        "content": str(img_url),
                                        "api_key": api_key
                                    }
                            else:
                                # Response JSON tapi format tidak dikenal
                                return {
                                    "success": False,
                                    "error": "Format response tidak dikenal",
                                    "api_key": api_key
                                }
                        except:
                            # Mungkin response teks biasa
                            text = await response.text()
                            if text.strip():
                                return {
                                    "success": True,
                                    "type": "text",
                                    "content": text.strip(),
                                    "api_key": api_key
                                }
                            else:
                                return {
                                    "success": False,
                                    "error": "Response kosong",
                                    "api_key": api_key
                                }
                else:
                    raise Exception(f"HTTP {response.status}")
                    
    except Exception as e:
        if retry_count < max_retries - 1:
            print(f"❌ Gagal dengan key {api_key[:8]}..., coba key lain...")
            await asyncio.sleep(1)
            return await get_dark_jokes(retry_count + 1, max_retries)
        
        return {
            "success": False,
            "error": str(e),
            "api_key": api_key
        }

@PY.UBOT("darkjokes")
@PY.UBOT("dark")
async def dark_jokes_command(client: Client, message: Message):
    ggl = await EMO.GAGAL(client)
    sks = await EMO.BERHASIL(client)
    prs = await EMO.PROSES(client)
    
    try:
        await client.send_chat_action(message.chat.id, ChatAction.TYPING)
        
        processing = await message.reply_text(f"{prs} <b>Mencari dark jokes...</b>")
        
        result = await get_dark_jokes()
        
        await processing.delete()
        
        if result.get("success"):
            api_key = result.get("api_key", "?")
            
            if result.get("type") == "image":
                # Kirim sebagai gambar
                file_path = f"darkjokes_{message.from_user.id}_{random.randint(1000,9999)}.jpg"
                with open(file_path, "wb") as f:
                    f.write(result["content"])
                
                await client.send_photo(
                    chat_id=message.chat.id,
                    photo=file_path,
                    caption=f"<blockquote><b>😈 DARK JOKES</b>\n</blockquote>"
                )
                
                if os.path.exists(file_path):
                    os.remove(file_path)
            else:
                # Kirim sebagai teks
                text_content = result.get("content", "")
                await message.reply_text(
                    f"<blockquote><b>😈 DARK JOKES</b>\n\n{text_content}</blockquote>"
                )
        else:
            error_msg = result.get("error", "Unknown error")
            api_key = result.get("api_key", "?")
            
            await message.reply_text(
                f"<blockquote><b>❌ GAGAL MENGAMBIL DARK JOKES</b>\n\n"
                f"Error: {error_msg}</blockquote>"
            )
        
    except Exception as e:
        await message.reply_text(f"{ggl} <b>Error: {str(e)[:100]}</b>")

