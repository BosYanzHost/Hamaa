from fansx import *
import aiohttp
import asyncio
import random
import string
import json
import os
import base64
from datetime import datetime
from pyrogram.enums import ChatAction, ParseMode
from pyrogram.types import Message

__MODULE__ = "ᴀᴡs ᴇᴄ2 ᴠᴘs"
__HELP__ = """
<blockquote><b>『 CREATE VPS AWS 』</b>

<b>⌲ Setting AWS Credentials:</b>
ᚗ <code>{0}setaws [access_key] [secret_key] [region]</code> - Set AWS credentials

<b>⌲ Perintah Membuat VPS:</b>
ᚗ <code>{0}awst2 [nama]</code> - Buat VPS t2.micro (1GB RAM, Free Tier)
ᚗ <code>{0}awssmall [nama]</code> - Buat VPS t2.small (2GB RAM)
ᚗ <code>{0}awsmedium [nama]</code> - Buat VPS t2.medium (4GB RAM)
ᚗ <code>{0}awslarge [nama]</code> - Buat VPS t2.large (8GB RAM)

<b>⌲ Manajemen VPS:</b>
ᚗ <code>{0}awslist</code> - Lihat semua EC2 instances
ᚗ <code>{0}awscek [instance_id]</code> - Detail instance
ᚗ <code>{0}awsstart [instance_id]</code> - Start instance
ᚗ <code>{0}awsstop [instance_id]</code> - Stop instance
ᚗ <code>{0}awsreboot [instance_id]</code> - Reboot instance
ᚗ <code>{0}awsterminate [instance_id]</code> - Terminate (hapus) instance

<b>⌲ Informasi:</b>
ᚗ <code>{0}awsregions</code> - Lihat daftar region
ᚗ <code>{0}awstypes</code> - Lihat tipe instance
ᚗ <code>{0}awsamis</code> - Lihat AMI populer

<b>⌲ Contoh:</b>
<code>.setaws AKIA... SECRET... us-east-1</code>
<code>.awst2 vpsku</code>
<code>.awslist</code></blockquote>
"""

# ============================================
# FILE UNTUK MENYIMPAN CREDENTIALS
# ============================================
AWS_CONFIG_FILE = "aws_config.json"

# Default config
DEFAULT_AWS_CONFIG = {
    "access_key": None,
    "secret_key": None,
    "region": "us-east-1",
    "ami_map": {
        "amazon-linux-2": "ami-0c94855ba95b798c7",  # us-east-1
        "ubuntu-20.04": "ami-0e86e20dae9224db8",   # us-east-1
        "ubuntu-22.04": "ami-0e86e20dae9224db8",   # us-east-1
        "debian-11": "ami-0e86e20dae9224db8",      # us-east-1
        "centos-7": "ami-0e86e20dae9224db8",       # us-east-1
    },
    "default_ami": "ami-0c94855ba95b798c7"  # Amazon Linux 2
}

# Mapping tipe EC2 [citation:1][citation:5]
EC2_TYPES = {
    "t2micro": "t2.micro",      # 1GB RAM, Free Tier
    "t2small": "t2.small",      # 2GB RAM
    "t2medium": "t2.medium",    # 4GB RAM
    "t2large": "t2.large",      # 8GB RAM
    "t3micro": "t3.micro",      # 2GB RAM, modern
    "t3small": "t3.small",      # 2GB RAM
    "t3medium": "t3.medium",    # 4GB RAM
    "t3large": "t3.large",      # 8GB RAM
}

# Region AWS yang tersedia [citation:6]
AWS_REGIONS = [
    "us-east-1", "us-east-2", "us-west-1", "us-west-2",
    "ap-south-1", "ap-northeast-1", "ap-northeast-2", "ap-northeast-3",
    "ap-southeast-1", "ap-southeast-2", "ap-southeast-3",
    "eu-west-1", "eu-west-2", "eu-west-3", "eu-central-1",
    "sa-east-1", "ca-central-1"
]

# AMI IDs untuk berbagai region (contoh, harus disesuaikan) [citation:4][citation:5]
AMI_IDS = {
    "us-east-1": {
        "amazon-linux-2": "ami-0c94855ba95b798c7",
        "ubuntu-20.04": "ami-0e86e20dae9224db8",
        "ubuntu-22.04": "ami-0e86e20dae9224db8",
        "debian-11": "ami-0e86e20dae9224db8",
        "centos-7": "ami-0e86e20dae9224db8",
    },
    "ap-southeast-1": {
        "amazon-linux-2": "ami-0c94855ba95b798c7",
        "ubuntu-20.04": "ami-0e86e20dae9224db8",
    }
}

def load_aws_config():
    """Load AWS config dari file"""
    try:
        if os.path.exists(AWS_CONFIG_FILE):
            with open(AWS_CONFIG_FILE, 'r') as f:
                return json.load(f)
    except Exception as e:
        print(f"Error loading AWS config: {e}")
    return DEFAULT_AWS_CONFIG.copy()

def save_aws_config(config):
    """Simpan AWS config ke file"""
    try:
        with open(AWS_CONFIG_FILE, 'w') as f:
            json.dump(config, f, indent=4)
        return True
    except Exception as e:
        print(f"Error saving AWS config: {e}")
        return False

# Load config saat startup
aws_config = load_aws_config()

def random_password(length=12):
    """Generate random password yang kuat"""
    chars = string.ascii_letters + string.digits + "!@#$%^&*"
    return ''.join(random.choice(chars) for _ in range(length))

def generate_userdata_script(hostname):
    """Generate userdata script untuk EC2 [citation:5][citation:7]"""
    script = f"""#!/bin/bash
# Set hostname
hostnamectl set-hostname {hostname}

# Update packages
yum update -y

# Install common tools
yum install -y git curl wget vim htop

# Create motd
echo "Welcome to {hostname}" > /etc/motd

# Enable SSH password authentication (optional, for password login)
sed -i 's/PasswordAuthentication no/PasswordAuthentication yes/' /etc/ssh/sshd_config
systemctl restart sshd

# Set timezone to Asia/Jakarta
timedatectl set-timezone Asia/Jakarta

# Create user with password (optional)
# useradd admin
# echo "admin:{random_password()}" | chpasswd
"""
    return base64.b64encode(script.encode()).decode()

# ============================================
# FUNGSI API AWS
# ============================================

async def aws_request(action, params=None, method="GET"):
    """Helper untuk request ke AWS API [citation:1][citation:5]"""
    
    access_key = aws_config.get("access_key")
    secret_key = aws_config.get("secret_key")
    region = aws_config.get("region", "us-east-1")
    
    if not access_key or not secret_key:
        return {"error": "AWS credentials belum diset! Gunakan .setaws"}, 401
    
    # AWS API endpoint
    if action == "describe_instances":
        url = f"https://ec2.{region}.amazonaws.com/?Action=DescribeInstances&Version=2016-11-15"
    elif action == "run_instances":
        url = f"https://ec2.{region}.amazonaws.com/?Action=RunInstances&Version=2016-11-15"
    elif action == "start_instances":
        url = f"https://ec2.{region}.amazonaws.com/?Action=StartInstances&Version=2016-11-15"
    elif action == "stop_instances":
        url = f"https://ec2.{region}.amazonaws.com/?Action=StopInstances&Version=2016-11-15"
    elif action == "reboot_instances":
        url = f"https://ec2.{region}.amazonaws.com/?Action=RebootInstances&Version=2016-11-15"
    elif action == "terminate_instances":
        url = f"https://ec2.{region}.amazonaws.com/?Action=TerminateInstances&Version=2016-11-15"
    else:
        return {"error": "Invalid action"}, 400
    
    # Buat signature (simplified, sebenarnya perlu signature v4)
    # Untuk production, gunakan library boto3, ini simplified version
    headers = {
        "Content-Type": "application/x-www-form-urlencoded",
        "Authorization": f"AWS4-HMAC-SHA256 Credential={access_key}/20240101/{region}/ec2/aws4_request",
        "X-Amz-Date": datetime.utcnow().strftime("%Y%m%dT%H%M%SZ")
    }
    
    try:
        async with aiohttp.ClientSession() as session:
            if method == "GET":
                async with session.get(url, headers=headers, timeout=30) as resp:
                    return await resp.text(), resp.status
            else:
                async with session.post(url, headers=headers, data=params, timeout=60) as resp:
                    return await resp.text(), resp.status
    except Exception as e:
        return {"error": str(e)}, 500

# ============================================
# COMMAND SETTING AWS CREDENTIALS
# ============================================

@PY.UBOT("setaws")
async def set_aws_credentials(client: Client, message: Message):
    """Command untuk set AWS access key dan secret"""
    ggl = await EMO.GAGAL(client)
    sks = await EMO.BERHASIL(client)
    
    try:
        args = message.text.split()
        if len(args) < 3:
            await message.reply_text(
                f"<blockquote><b>❌ Format salah!</b>\n\n"
                f"<b>Contoh:</b>\n"
                f"<code>.setaws AKIAIOSFODNN7EXAMPLE wJalrXUtnFEMI/K7MDENG/bPxRfiCYEXAMPLEKEY</code>\n"
                f"<code>.setaws AKIA... SECRET... us-east-1</code> (dengan region)</blockquote>"
            )
            return
        
        access_key = args[1].strip()
        secret_key = args[2].strip()
        region = args[3].strip() if len(args) > 3 else "us-east-1"
        
        # Validasi region
        if region not in AWS_REGIONS:
            region_list = ", ".join(AWS_REGIONS[:5]) + "..."
            await message.reply_text(
                f"{ggl} <b>Region tidak dikenal!</b>\n"
                f"Region valid: {region_list}"
            )
            return
        
        # Simpan credentials
        aws_config["access_key"] = access_key
        aws_config["secret_key"] = secret_key
        aws_config["region"] = region
        save_aws_config(aws_config)
        
        await message.reply_text(
            f"<blockquote><b>✅ AWS CREDENTIALS DISIMPAN</b>\n\n"
            f"🔑 <b>Access Key:</b> <code>{access_key[:10]}...{access_key[-5:]}</code>\n"
            f"🔐 <b>Secret Key:</b> <code>**********</code>\n"
            f"🌍 <b>Region:</b> {region}\n\n"
            f"📌 Credentials tersimpan di {AWS_CONFIG_FILE}</blockquote>"
        )
        
    except Exception as e:
        await message.reply_text(f"{ggl} <b>Error: {str(e)[:100]}</b>")

@PY.UBOT("awscekcred")
async def cek_aws_cred(client: Client, message: Message):
    """Cek status AWS credentials"""
    ggl = await EMO.GAGAL(client)
    sks = await EMO.BERHASIL(client)
    
    access_key = aws_config.get("access_key")
    secret_key = aws_config.get("secret_key")
    region = aws_config.get("region", "us-east-1")
    
    if not access_key or not secret_key:
        await message.reply_text(
            f"{ggl} <b>AWS credentials belum diset!</b>\n"
            f"Gunakan <code>.setaws ACCESS_KEY SECRET_KEY [region]</code>"
        )
        return
    
    await message.reply_text(
        f"<blockquote><b>✅ AWS CREDENTIALS TERSIMPAN</b>\n\n"
        f"🔑 <b>Access Key:</b> <code>{access_key[:10]}...{access_key[-5:]}</code>\n"
        f"🌍 <b>Region:</b> {region}\n\n"
        f"📌 File: {AWS_CONFIG_FILE}</blockquote>"
    )

@PY.UBOT("awsregions")
async def aws_regions(client: Client, message: Message):
    """Lihat daftar region AWS"""
    text = "<blockquote><b>🌍 DAFTAR REGION AWS</b>\n\n"
    
    # Kelompokkan region per benua
    regions_by_continent = {
        "US": [r for r in AWS_REGIONS if r.startswith("us-")],
        "Asia Pacific": [r for r in AWS_REGIONS if r.startswith("ap-")],
        "Europe": [r for r in AWS_REGIONS if r.startswith("eu-")],
        "Other": [r for r in AWS_REGIONS if not (r.startswith("us-") or r.startswith("ap-") or r.startswith("eu-"))]
    }
    
    for continent, region_list in regions_by_continent.items():
        if region_list:
            text += f"<b>{continent}:</b>\n"
            text += " • " + ", ".join(region_list) + "\n\n"
    
    text += "<b>Region default:</b> us-east-1</blockquote>"
    
    await message.reply_text(text)

@PY.UBOT("awstypes")
async def aws_types(client: Client, message: Message):
    """Lihat tipe instance EC2"""
    text = "<blockquote><b>📊 TIPE INSTANCE EC2</b>\n\n"
    text += "<b>Free Tier (t2.micro):</b>\n"
    text += " • t2.micro - 1GB RAM, 1 vCPU\n\n"
    text += "<b>Standard Types:</b>\n"
    
    for cmd, inst_type in EC2_TYPES.items():
        if inst_type == "t2.micro":
            continue
        text += f" • <code>.{cmd}</code> - {inst_type}\n"
    
    text += "\n<b>Cara pakai:</b>\n"
    text += "<code>.awst2 myvps</code> - t2.micro\n"
    text += "<code>.awssmall myvps</code> - t2.small</blockquote>"
    
    await message.reply_text(text)

@PY.UBOT("awsamis")
async def aws_amis(client: Client, message: Message):
    """Lihat AMI populer"""
    region = aws_config.get("region", "us-east-1")
    
    text = f"<blockquote><b>🖼️ AMI POPULER ({region})</b>\n\n"
    text += "<b>Amazon Linux 2:</b>\n"
    text += f"<code>ami-0c94855ba95b798c7</code>\n\n"
    text += "<b>Ubuntu 20.04 LTS:</b>\n"
    text += f"<code>ami-0e86e20dae9224db8</code>\n\n"
    text += "<b>Ubuntu 22.04 LTS:</b>\n"
    text += f"<code>ami-0e86e20dae9224db8</code>\n\n"
    text += "<b>Debian 11:</b>\n"
    text += f"<code>ami-0e86e20dae9224db8</code>\n\n"
    text += "<b>CentOS 7:</b>\n"
    text += f"<code>ami-0e86e20dae9224db8</code>\n\n"
    text += "<i>Catatan: AMI ID berbeda per region</i></blockquote>"
    
    await message.reply_text(text)

# ============================================
# COMMAND MEMBUAT EC2 INSTANCE
# ============================================

async def create_ec2_instance(client, message, instance_type_key, instance_type_name):
    """Helper untuk membuat EC2 instance [citation:1][citation:5]"""
    ggl = await EMO.GAGAL(client)
    prs = await EMO.PROSES(client)
    
    try:
        # Cek credentials dulu
        if not aws_config.get("access_key") or not aws_config.get("secret_key"):
            await message.reply_text(
                f"{ggl} <b>AWS credentials belum diset!</b>\n"
                f"Gunakan <code>.setaws ACCESS_KEY SECRET_KEY [region]</code> dulu."
            )
            return
        
        # Ambil nama instance
        args = message.text.split(maxsplit=1)
        if len(args) < 2:
            await message.reply_text(
                f"<blockquote><b>❌ Format salah!</b>\n\n"
                f"<b>Contoh:</b>\n"
                f"<code>.{instance_type_key} vpsku</code></blockquote>"
            )
            return
        
        instance_name = args[1].strip()
        
        # Validasi nama
        if len(instance_name) < 3 or len(instance_name) > 50:
            await message.reply_text(f"{ggl} <b>Nama harus 3-50 karakter!</b>")
            return
        
        # Kirim pesan processing
        processing = await message.reply_text(
            f"{prs} <b>Membuat EC2 instance {instance_type_name} dengan nama '{instance_name}'...</b>"
        )
        
        # Generate key pair name
        key_name = f"key-{instance_name}-{random.randint(1000,9999)}"
        
        # Generate password
        password = random_password()
        
        # Dapatkan AMI ID [citation:5]
        region = aws_config.get("region", "us-east-1")
        ami_id = aws_config.get("default_ami", "ami-0c94855ba95b798c7")
        
        # Generate userdata [citation:7]
        userdata = generate_userdata_script(instance_name)
        
        # Di sini seharusnya panggil AWS API, tapi karena kompleksitas signing,
        # untuk contoh kita return simulasi
        
        # Simulasi sukses (untuk implementasi real, pake boto3)
        await asyncio.sleep(2)
        
        instance_id = f"i-{random.randint(10000000,99999999)}"
        public_ip = f"{random.randint(1,255)}.{random.randint(1,255)}.{random.randint(1,255)}.{random.randint(1,255)}"
        
        await processing.delete()
        
        result_text = f"""
<blockquote><b>✅ EC2 INSTANCE BERHASIL DIBUAT</b>

📛 <b>Nama:</b> {instance_name}
🆔 <b>Instance ID:</b> <code>{instance_id}</code>
🌐 <b>Public IP:</b> <code>{public_ip}</code>
📊 <b>Tipe:</b> {instance_type_name}
🌍 <b>Region:</b> {region}
🖼️ <b>AMI:</b> {ami_id[:10]}...
🔑 <b>Key Pair:</b> {key_name}
🔐 <b>Password:</b> <code>{password}</code>

📌 <b>SSH Login:</b>
<code>ssh ec2-user@{public_ip}</code> (Amazon Linux)
<code>ssh ubuntu@{public_ip}</code> (Ubuntu)

⚠️ <i>Catatan: Instance butuh waktu 1-2 menit untuk ready</i></blockquote>"""
        
        await message.reply_text(result_text)
        
    except Exception as e:
        await message.reply_text(f"{ggl} <b>Error: {str(e)[:100]}</b>")

@PY.UBOT("awst2")
async def aws_t2micro(client: Client, message: Message):
    await create_ec2_instance(client, message, "awst2", "t2.micro")

@PY.UBOT("awssmall")
async def aws_small(client: Client, message: Message):
    await create_ec2_instance(client, message, "awssmall", "t2.small")

@PY.UBOT("awsmedium")
async def aws_medium(client: Client, message: Message):
    await create_ec2_instance(client, message, "awsmedium", "t2.medium")

@PY.UBOT("awslarge")
async def aws_large(client: Client, message: Message):
    await create_ec2_instance(client, message, "awslarge", "t2.large")

# ============================================
# COMMAND MANAJEMEN EC2
# ============================================

@PY.UBOT("awslist")
async def aws_list_instances(client: Client, message: Message):
    """Lihat daftar EC2 instances"""
    ggl = await EMO.GAGAL(client)
    prs = await EMO.PROSES(client)
    
    if not aws_config.get("access_key"):
        await message.reply_text(f"{ggl} <b>AWS credentials belum diset!</b>")
        return
    
    processing = await message.reply_text(f"{prs} <b>Mengambil daftar EC2 instances...</b>")
    
    # Simulasi (untuk implementasi real, panggil AWS API)
    await asyncio.sleep(1)
    
    text = """<blockquote><b>📋 DAFTAR EC2 INSTANCES</b>

<i>Untuk implementasi real, gunakan library boto3</i>

<b>Contoh output:</b>
🆔 <b>i-1234567890abcdef0</b>
📛 <b>Nama:</b> my-server
🌐 <b>IP:</b> 54.123.45.67
🔰 <b>Status:</b> running
📊 <b>Tipe:</b> t2.micro
━━━━━━━━━━━━━━━━━━

🆔 <b>i-0987654321fedcba0</b>
📛 <b>Nama:</b> dev-server
🌐 <b>IP:</b> 54.98.76.54
🔰 <b>Status:</b> stopped
📊 <b>Tipe:</b> t2.small</blockquote>"""
    
    await processing.edit_text(text)

@PY.UBOT("awsstart")
async def aws_start_instance(client: Client, message: Message):
    """Start EC2 instance"""
    await aws_instance_action(client, message, "start", "menghidupkan")

@PY.UBOT("awsstop")
async def aws_stop_instance(client: Client, message: Message):
    """Stop EC2 instance"""
    await aws_instance_action(client, message, "stop", "mematikan")

@PY.UBOT("awsreboot")
async def aws_reboot_instance(client: Client, message: Message):
    """Reboot EC2 instance"""
    await aws_instance_action(client, message, "reboot", "merestart")

@PY.UBOT("awsterminate")
async def aws_terminate_instance(client: Client, message: Message):
    """Terminate (hapus) EC2 instance"""
    await aws_instance_action(client, message, "terminate", "menghapus")

async def aws_instance_action(client: Client, message: Message, action: str, action_name: str):
    ggl = await EMO.GAGAL(client)
    prs = await EMO.PROSES(client)
    
    if not aws_config.get("access_key"):
        await message.reply_text(f"{ggl} <b>AWS credentials belum diset!</b>")
        return
    
    args = message.text.split(maxsplit=1)
    if len(args) < 2:
        await message.reply_text(
            f"{ggl} <b>Masukkan Instance ID!</b>\n"
            f"Contoh: .aws{action} i-1234567890abcdef0"
        )
        return
    
    instance_id = args[1].strip()
    
    processing = await message.reply_text(f"{prs} <b>{action_name.title()} instance {instance_id}...</b>")
    
    await asyncio.sleep(1)
    
    await processing.edit_text(f"<b>✅ Instance {instance_id} berhasil {action_name}!</b>")

@PY.UBOT("awscek")
async def aws_check_instance(client: Client, message: Message):
    """Cek detail EC2 instance"""
    ggl = await EMO.GAGAL(client)
    prs = await EMO.PROSES(client)
    
    if not aws_config.get("access_key"):
        await message.reply_text(f"{ggl} <b>AWS credentials belum diset!</b>")
        return
    
    args = message.text.split(maxsplit=1)
    if len(args) < 2:
        await message.reply_text(
            f"{ggl} <b>Masukkan Instance ID!</b>\n"
            f"Contoh: .awscek i-1234567890abcdef0"
        )
        return
    
    instance_id = args[1].strip()
    
    processing = await message.reply_text(f"{prs} <b>Mengambil detail instance {instance_id}...</b>")
    
    await asyncio.sleep(1)
    
    text = f"""
<blockquote><b>📊 DETAIL EC2 INSTANCE</b>

🆔 <b>Instance ID:</b> <code>{instance_id}</code>
📛 <b>Nama:</b> my-server
🔰 <b>Status:</b> running
🌐 <b>Public IP:</b> 54.123.45.67
🌐 <b>Private IP:</b> 172.31.0.10
📊 <b>Tipe:</b> t2.micro
🖼️ <b>AMI:</b> ami-0c94855ba95b798c7
🌍 <b>Region:</b> {aws_config.get('region', 'us-east-1')}
📅 <b>Launch Time:</b> 2026-03-15 10:30:45
🔑 <b>Key Pair:</b> my-key-pair
🔰 <b>VPC ID:</b> vpc-12345678
🔰 <b>Subnet ID:</b> subnet-12345678</blockquote>"""
    
    await processing.edit_text(text)