from fansx import *
import aiohttp
import asyncio
import json
import os
import re
from pyrogram.enums import ChatAction, ParseMode
from pyrogram.types import Message

__MODULE__ = "ᴠᴇʀᴄᴇʟ ᴅᴇᴘʟᴏʏ"
__HELP__ = """
<blockquote><b>『 VERCEL DEPLOY 』</b>

<b>⌲ Setting Token:</b>
ᚗ <code>{0}setvercel [token]</code> - Set Vercel API token

<b>⌲ Deploy Website (format):</b>
ᚗ <code>{0}deploy [nama]</code> - Reply ke kode HTML

<b>⌲ Contoh:</b>
1. Buat file HTML atau tulis kode HTML
2. Reply ke pesan/file tersebut dengan:
   <code>.deploy mysite</code>

<b>⌲ Hasil:</b>
• Website akan online di: https://[nama].vercel.app</blockquote>
"""

# ============================================
# KONFIGURASI
# ============================================
VERCEL_CONFIG_FILE = "vercel_config.json"

# Vercel API endpoint
VERCEL_API = "https://api.vercel.com"

def load_vercel_config():
    """Load Vercel config dari file"""
    try:
        if os.path.exists(VERCEL_CONFIG_FILE):
            with open(VERCEL_CONFIG_FILE, 'r') as f:
                return json.load(f)
    except:
        pass
    return {"token": None}

def save_vercel_config(config):
    """Simpan Vercel config ke file"""
    try:
        with open(VERCEL_CONFIG_FILE, 'w') as f:
            json.dump(config, f, indent=4)
        return True
    except:
        return False

# Load config
vercel_config = load_vercel_config()

def is_valid_html(content):
    """Cek apakah konten adalah HTML valid"""
    # Cek tag HTML dasar
    html_patterns = [
        r'<html',
        r'<!DOCTYPE\s+html',
        r'<head',
        r'<body',
        r'<div',
        r'<h[1-6]',
        r'<p>',
    ]
    
    content_lower = content.lower()
    for pattern in html_patterns:
        if re.search(pattern, content_lower, re.IGNORECASE):
            return True
    return False

async def vercel_request(method, endpoint, data=None):
    """Request ke API Vercel"""
    
    token = vercel_config.get("token")
    if not token:
        return {"error": "Token belum diset!"}, 401
    
    url = f"{VERCEL_API}/{endpoint}"
    headers = {
        "Authorization": f"Bearer {token}",
        "Content-Type": "application/json"
    }
    
    try:
        async with aiohttp.ClientSession() as session:
            if method == "GET":
                async with session.get(url, headers=headers, timeout=30) as resp:
                    return await resp.json(), resp.status
            elif method == "POST":
                async with session.post(url, headers=headers, json=data, timeout=60) as resp:
                    return await resp.json(), resp.status
    except asyncio.TimeoutError:
        return {"error": "Timeout"}, 408
    except Exception as e:
        return {"error": str(e)}, 500

# ============================================
# COMMAND SETTING TOKEN
# ============================================

@PY.UBOT("setvercel")
async def set_vercel_token(client: Client, message: Message):
    """Set Vercel API token"""
    ggl = await EMO.GAGAL(client)
    sks = await EMO.BERHASIL(client)
    
    try:
        args = message.text.split(maxsplit=1)
        if len(args) < 2:
            await message.reply_text(
                f"<blockquote><b>❌ Format: .setvercel [token]</b>\n\n"
                f"Ambil token di:\n"
                f"https://vercel.com/account/tokens</blockquote>"
            )
            return
        
        token = args[1].strip()
        
        await message.reply_text(f"⏳ <b>Testing token...</b>")
        
        # Test token dengan get user
        data, status = await vercel_request("GET", "v2/user")
        
        if status == 200:
            vercel_config["token"] = token
            save_vercel_config(vercel_config)
            
            user = data.get("user", {})
            name = user.get("name", "-")
            email = user.get("email", "-")
            
            await message.reply_text(
                f"<blockquote><b>✅ TOKEN VERCEL VALID</b>\n\n"
                f"👤 <b>Name:</b> {name}\n"
                f"📧 <b>Email:</b> {email}\n"
                f"🔑 <b>Token:</b> <code>{token[:8]}...{token[-5:]}</code></blockquote>"
            )
        else:
            error_msg = data.get("error", {}).get("message", "Invalid token")
            await message.reply_text(f"{ggl} <b>Token tidak valid!</b>\n{error_msg}")
            
    except Exception as e:
        await message.reply_text(f"{ggl} <b>Error: {str(e)[:100]}</b>")

@PY.UBOT("cektokenvercel")
async def cek_vercel_token(client: Client, message: Message):
    """Cek status token Vercel"""
    ggl = await EMO.GAGAL(client)
    sks = await EMO.BERHASIL(client)
    
    token = vercel_config.get("token")
    
    if not token:
        await message.reply_text(
            f"{ggl} <b>Token belum diset!</b>\n"
            f"Gunakan .setvercel [token]"
        )
        return
    
    await message.reply_text(f"⏳ <b>Memeriksa token...</b>")
    
    data, status = await vercel_request("GET", "v2/user")
    
    if status == 200:
        user = data.get("user", {})
        name = user.get("name", "-")
        email = user.get("email", "-")
        
        await message.reply_text(
            f"<blockquote><b>✅ TOKEN VERCEL VALID</b>\n\n"
            f"👤 <b>Name:</b> {name}\n"
            f"📧 <b>Email:</b> {email}\n"
            f"🔑 <b>Token:</b> <code>{token[:8]}...{token[-5:]}</code></blockquote>"
        )
    else:
        await message.reply_text(f"{ggl} <b>Token tidak valid!</b>")

# ============================================
# COMMAND DEPLOY
# ============================================

@PY.UBOT("deploy")
async def deploy_website(client: Client, message: Message):
    ggl = await EMO.GAGAL(client)
    sks = await EMO.BERHASIL(client)
    prs = await EMO.PROSES(client)
    
    try:
        await client.send_chat_action(message.chat.id, ChatAction.TYPING)
        
        # Cek token
        token = vercel_config.get("token")
        if not token:
            await message.reply_text(
                f"{ggl} <b>Token Vercel belum diset!</b>\n"
                f"Gunakan .setvercel [token] dulu"
            )
            return
        
        # Ambil nama project
        args = message.text.split(maxsplit=1)
        if len(args) < 2:
            await message.reply_text(
                f"<blockquote><b>🚀 DEPLOY WEBSITE</b>\n\n"
                f"<b>Format:</b> <code>.deploy [nama]</code> (reply ke HTML)\n\n"
                f"<b>Contoh:</b>\n"
                f"1. Tulis kode HTML\n"
                f"2. Reply dengan <code>.deploy mysite</code>\n\n"
                f"<b>Hasil:</b> https://mysite.vercel.app</blockquote>"
            )
            return
        
        project_name = args[1].strip()
        
        # Validasi nama project
        if not re.match(r'^[a-z0-9\-]+$', project_name):
            await message.reply_text(
                f"{ggl} <b>Nama project hanya boleh huruf kecil, angka, dan tanda strip!</b>"
            )
            return
        
        # Cek apakah ada reply
        if not message.reply_to_message:
            await message.reply_text(
                f"{ggl} <b>Reply ke pesan yang berisi kode HTML!</b>"
            )
            return
        
        replied = message.reply_to_message
        
        # Ambil konten HTML
        html_content = None
        source_type = ""
        
        # Cek dari teks
        if replied.text:
            html_content = replied.text
            source_type = "📝 Teks"
        
        # Cek dari file
        elif replied.document:
            doc = replied.document
            file_name = doc.file_name or ""
            
            # Cek ekstensi .html
            if file_name.endswith('.html') or file_name.endswith('.htm'):
                # Download file
                file_path = await replied.download()
                with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                    html_content = f.read()
                
                # Hapus file
                if os.path.exists(file_path):
                    os.remove(file_path)
                
                source_type = f"📄 File: {file_name}"
            else:
                await message.reply_text(
                    f"{ggl} <b>File harus berekstensi .html atau .htm!</b>"
                )
                return
        
        # Cek dari mimetype
        elif replied.document and replied.document.mime_type == "text/html":
            file_path = await replied.download()
            with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                html_content = f.read()
            
            if os.path.exists(file_path):
                os.remove(file_path)
            
            source_type = "📄 File HTML"
        
        else:
            await message.reply_text(
                f"{ggl} <b>Format tidak didukung!</b>\n"
                f"Reply ke teks HTML atau file .html"
            )
            return
        
        if not html_content:
            await message.reply_text(f"{ggl} <b>Konten HTML kosong!</b>")
            return
        
        # Validasi HTML
        if not is_valid_html(html_content):
            await message.reply_text(
                f"{ggl} <b>Bukan HTML yang valid!</b>\n"
                f"Pastikan berisi tag HTML seperti &lt;html&gt;, &lt;body&gt;, dll."
            )
            return
        
        # Kirim pesan processing
        processing = await message.reply_text(
            f"{prs} <b>Mendeploy website...</b>\n"
            f"📛 Nama: {project_name}\n"
            f"{source_type}"
        )
        
        # Prepare payload untuk deploy
        payload = {
            "name": project_name,
            "project": project_name,
            "target": "production",
            "files": [
                {
                    "file": "index.html",
                    "data": html_content
                }
            ],
            "projectSettings": {
                "framework": None
            }
        }
        
        # Request deploy
        deploy_data, deploy_status = await vercel_request("POST", "v13/deployments", payload)
        
        if deploy_status not in [200, 201, 202]:
            error_msg = deploy_data.get("error", {}).get("message", "Unknown error")
            await processing.edit_text(
                f"<blockquote><b>❌ DEPLOY FAILED</b>\n\n"
                f"Error: {error_msg}</blockquote>"
            )
            return
        
        # Dapatkan domain
        domain = f"{project_name}.vercel.app"
        
        # Coba cari custom domain
        try:
            domains_data, domains_status = await vercel_request("GET", f"v9/projects/{project_name}/domains")
            
            if domains_status == 200:
                domains = domains_data.get("domains", [])
                
                # Cari domain non-vercel.app
                for d in domains:
                    d_name = d.get("name", "")
                    if not d_name.endswith(".vercel.app"):
                        domain = d_name
                        break
                
                # Kalo gak ada, pake yang vercel.app
                if domain == f"{project_name}.vercel.app":
                    for d in domains:
                        if d.get("name", "").endswith(".vercel.app"):
                            domain = d.get("name")
                            break
        except:
            pass  # Fallback ke default domain
        
        await processing.delete()
        
        # Hasil sukses
        result = f"""
<blockquote><b>✅ DEPLOY SUCCESS</b>

📛 <b>Nama:</b> {project_name}
☁️ <b>Platform:</b> Vercel
📄 <b>Type:</b> Static HTML
⚙️ <b>Status:</b> Building
{source_type}

🔗 <b>URL:</b>
https://{domain}

📌 <b>Note:</b> Website akan online dalam 1-2 menit</blockquote>"""
        
        await message.reply_text(result)
        
    except Exception as e:
        await message.reply_text(
            f"<blockquote><b>❌ DEPLOY FAILED</b>\n\n"
            f"Error: {str(e)[:200]}</blockquote>"
        )

@PY.UBOT("deploysite")
async def deploy_site_alias(client: Client, message: Message):
    """Alias untuk deploy"""
    await deploy_website(client, message)

@PY.BOT("deploy")
async def deploy_bot(client: Client, message: Message):
    """Handler untuk bot"""
    ggl = "❌"
    
    try:
        # Cek token
        token = vercel_config.get("token")
        if not token:
            await message.reply_text(f"{ggl} Token Vercel belum diset!")
            return
        
        # Ambil nama project
        args = message.text.split(maxsplit=1)
        if len(args) < 2:
            await message.reply_text(
                f"{ggl} Format: /deploy [nama] (reply ke HTML)"
            )
            return
        
        project_name = args[1].strip()
        
        # Cek reply
        if not message.reply_to_message:
            await message.reply_text(f"{ggl} Reply ke pesan HTML!")
            return
        
        replied = message.reply_to_message
        
        # Ambil HTML
        html_content = None
        
        if replied.text:
            html_content = replied.text
        elif replied.document and replied.document.file_name.endswith('.html'):
            file_path = await replied.download()
            with open(file_path, 'r', encoding='utf-8') as f:
                html_content = f.read()
            if os.path.exists(file_path):
                os.remove(file_path)
        else:
            await message.reply_text(f"{ggl} Format tidak didukung!")
            return
        
        if not html_content:
            await message.reply_text(f"{ggl} Konten HTML kosong!")
            return
        
        processing = await message.reply_text("⏳ Deploying...")
        
        # Deploy
        payload = {
            "name": project_name,
            "project": project_name,
            "target": "production",
            "files": [{"file": "index.html", "data": html_content}],
            "projectSettings": {"framework": None}
        }
        
        data, status = await vercel_request("POST", "v13/deployments", payload)
        
        if status in [200, 201, 202]:
            await processing.delete()
            await message.reply_text(
                f"✅ Deploy success!\n🔗 https://{project_name}.vercel.app"
            )
        else:
            error_msg = data.get("error", {}).get("message", "Unknown error")
            await processing.edit_text(f"{ggl} Failed: {error_msg}")
        
    except Exception as e:
        await message.reply_text(f"{ggl} Error: {str(e)[:100]}")