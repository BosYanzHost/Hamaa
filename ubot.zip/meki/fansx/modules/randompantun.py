from fansx import *
import aiohttp
import asyncio
import random
from urllib.parse import quote
from pyrogram.enums import ChatAction, ParseMode
from pyrogram.types import Message

__MODULE__ = "ʀᴀɴᴅᴏᴍ ᴘᴀɴᴛᴜɴ"
__HELP__ = """
<blockquote><b>🔠 RANDOM PANTUN</b>

<b>⌲ Perintah:</b>
ᚗ <code>{0}randompantun</code> - Buat pantun random
ᚗ <code>{0}pantun</code> - Buat pantun random

<b>⌲ Contoh:</b>
<code>.randompantun</code>
<code>.pantun</code></blockquote>
"""

# ============================================
# KONFIGURASI
# ============================================
BASE_URL = "https://api.siputzx.my.id/api/ai/duckai"
MODEL = "gpt-4o-mini"

# System prompt khusus untuk pantun
SYSTEM_PROMPT = """Anda adalah seorang penyair pantun tradisional Indonesia yang sangat ahli. 
Tugas Anda adalah membuat pantun yang indah dengan ciri-ciri:
- Terdiri dari 4 baris
- Bersajak a-b-a-b
- Baris 1-2 adalah sampiran
- Baris 3-4 adalah isi
- Gunakan bahasa Indonesia yang baik dan benar
- Pantun harus menarik, bermakna, dan bisa lucu, romantis, atau nasihat (variasi)

Berikan HANYA pantunnya saja, tanpa penjelasan, tanpa kata "Pantun:", langsung teks pantunnya."""

async def generate_pantun():
    """Generate pantun dari Duck AI"""
    
    # Variasi prompt biar gak monoton
    variations = [
        "Buatkan pantun yang indah",
        "Ciptakan pantun menarik",
        "Buat satu pantun lucu",
        "Tolong buatkan pantun romantis",
        "Buat pantun nasihat yang bagus",
        "Ciptakan pantun jenaka"
    ]
    user_message = random.choice(variations)
    
    # Encode parameter
    encoded_prompt = quote(SYSTEM_PROMPT)
    encoded_message = quote(user_message)
    
    url = f"{BASE_URL}?message={encoded_message}&model={MODEL}&systemPrompt={encoded_prompt}"
    
    try:
        async with aiohttp.ClientSession() as session:
            async with session.get(url, timeout=30) as response:
                if response.status == 200:
                    data = await response.json()
                    
                    if data.get("status") and data.get("data"):
                        message = data["data"].get("message", "")
                        return {
                            "success": True,
                            "pantun": message.strip()
                        }
                    else:
                        return {"success": False, "error": "Response tidak valid"}
                else:
                    return {"success": False, "error": f"HTTP {response.status}"}
    except asyncio.TimeoutError:
        return {"success": False, "error": "Timeout"}
    except Exception as e:
        return {"success": False, "error": str(e)}

def bersihkan_pantun(teks):
    """Bersihkan teks pantun dari hal-hal yang tidak perlu"""
    # Hapus kata "Pantun:" di awal
    teks = teks.replace("Pantun:", "").replace("pantun:", "").strip()
    
    # Hapus tanda kutip berlebih
    teks = teks.strip('"\'')
    
    # Pastikan 4 baris
    baris = teks.split('\n')
    if len(baris) >= 4:
        # Ambil 4 baris pertama
        baris = baris[:4]
        teks = '\n'.join(baris)
    
    return teks

@PY.UBOT("randompantun")
@PY.UBOT("pantun")
async def random_pantun(client: Client, message: Message):
    ggl = await EMO.GAGAL(client)
    sks = await EMO.BERHASIL(client)
    prs = await EMO.PROSES(client)
    
    try:
        await client.send_chat_action(message.chat.id, ChatAction.TYPING)
        
        processing = await message.reply_text(f"{prs} <b>AI sedang merangkai pantun...</b>")
        
        # Generate pantun
        result = await generate_pantun()
        
        await processing.delete()
        
        if result.get("success"):
            pantun = result["pantun"]
            pantun = bersihkan_pantun(pantun)
            
            # Format output
            formatted = f"""
<blockquote>{pantun}</blockquote>"""
            
            await message.reply_text(formatted)
        else:
            error_msg = result.get("error", "Unknown error")
            
            # Fallback pantun manual
            pantun_manual = [
                "Jalan-jalan ke Kota Blitar\nJangan lupa beli jamu\nKalau kamu rajin belajar\nPasti jadi anak yang maju",
                "Burung merpati terbang melayang\nHinggap sebentar di pohon jati\nHati ini selalu terkenang\nKebaikanmu sejati",
                "Pergi ke pasar membeli ikan\nIkan segar di atas dulang\nRajin belajar sepanjang zaman\nAgar cita-cita mudah tercapai"
            ]
            
            await message.reply_text(
                f"<blockquote><b>🎭 PANTUN</b>\n\n"
                f"{random.choice(pantun_manual)}\n\n"
                f"⚠️ AI error, pakai pantun cadangan</blockquote>"
            )
        
    except Exception as e:
        await message.reply_text(f"{ggl} <b>Error: {str(e)[:100]}</b>")

