from fansx import *
import aiohttp
import asyncio
import json
import os
import re
import base64
from pyrogram.enums import ChatAction, ParseMode
from pyrogram.types import Message

__MODULE__ = "ɴᴇᴛʟɪғʏ ᴅᴇᴘʟᴏʏ"
__HELP__ = """
<blockquote><b>『 NETLIFY DEPLOY 』</b>

<b>⌲ Setting Token:</b>
ᚗ <code>{0}setnetlify [token]</code> - Set Netlify API token

<b>⌲ Deploy Website (format):</b>
ᚗ <code>{0}netlify [nama]</code> - Reply ke kode HTML

<b>⌲ Contoh:</b>
1. Buat file HTML atau tulis kode HTML
2. Reply ke pesan/file tersebut dengan:
   <code>.netlify mysite</code>

<b>⌲ Hasil:</b>
• Website akan online di: https://[nama].netlify.app</blockquote>
"""

# ============================================
# KONFIGURASI
# ============================================
NETLIFY_CONFIG_FILE = "netlify_config.json"

# Netlify API endpoint
NETLIFY_API = "https://api.netlify.com/api/v1"

def load_netlify_config():
    """Load Netlify config dari file"""
    try:
        if os.path.exists(NETLIFY_CONFIG_FILE):
            with open(NETLIFY_CONFIG_FILE, 'r') as f:
                return json.load(f)
    except:
        pass
    return {"token": None}

def save_netlify_config(config):
    """Simpan Netlify config ke file"""
    try:
        with open(NETLIFY_CONFIG_FILE, 'w') as f:
            json.dump(config, f, indent=4)
        return True
    except:
        return False

# Load config
netlify_config = load_netlify_config()

def is_valid_html(content):
    """Cek apakah konten adalah HTML valid"""
    html_patterns = [
        r'<html',
        r'<!DOCTYPE\s+html',
        r'<head',
        r'<body',
        r'<div',
        r'<h[1-6]',
        r'<p>',
    ]
    
    content_lower = content.lower()
    for pattern in html_patterns:
        if re.search(pattern, content_lower, re.IGNORECASE):
            return True
    return False

async def netlify_request(method, endpoint, data=None, files=None):
    """Request ke API Netlify"""
    
    token = netlify_config.get("token")
    if not token:
        return {"error": "Token belum diset!"}, 401
    
    url = f"{NETLIFY_API}/{endpoint}"
    headers = {
        "Authorization": f"Bearer {token}"
    }
    
    try:
        async with aiohttp.ClientSession() as session:
            if method == "GET":
                async with session.get(url, headers=headers, timeout=30) as resp:
                    return await resp.json(), resp.status
            elif method == "POST":
                if files:
                    # Untuk upload file
                    form_data = aiohttp.FormData()
                    for key, value in data.items():
                        form_data.add_field(key, value)
                    form_data.add_field('files', files, filename='index.html')
                    
                    async with session.post(url, headers=headers, data=form_data, timeout=60) as resp:
                        return await resp.json(), resp.status
                else:
                    async with session.post(url, headers=headers, json=data, timeout=60) as resp:
                        return await resp.json(), resp.status
            elif method == "PUT":
                async with session.put(url, headers=headers, json=data, timeout=60) as resp:
                    return await resp.json(), resp.status
            elif method == "DELETE":
                async with session.delete(url, headers=headers, timeout=30) as resp:
                    if resp.status == 204:
                        return {}, 204
                    return await resp.json(), resp.status
    except asyncio.TimeoutError:
        return {"error": "Timeout"}, 408
    except Exception as e:
        return {"error": str(e)}, 500

# ============================================
# COMMAND SETTING TOKEN
# ============================================

@PY.UBOT("setnetlify")
async def set_netlify_token(client: Client, message: Message):
    """Set Netlify API token"""
    ggl = await EMO.GAGAL(client)
    sks = await EMO.BERHASIL(client)
    
    try:
        args = message.text.split(maxsplit=1)
        if len(args) < 2:
            await message.reply_text(
                f"<blockquote><b>❌ Format: .setnetlify [token]</b>\n\n"
                f"Ambil token di:\n"
                f"https://app.netlify.com/user/applications/personal</blockquote>"
            )
            return
        
        token = args[1].strip()
        
        await message.reply_text(f"⏳ <b>Testing token...</b>")
        
        # Test token dengan get user
        data, status = await netlify_request("GET", "user")
        
        if status == 200:
            netlify_config["token"] = token
            save_netlify_config(netlify_config)
            
            email = data.get("email", "-")
            name = data.get("full_name", "-")
            slug = data.get("slug", "-")
            
            await message.reply_text(
                f"<blockquote><b>✅ TOKEN NETLIFY VALID</b>\n\n"
                f"👤 <b>Name:</b> {name}\n"
                f"📧 <b>Email:</b> {email}\n"
                f"🔗 <b>Slug:</b> {slug}\n"
                f"🔑 <b>Token:</b> <code>{token[:8]}...{token[-5:]}</code></blockquote>"
            )
        else:
            error_msg = data.get("message", "Invalid token")
            await message.reply_text(f"{ggl} <b>Token tidak valid!</b>\n{error_msg}")
            
    except Exception as e:
        await message.reply_text(f"{ggl} <b>Error: {str(e)[:100]}</b>")

@PY.UBOT("cektokenetlify")
async def cek_netlify_token(client: Client, message: Message):
    """Cek status token Netlify"""
    ggl = await EMO.GAGAL(client)
    sks = await EMO.BERHASIL(client)
    
    token = netlify_config.get("token")
    
    if not token:
        await message.reply_text(
            f"{ggl} <b>Token belum diset!</b>\n"
            f"Gunakan .setnetlify [token]"
        )
        return
    
    await message.reply_text(f"⏳ <b>Memeriksa token...</b>")
    
    data, status = await netlify_request("GET", "user")
    
    if status == 200:
        email = data.get("email", "-")
        name = data.get("full_name", "-")
        
        await message.reply_text(
            f"<blockquote><b>✅ TOKEN NETLIFY VALID</b>\n\n"
            f"👤 <b>Name:</b> {name}\n"
            f"📧 <b>Email:</b> {email}\n"
            f"🔑 <b>Token:</b> <code>{token[:8]}...{token[-5:]}</code></blockquote>"
        )
    else:
        await message.reply_text(f"{ggl} <b>Token tidak valid!</b>")

# ============================================
# COMMAND DEPLOY NETLIFY
# ============================================

@PY.UBOT("netlify")
async def deploy_netlify(client: Client, message: Message):
    ggl = await EMO.GAGAL(client)
    sks = await EMO.BERHASIL(client)
    prs = await EMO.PROSES(client)
    
    try:
        await client.send_chat_action(message.chat.id, ChatAction.TYPING)
        
        # Cek token
        token = netlify_config.get("token")
        if not token:
            await message.reply_text(
                f"{ggl} <b>Token Netlify belum diset!</b>\n"
                f"Gunakan .setnetlify [token] dulu"
            )
            return
        
        # Ambil nama site
        args = message.text.split(maxsplit=1)
        if len(args) < 2:
            await message.reply_text(
                f"<blockquote><b>🚀 NETLIFY DEPLOY</b>\n\n"
                f"<b>Format:</b> <code>.netlify [nama]</code> (reply ke HTML)\n\n"
                f"<b>Contoh:</b>\n"
                f"1. Tulis kode HTML\n"
                f"2. Reply dengan <code>.netlify mysite</code>\n\n"
                f"<b>Hasil:</b> https://[nama].netlify.app</blockquote>"
            )
            return
        
        site_name = args[1].strip()
        
        # Validasi nama site
        if not re.match(r'^[a-z0-9\-]+$', site_name):
            await message.reply_text(
                f"{ggl} <b>Nama site hanya boleh huruf kecil, angka, dan tanda strip!</b>"
            )
            return
        
        # Cek apakah ada reply
        if not message.reply_to_message:
            await message.reply_text(
                f"{ggl} <b>Reply ke pesan yang berisi kode HTML!</b>"
            )
            return
        
        replied = message.reply_to_message
        
        # Ambil konten HTML
        html_content = None
        source_type = ""
        
        # Cek dari teks
        if replied.text:
            html_content = replied.text
            source_type = "📝 Teks"
        
        # Cek dari file
        elif replied.document:
            doc = replied.document
            file_name = doc.file_name or ""
            
            # Cek ekstensi .html
            if file_name.endswith('.html') or file_name.endswith('.htm'):
                # Download file
                file_path = await replied.download()
                with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                    html_content = f.read()
                
                # Hapus file
                if os.path.exists(file_path):
                    os.remove(file_path)
                
                source_type = f"📄 File: {file_name}"
            else:
                await message.reply_text(
                    f"{ggl} <b>File harus berekstensi .html atau .htm!</b>"
                )
                return
        
        # Cek dari mimetype
        elif replied.document and replied.document.mime_type == "text/html":
            file_path = await replied.download()
            with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                html_content = f.read()
            
            if os.path.exists(file_path):
                os.remove(file_path)
            
            source_type = "📄 File HTML"
        
        else:
            await message.reply_text(
                f"{ggl} <b>Format tidak didukung!</b>\n"
                f"Reply ke teks HTML atau file .html"
            )
            return
        
        if not html_content:
            await message.reply_text(f"{ggl} <b>Konten HTML kosong!</b>")
            return
        
        # Validasi HTML
        if not is_valid_html(html_content):
            await message.reply_text(
                f"{ggl} <b>Bukan HTML yang valid!</b>\n"
                f"Pastikan berisi tag HTML seperti &lt;html&gt;, &lt;body&gt;, dll."
            )
            return
        
        # Kirim pesan processing
        processing = await message.reply_text(
            f"{prs} <b>Mendeploy ke Netlify...</b>\n"
            f"📛 Nama: {site_name}\n"
            f"{source_type}"
        )
        
        # Step 1: Cek ketersediaan nama site
        check_data, check_status = await netlify_request("GET", f"sites/{site_name}")
        
        if check_status != 404:
            await processing.edit_text(
                f"{ggl} <b>Nama site '{site_name}' sudah digunakan!</b>\n"
                f"Coba nama lain."
            )
            return
        
        # Step 2: Buat site baru
        site_data = {
            "name": site_name,
            "custom_domain": None,
            "force_ssl": True
        }
        
        site_result, site_status = await netlify_request("POST", "sites", site_data)
        
        if site_status not in [200, 201]:
            error_msg = site_result.get("message", "Failed to create site")
            await processing.edit_text(f"{ggl} <b>Gagal buat site!</b>\n{error_msg}")
            return
        
        site_id = site_result.get("id")
        site_url = site_result.get("url", f"https://{site_name}.netlify.app")
        
        # Step 3: Upload file HTML
        await processing.edit_text(f"{prs} <b>Uploading HTML file...</b>")
        
        # Deploy file ke site
        deploy_data = {
            "title": "Deploy via Telegram"
        }
        
        deploy_result, deploy_status = await netlify_request(
            "POST", 
            f"sites/{site_id}/deploys",
            deploy_data,
            files=html_content.encode('utf-8')
        )
        
        if deploy_status not in [200, 201]:
            error_msg = deploy_result.get("message", "Failed to deploy")
            await processing.edit_text(f"{ggl} <b>Gagal deploy!</b>\n{error_msg}")
            return
        
        deploy_id = deploy_result.get("id")
        deploy_url = deploy_result.get("deploy_url")
        
        await processing.delete()
        
        # Hasil sukses
        result = f"""
<blockquote><b>✅ NETLIFY DEPLOY SUCCESS</b>

📛 <b>Nama:</b> {site_name}
🆔 <b>Site ID:</b> <code>{site_id[:8]}...</code>
☁️ <b>Platform:</b> Netlify
📄 <b>Type:</b> Static HTML
⚙️ <b>Status:</b> Deployed
{source_type}

🔗 <b>URL:</b>
• Production: {site_url}
• Deploy: {deploy_url}

📌 <b>Note:</b> Website online sekarang!</blockquote>"""
        
        await message.reply_text(result)
        
    except Exception as e:
        await message.reply_text(
            f"<blockquote><b>❌ NETLIFY DEPLOY FAILED</b>\n\n"
            f"Error: {str(e)[:200]}</blockquote>"
        )

@PY.UBOT("netlifylist")
async def netlify_list(client: Client, message: Message):
    """Lihat daftar site di Netlify"""
    ggl = await EMO.GAGAL(client)
    prs = await EMO.PROSES(client)
    
    if not netlify_config.get("token"):
        await message.reply_text(f"{ggl} <b>Token belum diset!</b>")
        return
    
    processing = await message.reply_text(f"{prs} <b>Mengambil daftar site...</b>")
    
    data, status = await netlify_request("GET", "sites?per_page=100")
    
    if status == 200:
        sites = data if isinstance(data, list) else []
        
        if not sites:
            await processing.edit_text("<b>📭 Belum ada site.</b>")
            return
        
        text = "<blockquote><b>📋 DAFTAR SITE NETLIFY</b>\n\n"
        
        for s in sites[:10]:  # Ambil 10 aja
            name = s.get("name", "-")
            url = s.get("url", "-")
            created = s.get("created_at", "-")[:10]
            
            text += f"📛 <b>{name}</b>\n"
            text += f"🔗 {url}\n"
            text += f"📅 {created}\n"
            text += f"━━━━━━━━━━━━━━━\n"
        
        text += f"\n📊 Total: {len(sites)} site</blockquote>"
        
        await processing.edit_text(text)
    else:
        await processing.edit_text(f"{ggl} <b>Gagal mengambil data!</b>")

@PY.UBOT("netlifydelete")
async def netlify_delete(client: Client, message: Message):
    """Hapus site dari Netlify"""
    ggl = await EMO.GAGAL(client)
    prs = await EMO.PROSES(client)
    
    if not netlify_config.get("token"):
        await message.reply_text(f"{ggl} <b>Token belum diset!</b>")
        return
    
    args = message.text.split(maxsplit=1)
    if len(args) < 2:
        await message.reply_text(f"{ggl} <b>Masukkan nama site!</b>\nContoh: .netlifydelete mysite")
        return
    
    site_name = args[1].strip()
    
    # Konfirmasi
    confirm = await message.reply_text(
        f"⚠️ <b>Yakin hapus site {site_name}?</b>\n"
        f"Ketik <code>ya</code> untuk konfirmasi."
    )
    
    try:
        resp = await client.wait_for_message(
            chat_id=message.chat.id,
            from_user_id=message.from_user.id,
            timeout=10
        )
        
        if resp and resp.text and resp.text.lower() == "ya":
            await confirm.edit_text(f"{prs} <b>Menghapus site {site_name}...</b>")
            
            _, status = await netlify_request("DELETE", f"sites/{site_name}")
            
            if status == 204:
                await confirm.edit_text(f"<b>✅ Site {site_name} dihapus!</b>")
            else:
                await confirm.edit_text(f"{ggl} <b>Gagal menghapus site!</b>")
        else:
            await confirm.edit_text("<b>❌ Dibatalkan</b>")
            
    except asyncio.TimeoutError:
        await confirm.edit_text("<b>⏱️ Timeout, dibatalkan</b>")

# ============================================
# COMMAND INFO AKUN
# ============================================

@PY.UBOT("netlifyaccount")
async def netlify_account(client: Client, message: Message):
    """Info akun Netlify"""
    ggl = await EMO.GAGAL(client)
    prs = await EMO.PROSES(client)
    
    if not netlify_config.get("token"):
        await message.reply_text(f"{ggl} <b>Token belum diset!</b>")
        return
    
    processing = await message.reply_text(f"{prs} <b>Mengambil info akun...</b>")
    
    # Get user
    user_data, user_status = await netlify_request("GET", "user")
    
    # Get sites count
    sites_data, sites_status = await netlify_request("GET", "sites?per_page=1")
    
    if user_status == 200:
        email = user_data.get("email", "-")
        name = user_data.get("full_name", "-")
        slug = user_data.get("slug", "-")
        
        sites_count = len(sites_data) if sites_status == 200 else "?"
        
        text = f"""
<blockquote><b>📊 INFO AKUN NETLIFY</b>

👤 <b>Name:</b> {name}
📧 <b>Email:</b> {email}
🔗 <b>Slug:</b> {slug}
📦 <b>Sites:</b> {sites_count}</blockquote>"""
        
        await processing.edit_text(text)
    else:
        await processing.edit_text(f"{ggl} <b>Gagal ambil info akun!</b>")