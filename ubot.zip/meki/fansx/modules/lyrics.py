import requests
import wget
import os
import random
from pyrogram import Client
from fansx import *

# Daftar API keys By Zyura (12 key)
API_KEYS = [
    "eIxUwMpn",
    "keoCFdc6",
    "bv7m372F",
    "iAiB9QKT",
    "JP7Cy8Y2",
    "GI4vPxYv",
    "HRPga9TN",
    "PDwqhVsj",
    "m8jpBeZR",
    "PXkxh5hw",
    "MFnlpM6A",
    "u299UiOF"
]

def get_random_apikey():
    return random.choice(API_KEYS)

__MODULE__ = "ʟʏʀɪᴄꜱ"
__HELP__ = """
<b>『 ʟʏʀɪᴄꜱ 』</b>

  <b>➢ ᴘᴇʀɪɴᴛᴀʜ:</b> <code>{0}lyrics [judul lagu]</code> 
   <i>penjelasan:</i> search lyrics music

📌 Contoh:
<code>.lyrics tak ingin usai</code>
<code>.lyrics bohemian rhapsody</code>
"""

@PY.UBOT("lyrics")
async def lyrics(client, message):
    ggl = await EMO.GAGAL(client)
    sks = await EMO.BERHASIL(client)
    prs = await EMO.PROSES(client)
    
    jalan = await message.reply(f"{prs} Processing...")
    
    if len(message.command) < 2:
        return await jalan.edit(f"{ggl} Contoh: <code>.lyrics tak ingin usai</code>")
    
    # Ambil judul lagu
    judul = " ".join(message.command[1:])
    chat_id = message.chat.id
    
    # Ambil API key random
    apikey = get_random_apikey()
    
    # PERBAIKAN URL - ini yang bener!
    url = f"https://api.betabotz.eu.org/api/search/lirik?lirik={judul}&apikey={apikey}"
    
    try:
        response = requests.get(url, timeout=10)
        
        if response.status_code == 200:
            data = response.json()
            
            if data.get("status") and "result" in data:
                hasil = data['result']
                
                # Ambil data - perhatikan keynya 'lirik' bukan 'lyrics'
                lirik = hasil.get('lirik', 'Lirik tidak ditemukan')
                judul_lagu = hasil.get('judul', judul)
                penyanyi = hasil.get('penyanyi', 'Unknown Artist')
                
                # Batasi panjang lirik
                if len(lirik) > 3500:
                    lirik = lirik[:3500] + "...\n\n(Lirik dipotong karena terlalu panjang)"
                
                # Format caption - LANGSUNG KIRIM LIRIK, GA USAH GAMBAR
                caption = f"""
<blockquote><b>🎵 LYRIC FINDER</b>

📌 <b>Judul:</b> {judul_lagu}
🎤 <b>Penyanyi:</b> {penyanyi}
🔑 <b>Key:</b> <code>{apikey[:8]}...</code>

<b>📝 LIRIK:</b>
<code>{lirik}</code>

{sks} <b>Powered by:</b> Ubot Premium Zyura</blockquote>
"""
                
                # Kirim langsung teks, ga usah pake photo
                await jalan.edit(caption)
                
            else:
                await jalan.edit(f"{ggl} Lirik tidak ditemukan untuk: <code>{judul}</code>")
        else:
            await jalan.edit(f"{ggl} Gagal mengambil data! HTTP {response.status_code}")
    
    except Exception as e:
        await jalan.edit(f"{ggl} Error: {str(e)[:100]}")