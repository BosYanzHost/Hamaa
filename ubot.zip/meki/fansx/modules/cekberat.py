from fansx import *
import random
import asyncio
from pyrogram.enums import ChatAction
from pyrogram.types import Message

__MODULE__ = "ᴄᴇᴋ ʙᴇʀᴀᴛ"
__HELP__ = """
<blockquote><b>『 CEK BERAT BADAN 』</b>

<b>⌲ Perintah:</b>
ᚗ <code>{0}berat [nama]</code> 
⊶ Mengecek berat badan random seseorang

<b>⌲ Contoh:</b>
<code>.berat</code> (untuk cek diri sendiri)
<code>.berat Budi</code> (untuk cek orang lain)
<code>.berat @username</code></blockquote>
"""

def get_description(berat):
    """Mendapatkan deskripsi berdasarkan berat badan"""
    if berat >= 90:
        return "Big boy/girl! 💪"
    elif berat >= 70:
        return "Berisi dan sehat! 😊"
    elif berat >= 55:
        return "Ideal banget! 👍"
    elif berat >= 45:
        return "Langsing nih~ 🌸"
    else:
        return "Kurus banget, makan yang banyak! 🍔"

@PY.UBOT("berat")
async def cek_berat(client: Client, message: Message):
    ggl = await EMO.GAGAL(client)
    sks = await EMO.BERHASIL(client)
    prs = await EMO.PROSES(client)
    
    try:
        await client.send_chat_action(message.chat.id, ChatAction.TYPING)
        
        # Ambil nama dari input atau reply
        nama = "Kamu"
        
        # Cek apakah reply ke user
        if message.reply_to_message and message.reply_to_message.from_user:
            user = message.reply_to_message.from_user
            nama = user.first_name
            if user.last_name:
                nama += f" {user.last_name}"
        
        # Cek dari argumen
        args = message.text.split(maxsplit=1)
        if len(args) > 1:
            input_nama = args[1].strip()
            
            # Cek apakah mention @username
            if input_nama.startswith('@'):
                try:
                    user = await client.get_users(input_nama)
                    nama = user.first_name
                    if user.last_name:
                        nama += f" {user.last_name}"
                except:
                    nama = input_nama
            else:
                nama = input_nama
        
        # Jika tidak ada input dan tidak reply, pakai nama sender
        elif nama == "Kamu":
            nama = message.from_user.first_name
            if message.from_user.last_name:
                nama += f" {message.from_user.last_name}"
        
        # Generate random berat (40-100 kg)
        berat = random.randint(40, 100)
        desc = get_description(berat)
        
        # Kirim pesan processing dulu (biar ada efek)
        processing = await message.reply_text(f"{prs} <b>Menimbang {nama}...</b>")
        
        # Tunggu bentar biar keliatan prosesnya
        await asyncio.sleep(1)
        
        # Format pesan
        txt = f"""
<blockquote><b>⚖️ CEK BERAT BADAN</b>

<b>👤 Nama:</b> <code>{nama}</code>
<b>📊 Berat:</b> <code>{berat} kg</code>

<b>💬 {desc}</b></blockquote>
"""
        
        await processing.edit_text(txt)
        
    except Exception as e:
        await message.reply_text(f"{ggl} <b>Error: {str(e)[:100]}</b>")

@PY.UBOT("cekberat")
async def cek_berat_alias(client: Client, message: Message):
    """Alias untuk berat"""
    await cek_berat(client, message)

@PY.UBOT("weight")
async def weight_alias(client: Client, message: Message):
    """Alias untuk berat"""
    await cek_berat(client, message)

@PY.BOT("berat")
async def cek_berat_bot(client: Client, message: Message):
    """Handler untuk bot"""
    try:
        nama = "Kamu"
        
        if message.reply_to_message and message.reply_to_message.from_user:
            user = message.reply_to_message.from_user
            nama = user.first_name
            if user.last_name:
                nama += f" {user.last_name}"
        
        args = message.text.split(maxsplit=1)
        if len(args) > 1:
            input_nama = args[1].strip()
            if input_nama.startswith('@'):
                try:
                    user = await client.get_users(input_nama)
                    nama = user.first_name
                    if user.last_name:
                        nama += f" {user.last_name}"
                except:
                    nama = input_nama
            else:
                nama = input_nama
        
        # Generate random berat (40-100 kg)
        berat = random.randint(40, 100)
        desc = get_description(berat)
        
        txt = f"""
⚖️ *CEK BERAT BADAN*

👤 Nama: {nama}
📊 Berat: {berat} kg

💬 {desc}
"""
        await message.reply_text(txt)
        
    except Exception as e:
        await message.reply_text(f"❌ Error: {str(e)[:100]}")

@PY.BOT("cekberat")
async def cek_berat_bot_alias(client: Client, message: Message):
    """Alias untuk bot"""
    await cek_berat_bot(client, message)

@PY.BOT("weight")
async def weight_bot_alias(client: Client, message: Message):
    """Alias untuk bot"""
    await cek_berat_bot(client, message)