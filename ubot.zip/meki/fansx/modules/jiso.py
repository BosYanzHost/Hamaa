from fansx import *
import aiohttp
import asyncio
import os
import random
from pyrogram.enums import ChatAction, ParseMode
from pyrogram.types import Message

__MODULE__ = "ᴊɪsᴏ ɢᴀʟʟᴇʀʏ"
__HELP__ = """
<blockquote><b>🎨 JISO RANDOM IMAGE</b>

<b>⌲ Perintah:</b>
ᚗ <code>{0}jiso</code> - Ambil random gambar Jiso
ᚗ <code>{0}jiso [jumlah]</code> - Ambil beberapa gambar (max 5)

<b>⌲ Contoh:</b>
<code>.jiso</code>
<code>.jiso 3</code></blockquote>
"""

# ============================================
# KONFIGURASI
# ============================================
JISO_API_URL = "https://api.theresav.biz.id/image/jiso"
API_KEY = "UYGSg"

async def get_jiso_image():
    """Ambil random gambar Jiso dari API"""
    url = f"{JISO_API_URL}?apikey={API_KEY}"
    
    try:
        async with aiohttp.ClientSession() as session:
            async with session.get(url, timeout=15) as response:
                if response.status == 200:
                    # Cek content-type
                    content_type = response.headers.get("Content-Type", "")
                    
                    if "image" in content_type:
                        # Langsung gambar
                        return {
                            "success": True,
                            "image": await response.read()
                        }
                    else:
                        # Mungkin JSON dengan URL
                        try:
                            data = await response.json()
                            # Coba cari URL gambar di berbagai kemungkinan struktur
                            img_url = None
                            if isinstance(data, dict):
                                if data.get("url"):
                                    img_url = data["url"]
                                elif data.get("image_url"):
                                    img_url = data["image_url"]
                                elif data.get("data") and isinstance(data["data"], dict):
                                    img_url = data["data"].get("url")
                                elif data.get("result") and isinstance(data["result"], dict):
                                    img_url = data["result"].get("url")
                            
                            if img_url:
                                # Download dari URL
                                async with session.get(img_url, timeout=15) as img_resp:
                                    if img_resp.status == 200:
                                        return {
                                            "success": True,
                                            "image": await img_resp.read()
                                        }
                        except:
                            pass
                        
                        return {
                            "success": False,
                            "error": "API tidak mengembalikan gambar atau format tidak dikenali"
                        }
                else:
                    return {"success": False, "error": f"HTTP {response.status}"}
    except asyncio.TimeoutError:
        return {"success": False, "error": "Timeout - server terlalu lambat"}
    except Exception as e:
        return {"success": False, "error": str(e)}

@PY.UBOT("jiso")
async def jiso_command(client: Client, message: Message):
    ggl = await EMO.GAGAL(client)
    sks = await EMO.BERHASIL(client)
    prs = await EMO.PROSES(client)
    
    # Parse jumlah gambar dari argumen
    args = message.text.split()
    count = 1
    if len(args) > 1 and args[1].isdigit():
        count = min(int(args[1]), 5)  # Maksimal 5 gambar biar gak spam
    
    try:
        await client.send_chat_action(message.chat.id, ChatAction.UPLOAD_PHOTO)
        
        processing = await message.reply_text(f"{prs} <b>Mencari {count} gambar Jiso...</b>")
        
        # Koleksi gambar yang berhasil diambil
        images = []
        failed = 0
        
        for i in range(count):
            result = await get_jiso_image()
            if result.get("success") and result.get("image"):
                images.append(result["image"])
            else:
                failed += 1
        
        await processing.delete()
        
        if images:
            # Kirim gambar satu per satu
            sent_count = 0
            for img_data in images:
                # Simpan gambar sementara
                file_path = f"jiso_{message.from_user.id}_{random.randint(1000,9999)}.jpg"
                with open(file_path, "wb") as f:
                    f.write(img_data)
                
                # Kirim gambar
                await client.send_photo(
                    chat_id=message.chat.id,
                    photo=file_path,
                    caption="<blockquote><b>🎨 JISO GALLERY</b>\n\n⚡ <b>Powered by:</b> Ubot Premium Zyura</blockquote>"
                )
                
                # Hapus file
                if os.path.exists(file_path):
                    os.remove(file_path)
                
                sent_count += 1
                await asyncio.sleep(0.5)  # Jeda biar gak kena flood
            
            # Info tambahan jika ada yang gagal
            if failed > 0:
                await message.reply_text(f"{sks} <b>Berhasil mengirim {sent_count} gambar</b>\n⚠️ {failed} gambar gagal diambil")
        else:
            error_msg = result.get("error", "Unknown error") if 'result' in locals() else "Semua gambar gagal diambil"
            await message.reply_text(
                f"<blockquote><b>❌ GAGAL MENGAMBIL GAMBAR</b>\n\n"
                f"Error: {error_msg}</blockquote>"
            )
        
    except Exception as e:
        await message.reply_text(f"{ggl} <b>Error: {str(e)[:100]}</b>")
