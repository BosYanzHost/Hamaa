from fansx import *
import aiohttp
import asyncio
import random
from urllib.parse import quote
from pyrogram.enums import ChatAction, ParseMode
from pyrogram.types import Message

__MODULE__ = "ꜰᴏɴᴛ sᴇᴀʀᴄʜ"
__HELP__ = """
<blockquote><b>🔤 FONT SEARCH (8FONT)</b>

<b>⌲ Perintah:</b>
ᚗ <code>{0}font [nama font]</code> - Cari font
ᚗ <code>{0}fontrandom</code> - Font random

<b>⌲ Contoh:</b>
<code>.font Poppins</code>
<code>.font Arial</code>
<code>.font Times New Roman</code>
<code>.fontrandom</code>

<b>⌲ Catatan:</b>
• Menampilkan 1 font random dari hasil
• Font bisa di-download dari 8font.com</blockquote>
"""

# ============================================
# KONFIGURASI
# ============================================
API_URL = "https://api.baguss.xyz/api/search/8fonts"

# Daftar font populer untuk random
POPULAR_FONTS = [
    "Poppins", "Arial", "Helvetica", "Times New Roman", 
    "Roboto", "Open Sans", "Montserrat", "Lato",
    "Comic Sans", "Impact", "Georgia", "Verdana",
    "Courier New", "Garamond", "Calibri", "Tahoma"
]

async def search_fonts(query: str):
    """Cari font dari API"""
    try:
        encoded_query = quote(query)
        url = f"{API_URL}?q={encoded_query}"
        
        async with aiohttp.ClientSession() as session:
            async with session.get(url, timeout=15) as response:
                if response.status == 200:
                    data = await response.json()
                    if data.get("status") and data.get("fonts"):
                        return {
                            "keyword": data.get("keyword", query),
                            "total": data.get("total_results", 0),
                            "fonts": data.get("fonts", [])
                        }
    except Exception as e:
        print(f"Error search fonts: {e}")
    return None

def clean_date(date_str):
    """Bersihkan format tanggal"""
    if not date_str:
        return "Unknown"
    # Hapus karakter '|' di akhir
    return date_str.replace(" |", "").strip()

@PY.UBOT("font")
async def search_font_command(client: Client, message: Message):
    ggl = await EMO.GAGAL(client)
    prs = await EMO.PROSES(client)
    
    try:
        await client.send_chat_action(message.chat.id, ChatAction.TYPING)
        
        args = message.text.split(maxsplit=1)
        if len(args) < 2:
            await message.reply_text(
                f"<blockquote><b>❌ Masukkan nama font!</b>\n\n"
                f"<b>Contoh:</b>\n"
                f"<code>.font Poppins</code>\n"
                f"<code>.font Arial</code>\n"
                f"<code>.font Times New Roman</code>\n\n"
                f"Atau coba <code>.fontrandom</code></blockquote>"
            )
            return
        
        query = args[1].strip()
        
        processing = await message.reply_text(f"{prs} <b>Mencari font '{query}'...</b>")
        
        result = await search_fonts(query)
        
        if not result or not result.get("fonts"):
            await processing.edit_text(
                f"{ggl} <b>Font '{query}' tidak ditemukan!</b>\n\n"
                f"Coba kata kunci lain atau <code>.fontrandom</code>"
            )
            return
        
        fonts = result["fonts"]
        total = result["total"]
        
        # Ambil 1 font random
        font = random.choice(fonts)
        
        title = font.get("title", "Unknown Font")
        categories = font.get("categories", [])
        date = clean_date(font.get("date", ""))
        image = font.get("image", "")
        
        # Format kategori
        category_text = ", ".join(categories) if categories else "Tidak ada kategori"
        
        # Buat caption
        caption = f"""
<blockquote><b>🔤 FONT DITEMUKAN</b>

<b>📌 Nama:</b> {title}
<b>📋 Kategori:</b> {category_text}
<b>📅 Update:</b> {date}
<b>🔍 Kata Kunci:</b> {query}
<b>📊 Total Hasil:</b> {total} font</blockquote>"""
        
        await processing.delete()
        
        # Kirim dengan gambar jika ada
        if image:
            try:
                await client.send_photo(
                    chat_id=message.chat.id,
                    photo=image,
                    caption=caption
                )
            except Exception as e:
                # Fallback jika gambar gagal
                await message.reply_text(caption)
        else:
            await message.reply_text(caption)
        
    except Exception as e:
        await message.reply_text(f"{ggl} <b>Error: {str(e)[:100]}</b>")

@PY.UBOT("fontrandom")
async def random_font_command(client: Client, message: Message):
    """Cari font random dari daftar populer"""
    random_query = random.choice(POPULAR_FONTS)
    
    # Ubah command sementara
    message.text = f".font {random_query}"
    await search_font_command(client, message)

@PY.UBOT("fontinfo")
async def font_info(client: Client, message: Message):
    """Info fitur font search"""
    
    text = """
<blockquote><b>🔤 INFO FONT SEARCH</b>

<b>Sumber:</b> 8font.com via api.baguss.xyz
<b>Update:</b> Real-time

<b>Fitur:</b>
• Cari font berdasarkan nama
• Tampilkan 1 font random dari hasil
• Lihat kategori & tanggal update
• Preview gambar font
• Font random dari daftar populer

<b>Cara pakai:</b>
• <code>.font [nama]</code> - Cari font
• <code>.fontrandom</code> - Font random

<b>Contoh:</b>
<code>.font Poppins</code>
<code>.font Arial</code>
<code>.fontrandom</code>

<b>Daftar font populer:</b>
Poppins, Arial, Roboto, Open Sans, Montserrat, Lato, Comic Sans, Impact, Georgia, Verdana</blockquote>"""
    
    await message.reply_text(text)

@PY.UBOT("fontlist")
async def font_list(client: Client, message: Message):
    """Tampilkan daftar font populer"""
    
    text = "<blockquote><b>📋 DAFTAR FONT POPULER</b>\n\n"
    
    # Tampilkan dalam 5 kolom
    per_row = 5
    rows = [POPULAR_FONTS[i:i+per_row] for i in range(0, len(POPULAR_FONTS), per_row)]
    
    for row in rows:
        text += " • " + " • ".join(row) + "\n"
    
    text += f"\n<b>Total:</b> {len(POPULAR_FONTS)} font\n\n"
    text += "<b>Coba:</b> <code>.font [nama]</code> atau <code>.fontrandom</code></blockquote>"
    
    await message.reply_text(text)