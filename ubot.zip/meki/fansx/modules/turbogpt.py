from fansx import *
import random
import requests
from pyrogram.enums import ChatAction, ParseMode
from pyrogram import filters
from pyrogram.types import Message

__MODULE__ = "ᴛᴜʀʙᴏ ɢᴘᴛ"
__HELP__ = """
<blockquote><b>✮ Bantuan Untuk Turbo Gpt ✮

perintah : <code>{0}turbo</code>
    buat menjawab pertanyaan <code>{0}turbo</code> haii</b></blockquote>
"""

# API Key statis
API_KEY = "iyNntkdC"
BASE_URL = "https://api.botcahx.eu.org/api/search/openai-chat"

@PY.UBOT("turbo")
@PY.TOP_CMD
async def chat_gpt(client, message):
    try:
        await client.send_chat_action(message.chat.id, ChatAction.TYPING)

        if len(message.command) < 2:
            await message.reply_text(
                "<emoji id=5019523782004441717>❌</emoji>mohon gunakan format\ncontoh : .turbo hai"
            )
        else:
            prs = await message.reply_text(f"<emoji id=6226405134004389590>🔍</emoji>Turbo Sedang Menjawab Pesan Anda....")
            hai = message.text.split(' ', 1)[1]
            
            # Ubah URL API dan parameter
            params = {
                "apikey": API_KEY,
                "text": hai
            }
            response = requests.get(BASE_URL, params=params, timeout=15)

            try:
                json_response = response.json()
                if "message" in json_response:
                    x = json_response["message"]                  
                    await prs.edit(
                      f"<blockquote>{x}</blockquote>"
                    )
                else:
                    await message.reply_text("No 'message' key found in the response.")
            except KeyError:
                await message.reply_text("Error accessing the response.")
    except Exception as e:
        await message.reply_text(f"{e}")

@PY.BOT("turbo")
async def chat_gpt_bot(client, message):
    try:
        await client.send_chat_action(message.chat.id, ChatAction.TYPING)

        if len(message.command) < 2:
            await message.reply_text(
                "<emoji id=5019523782004441717>❌</emoji>mohon gunakan format\ncontoh : /turbo hai"
            )
        else:
            prs = await message.reply_text(f"<emoji id=6226405134004389590>🔍</emoji>Turbo Sedang Menjawab Pesan Anda....")
            hai = message.text.split(' ', 1)[1]
            
            # Ubah URL API dan parameter
            params = {
                "apikey": API_KEY,
                "text": hai
            }
            response = requests.get(BASE_URL, params=params, timeout=15)

            try:
                json_response = response.json()
                if "message" in json_response:
                    x = json_response["message"]                  
                    await prs.edit(
                      f"<blockquote>{x}</blockquote>"
                    )
                else:
                    await message.reply_text("No 'message' key found in the response.")
            except KeyError:
                await message.reply_text("Error accessing the response.")
    except Exception as e:
        await message.reply_text(f"{e}")