from fansx import *
import requests
import aiohttp
import os
import random
from pyrogram.enums import ChatAction, ParseMode
from pyrogram.types import Message, InlineKeyboardMarkup, InlineKeyboardButton

__MODULE__ = "ᴍᴀɴɢᴋᴀɴᴇ"
__HELP__ = """
<blockquote><b>『 SOUND EFFECTS 』</b>

<b>⌲ Perintah:</b>
ᚗ <code>{0}mangkane1</code> - <code>{0}mangkane9</code> 
⊶ Memutar sound effect manga

<b>⌲ Sound Lainnya:</b>
ᚗ <code>{0}acumalaka</code>
ᚗ <code>{0}reza-kecap</code>
ᚗ <code>{0}farhan-kebab</code>
ᚗ <code>{0}omaga</code>
ᚗ <code>{0}kamu-nanya</code>
ᚗ <code>{0}anjay</code>
ᚗ <code>{0}siuu</code>

<b>⌲ Contoh:</b>
<code>.mangkane1</code>
<code>.acumalaka</code>
<code>.mangkane5 thumb</code> (dengan thumbnail)</blockquote>
"""

# URL base untuk berbagai sound
MANGAKANE_BASE = "https://raw.githubusercontent.com/hyuura/Rest-Sound/main/HyuuraKane"
MANGAKANE_BASE2 = "https://raw.githubusercontent.com/aisyah-rest/mangkane/main/mangkanenya"
SOUND_BASE = "https://github.com/FahriAdison/Base-Sound/raw/main/audio"
TIKTOK_BASE = "https://github.com/DGXeon/Tiktokmusic-API/raw/master/tiktokmusic"

# Thumbnail default
DEFAULT_THUMB = "https://telegra.ph/file/48b67f699cfa231e4d5c2.jpg"

# URL group bot
GROUPBOT_URL = "https://t.me/ubot_premium_zyura"  # Ganti dengan link group lo

# Daftar sound yang tersedia
SOUNDS = {
    # Mangkane 1-9
    **{f"mangkane{i}": {"url": f"{MANGAKANE_BASE if i < 25 else MANGAKANE_BASE2}/mangkane{i}.mp3", "thumb": DEFAULT_THUMB} for i in range(1, 10)},
    
    # Sound khusus
    "acumalaka": {"url": f"{SOUND_BASE}/acumalaka.mp3", "thumb": DEFAULT_THUMB},
    "reza-kecap": {"url": f"{SOUND_BASE}/reza-kecap.mp3", "thumb": DEFAULT_THUMB},
    "farhan-kebab": {"url": f"{SOUND_BASE}/farhan-kebab.mp3", "thumb": DEFAULT_THUMB},
    "omaga": {"url": f"{SOUND_BASE}/omaga.mp3", "thumb": DEFAULT_THUMB},
    "kamu-nanya": {"url": f"{SOUND_BASE}/kamu-nanya.mp3", "thumb": DEFAULT_THUMB},
    "anjay": {"url": f"{SOUND_BASE}/anjay.mp3", "thumb": DEFAULT_THUMB},
    "siuu": {"url": f"{SOUND_BASE}/siuu.mp3", "thumb": DEFAULT_THUMB},
}

async def download_audio(url):
    """Download audio dari URL"""
    try:
        async with aiohttp.ClientSession() as session:
            async with session.get(url, timeout=15) as response:
                if response.status == 200:
                    return await response.read()
    except Exception as e:
        print(f"Error download audio: {e}")
    return None

async def mp3_to_ogg(mp3_data):
    """Simulasi konversi MP3 ke OGG (karena di Python butuh library tambahan)"""
    # Untuk sementara, return data asli
    # Kalo mau beneran konversi, pake pydub atau ffmpeg
    return mp3_data
@PY.UBOT("mangkane1")
@PY.UBOT("mangkane2")
@PY.UBOT("mangkane3")
@PY.UBOT("mangkane4")
@PY.UBOT("mangkane5")
@PY.UBOT("mangkane6")
@PY.UBOT("mangkane7")
@PY.UBOT("mangkane8")
@PY.UBOT("mangkane9")
async def mangkane_handler(client: Client, message: Message):
    await play_sound(client, message, message.command[0])
    
@PY.UBOT("acumalaka")
@PY.UBOT("reza-kecap")
@PY.UBOT("farhan-kebab")
@PY.UBOT("omaga")
@PY.UBOT("kamu-nanya")
@PY.UBOT("anjay")
@PY.UBOT("siuu")
async def special_sound_handler(client: Client, message: Message):
    await play_sound(client, message, message.command[0])
async def play_sound(client: Client, message: Message, sound_name: str):
    ggl = await EMO.GAGAL(client)
    sks = await EMO.BERHASIL(client)
    prs = await EMO.PROSES(client)
    
    try:
        await client.send_chat_action(message.chat.id, ChatAction.TYPING)
        
        # Cek apakah sound tersedia
        if sound_name not in SOUNDS:
            await message.reply_text(f"{ggl} <b>Sound '{sound_name}' tidak ditemukan!</b>")
            return
        
        sound_info = SOUNDS[sound_name]
        sound_url = sound_info["url"]
        thumb_url = sound_info["thumb"]
        
        # Cek apakah user minta thumbnail (pake argumen 'thumb')
        args = message.text.split()
        use_thumb = len(args) > 1 and args[1].lower() == 'thumb'
        
        # Kirim pesan processing
        processing = await message.reply_text(f"{prs} <b>Memutar {sound_name}...</b>")
        
        # Download audio
        audio_data = await download_audio(sound_url)
        
        if audio_data:
            # Simpan sementara
            file_path = f"{sound_name}_{message.from_user.id}.mp3"
            with open(file_path, 'wb') as f:
                f.write(audio_data)
            
            await processing.delete()
            
            if use_thumb:
                # Kirim dengan thumbnail external (kaya di contoh)
                try:
                    # Download thumbnail
                    async with aiohttp.ClientSession() as session:
                        async with session.get(thumb_url, timeout=10) as thumb_resp:
                            if thumb_resp.status == 200:
                                thumb_data = await thumb_resp.read()
                                
                                # Kirim audio dengan external reply
                                await client.send_audio(
                                    chat_id=message.chat.id,
                                    audio=file_path,
                                    title=f"🎵 {sound_name}",
                                    performer="Sound Effect",
                                    thumb=thumb_data,
                                    caption=f"<blockquote><b>🎵 {sound_name}</b></blockquote>"
                                )
                            else:
                                # Fallback kalo thumbnail gagal
                                await client.send_audio(
                                    chat_id=message.chat.id,
                                    audio=file_path,
                                    caption=f"<blockquote><b>🎵 {sound_name}</b></blockquote>"
                                )
                except Exception as e:
                    print(f"Error sending with thumb: {e}")
                    await client.send_audio(
                        chat_id=message.chat.id,
                        audio=file_path,
                        caption=f"<blockquote><b>🎵 {sound_name}</b></blockquote>"
                    )
            else:
                # Kirim audio biasa
                await client.send_audio(
                    chat_id=message.chat.id,
                    audio=file_path,
                    caption=f"<blockquote><b>🎵 {sound_name}</b></blockquote>"
                )
            
            # Hapus file
            if os.path.exists(file_path):
                os.remove(file_path)
        else:
            await processing.edit_text(f"{ggl} <b>Gagal memuat audio!</b>")
        
    except Exception as e:
        await message.reply_text(f"{ggl} <b>Error: {str(e)[:100]}</b>")

@PY.UBOT("soundlist")
async def sound_list(client: Client, message: Message):
    """Menampilkan daftar sound yang tersedia"""
    
    # Kelompokkan sound berdasarkan kategori
    mangkane_sounds = [s for s in SOUNDS.keys() if s.startswith('mangkane')]
    special_sounds = [s for s in SOUNDS.keys() if not s.startswith('mangkane')]
    
    text = "<blockquote><b>📋 DAFTAR SOUND EFFECTS</b>\n\n"
    
    text += "<b>🎵 Mangkane Series (1-9):</b>\n"
    text += " • " + ", ".join(mangkane_sounds) + "\n\n"
    
    text += "<b>🎵 Special Sounds:</b>\n"
    text += " • " + ", ".join(special_sounds) + "\n\n"
    
    text += "<b>💡 Cara pakai:</b>\n"
    text += "• <code>.mangkane1</code> (tanpa thumb)\n"
    text += "• <code>.mangkane1 thumb</code> (dengan thumb)\n"
    text += "• <code>.acumalaka</code>\n"
    text += "• <code>.siuu</code></blockquote>"
    
    await message.reply_text(text)

@PY.UBOT("soundthumb")
async def sound_thumb_command(client: Client, message: Message):
    """Alias untuk mangkane dengan thumb"""
    args = message.text.split()
    if len(args) > 1:
        sound_name = args[1]
        # Ubah command jadi sound_name + thumb
        message.text = f".{sound_name} thumb"
        await play_sound(client, message, sound_name)
    else:
        await message.reply_text(f"{ggl} <b>Masukkan nama sound!</b>\nContoh: .soundthumb mangkane1")

@PY.BOT("mangkane1")
async def mangkane_bot_handler(client: Client, message: Message):
    """Handler untuk bot"""
    sound_name = message.text.split()[0].replace('/', '')
    await play_sound_bot(client, message, sound_name)

async def play_sound_bot(client: Client, message: Message, sound_name: str):
    try:
        if sound_name not in SOUNDS:
            await message.reply_text(f"❌ Sound '{sound_name}' tidak ditemukan!")
            return
        
        sound_info = SOUNDS[sound_name]
        sound_url = sound_info["url"]
        
        processing = await message.reply_text(f"🔍 Memutar {sound_name}...")
        
        audio_data = await download_audio(sound_url)
        
        if audio_data:
            file_path = f"{sound_name}_bot_{message.from_user.id}.mp3"
            with open(file_path, 'wb') as f:
                f.write(audio_data)
            
            await processing.delete()
            
            await client.send_audio(
                chat_id=message.chat.id,
                audio=file_path,
                caption=f"🎵 {sound_name}"
            )
            
            if os.path.exists(file_path):
                os.remove(file_path)
        else:
            await processing.edit_text("❌ Gagal memuat audio!")
        
    except Exception as e:
        await message.reply_text(f"❌ Error: {str(e)[:100]}")