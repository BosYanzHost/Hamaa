from fansx import *
import aiohttp
import asyncio
from urllib.parse import quote
from pyrogram.enums import ChatAction
from pyrogram.types import Message

__MODULE__ = "ᴄᴀʀɪ ɢʀᴜᴘ ᴡᴀ"
__HELP__ = """
<blockquote><b>『 CARI GRUP WHATSAPP 』</b>

<b>⌲ Perintah:</b>
ᚗ <code>{0}grubwa [kata kunci]</code> 
⊶ Mencari grup WhatsApp berdasarkan kata kunci

<b>⌲ Contoh:</b>
<code>.grubwa ML indonesia</code>
<code>.grubwa anime</code>
<code>.grubwa coding</code></blockquote>
"""

# Base URL API
BASE_URL = "https://api.deline.web.id/search/grubwa"

async def search_grubwa(query: str):
    """Mencari grup WhatsApp dari API"""
    try:
        async with aiohttp.ClientSession() as session:
            params = {"q": query}
            async with session.get(BASE_URL, params=params, timeout=15) as response:
                if response.status == 200:
                    data = await response.json()
                    return data
                return None
    except Exception as e:
        print(f"Error search grubwa: {e}")
        return None

@PY.UBOT("grubwa")
async def grubwa_search(client: Client, message: Message):
    ggl = await EMO.GAGAL(client)
    sks = await EMO.BERHASIL(client)
    prs = await EMO.PROSES(client)
    
    try:
        await client.send_chat_action(message.chat.id, ChatAction.TYPING)
        
        # Ambil query
        args = message.text.split(maxsplit=1)
        if len(args) < 2:
            await message.reply_text(
                f"<blockquote><b>❌ Masukkan kata kunci!</b>\n\n"
                f"<b>Contoh:</b>\n"
                f"<code>.grubwa ML indonesia</code>\n"
                f"<code>.grubwa anime</code></blockquote>"
            )
            return
        
        query = args[1].strip()
        
        # Kirim pesan processing
        processing = await message.reply_text(f"{prs} <b>Mencari grup WhatsApp: {query}...</b>")
        
        # Panggil API
        data = await search_grubwa(query)
        
        if data and data.get("status"):
            total = data.get("total", 0)
            results = data.get("result", [])
            
            if total == 0 or not results:
                await processing.edit_text(
                    f"{ggl} <b>Tidak ada grup WhatsApp ditemukan untuk '{query}'</b>"
                )
                return
            
            # Format hasil
            text = f"<blockquote><b>📱 HASIL PENCARIAN GRUP WA</b>\n\n"
            text += f"🔎 <b>Kata Kunci:</b> {query}\n"
            text += f"📊 <b>Total Ditemukan:</b> {total}\n\n"
            
            for i, group in enumerate(results, 1):
                name = group.get("Name", "Tanpa Nama")
                link = group.get("Link", "#")
                desc = group.get("Description", "Tidak ada deskripsi")
                
                # Batasi panjang deskripsi
                if len(desc) > 100:
                    desc = desc[:100] + "..."
                
                text += f"<b>{i}. {name}</b>\n"
                text += f"📝 {desc}\n"
                text += f"🔗 <code>{link}</code>\n\n"
            
            text += "</blockquote>"
            
            await processing.delete()
            await message.reply_text(text)
        else:
            await processing.edit_text(
                f"{ggl} <b>Gagal mencari grup WhatsApp!</b>"
            )
        
    except asyncio.TimeoutError:
        await message.reply_text(f"{ggl} <b>Timeout! Server sedang sibuk.</b>")
    except aiohttp.ClientError as e:
        await message.reply_text(f"{ggl} <b>Gagal terhubung ke server: {str(e)[:100]}</b>")
    except Exception as e:
        await message.reply_text(f"{ggl} <b>Error: {str(e)[:100]}</b>")

@PY.UBOT("cariwa")
async def cariwa_alias(client: Client, message: Message):
    """Alias untuk grubwa"""
    await grubwa_search(client, message)

@PY.BOT("grubwa")
async def grubwa_bot(client: Client, message: Message):
    """Handler untuk bot"""
    try:
        args = message.text.split(maxsplit=1)
        if len(args) < 2:
            await message.reply_text(
                "❌ Masukkan kata kunci!\n"
                "Contoh: /grubwa ML indonesia"
            )
            return
        
        query = args[1].strip()
        
        processing = await message.reply_text(f"🔍 Mencari grup WA: {query}...")
        
        data = await search_grubwa(query)
        
        if data and data.get("status"):
            total = data.get("total", 0)
            results = data.get("result", [])
            
            if total == 0 or not results:
                await processing.edit_text(f"❌ Tidak ada grup ditemukan untuk '{query}'")
                return
            
            text = f"📱 *HASIL PENCARIAN GRUP WA*\n\n"
            text += f"🔎 Kata Kunci: {query}\n"
            text += f"📊 Total: {total}\n\n"
            
            for i, group in enumerate(results, 1):
                name = group.get("Name", "Tanpa Nama")
                link = group.get("Link", "#")
                
                text += f"*{i}. {name}*\n"
                text += f"Link: {link}\n\n"
            
            await processing.edit_text(text)
        else:
            await processing.edit_text("❌ Gagal mencari grup WhatsApp!")
        
    except Exception as e:
        await message.reply_text(f"❌ Error: {str(e)[:100]}")