from fansx import *
import aiohttp
import asyncio
from urllib.parse import quote
from pyrogram.enums import ChatAction, ParseMode
from pyrogram.types import Message

__MODULE__ = "ɪsʟᴀᴍ ᴀɪ"
__HELP__ = """
<blockquote><b>🕌 ISLAM AI</b>

<b>⌲ Perintah:</b>
ᚗ <code>{0}islam [pertanyaan]</code> - Tanya tentang Islam

<b>⌲ Contoh:</b>
<code>.islam apa itu puasa?</code>
<code>.islam bagaimana cara sholat?</code></blockquote>
"""

# ============================================
# KONFIGURASI
# ============================================
BASE_URL = "https://api-faa.my.id/faa/islam-ai"

async def ask_islam(query: str):
    """Tanya Islam AI"""
    try:
        encoded_query = quote(query)
        url = f"{BASE_URL}?text={encoded_query}"
        
        async with aiohttp.ClientSession() as session:
            async with session.get(url, timeout=30) as response:
                if response.status == 200:
                    data = await response.json()
                    
                    if data.get("status") and data.get("result"):
                        return {
                            "success": True,
                            "result": data["result"]
                        }
                    else:
                        return {
                            "success": False,
                            "error": "Response tidak valid"
                        }
                else:
                    return {
                        "success": False,
                        "error": f"HTTP {response.status}"
                    }
    except asyncio.TimeoutError:
        return {"success": False, "error": "Timeout"}
    except Exception as e:
        return {"success": False, "error": str(e)}

@PY.UBOT("islam")
async def islam_ai(client: Client, message: Message):
    ggl = await EMO.GAGAL(client)
    sks = await EMO.BERHASIL(client)
    prs = await EMO.PROSES(client)
    
    try:
        await client.send_chat_action(message.chat.id, ChatAction.TYPING)
        
        # Ambil pertanyaan
        args = message.text.split(maxsplit=1)
        if len(args) < 2:
            await message.reply_text(
                f"<blockquote><b>❌ Masukkan pertanyaan tentang Islam!</b>\n\n"
                f"<b>Contoh:</b>\n"
                f"<code>.islam apa itu puasa?</code>\n"
                f"<code>.islam bagaimana cara sholat?</code>\n"
                f"<code>.islam rukun iman ada berapa?</code></blockquote>"
            )
            return
        
        query = args[1].strip()
        
        # Kirim pesan processing
        processing = await message.reply_text(f"{prs} <b>Islam AI sedang mencari jawaban...</b>")
        
        # Tanya AI
        result = await ask_islam(query)
        
        await processing.delete()
        
        if result.get("success"):
            answer = result["result"]
            
            # Format jawaban
            reply_text = f"""
<blockquote><b>🕌 ISLAM AI</b>

{answer}

⚡ <b>Powered by:</b> Ubot Premium Zyura</blockquote>"""
            
            await message.reply_text(reply_text)
        else:
            error_msg = result.get("error", "Unknown error")
            await message.reply_text(
                f"<blockquote><b>❌ GAGAL</b>\n\n{error_msg}</blockquote>"
            )
        
    except Exception as e:
        await message.reply_text(f"{ggl} <b>Error: {str(e)[:100]}</b>")

