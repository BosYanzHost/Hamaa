from fansx import *
import aiohttp
import asyncio
from urllib.parse import quote
from pyrogram.enums import ChatAction
from pyrogram.types import Message

__MODULE__ = "ᴊs ᴏʙꜰᴜꜱᴄᴀᴛᴏʀ"
__HELP__ = """
<blockquote><b>『 JAVASCRIPT OBFUSCATOR 』</b>

<b>⌲ Perintah:</b>
ᚗ <code>{0}encjs [kode js]</code> 
⊶ Mengobfuscate kode JavaScript

<b>⌲ Contoh:</b>
<code>.encjs console.log('amel Cantik')</code>
<code>.encjs alert('Hello World')</code>

<b>⌲ Bisa juga reply ke pesan yang berisi kode:</b>
Reply ke pesan kode lalu ketik <code>.encjs</code></blockquote>
"""

# Base URL API
BASE_URL = "https://api.deline.web.id/tools/enc"

async def obfuscate_js(text: str):
    """Mengobfuscate kode JavaScript"""
    try:
        async with aiohttp.ClientSession() as session:
            params = {"text": text}
            async with session.get(BASE_URL, params=params, timeout=30) as response:
                if response.status == 200:
                    data = await response.json()
                    return data
                return None
    except Exception as e:
        print(f"Error obfuscate JS: {e}")
        return None

@PY.UBOT("encjs")
async def obfuscate_js_command(client: Client, message: Message):
    ggl = await EMO.GAGAL(client)
    sks = await EMO.BERHASIL(client)
    prs = await EMO.PROSES(client)
    
    try:
        await client.send_chat_action(message.chat.id, ChatAction.TYPING)
        
        # Ambil kode dari reply atau argumen
        code = None
        
        # Cek apakah reply ke pesan
        if message.reply_to_message and message.reply_to_message.text:
            code = message.reply_to_message.text
        
        # Cek dari argumen
        if not code:
            args = message.text.split(maxsplit=1)
            if len(args) > 1:
                code = args[1].strip()
        
        if not code:
            await message.reply_text(
                f"<blockquote><b>❌ Masukkan kode JavaScript!</b>\n\n"
                f"<b>Contoh:</b>\n"
                f"<code>.encjs console.log('amel Cantik')</code>\n"
                f"Atau reply ke pesan yang berisi kode JS.</blockquote>"
            )
            return
        
        # Batasi panjang kode
        if len(code) > 1000:
            await message.reply_text(f"{ggl} <b>Kode terlalu panjang! Maksimal 1000 karakter.</b>")
            return
        
        # Kirim pesan processing
        processing = await message.reply_text(f"{prs} <b>Mengobfuscate kode JavaScript...</b>")
        
        # Panggil API
        data = await obfuscate_js(code)
        
        if data and data.get("status"):
            result = data.get("result", "")
            
            if result:
                await processing.delete()
                
                # Format hasil
                text = f"<blockquote><b>🔐 JS OBFUSCATOR</b>\n\n"
                text += f"<b>Input:</b>\n<code>{code[:200]}{'...' if len(code) > 200 else ''}</code>\n\n"
                text += f"<b>Output:</b>\n<code>{result[:1000]}{'...' if len(result) > 1000 else ''}</code>\n"
                
                if len(result) > 1000:
                    text += f"\n📝 <i>Hasil dipotong, total {len(result)} karakter</i>"
                
                text += "</blockquote>"
                
                # Kirim hasil
                await message.reply_text(text)
                
                # Kalo hasilnya pendek, kirim juga sebagai file teks
                if len(result) > 1500:
                    file_path = f"obfuscated_{message.from_user.id}.js"
                    with open(file_path, 'w') as f:
                        f.write(result)
                    
                    await client.send_document(
                        chat_id=message.chat.id,
                        document=file_path,
                        caption=f"📁 Hasil obfuscate (full) untuk kode:\n<code>{code[:50]}...</code>"
                    )
                    
                    import os
                    if os.path.exists(file_path):
                        os.remove(file_path)
            else:
                await processing.edit_text(f"{ggl} <b>Hasil obfuscate kosong!</b>")
        else:
            await processing.edit_text(
                f"{ggl} <b>Gagal mengobfuscate kode!</b>\n"
                f"Pastikan kode JavaScript valid."
            )
        
    except asyncio.TimeoutError:
        await message.reply_text(f"{ggl} <b>Timeout! Server sedang sibuk.</b>")
    except aiohttp.ClientError as e:
        await message.reply_text(f"{ggl} <b>Gagal terhubung ke server: {str(e)[:100]}</b>")
    except Exception as e:
        await message.reply_text(f"{ggl} <b>Error: {str(e)[:100]}</b>")

@PY.UBOT("obfuscate")
async def obfuscate_alias(client: Client, message: Message):
    """Alias untuk encjs"""
    await obfuscate_js_command(client, message)

@PY.BOT("encjs")
async def obfuscate_js_bot(client: Client, message: Message):
    """Handler untuk bot"""
    try:
        code = None
        
        if message.reply_to_message and message.reply_to_message.text:
            code = message.reply_to_message.text
        
        if not code:
            args = message.text.split(maxsplit=1)
            if len(args) > 1:
                code = args[1].strip()
        
        if not code:
            await message.reply_text(
                "❌ Masukkan kode JavaScript!\n"
                "Contoh: /encjs console.log('test')"
            )
            return
        
        if len(code) > 1000:
            await message.reply_text("❌ Kode terlalu panjang! Maksimal 1000 karakter.")
            return
        
        processing = await message.reply_text("🔍 Mengobfuscate kode...")
        
        data = await obfuscate_js(code)
        
        if data and data.get("status"):
            result = data.get("result", "")
            
            if result:
                await processing.delete()
                
                if len(result) <= 4000:
                    await message.reply_text(f"```javascript\n{result}\n```")
                else:
                    # Kirim sebagai file
                    file_path = f"obfuscated_bot_{message.from_user.id}.js"
                    with open(file_path, 'w') as f:
                        f.write(result)
                    
                    await client.send_document(
                        chat_id=message.chat.id,
                        document=file_path,
                        caption=f"📁 Hasil obfuscate"
                    )
                    
                    import os
                    if os.path.exists(file_path):
                        os.remove(file_path)
            else:
                await processing.edit_text("❌ Hasil obfuscate kosong!")
        else:
            await processing.edit_text("❌ Gagal mengobfuscate kode!")
        
    except Exception as e:
        await message.reply_text(f"❌ Error: {str(e)[:100]}")