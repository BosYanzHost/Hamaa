from fansx import *
import aiohttp
import asyncio
import os
import random
from pyrogram.enums import ChatAction, ParseMode
from pyrogram.types import Message

__MODULE__ = "ᴛᴇxᴛ ᴛᴏ sᴘᴇᴇᴄʜ ᴠ𝟸"
__HELP__ = """
<blockquote><b>🔊 TEXT TO SPEECH V2</b>

<b>⌲ Perintah:</b>
ᚗ <code>{0}tts2 [teks]</code> - Ubah teks jadi suara (V2)
ᚗ <code>{0}speak2 [teks]</code> - Alternatif

<b>⌲ Contoh:</b>
<code>.tts2 Hello good morning</code>
<code>.speak2 Selamat pagi semuanya</code></blockquote>
"""

# ============================================
# KONFIGURASI
# ============================================
TTS2_API = "https://anabot.my.id/api/ai/text2speech_2"
API_KEY = "freeApikey"  # Bisa diganti nanti

# Batasan karakter
MAX_CHARS = 1000  # Batasi biar gak kegedean

async def text_to_speech_v2(text):
    """Ubah teks jadi file audio (V2)"""
    
    # Encode parameter
    url = f"{TTS2_API}?text={text}&apikey={API_KEY}"
    
    try:
        async with aiohttp.ClientSession() as session:
            async with session.get(url, timeout=30) as response:
                if response.status == 200:
                    # Cek content-type
                    content_type = response.headers.get("Content-Type", "")
                    
                    if "audio" in content_type or "mp3" in content_type or "mpeg" in content_type:
                        # Langsung audio
                        return {
                            "success": True,
                            "audio": await response.read(),
                            "direct": True
                        }
                    else:
                        # Mungkin JSON dengan URL audio
                        try:
                            data = await response.json()
                            
                            # Cek berbagai format respons
                            if data.get("status") == "success" and data.get("result"):
                                audio_url = data["result"]
                            elif data.get("audio_url"):
                                audio_url = data["audio_url"]
                            elif data.get("url"):
                                audio_url = data["url"]
                            else:
                                return {"success": False, "error": "Format respons tidak dikenali", "data": data}
                            
                            # Download audio dari URL
                            async with session.get(audio_url, timeout=30) as audio_resp:
                                if audio_resp.status == 200:
                                    return {
                                        "success": True,
                                        "audio": await audio_resp.read()
                                    }
                                else:
                                    return {"success": False, "error": f"Gagal download audio: HTTP {audio_resp.status}"}
                        except:
                            return {"success": False, "error": "API tidak mengembalikan audio"}
                elif response.status == 401:
                    return {"success": False, "error": "API Key tidak valid atau habis quota"}
                elif response.status == 429:
                    return {"success": False, "error": "Terlalu banyak request, coba lagi nanti"}
                elif response.status == 413:
                    return {"success": False, "error": "Teks terlalu panjang"}
                else:
                    return {"success": False, "error": f"HTTP {response.status}"}
    except asyncio.TimeoutError:
        return {"success": False, "error": "Timeout - server terlalu lambat"}
    except Exception as e:
        return {"success": False, "error": str(e)}

@PY.UBOT("tts2")
@PY.UBOT("speak2")
async def tts2_command(client: Client, message: Message):
    ggl = await EMO.GAGAL(client)
    sks = await EMO.BERHASIL(client)
    prs = await EMO.PROSES(client)
    
    # Parse argumen
    args = message.text.split()[1:]
    
    if not args:
        # Tampilkan help
        help_text = f"""
<blockquote><b>Cara pakai:</b>
ᚗ <code>.tts2 [teks]</code>
ᚗ <code>.speak2 [teks]</code>

<b>Contoh:</b>
<code>.tts2 Hello good morning</code>
<code>.speak2 Selamat pagi semuanya</code>
<code>.tts2 Selamat datang di grup ini</code>

<b>📌 Fitur:</b>
• Versi 2 dengan kualitas suara lebih baik
• Support berbagai bahasa
• Maksimal {MAX_CHARS} karakter

<b>💡 Tips:</b>
Bisa buat ucapan selamat datang, pengumuman, atau pesan lucu dalam bentuk suara!</blockquote>"""
        
        await message.reply_text(help_text)
        return
    
    # Gabungkan argumen jadi teks
    text = " ".join(args)
    
    # Cek panjang teks
    if len(text) > MAX_CHARS:
        await message.reply_text(
            f"{ggl} <b>Teks terlalu panjang! Maksimal {MAX_CHARS} karakter.</b>\n"
            f"Teks kamu: {len(text)} karakter"
        )
        return
    
    try:
        await client.send_chat_action(message.chat.id, ChatAction.RECORD_AUDIO)
        
        processing = await message.reply_text(
            f"{prs} <b>Mengubah teks jadi suara (V2)...</b>\n"
            f"<code>{text[:50]}{'...' if len(text) > 50 else ''}</code>"
        )
        
        # Generate audio
        result = await text_to_speech_v2(text)
        
        await processing.delete()
        
        if result.get("success") and result.get("audio"):
            # Simpan audio sementara
            file_path = f"tts2_{message.from_user.id}_{random.randint(1000,9999)}.mp3"
            with open(file_path, "wb") as f:
                f.write(result["audio"])
            
            # Buat caption
            caption = f"<blockquote><b>🔊 TEXT TO SPEECH V2</b>\n\n"
            caption += f"<b>💬 Teks:</b> {text[:200]}{'...' if len(text) > 200 else ''}\n"
            caption += f"<b>📊 Panjang:</b> {len(text)} karakter\n"
            caption += f"\n⚡ Powered by: Ubot Premium Zyura</blockquote>"
            
            # Kirim audio
            await client.send_audio(
                chat_id=message.chat.id,
                audio=file_path,
                caption=caption,
                title="Text to Speech V2",
                performer="AI Voice Generator",
                duration=len(text) // 10  # Estimasi durasi
            )
            
            # Hapus file
            if os.path.exists(file_path):
                os.remove(file_path)
            
        else:
            error_msg = result.get("error", "Unknown error")
            
            # Pesan error yang lebih friendly
            if "401" in error_msg or "API Key" in error_msg:
                user_friendly = "API Key error atau quota habis. Hubungi admin bot."
            elif "429" in error_msg:
                user_friendly = "Server lagi sibuk, coba lagi nanti."
            elif "413" in error_msg:
                user_friendly = f"Teks terlalu panjang. Maksimal {MAX_CHARS} karakter."
            else:
                user_friendly = error_msg
            
            await message.reply_text(
                f"<blockquote><b>❌ GAGAL MEMBUAT AUDIO</b>\n\n"
                f"<b>Error:</b> {user_friendly}</blockquote>"
            )
        
    except Exception as e:
        await message.reply_text(f"{ggl} <b>Error: {str(e)[:100]}</b>")

