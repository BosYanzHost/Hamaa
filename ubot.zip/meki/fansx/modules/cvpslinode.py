from fansx import *
import requests
import aiohttp
import asyncio
import random
import string
import json
import os
from datetime import datetime
from pyrogram.enums import ChatAction, ParseMode
from pyrogram.types import Message

__MODULE__ = "ʟɪɴᴏᴅᴇ ᴠᴘs"
__HELP__ = """
<blockquote><b>『 CREATE VPS LINODE 』</b>

<b>⌲ Setting Token:</b>
ᚗ <code>{0}setlinodetoken [token]</code> - Set token Linode API

<b>⌲ Perintah Membuat VPS:</b>
ᚗ <code>{0}linode2gb [nama]</code> - Buat VPS 2GB
ᚗ <code>{0}linode4gb [nama]</code> - Buat VPS 4GB
ᚗ <code>{0}linode8gb [nama]</code> - Buat VPS 8GB
ᚗ <code>{0}linode16gb [nama]</code> - Buat VPS 16GB

<b>⌲ Manajemen VPS:</b>
ᚗ <code>{0}listlinode</code> - Lihat semua VPS
ᚗ <code>{0}cekvps [id]</code> - Detail VPS
ᚗ <code>{0}onlinode [id]</code> - Hidupkan VPS
ᚗ <code>{0}offlinode [id]</code> - Matikan VPS
ᚗ <code>{0}rebootlinode [id]</code> - Restart VPS
ᚗ <code>{0}rebuildlinode [id] [image]</code> - Rebuild VPS
ᚗ <code>{0}delinode [id]</code> - Hapus VPS

<b>⌲ Informasi Akun:</b>
ᚗ <code>{0}saldolinode</code> - Cek saldo
ᚗ <code>{0}sisalinode</code> - Total VPS aktif
ᚗ <code>{0}cektoken</code> - Cek status token

<b>⌲ Contoh:</b>
<code>.setlinodetoken abc123...</code>
<code>.linode2gb vpsku</code>
<code>.listlinode</code></blockquote>
"""

# ============================================
# FILE UNTUK MENYIMPAN TOKEN
# ============================================
CONFIG_FILE = "linode_config.json"

# Default config
DEFAULT_CONFIG = {
    "token": None,
    "default_region": "ap-south",
    "default_image": "linode/ubuntu20.04"
}

# Region options
REGIONS = {
    "sg": "ap-south",  # Singapore/Mumbai
    "jp": "ap-northeast",  # Japan
    "us": "us-central",  # US Central
    "uk": "eu-west",  # London
}

# Image options
IMAGES = {
    "ubuntu20": "linode/ubuntu20.04",
    "ubuntu22": "linode/ubuntu22.04",
    "debian11": "linode/debian11",
    "centos7": "linode/centos7",
    "almalinux8": "linode/almalinux8",
}

# Mapping tipe Linode
LINODE_TYPES = {
    "2gb": "g6-standard-1",   # 2GB RAM, 1 CPU, 50GB Disk
    "4gb": "g6-standard-2",   # 4GB RAM, 2 CPU, 80GB Disk
    "8gb": "g6-standard-4",   # 8GB RAM, 4 CPU, 160GB Disk
    "16gb": "g6-standard-8",  # 16GB RAM, 8 CPU, 320GB Disk
}

def load_config():
    """Load konfigurasi dari file"""
    try:
        if os.path.exists(CONFIG_FILE):
            with open(CONFIG_FILE, 'r') as f:
                return json.load(f)
    except Exception as e:
        print(f"Error loading config: {e}")
    return DEFAULT_CONFIG.copy()

def save_config(config):
    """Simpan konfigurasi ke file"""
    try:
        with open(CONFIG_FILE, 'w') as f:
            json.dump(config, f, indent=4)
        return True
    except Exception as e:
        print(f"Error saving config: {e}")
        return False

# Load config saat startup
linode_config = load_config()

def random_password(length=12):
    """Generate random password yang kuat"""
    chars = string.ascii_letters + string.digits + "!@#$%^&*"
    return ''.join(random.choice(chars) for _ in range(length))

# ============================================
# FUNGSI API LINODE
# ============================================

async def linode_request(method, endpoint, data=None):
    """Helper untuk request ke API Linode"""
    
    token = linode_config.get("token")
    if not token:
        return {"error": "Token belum diset! Gunakan .setlinodetoken [token]"}, 401
    
    url = f"https://api.linode.com/v4/{endpoint}"
    headers = {
        "Content-Type": "application/json",
        "Authorization": f"Bearer {token}"
    }
    
    try:
        async with aiohttp.ClientSession() as session:
            if method == "GET":
                async with session.get(url, headers=headers, timeout=30) as resp:
                    return await resp.json(), resp.status
            elif method == "POST":
                async with session.post(url, headers=headers, json=data, timeout=60) as resp:
                    return await resp.json(), resp.status
            elif method == "DELETE":
                async with session.delete(url, headers=headers, timeout=30) as resp:
                    if resp.status == 200:
                        return {}, resp.status
                    return await resp.json(), resp.status
            elif method == "PUT":
                async with session.put(url, headers=headers, json=data, timeout=30) as resp:
                    return await resp.json(), resp.status
    except asyncio.TimeoutError:
        return {"error": "Timeout"}, 408
    except Exception as e:
        return {"error": str(e)}, 500

# ============================================
# COMMAND SETTING TOKEN
# ============================================

@PY.UBOT("setlinodetoken")
async def set_linode_token(client: Client, message: Message):
    """Command untuk set token Linode API"""
    ggl = await EMO.GAGAL(client)
    sks = await EMO.BERHASIL(client)
    
    try:
        args = message.text.split(maxsplit=1)
        if len(args) < 2:
            await message.reply_text(
                f"<blockquote><b>❌ Format salah!</b>\n\n"
                f"<b>Contoh:</b>\n"
                f"<code>.setlinodetoken YOUR_TOKEN_HERE</code></blockquote>"
            )
            return
        
        token = args[1].strip()
        
        # Test token dengan request sederhana
        await message.reply_text(f"⏳ <b>Testing token...</b>")
        
        # Coba get account info
        test_data, status = await linode_request("GET", "account")
        
        if status == 200:
            # Token valid
            linode_config["token"] = token
            save_config(linode_config)
            
            account = test_data.get("company", "Akun Linode")
            email = test_data.get("email", "-")
            
            await message.reply_text(
                f"<blockquote><b>✅ TOKEN BERHASIL DISET</b>\n\n"
                f"🔑 <b>Token:</b> <code>{token[:15]}...{token[-5:]}</code>\n"
                f"🏢 <b>Akun:</b> {account}\n"
                f"📧 <b>Email:</b> {email}\n\n"
                f"📌 Token tersimpan di {CONFIG_FILE}</blockquote>"
            )
        else:
            error_msg = test_data.get("errors", [{}])[0].get("reason", "Unknown error")
            await message.reply_text(
                f"{ggl} <b>Token tidak valid!</b>\n"
                f"Error: {error_msg}"
            )
            
    except Exception as e:
        await message.reply_text(f"{ggl} <b>Error: {str(e)[:100]}</b>")

@PY.UBOT("cektoken")
async def cek_token(client: Client, message: Message):
    """Cek status token Linode"""
    ggl = await EMO.GAGAL(client)
    sks = await EMO.BERHASIL(client)
    
    token = linode_config.get("token")
    
    if not token:
        await message.reply_text(
            f"{ggl} <b>Token belum diset!</b>\n"
            f"Gunakan <code>.setlinodetoken [token]</code>"
        )
        return
    
    await message.reply_text(f"⏳ <b>Memeriksa token...</b>")
    
    data, status = await linode_request("GET", "account")
    
    if status == 200:
        account = data.get("company", "Akun Linode")
        email = data.get("email", "-")
        balance = data.get("balance", 0) / 100
        
        await message.reply_text(
            f"<blockquote><b>✅ TOKEN VALID</b>\n\n"
            f"🏢 <b>Akun:</b> {account}\n"
            f"📧 <b>Email:</b> {email}\n"
            f"💰 <b>Balance:</b> ${balance:.2f}\n"
            f"🔑 <b>Token:</b> <code>{token[:10]}...{token[-5:]}</code></blockquote>"
        )
    else:
        error_msg = data.get("errors", [{}])[0].get("reason", "Unknown error")
        await message.reply_text(
            f"{ggl} <b>Token tidak valid!</b>\n"
            f"Error: {error_msg}"
        )

# ============================================
# FUNGSI MEMBUAT VPS
# ============================================

async def create_linode(label, type_key, region=None, image=None):
    """Membuat VPS Linode baru"""
    
    # Generate password random
    password = random_password()
    
    # Data untuk request
    data = {
        "label": label,
        "region": region or linode_config.get("default_region", "ap-south"),
        "type": LINODE_TYPES[type_key],
        "image": image or linode_config.get("default_image", "linode/ubuntu20.04"),
        "root_pass": password,
        "stackscript_id": None,
        "authorized_keys": None,
        "backups_enabled": False
    }
    
    # Kirim request
    response, status = await linode_request("POST", "linode/instances", data)
    
    if status not in [200, 201]:
        return None, response, password
    
    return response, None, password

# ============================================
# COMMAND MEMBUAT VPS
# ============================================

@PY.UBOT("linode2gb")
async def linode_2gb(client: Client, message: Message):
    await create_linode_handler(client, message, "2gb")

@PY.UBOT("linode4gb")
async def linode_4gb(client: Client, message: Message):
    await create_linode_handler(client, message, "4gb")

@PY.UBOT("linode8gb")
async def linode_8gb(client: Client, message: Message):
    await create_linode_handler(client, message, "8gb")

@PY.UBOT("linode16gb")
async def linode_16gb(client: Client, message: Message):
    await create_linode_handler(client, message, "16gb")

async def create_linode_handler(client: Client, message: Message, type_key: str):
    ggl = await EMO.GAGAL(client)
    sks = await EMO.BERHASIL(client)
    prs = await EMO.PROSES(client)
    
    try:
        # Cek token dulu
        if not linode_config.get("token"):
            await message.reply_text(
                f"{ggl} <b>Token belum diset!</b>\n"
                f"Gunakan <code>.setlinodetoken [token]</code> dulu."
            )
            return
        
        # Ambil label VPS
        args = message.text.split(maxsplit=1)
        if len(args) < 2:
            await message.reply_text(
                f"<blockquote><b>❌ Format salah!</b>\n\n"
                f"<b>Contoh:</b>\n"
                f"<code>.linode{type_key} vpsku</code></blockquote>"
            )
            return
        
        label = args[1].strip()
        
        # Validasi label
        if len(label) < 3 or len(label) > 50:
            await message.reply_text(f"{ggl} <b>Label harus 3-50 karakter!</b>")
            return
        
        # Kirim pesan processing
        processing = await message.reply_text(
            f"{prs} <b>Membuat VPS {type_key.upper()} dengan label '{label}'...</b>"
        )
        
        # Buat VPS
        result, error, password = await create_linode(label, type_key)
        
        if error:
            error_msg = error.get("errors", [{}])[0].get("reason", "Unknown error")
            await processing.edit_text(f"{ggl} <b>Gagal membuat VPS!</b>\nError: {error_msg}")
            return
        
        # Dapatkan ID dan IP
        linode_id = result.get("id")
        ip_address = result.get("ipv4", [""])[0]
        
        await processing.edit_text(
            f"{prs} <b>VPS dibuat! Menunggu IP aktif (60 detik)...</b>"
        )
        
        # Tunggu 60 detik untuk IP aktif
        await asyncio.sleep(60)
        
        # Ambil info terbaru
        info, status = await linode_request("GET", f"linode/instances/{linode_id}")
        
        if status == 200:
            ip_address = info.get("ipv4", [""])[0]
            status_vps = info.get("status", "unknown")
        
        # Kirim hasil
        await processing.delete()
        
        result_text = f"""
<blockquote><b>✅ VPS LINODE {type_key.upper()} BERHASIL DIBUAT</b>

📛 <b>Label:</b> {label}
🆔 <b>ID:</b> <code>{linode_id}</code>
🌐 <b>IP Address:</b> <code>{ip_address}</code>
🔑 <b>Password:</b> <code>{password}</code>
📊 <b>Tipe:</b> {type_key.upper()} RAM
🔰 <b>Status:</b> {status_vps}

📌 Simpan data ini baik-baik!</blockquote>"""
        
        await message.reply_text(result_text)
        
    except Exception as e:
        await message.reply_text(f"{ggl} <b>Error: {str(e)[:100]}</b>")

# ============================================
# COMMAND MANAJEMEN VPS
# ============================================

@PY.UBOT("listlinode")
async def list_linode(client: Client, message: Message):
    """Lihat daftar semua VPS"""
    ggl = await EMO.GAGAL(client)
    prs = await EMO.PROSES(client)
    
    if not linode_config.get("token"):
        await message.reply_text(f"{ggl} <b>Token belum diset!</b>")
        return
    
    processing = await message.reply_text(f"{prs} <b>Mengambil daftar VPS...</b>")
    
    data, status = await linode_request("GET", "linode/instances")
    
    if status == 200:
        instances = data.get("data", [])
        
        if not instances:
            await processing.edit_text("<b>📭 Belum ada VPS yang dibuat.</b>")
            return
        
        text = "<blockquote><b>📋 DAFTAR VPS LINODE</b>\n\n"
        
        for vps in instances:
            text += f"📛 <b>Label:</b> {vps.get('label', '-')}\n"
            text += f"🆔 <b>ID:</b> <code>{vps.get('id')}</code>\n"
            text += f"🌐 <b>IP:</b> {vps.get('ipv4', ['-'])[0]}\n"
            text += f"🔰 <b>Status:</b> {vps.get('status', '-')}\n"
            text += f"━━━━━━━━━━━━━━━━━━\n"
        
        text += f"<b>📊 Total:</b> {len(instances)} VPS</blockquote>"
        
        await processing.edit_text(text)
    else:
        error_msg = data.get("errors", [{}])[0].get("reason", "Unknown error")
        await processing.edit_text(f"{ggl} <b>Gagal!</b>\n{error_msg}")

@PY.UBOT("cekvps")
async def cek_vps(client: Client, message: Message):
    """Lihat detail VPS"""
    ggl = await EMO.GAGAL(client)
    prs = await EMO.PROSES(client)
    
    if not linode_config.get("token"):
        await message.reply_text(f"{ggl} <b>Token belum diset!</b>")
        return
    
    args = message.text.split(maxsplit=1)
    if len(args) < 2:
        await message.reply_text(f"{ggl} <b>Masukkan ID VPS!</b>\nContoh: .cekvps 123456")
        return
    
    vps_id = args[1].strip()
    
    processing = await message.reply_text(f"{prs} <b>Mengambil detail VPS {vps_id}...</b>")
    
    data, status = await linode_request("GET", f"linode/instances/{vps_id}")
    
    if status == 200:
        specs = data.get("specs", {})
        alerts = data.get("alerts", {})
        
        text = f"""
<blockquote><b>📊 DETAIL VPS LINODE</b>

📛 <b>Label:</b> {data.get('label', '-')}
🆔 <b>ID:</b> <code>{data.get('id')}</code>
🔰 <b>Status:</b> {data.get('status', '-')}
🌐 <b>IP:</b> {data.get('ipv4', ['-'])[0]}
📍 <b>Region:</b> {data.get('region', '-')}
📦 <b>Tipe:</b> {data.get('type', '-')}

<b>⚙️ Spesifikasi:</b>
• RAM: {specs.get('memory', 0)} MB
• CPU: {specs.get('vcpus', 0)} Core
• Disk: {specs.get('disk', 0)} MB

<b>⏰ Created:</b> {data.get('created', '-')[:10]}</blockquote>"""
        
        await processing.edit_text(text)
    else:
        error_msg = data.get("errors", [{}])[0].get("reason", "Unknown error")
        await processing.edit_text(f"{ggl} <b>Gagal!</b>\n{error_msg}")

@PY.UBOT("onlinode")
async def on_linode(client: Client, message: Message):
    """Hidupkan VPS"""
    await power_linode(client, message, "boot", "menghidupkan")

@PY.UBOT("offlinode")
async def off_linode(client: Client, message: Message):
    """Matikan VPS"""
    await power_linode(client, message, "shutdown", "mematikan")

@PY.UBOT("rebootlinode")
async def reboot_linode(client: Client, message: Message):
    """Restart VPS"""
    await power_linode(client, message, "reboot", "merestart")

async def power_linode(client: Client, message: Message, action: str, action_name: str):
    ggl = await EMO.GAGAL(client)
    prs = await EMO.PROSES(client)
    
    if not linode_config.get("token"):
        await message.reply_text(f"{ggl} <b>Token belum diset!</b>")
        return
    
    args = message.text.split(maxsplit=1)
    if len(args) < 2:
        await message.reply_text(f"{ggl} <b>Masukkan ID VPS!</b>\nContoh: .{action}linode 123456")
        return
    
    vps_id = args[1].strip()
    
    processing = await message.reply_text(f"{prs} <b>{action_name.title()} VPS {vps_id}...</b>")
    
    data, status = await linode_request("POST", f"linode/instances/{vps_id}/{action}")
    
    if status in [200, 201, 202]:
        await processing.edit_text(f"<b>✅ VPS {vps_id} berhasil {action_name}!</b>")
    else:
        error_msg = data.get("errors", [{}])[0].get("reason", "Unknown error")
        await processing.edit_text(f"{ggl} <b>Gagal {action_name} VPS!</b>\n{error_msg}")

@PY.UBOT("delinode")
async def delete_linode(client: Client, message: Message):
    """Hapus VPS"""
    ggl = await EMO.GAGAL(client)
    prs = await EMO.PROSES(client)
    
    if not linode_config.get("token"):
        await message.reply_text(f"{ggl} <b>Token belum diset!</b>")
        return
    
    args = message.text.split(maxsplit=1)
    if len(args) < 2:
        await message.reply_text(f"{ggl} <b>Masukkan ID VPS!</b>\nContoh: .delinode 123456")
        return
    
    vps_id = args[1].strip()
    
    processing = await message.reply_text(f"{prs} <b>Menghapus VPS {vps_id}...</b>")
    
    data, status = await linode_request("DELETE", f"linode/instances/{vps_id}")
    
    if status == 200:
        await processing.edit_text(f"<b>✅ VPS {vps_id} berhasil dihapus!</b>")
    else:
        error_msg = data.get("errors", [{}])[0].get("reason", "Unknown error")
        await processing.edit_text(f"{ggl} <b>Gagal menghapus VPS!</b>\n{error_msg}")

@PY.UBOT("saldolinode")
async def saldo_linode(client: Client, message: Message):
    """Cek saldo akun Linode"""
    ggl = await EMO.GAGAL(client)
    prs = await EMO.PROSES(client)
    
    if not linode_config.get("token"):
        await message.reply_text(f"{ggl} <b>Token belum diset!</b>")
        return
    
    processing = await message.reply_text(f"{prs} <b>Mengambil info akun...</b>")
    
    data, status = await linode_request("GET", "account")
    
    if status == 200:
        balance = data.get("balance", 0) / 100
        credit = data.get("credit_remaining", 0) / 100
        company = data.get("company", "Personal")
        email = data.get("email", "-")
        
        text = f"""
<blockquote><b>💰 SALDO AKUN LINODE</b>

🏢 <b>Akun:</b> {company}
📧 <b>Email:</b> {email}
💵 <b>Balance:</b> ${balance:.2f}
💳 <b>Credit:</b> ${credit:.2f}</blockquote>"""
        
        await processing.edit_text(text)
    else:
        error_msg = data.get("errors", [{}])[0].get("reason", "Unknown error")
        await processing.edit_text(f"{ggl} <b>Gagal!</b>\n{error_msg}")

@PY.UBOT("sisalinode")
async def sisa_linode(client: Client, message: Message):
    """Cek jumlah VPS aktif"""
    ggl = await EMO.GAGAL(client)
    prs = await EMO.PROSES(client)
    
    if not linode_config.get("token"):
        await message.reply_text(f"{ggl} <b>Token belum diset!</b>")
        return
    
    processing = await message.reply_text(f"{prs} <b>Menghitung VPS...</b>")
    
    data, status = await linode_request("GET", "linode/instances")
    
    if status == 200:
        instances = data.get("data", [])
        total = len(instances)
        
        await processing.edit_text(f"<b>📊 Total VPS aktif: {total}</b>")
    else:
        error_msg = data.get("errors", [{}])[0].get("reason", "Unknown error")
        await processing.edit_text(f"{ggl} <b>Gagal!</b>\n{error_msg}")

@PY.UBOT("rebuildlinode")
async def rebuild_linode(client: Client, message: Message):
    """Rebuild VPS dengan image baru"""
    ggl = await EMO.GAGAL(client)
    prs = await EMO.PROSES(client)
    
    if not linode_config.get("token"):
        await message.reply_text(f"{ggl} <b>Token belum diset!</b>")
        return
    
    args = message.text.split()
    if len(args) < 3:
        await message.reply_text(
            f"<blockquote><b>❌ Format: .rebuildlinode [id] [image]</b>\n\n"
            f"<b>Image options:</b>\n"
            f"• ubuntu20 - Ubuntu 20.04\n"
            f"• ubuntu22 - Ubuntu 22.04\n"
            f"• debian11 - Debian 11\n"
            f"• centos7 - CentOS 7\n"
            f"• almalinux8 - AlmaLinux 8</blockquote>"
        )
        return
    
    vps_id = args[1]
    image_key = args[2].lower()
    
    # Mapping image
    image_map = {
        "ubuntu20": "linode/ubuntu20.04",
        "ubuntu22": "linode/ubuntu22.04",
        "debian11": "linode/debian11",
        "centos7": "linode/centos7",
        "almalinux8": "linode/almalinux8",
    }
    
    image = image_map.get(image_key)
    if not image:
        await message.reply_text(f"{ggl} <b>Image tidak valid!</b>")
        return
    
    # Generate password baru
    password = random_password()
    
    processing = await message.reply_text(f"{prs} <b>Rebuild VPS {vps_id} dengan {image_key}...</b>")
    
    data = {
        "image": image,
        "root_pass": password
    }
    
    response, status = await linode_request("POST", f"linode/instances/{vps_id}/rebuild", data)
    
    if status in [200, 201, 202]:
        await processing.edit_text(
            f"<b>✅ VPS {vps_id} berhasil direbuild!</b>\n"
            f"🖼️ <b>Image:</b> {image_key}\n"
            f"🔑 <b>Password baru:</b> <code>{password}</code>"
        )
    else:
        error_msg = response.get("errors", [{}])[0].get("reason", "Unknown error")
        await processing.edit_text(f"{ggl} <b>Gagal rebuild!</b>\n{error_msg}")