from fansx import *
import aiohttp
import asyncio
import random
import re
from datetime import datetime
from pyrogram.enums import ChatAction, ParseMode
from pyrogram.types import Message

__MODULE__ = "ᴄᴇᴋ ᴇ-ᴡᴀʟʟᴇᴛ"
__HELP__ = """
<blockquote><b>💰 CEK E-WALLET OTOMATIS</b>

<b>⌲ Perintah:</b>
ᚗ <code>{0}cekwallet [nomor]</code> - Cek semua e-wallet

<b>⌲ Contoh:</b>
<code>.cekwallet 0838383838383838</code>
<code>.cekwallet 081234567890</code>

<b>⌲ E-wallet yang dicek:</b>
• DANA (💙)
• OVO (💜)
• GoPay (💚)
• ShopeePay (🛒)

<b>⌲ Catatan:</b>
• Gunakan nomor Indonesia
• Hasil bisa berbeda tergantung provider</blockquote>
"""

# ============================================
# DAFTAR API KEYS (12 KEY)
# ============================================
API_KEYS = [
    "eIxUwMpn",
    "keoCFdc6",
    "bv7m372F",
    "iAiB9QKT",
    "JP7Cy8Y2",
    "GI4vPxYv",
    "HRPga9TN",
    "PDwqhVsj",
    "m8jpBeZR",
    "PXkxh5hw",
    "MFnlpM6A",
    "u299UiOF"
]

# Base URL API
API_URL = "https://api.botcahx.eu.org/api/tools/cek-ewallet"

# Daftar e-wallet yang didukung
WALLETS = ["dana", "ovo", "gopay", "shopeepay"]

# Nama display untuk setiap wallet
WALLET_NAMES = {
    "dana": "DANA",
    "ovo": "OVO",
    "gopay": "GoPay",
    "shopeepay": "ShopeePay"
}

# Emoji untuk setiap wallet
WALLET_EMOJI = {
    "dana": "💙",
    "ovo": "💜",
    "gopay": "💚",
    "shopeepay": "🛒"
}

def get_random_apikey():
    """Mengambil API key secara random dari daftar"""
    return random.choice(API_KEYS)

def clean_phone_number(number):
    """Bersihkan nomor telepon"""
    # Hapus semua karakter non-digit
    cleaned = ''.join(filter(str.isdigit, number))
    
    # Jika diawali 62, ubah ke 0
    if cleaned.startswith('62'):
        cleaned = '0' + cleaned[2:]
    
    # Validasi panjang nomor Indonesia (10-13 digit)
    if len(cleaned) < 10 or len(cleaned) > 13:
        return None
    
    return cleaned

async def check_wallet(wallet: str, number: str, api_key: str):
    """Cek status nomor di e-wallet tertentu"""
    try:
        params = {
            "wallet": wallet,
            "nomer": number,
            "apikey": api_key
        }
        
        async with aiohttp.ClientSession() as session:
            async with session.get(API_URL, params=params, timeout=10) as response:
                if response.status == 200:
                    data = await response.json()
                    
                    if data.get("status") and data.get("result"):
                        result = data["result"]
                        
                        # Cek apakah terdaftar
                        success = result.get("success", False)
                        customer_info = result.get("data", {}).get("customer_info", {})
                        
                        # Format berbeda tiap provider
                        if wallet == "dana":
                            registered = customer_info.get("success", False)
                        else:
                            registered = success
                        
                        return {
                            "wallet": wallet,
                            "registered": registered,
                            "data": result
                        }
    except Exception as e:
        print(f"Error check {wallet}: {e}")
    
    return {
        "wallet": wallet,
        "registered": False,
        "error": True
    }

@PY.UBOT("cekwallet")
async def check_all_wallets(client: Client, message: Message):
    ggl = await EMO.GAGAL(client)
    prs = await EMO.PROSES(client)
    
    try:
        await client.send_chat_action(message.chat.id, ChatAction.TYPING)
        
        # Ambil nomor dari argumen
        args = message.text.split(maxsplit=1)
        if len(args) < 2:
            await message.reply_text(
                f"<blockquote><b>❌ Masukkan nomor telepon!</b>\n\n"
                f"<b>Contoh:</b>\n"
                f"<code>.cekwallet 0838383838383838</code>\n"
                f"<code>.cekwallet 081234567890</code></blockquote>"
            )
            return
        
        raw_number = args[1].strip()
        number = clean_phone_number(raw_number)
        
        if not number:
            await message.reply_text(
                f"{ggl} <b>Nomor telepon tidak valid!</b>\n"
                f"Gunakan format Indonesia (10-13 digit)."
            )
            return
        
        # Ambil API key random
        api_key = get_random_apikey()
        
        # Kirim pesan processing
        processing = await message.reply_text(
            f"{prs} <b>Mengecek nomor {number} di semua e-wallet...</b>\n"
        )
        
        # Cek semua wallet secara paralel
        tasks = []
        for wallet in WALLETS:
            tasks.append(check_wallet(wallet, number, api_key))
        
        results = await asyncio.gather(*tasks)
        
        # Hitung yang terdaftar
        registered_count = sum(1 for r in results if r.get("registered"))
        
        # Format hasil
        text = f"""
<blockquote><b>💰 HASIL CEK E-WALLET</b>

📞 <b>Nomor:</b> {number}
📊 <b>Terdaftar:</b> {registered_count}/{len(WALLETS)}

<b>📋 DETAIL:</b>
"""
        
        for result in results:
            wallet = result["wallet"]
            registered = result.get("registered", False)
            emoji = WALLET_EMOJI.get(wallet, "❓")
            name = WALLET_NAMES.get(wallet, wallet.title())
            
            if registered:
                status = "✅ TERDAFTAR"
            else:
                status = "❌ Tidak terdaftar"
            
            text += f"\n{emoji} <b>{name}:</b> {status}"
        
        # Tambah info timestamp
        text += f"\n\n⏱️ <b>Waktu:</b> {datetime.now().strftime('%H:%M:%S')} WIB"
        text += "</blockquote>"
        
        await processing.delete()
        await message.reply_text(text)
        
    except Exception as e:
        await message.reply_text(f"{ggl} <b>Error: {str(e)[:100]}</b>")

@PY.UBOT("cekwalletinfo")
async def wallet_info(client: Client, message: Message):
    """Info fitur cek wallet"""
    
    text = """
<blockquote><b>💰 INFO CEK E-WALLET</b>

<b>Sumber:</b> api.botcahx.eu.org
<b>API Keys:</b> 12 random keys
<b>Update:</b> Real-time

<b>E-wallet yang dicek:</b>
• 💙 DANA
• 💜 OVO
• 💚 GoPay
• 🛒 ShopeePay

<b>Cara pakai:</b>
<code>.cekwallet [nomor]</code>

<b>Contoh:</b>
<code>.cekwallet 0838383838383838</code>
<code>.cekwallet 081234567890</code>

<b>Catatan:</b>
• Nomor akan dicek di semua wallet
• Hasil ditampilkan dalam 1 pesan
• Menggunakan random API key setiap request</blockquote>"""
    
    await message.reply_text(text)