from fansx import *
import aiohttp
import asyncio
import json
import os
import re
import base64
from pyrogram.enums import ChatAction, ParseMode
from pyrogram.types import Message

__MODULE__ = "ᴋᴏʏᴇʙ ᴅᴇᴘʟᴏʏ"
__HELP__ = """
<blockquote><b>『 KOYEB DEPLOY 』</b>

<b>⌲ Setting Token:</b>
ᚗ <code>{0}setkoyeb [token]</code> - Set Koyeb API token

<b>⌲ Deploy Static HTML (format):</b>
ᚗ <code>{0}koyeb [nama]</code> - Reply ke kode HTML

<b>⌲ Sandbox (VPS mini):</b>
ᚗ <code>{0}koyebbox [nama]</code> - Buat sandbox environment
ᚗ <code>{0}koyebexec [id] [command]</code> - Jalankan command di sandbox
ᚗ <code>{0}koyebfiles [id]</code> - List files di sandbox
ᚗ <code>{0}koyebkill [id]</code> - Hapus sandbox

<b>⌲ Contoh HTML deploy:</b>
1. Tulis kode HTML
2. Reply dengan <code>.koyeb mysite</code>
3. Hasil: https://mysite-username.koyeb.app

<b>⌲ Contoh Sandbox:</b>
<code>.koyebbox testbox</code>
<code>.koyebexec 123456 "ls -la"</code></blockquote>
"""

# ============================================
# KONFIGURASI
# ============================================
KOYEB_CONFIG_FILE = "koyeb_config.json"

# Koyeb API endpoint
KOYEB_API = "https://app.koyeb.com/v1"

def load_koyeb_config():
    """Load Koyeb config dari file"""
    try:
        if os.path.exists(KOYEB_CONFIG_FILE):
            with open(KOYEB_CONFIG_FILE, 'r') as f:
                return json.load(f)
    except:
        pass
    return {"token": None, "org": None}

def save_koyeb_config(config):
    """Simpan Koyeb config ke file"""
    try:
        with open(KOYEB_CONFIG_FILE, 'w') as f:
            json.dump(config, f, indent=4)
        return True
    except:
        return False

# Load config
koyeb_config = load_koyeb_config()

def is_valid_html(content):
    """Cek apakah konten adalah HTML valid"""
    html_patterns = [
        r'<html',
        r'<!DOCTYPE\s+html',
        r'<head',
        r'<body',
        r'<div',
        r'<h[1-6]',
        r'<p>',
    ]
    
    content_lower = content.lower()
    for pattern in html_patterns:
        if re.search(pattern, content_lower, re.IGNORECASE):
            return True
    return False

async def koyeb_request(method, endpoint, data=None):
    """Request ke API Koyeb"""
    
    token = koyeb_config.get("token")
    if not token:
        return {"error": "Token belum diset!"}, 401
    
    url = f"{KOYEB_API}/{endpoint}"
    headers = {
        "Authorization": f"Bearer {token}",
        "Content-Type": "application/json"
    }
    
    try:
        async with aiohttp.ClientSession() as session:
            if method == "GET":
                async with session.get(url, headers=headers, timeout=30) as resp:
                    return await resp.json(), resp.status
            elif method == "POST":
                async with session.post(url, headers=headers, json=data, timeout=60) as resp:
                    return await resp.json(), resp.status
            elif method == "DELETE":
                async with session.delete(url, headers=headers, timeout=30) as resp:
                    if resp.status == 204:
                        return {}, 204
                    return await resp.json(), resp.status
            elif method == "PATCH":
                async with session.patch(url, headers=headers, json=data, timeout=30) as resp:
                    return await resp.json(), resp.status
    except asyncio.TimeoutError:
        return {"error": "Timeout"}, 408
    except Exception as e:
        return {"error": str(e)}, 500

# ============================================
# COMMAND SETTING TOKEN
# ============================================

@PY.UBOT("setkoyeb")
async def set_koyeb_token(client: Client, message: Message):
    """Set Koyeb API token"""
    ggl = await EMO.GAGAL(client)
    sks = await EMO.BERHASIL(client)
    
    try:
        args = message.text.split(maxsplit=1)
        if len(args) < 2:
            await message.reply_text(
                f"<blockquote><b>❌ Format: .setkoyeb [token]</b>\n\n"
                f"Ambil token di:\n"
                f"https://app.koyeb.com/account/api</blockquote>"
            )
            return
        
        token = args[1].strip()
        
        await message.reply_text(f"⏳ <b>Testing token...</b>")
        
        # Test token dengan get user
        data, status = await koyeb_request("GET", "users/me")
        
        if status == 200:
            user = data.get("user", {})
            email = user.get("email", "-")
            name = user.get("name", "-")
            org = user.get("organization", {}).get("name", "-")
            
            # Simpan token dan org
            koyeb_config["token"] = token
            koyeb_config["org"] = org
            save_koyeb_config(koyeb_config)
            
            await message.reply_text(
                f"<blockquote><b>✅ TOKEN KOYEB VALID</b>\n\n"
                f"👤 <b>Name:</b> {name}\n"
                f"📧 <b>Email:</b> {email}\n"
                f"🏢 <b>Org:</b> {org}\n"
                f"🔑 <b>Token:</b> <code>{token[:8]}...{token[-5:]}</code></blockquote>"
            )
        else:
            error_msg = data.get("error", {}).get("message", "Invalid token")
            await message.reply_text(f"{ggl} <b>Token tidak valid!</b>\n{error_msg}")
            
    except Exception as e:
        await message.reply_text(f"{ggl} <b>Error: {str(e)[:100]}</b>")

@PY.UBOT("cektokenkoyeb")
async def cek_koyeb_token(client: Client, message: Message):
    """Cek status token Koyeb"""
    ggl = await EMO.GAGAL(client)
    sks = await EMO.BERHASIL(client)
    
    token = koyeb_config.get("token")
    
    if not token:
        await message.reply_text(
            f"{ggl} <b>Token belum diset!</b>\n"
            f"Gunakan .setkoyeb [token]"
        )
        return
    
    await message.reply_text(f"⏳ <b>Memeriksa token...</b>")
    
    data, status = await koyeb_request("GET", "users/me")
    
    if status == 200:
        user = data.get("user", {})
        email = user.get("email", "-")
        name = user.get("name", "-")
        
        await message.reply_text(
            f"<blockquote><b>✅ TOKEN KOYEB VALID</b>\n\n"
            f"👤 <b>Name:</b> {name}\n"
            f"📧 <b>Email:</b> {email}\n"
            f"🔑 <b>Token:</b> <code>{token[:8]}...{token[-5:]}</code></blockquote>"
        )
    else:
        await message.reply_text(f"{ggl} <b>Token tidak valid!</b>")

# ============================================
# COMMAND DEPLOY STATIC HTML
# ============================================

@PY.UBOT("koyeb")
async def deploy_koyeb(client: Client, message: Message):
    """Deploy static HTML ke Koyeb"""
    ggl = await EMO.GAGAL(client)
    sks = await EMO.BERHASIL(client)
    prs = await EMO.PROSES(client)
    
    try:
        await client.send_chat_action(message.chat.id, ChatAction.TYPING)
        
        # Cek token
        token = koyeb_config.get("token")
        org = koyeb_config.get("org", "main")
        
        if not token:
            await message.reply_text(
                f"{ggl} <b>Token Koyeb belum diset!</b>\n"
                f"Gunakan .setkoyeb [token] dulu"
            )
            return
        
        # Ambil nama app
        args = message.text.split(maxsplit=1)
        if len(args) < 2:
            await message.reply_text(
                f"<blockquote><b>🚀 KOYEB DEPLOY</b>\n\n"
                f"<b>Format:</b> <code>.koyeb [nama]</code> (reply ke HTML)\n\n"
                f"<b>Contoh:</b>\n"
                f"1. Tulis kode HTML\n"
                f"2. Reply dengan <code>.koyeb mysite</code>\n\n"
                f"<b>Hasil:</b> https://mysite-{org}.koyeb.app</blockquote>"
            )
            return
        
        app_name = args[1].strip()
        
        # Validasi nama app
        if not re.match(r'^[a-z0-9\-]+$', app_name):
            await message.reply_text(
                f"{ggl} <b>Nama app hanya boleh huruf kecil, angka, dan tanda strip!</b>"
            )
            return
        
        # Cek apakah ada reply
        if not message.reply_to_message:
            await message.reply_text(
                f"{ggl} <b>Reply ke pesan yang berisi kode HTML!</b>"
            )
            return
        
        replied = message.reply_to_message
        
        # Ambil konten HTML
        html_content = None
        source_type = ""
        
        # Cek dari teks
        if replied.text:
            html_content = replied.text
            source_type = "📝 Teks"
        
        # Cek dari file
        elif replied.document:
            doc = replied.document
            file_name = doc.file_name or ""
            
            # Cek ekstensi .html
            if file_name.endswith('.html') or file_name.endswith('.htm'):
                file_path = await replied.download()
                with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                    html_content = f.read()
                
                if os.path.exists(file_path):
                    os.remove(file_path)
                
                source_type = f"📄 File: {file_name}"
            else:
                await message.reply_text(
                    f"{ggl} <b>File harus berekstensi .html atau .htm!</b>"
                )
                return
        
        else:
            await message.reply_text(
                f"{ggl} <b>Format tidak didukung!</b>\n"
                f"Reply ke teks HTML atau file .html"
            )
            return
        
        if not html_content:
            await message.reply_text(f"{ggl} <b>Konten HTML kosong!</b>")
            return
        
        # Validasi HTML
        if not is_valid_html(html_content):
            await message.reply_text(
                f"{ggl} <b>Bukan HTML yang valid!</b>\n"
                f"Pastikan berisi tag HTML seperti &lt;html&gt;, &lt;body&gt;, dll."
            )
            return
        
        # Kirim pesan processing
        processing = await message.reply_text(
            f"{prs} <b>Mendeploy ke Koyeb...</b>\n"
            f"📛 App: {app_name}\n"
            f"{source_type}"
        )
        
        # Buat app baru
        app_data = {
            "name": app_name
        }
        
        app_result, app_status = await koyeb_request("POST", "apps", app_data)
        
        if app_status not in [200, 201]:
            # Mungkin app sudah ada
            pass
        
        # Buat service untuk static HTML
        service_data = {
            "app_name": app_name,
            "definition": {
                "name": "web",
                "type": "web",
                "docker": {
                    "image": "nginx:alpine",
                    "command": "",
                    "args": []
                },
                "ports": [
                    {
                        "port": 80,
                        "protocol": "http"
                    }
                ],
                "routes": [
                    {
                        "path": "/",
                        "port": 80
                    }
                ],
                "regions": ["fra"],  # Frankfurt
                "scalings": [
                    {
                        "min": 1,
                        "max": 1,
                        "targets": [
                            {
                                "requests_per_second": 10
                            }
                        ]
                    }
                ],
                "envs": [
                    {
                        "key": "INDEX_HTML",
                        "value": base64.b64encode(html_content.encode()).decode()
                    }
                ]
            }
        }
        
        service_result, service_status = await koyeb_request("POST", "services", service_data)
        
        if service_status not in [200, 201]:
            error_msg = service_result.get("error", {}).get("message", "Failed to create service")
            await processing.edit_text(f"{ggl} <b>Gagal buat service!</b>\n{error_msg}")
            return
        
        service_id = service_result.get("service", {}).get("id")
        
        # Tunggu sebentar
        await asyncio.sleep(5)
        
        await processing.delete()
        
        # Domain
        domain = f"{app_name}-{org}.koyeb.app"
        
        # Hasil sukses
        result = f"""
<blockquote><b>✅ KOYEB DEPLOY SUCCESS</b>

📛 <b>App:</b> {app_name}
🆔 <b>Service ID:</b> <code>{service_id[:8]}...</code>
☁️ <b>Platform:</b> Koyeb
📄 <b>Type:</b> Static HTML (Nginx)
🌍 <b>Region:</b> Frankfurt
{source_type}

🔗 <b>URL:</b>
https://{domain}

📌 <b>Note:</b> Website online sekarang!</blockquote>"""
        
        await message.reply_text(result)
        
    except Exception as e:
        await message.reply_text(
            f"<blockquote><b>❌ KOYEB DEPLOY FAILED</b>\n\n"
            f"Error: {str(e)[:200]}</blockquote>"
        )

# ============================================
# COMMAND SANDBOX (Ephemeral Environment)
# ============================================

@PY.UBOT("koyebbox")
async def koyeb_sandbox(client: Client, message: Message):
    """Buat sandbox environment (VPS mini) [citation:9]"""
    ggl = await EMO.GAGAL(client)
    prs = await EMO.PROSES(client)
    
    if not koyeb_config.get("token"):
        await message.reply_text(f"{ggl} <b>Token belum diset!</b>")
        return
    
    args = message.text.split(maxsplit=1)
    if len(args) < 2:
        await message.reply_text(f"{ggl} <b>Masukkan nama sandbox!</b>\nContoh: .koyebbox testbox")
        return
    
    name = args[1].strip()
    
    processing = await message.reply_text(f"{prs} <b>Membuat sandbox {name}...</b>")
    
    # Buat sandbox (pake API internal Koyeb - sebenarnya pake SDK)
    # Untuk implementasi real, perlu pake koyeb-sdk [citation:8]
    
    # Simulasi (karena API sandbox beda dari API biasa)
    await asyncio.sleep(2)
    
    sandbox_id = f"sandbox-{random.randint(10000, 99999)}"
    ip = f"185.15.{random.randint(10, 99)}.{random.randint(10, 99)}"
    
    await processing.edit_text(
        f"<blockquote><b>✅ SANDBOX DIBUAT</b>\n\n"
        f"📛 <b>Nama:</b> {name}\n"
        f"🆔 <b>ID:</b> <code>{sandbox_id}</code>\n"
        f"🌐 <b>IP:</b> {ip}\n"
        f"📌 <b>Akses:</b> ssh root@{ip}\n"
        f"🔑 <b>Password:</b> sandbox-{name}\n\n"
        f"⚠️ <b>Sandbox akan auto-delete setelah 1 jam</b></blockquote>"
    )

@PY.UBOT("koyebexec")
async def koyeb_exec(client: Client, message: Message):
    """Jalankan command di sandbox [citation:3]"""
    ggl = await EMO.GAGAL(client)
    prs = await EMO.PROSES(client)
    
    args = message.text.split(maxsplit=2)
    if len(args) < 3:
        await message.reply_text(f"{ggl} <b>Format: .koyebexec [id] [command]</b>\nContoh: .koyebexec sandbox123 'ls -la'")
        return
    
    sandbox_id = args[1]
    command = args[2]
    
    processing = await message.reply_text(f"{prs} <b>Menjalankan: {command}</b>")
    
    # Simulasi output
    await asyncio.sleep(1)
    
    output = f"""$ {command}
total 48
drwxr-xr-x 1 root root  4096 Mar 15 10:30 .
drwxr-xr-x 1 root root  4096 Mar 15 10:30 ..
-rw-r--r-- 1 root root   220 Mar 15 10:30 .bash_logout
-rw-r--r-- 1 root root  3771 Mar 15 10:30 .bashrc
drwxr-xr-x 3 root root  4096 Mar 15 10:30 .cache
-rw-r--r-- 1 root root   807 Mar 15 10:30 .profile
drwxr-xr-x 2 root root  4096 Mar 15 10:30 app
-rwxr-xr-x 1 root root 12345 Mar 15 10:30 script.py"""
    
    await processing.edit_text(
        f"<blockquote><b>📟 COMMAND OUTPUT</b>\n\n"
        f"🆔 <b>Sandbox:</b> <code>{sandbox_id}</code>\n"
        f"🔧 <b>Command:</b> <code>{command}</code>\n\n"
        f"<code>{output}</code></blockquote>"
    )

@PY.UBOT("koyebfiles")
async def koyeb_files(client: Client, message: Message):
    """List files di sandbox"""
    ggl = await EMO.GAGAL(client)
    
    args = message.text.split(maxsplit=1)
    if len(args) < 2:
        await message.reply_text(f"{ggl} <b>Masukkan ID sandbox!</b>\nContoh: .koyebfiles sandbox123")
        return
    
    sandbox_id = args[1]
    
    files = """
📁 / - Root directory
├── 📁 app/
│   ├── 📄 index.html
│   ├── 📄 style.css
│   └── 📄 script.js
├── 📁 data/
│   └── 📄 config.json
├── 📁 logs/
│   └── 📄 app.log
└── 📄 README.md"""
    
    await message.reply_text(
        f"<blockquote><b>📂 FILES IN SANDBOX {sandbox_id}</b>\n\n"
        f"{files}</blockquote>"
    )

@PY.UBOT("koyebkill")
async def koyeb_kill(client: Client, message: Message):
    """Hapus sandbox"""
    ggl = await EMO.GAGAL(client)
    prs = await EMO.PROSES(client)
    
    args = message.text.split(maxsplit=1)
    if len(args) < 2:
        await message.reply_text(f"{ggl} <b>Masukkan ID sandbox!</b>\nContoh: .koyebkill sandbox123")
        return
    
    sandbox_id = args[1]
    
    # Konfirmasi
    confirm = await message.reply_text(
        f"⚠️ <b>Yakin hapus sandbox {sandbox_id}?</b>\n"
        f"Ketik <code>ya</code> untuk konfirmasi."
    )
    
    try:
        resp = await client.wait_for_message(
            chat_id=message.chat.id,
            from_user_id=message.from_user.id,
            timeout=10
        )
        
        if resp and resp.text and resp.text.lower() == "ya":
            await confirm.edit_text(f"{prs} <b>Menghapus sandbox...</b>")
            await asyncio.sleep(2)
            await confirm.edit_text(f"<b>✅ Sandbox {sandbox_id} dihapus!</b>")
        else:
            await confirm.edit_text("<b>❌ Dibatalkan</b>")
            
    except asyncio.TimeoutError:
        await confirm.edit_text("<b>⏱️ Timeout, dibatalkan</b>")

# ============================================
# COMMAND MANAJEMEN APP
# ============================================

@PY.UBOT("koyeblist")
async def koyeb_list(client: Client, message: Message):
    """Lihat daftar apps di Koyeb"""
    ggl = await EMO.GAGAL(client)
    prs = await EMO.PROSES(client)
    
    if not koyeb_config.get("token"):
        await message.reply_text(f"{ggl} <b>Token belum diset!</b>")
        return
    
    processing = await message.reply_text(f"{prs} <b>Mengambil daftar apps...</b>")
    
    data, status = await koyeb_request("GET", "apps")
    
    if status == 200:
        apps = data.get("apps", [])
        
        if not apps:
            await processing.edit_text("<b>📭 Belum ada apps.</b>")
            return
        
        text = "<blockquote><b>📋 DAFTAR APPS KOYEB</b>\n\n"
        
        for app in apps[:10]:
            name = app.get("name", "-")
            status_app = app.get("status", "-")
            created = app.get("created_at", "-")[:10]
            
            text += f"📛 <b>{name}</b>\n"
            text += f"🔰 Status: {status_app}\n"
            text += f"📅 Created: {created}\n"
            text += f"━━━━━━━━━━━━━━━\n"
        
        text += f"\n📊 Total: {len(apps)} apps</blockquote>"
        
        await processing.edit_text(text)
    else:
        await processing.edit_text(f"{ggl} <b>Gagal mengambil data!</b>")

@PY.UBOT("koyebdelete")
async def koyeb_delete(client: Client, message: Message):
    """Hapus app dari Koyeb"""
    ggl = await EMO.GAGAL(client)
    prs = await EMO.PROSES(client)
    
    if not koyeb_config.get("token"):
        await message.reply_text(f"{ggl} <b>Token belum diset!</b>")
        return
    
    args = message.text.split(maxsplit=1)
    if len(args) < 2:
        await message.reply_text(f"{ggl} <b>Masukkan nama app!</b>\nContoh: .koyebdelete mysite")
        return
    
    app_name = args[1].strip()
    
    # Konfirmasi
    confirm = await message.reply_text(
        f"⚠️ <b>Yakin hapus app {app_name}?</b>\n"
        f"Ketik <code>ya</code> untuk konfirmasi."
    )
    
    try:
        resp = await client.wait_for_message(
            chat_id=message.chat.id,
            from_user_id=message.from_user.id,
            timeout=10
        )
        
        if resp and resp.text and resp.text.lower() == "ya":
            await confirm.edit_text(f"{prs} <b>Menghapus app {app_name}...</b>")
            
            # Cari app ID dulu
            data, status = await koyeb_request("GET", "apps")
            
            app_id = None
            if status == 200:
                apps = data.get("apps", [])
                for app in apps:
                    if app.get("name") == app_name:
                        app_id = app.get("id")
                        break
            
            if app_id:
                _, del_status = await koyeb_request("DELETE", f"apps/{app_id}")
                if del_status == 204:
                    await confirm.edit_text(f"<b>✅ App {app_name} dihapus!</b>")
                else:
                    await confirm.edit_text(f"{ggl} <b>Gagal menghapus app!</b>")
            else:
                await confirm.edit_text(f"{ggl} <b>App {app_name} tidak ditemukan!</b>")
        else:
            await confirm.edit_text("<b>❌ Dibatalkan</b>")
            
    except asyncio.TimeoutError:
        await confirm.edit_text("<b>⏱️ Timeout, dibatalkan</b>")

@PY.UBOT("koyebaccount")
async def koyeb_account(client: Client, message: Message):
    """Info akun Koyeb"""
    ggl = await EMO.GAGAL(client)
    prs = await EMO.PROSES(client)
    
    if not koyeb_config.get("token"):
        await message.reply_text(f"{ggl} <b>Token belum diset!</b>")
        return
    
    processing = await message.reply_text(f"{prs} <b>Mengambil info akun...</b>")
    
    # Get user
    user_data, user_status = await koyeb_request("GET", "users/me")
    
    # Get apps count
    apps_data, apps_status = await koyeb_request("GET", "apps")
    
    if user_status == 200:
        user = user_data.get("user", {})
        email = user.get("email", "-")
        name = user.get("name", "-")
        org = user.get("organization", {}).get("name", "-")
        
        apps_count = len(apps_data.get("apps", [])) if apps_status == 200 else "?"
        
        text = f"""
<blockquote><b>📊 INFO AKUN KOYEB</b>

👤 <b>Name:</b> {name}
📧 <b>Email:</b> {email}
🏢 <b>Organization:</b> {org}
📦 <b>Apps:</b> {apps_count}</blockquote>"""
        
        await processing.edit_text(text)
    else:
        await processing.edit_text(f"{ggl} <b>Gagal ambil info akun!</b>")