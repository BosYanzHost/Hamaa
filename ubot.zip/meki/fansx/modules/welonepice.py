from fansx import *
import aiohttp
import asyncio
import os
import random
from pyrogram.enums import ChatAction, ParseMode
from pyrogram.types import Message

__MODULE__ = "ᴏɴᴇ ᴘɪᴇᴄᴇ ᴡᴇʟᴄᴏᴍᴇ"
__HELP__ = """
<blockquote><b>🏴‍☠️ ONE PIECE WELCOME CANVAS</b>

<b>⌲ Perintah:</b>
ᚗ <code>{0}onepiece [nama]</code> - Buat welcome card One Piece
ᚗ <code>{0}op [nama]</code> - Singkatan

<b>⌲ Contoh:</b>
<code>.onepiece Najmy</code>
<code>.op Najmy | Member</code></blockquote>
"""

# ============================================
# KONFIGURASI
# ============================================
ONEPIECE_API = "https://anabot.my.id/api/canvas/onePiece"
API_KEY = "freeApikey"  # Bisa diganti nanti

# Default values
DEFAULT_ROLE = "Member"

async def create_onepiece_welcome(image_url, name, role=DEFAULT_ROLE):
    """Buat gambar welcome One Piece"""
    
    # Encode semua parameter
    url = (f"{ONEPIECE_API}?image={image_url}"
           f"&name={name}"
           f"&role={role}"
           f"&apikey={API_KEY}")
    
    try:
        async with aiohttp.ClientSession() as session:
            async with session.get(url, timeout=30) as response:
                if response.status == 200:
                    # Cek content-type
                    content_type = response.headers.get("Content-Type", "")
                    
                    if "image" in content_type:
                        # Langsung gambar
                        return {
                            "success": True,
                            "image": await response.read(),
                            "direct": True
                        }
                    else:
                        # Mungkin JSON dengan URL gambar
                        try:
                            data = await response.json()
                            
                            # Cek berbagai format respons
                            if data.get("status") == "success" and data.get("result"):
                                img_url = data["result"]
                            elif data.get("image_url"):
                                img_url = data["image_url"]
                            elif data.get("url"):
                                img_url = data["url"]
                            else:
                                return {"success": False, "error": "Format respons tidak dikenali", "data": data}
                            
                            # Download gambar dari URL
                            async with session.get(img_url, timeout=15) as img_resp:
                                if img_resp.status == 200:
                                    return {
                                        "success": True,
                                        "image": await img_resp.read()
                                    }
                                else:
                                    return {"success": False, "error": f"Gagal download gambar: HTTP {img_resp.status}"}
                        except:
                            return {"success": False, "error": "API tidak mengembalikan gambar"}
                else:
                    return {"success": False, "error": f"HTTP {response.status}"}
    except asyncio.TimeoutError:
        return {"success": False, "error": "Timeout - server terlalu lambat"}
    except Exception as e:
        return {"success": False, "error": str(e)}

def parse_onepiece_args(args, user_full_name):
    """Parse argumen dengan format: nama | role"""
    if not args:
        return {
            "name": user_full_name,
            "role": DEFAULT_ROLE
        }
    
    # Format: nama | role
    full_text = " ".join(args)
    parts = [p.strip() for p in full_text.split("|")]
    
    result = {
        "name": user_full_name,
        "role": DEFAULT_ROLE
    }
    
    # Parse nama
    if len(parts) >= 1 and parts[0]:
        result["name"] = parts[0]
    
    # Parse role
    if len(parts) >= 2 and parts[1]:
        result["role"] = parts[1]
    
    return result

@PY.UBOT("onepiece")
@PY.UBOT("op")
async def onepiece_command(client: Client, message: Message):
    ggl = await EMO.GAGAL(client)
    sks = await EMO.BERHASIL(client)
    prs = await EMO.PROSES(client)
    
    # Parse argumen
    args = message.text.split()[1:]
    
    # Dapatkan info user
    user = message.from_user
    user_name = user.first_name or ""
    if user.last_name:
        user_name += f" {user.last_name}"
    
    # Dapatkan foto profil user
    user_photo_url = "https://picsum.photos/200"  # Default
    
    try:
        photos = await client.get_chat_photos(user.id, limit=1)
        if photos:
            # Dapatkan file_id foto
            photo_file_id = photos[0].file_id
            
            # Download foto
            photo_path = await client.download_media(photo_file_id)
            
            if photo_path and os.path.exists(photo_path):
                # Upload ke tempat penyimpanan sementara
                # Untuk sekarang pake foto default dulu
                # Nanti bisa ditambah fitur upload ke server
                user_photo_url = "https://picsum.photos/200"  # Ganti dengan URL setelah diupload
                
                # Hapus file sementara
                os.remove(photo_path)
    except Exception as e:
        print(f"Error ambil foto: {e}")
    
    # Parse argumen
    parsed = parse_onepiece_args(args, user_name)
    
    # Cek apakah user reply ke pesan
    reply_to = message.reply_to_message
    if reply_to and reply_to.from_user:
        target_user = reply_to.from_user
        target_name = target_user.first_name or ""
        if target_user.last_name:
            target_name += f" {target_user.last_name}"
        
        # Ganti dengan data user yang direply
        parsed["name"] = target_name
        
        # Coba ambil foto user yang direply
        try:
            target_photos = await client.get_chat_photos(target_user.id, limit=1)
            if target_photos:
                photo_file_id = target_photos[0].file_id
                photo_path = await client.download_media(photo_file_id)
                if photo_path and os.path.exists(photo_path):
                    user_photo_url = "https://picsum.photos/200"  # Ganti dengan URL setelah diupload
                    os.remove(photo_path)
        except:
            pass
    
    if not args:
        # Tampilkan help
        help_text = f"""
<blockquote><b>Cara pakai:</b>
ᚗ <code>.onepiece [nama]</code>
ᚗ <code>.onepiece [nama] | [role]</code>

<b>Contoh sederhana:</b>
<code>.onepiece {user_name}</code>
<code>.op {user_name}</code>

<b>Contoh lengkap:</b>
<code>.onepiece {user_name} | Kapten</code>
<code>.op {user_name} | Member</code>

<b>📌 Fitur:</b>
• Theme One Piece keren
• Auto ambil foto profil
• Bisa reply ke user lain
• Kustom role (Kapten, Member, dll)

<b>✨ Tips:</b>
Reply ke pesan orang lain buat buatin welcome card One Piece buat dia!</blockquote>"""
        
        await message.reply_text(help_text)
        return
    
    try:
        await client.send_chat_action(message.chat.id, ChatAction.UPLOAD_PHOTO)
        
        processing = await message.reply_text(
            f"{prs} <b>Membuat welcome card One Piece...</b>\n"
            f"<b>Untuk:</b> {parsed['name']}"
        )
        
        # Buat welcome card One Piece
        result = await create_onepiece_welcome(
            image_url=user_photo_url,
            name=parsed['name'],
            role=parsed['role']
        )
        
        await processing.delete()
        
        if result.get("success") and result.get("image"):
            # Simpan gambar sementara
            file_path = f"onepiece_{message.from_user.id}_{random.randint(1000,9999)}.png"
            with open(file_path, "wb") as f:
                f.write(result["image"])
            
            # Buat caption dengan info
            caption = f"<blockquote><b>🏴‍☠️ ONE PIECE WELCOME</b>\n\n"
            caption += f"<b>👤 Nama:</b> {parsed['name']}\n"
            caption += f"<b>📌 Role:</b> {parsed['role']}\n"
            caption += f"\n⚡ Powered by: Ubot Premium Zyura</blockquote>"
            
            # Kirim gambar
            await client.send_photo(
                chat_id=message.chat.id,
                photo=file_path,
                caption=caption
            )
            
            # Hapus file
            if os.path.exists(file_path):
                os.remove(file_path)
            
        else:
            error_msg = result.get("error", "Unknown error")
            await message.reply_text(
                f"<blockquote><b>❌ GAGAL MEMBUAT GAMBAR</b>\n\n"
                f"<b>Error:</b> {error_msg}</blockquote>"
            )
        
    except Exception as e:
        await message.reply_text(f"{ggl} <b>Error: {str(e)[:100]}</b>")

