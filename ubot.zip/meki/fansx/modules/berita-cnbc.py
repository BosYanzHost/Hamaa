from fansx import *
import aiohttp
import asyncio
import random
import json
import os
import re
from datetime import datetime
from pyrogram.enums import ChatAction, ParseMode
from pyrogram.types import Message

__MODULE__ = "ʙᴇʀɪᴛᴀ ᴄɴʙᴄ"
__HELP__ = """
<blockquote><b>📰 BERITA CNBC INDONESIA</b>

<b>⌲ Perintah:</b>
ᚗ <code>{0}cnbc</code> - Berita terbaru (1 jam terakhir)
ᚗ <code>{0}cnbctop</code> - 5 berita terbaru
ᚗ <code>{0}cnbclatest</code> - Semua berita terbaru

<b>⌲ Update:</b> 15 Maret 2026
<b>⌲ Sumber:</b> CNBC Indonesia

<b>⌲ Contoh:</b>
<code>.cnbc</code> - Berita paling baru
<code>.cnbctop</code> - 5 berita terbaru</blockquote>
"""

# ============================================
# KONFIGURASI
# ============================================
API_URL = "https://api.deline.web.id/berita/cnbc"

# Warna untuk kategori
CATEGORY_COLORS = {
    "Internasional": "🔴",
    "FOTO INTERNASIONAL": "📸",
    "FOTO": "🖼️",
    "VIDEO": "🎥",
    "default": "📌"
}

async def get_news():
    """Ambil daftar berita dari API"""
    try:
        async with aiohttp.ClientSession() as session:
            async with session.get(API_URL, timeout=15) as response:
                if response.status == 200:
                    data = await response.json()
                    if data.get("status") and data.get("data"):
                        return data.get("data", [])
    except Exception as e:
        print(f"Error get news: {e}")
    return None

def parse_time_ago(time_str):
    """Parse waktu relatif (contoh: '8 menit yang lalu')"""
    if not time_str:
        return 999999  # Default ke sangat lama
    
    time_str = time_str.lower()
    
    # Cari angka
    numbers = re.findall(r'\d+', time_str)
    if not numbers:
        return 999999
    
    num = int(numbers[0])
    
    if 'menit' in time_str:
        return num
    elif 'jam' in time_str:
        return num * 60
    elif 'hari' in time_str:
        return num * 1440
    else:
        return 999999

def get_category_emoji(category):
    """Dapatkan emoji berdasarkan kategori"""
    return CATEGORY_COLORS.get(category, CATEGORY_COLORS["default"])

def truncate_title(title, limit=100):
    """Potong judul jika terlalu panjang"""
    if len(title) > limit:
        return title[:limit] + "..."
    return title

@PY.UBOT("cnbc")
async def cnbc_latest(client: Client, message: Message):
    """Ambil 1 berita terbaru"""
    ggl = await EMO.GAGAL(client)
    prs = await EMO.PROSES(client)
    
    try:
        await client.send_chat_action(message.chat.id, ChatAction.TYPING)
        
        processing = await message.reply_text(f"{prs} <b>Mengambil berita terbaru CNBC...</b>")
        
        news_list = await get_news()
        
        if not news_list:
            await processing.edit_text(f"{ggl} <b>Gagal mengambil berita!</b>")
            return
        
        # Urutkan berdasarkan waktu (paling baru)
        news_with_time = []
        for n in news_list:
            time_str = n.get("date", "") or n.get("label", "")
            time_val = parse_time_ago(time_str)
            news_with_time.append((n, time_val))
        
        # Urutkan ascending (nilai kecil = lebih baru)
        news_with_time.sort(key=lambda x: x[1])
        
        # Ambil 5 berita terbaru
        latest_news = [n for n, _ in news_with_time[:5]]
        
        # Ambil 1 random dari 5 terbaru
        news = random.choice(latest_news)
        
        title = news.get("title", "Judul tidak tersedia")
        link = news.get("link", "#")
        image = news.get("image", "")
        category = news.get("category", "Umum")
        time_str = news.get("date", "") or news.get("label", "")
        type_news = news.get("type", "article")
        
        # Bersihkan label
        if time_str and len(time_str) > 30:
            time_str = time_str.replace(title, "").strip()
        
        # Emoji untuk tipe
        type_emoji = "📹" if type_news == "video" else "📰"
        
        await processing.delete()
        
        # Coba kirim dengan foto
        if image:
            try:
                await client.send_photo(
                    chat_id=message.chat.id,
                    photo=image,
                    caption=f"<blockquote><b>{type_emoji} CNBC TERBARU</b>\n\n"
                            f"<b>{truncate_title(title)}</b>\n\n"
                            f"{get_category_emoji(category)} <b>Kategori:</b> {category}\n"
                            f"⏱️ <b>{time_str}</b>\n"
                            f"🔗 <b>Baca:</b>\n{link}</blockquote>"
                )
                return
            except:
                pass
        
        # Kirim tanpa foto
        await message.reply_text(
            f"<blockquote><b>{type_emoji} CNBC TERBARU</b>\n\n"
            f"<b>{truncate_title(title)}</b>\n\n"
            f"{get_category_emoji(category)} <b>Kategori:</b> {category}\n"
            f"⏱️ <b>{time_str}</b>\n"
            f"🔗 <b>Baca:</b>\n{link}</blockquote>"
        )
        
    except Exception as e:
        await message.reply_text(f"{ggl} <b>Error: {str(e)[:100]}</b>")

@PY.UBOT("cnbctop")
async def cnbc_top5(client: Client, message: Message):
    """Tampilkan 5 berita terbaru"""
    ggl = await EMO.GAGAL(client)
    prs = await EMO.PROSES(client)
    
    try:
        await client.send_chat_action(message.chat.id, ChatAction.TYPING)
        
        processing = await message.reply_text(f"{prs} <b>Mengambil 5 berita terbaru...</b>")
        
        news_list = await get_news()
        
        if not news_list:
            await processing.edit_text(f"{ggl} <b>Gagal mengambil berita!</b>")
            return
        
        # Urutkan berdasarkan waktu
        news_with_time = []
        for n in news_list:
            time_str = n.get("date", "") or n.get("label", "")
            time_val = parse_time_ago(time_str)
            news_with_time.append((n, time_val, time_str))
        
        news_with_time.sort(key=lambda x: x[1])
        top5 = news_with_time[:5]
        
        text = "<blockquote><b>📰 TOP 5 BERITA CNBC</b>\n\n"
        
        for i, (news, _, time_str) in enumerate(top5, 1):
            title = news.get("title", "Judul tidak tersedia")
            category = news.get("category", "Umum")
            type_news = news.get("type", "article")
            
            type_emoji = "📹" if type_news == "video" else "📰"
            
            text += f"{i}. {type_emoji} <b>{truncate_title(title, 70)}</b>\n"
            text += f"   {get_category_emoji(category)} {category} | ⏱️ {time_str}\n\n"
        
        text += "<i>Gunakan .cnbc untuk baca berita lengkap</i></blockquote>"
        
        await processing.edit_text(text)
        
    except Exception as e:
        await message.reply_text(f"{ggl} <b>Error: {str(e)[:100]}</b>")

@PY.UBOT("cnbclatest")
async def cnbc_all_latest(client: Client, message: Message):
    """Tampilkan semua berita terbaru (update)"""
    ggl = await EMO.GAGAL(client)
    prs = await EMO.PROSES(client)
    
    try:
        await client.send_chat_action(message.chat.id, ChatAction.TYPING)
        
        processing = await message.reply_text(f"{prs} <b>Mengupdate berita CNBC...</b>")
        
        news_list = await get_news()
        
        if not news_list:
            await processing.edit_text(f"{ggl} <b>Gagal mengambil berita!</b>")
            return
        
        # Urutkan berdasarkan waktu
        news_with_time = []
        for n in news_list:
            time_str = n.get("date", "") or n.get("label", "")
            time_val = parse_time_ago(time_str)
            news_with_time.append((n, time_val, time_str))
        
        news_with_time.sort(key=lambda x: x[1])
        
        text = "<blockquote><b>📰 UPDATE BERITA CNBC</b>\n"
        text += f"📅 15 Maret 2026\n"
        text += f"📊 Total: {len(news_list)} berita\n\n"
        
        # Tampilkan 10 terbaru
        for i, (news, _, time_str) in enumerate(news_with_time[:10], 1):
            title = news.get("title", "Judul tidak tersedia")
            category = news.get("category", "Umum")
            type_news = news.get("type", "article")
            
            type_emoji = "📹" if type_news == "video" else "📰"
            
            text += f"{type_emoji} <b>{truncate_title(title, 60)}</b>\n"
            text += f"   {get_category_emoji(category)} {category} | ⏱️ {time_str}\n\n"
        
        text += "<i>.cnbc = berita random\n.cnbctop = 5 terbaru</i></blockquote>"
        
        await processing.edit_text(text)
        
    except Exception as e:
        await message.reply_text(f"{ggl} <b>Error: {str(e)[:100]}</b>")

@PY.UBOT("cnbcinfo")
async def cnbc_info(client: Client, message: Message):
    """Info fitur berita CNBC"""
    
    text = """
<blockquote><b>📰 INFO BERITA CNBC</b>

<b>Sumber:</b> CNBC Indonesia
<b>Update:</b> 15 Maret 2026
<b>Total:</b> 30+ berita

<b>Cara pakai:</b>
• <code>.cnbc</code> - Berita random dari 5 terbaru
• <code>.cnbctop</code> - 5 berita terbaru
• <code>.cnbclatest</code> - Update 10 berita terbaru

<b>Kategori:</b>
🔴 Internasional
📸 FOTO
🎥 Video
📌 Umum

<b>Contoh:</b>
<code>.cnbc</code>
<code>.cnbctop</code></blockquote>"""
    
    await message.reply_text(text)