from fansx import *
import aiohttp
import asyncio
import json
import os
from datetime import datetime
from pyrogram.enums import ChatAction, ParseMode
from pyrogram.types import Message

__MODULE__ = "ꜰᴀᴋᴇ ɴᴜᴍʙᴇʀ"
__HELP__ = """
<blockquote><b>📱 FAKE NUMBER (Temporary)</b>

<b>⌲ Perintah:</b>
ᚗ <code>{0}fakenumber</code> - List negara tersedia
ᚗ <code>{0}fakenumber [negara]</code> - Dapatkan nomor dari negara
ᚗ <code>{0}lihatpesan [nomor]</code> - Lihat pesan masuk

<b>⌲ Contoh:</b>
<code>.fakenumber</code> (lihat daftar negara)
<code>.fakenumber id</code> (nomor Indonesia)
<code>.lihatpesan 6281234567890</code>

<b>⌲ Catatan:</b>
• Nomor hanya aktif sementara
• Pesan akan hilang setelah beberapa waktu</blockquote>
"""

# ============================================
# KONFIGURASI
# ============================================
BASE_URL = "https://api.vreden.my.id/api/v1/tools/fakenumber"

# Cache untuk daftar negara
countries_cache = {"data": None, "timestamp": 0}

async def get_countries():
    """Ambil daftar negara dari API"""
    global countries_cache
    
    # Cek cache (refresh setiap 1 jam)
    now = datetime.now().timestamp()
    if countries_cache["data"] and now - countries_cache["timestamp"] < 3600:
        return countries_cache["data"]
    
    try:
        async with aiohttp.ClientSession() as session:
            async with session.get(f"{BASE_URL}/country", timeout=15) as response:
                if response.status == 200:
                    data = await response.json()
                    if data.get("status") and data.get("result"):
                        countries_cache["data"] = data["result"]
                        countries_cache["timestamp"] = now
                        return data["result"]
    except Exception as e:
        print(f"Error get countries: {e}")
    return None

async def get_numbers(country_id: str):
    """Ambil nomor dari negara tertentu"""
    try:
        async with aiohttp.ClientSession() as session:
            async with session.get(f"{BASE_URL}/number?id={country_id}", timeout=15) as response:
                if response.status == 200:
                    data = await response.json()
                    if data.get("status") and data.get("result"):
                        return data["result"]
    except Exception as e:
        print(f"Error get numbers: {e}")
    return None

async def get_messages(number: str):
    """Ambil pesan dari nomor tertentu"""
    try:
        # Bersihkan nomor (ambil angka saja)
        clean_number = ''.join(filter(str.isdigit, number))
        
        async with aiohttp.ClientSession() as session:
            async with session.get(f"{BASE_URL}/message?number={clean_number}", timeout=15) as response:
                if response.status == 200:
                    data = await response.json()
                    if data.get("status") and data.get("result"):
                        return data["result"]
    except Exception as e:
        print(f"Error get messages: {e}")
    return None

def format_time_wib(time_str):
    """Format waktu WIB"""
    try:
        # Format: "2026-02-19 18:49:07"
        if time_str and len(time_str) >= 16:
            return time_str[11:16]  # Ambil jam:menit
    except:
        pass
    return "-"

@PY.UBOT("fakenumber")
async def fake_number(client: Client, message: Message):
    ggl = await EMO.GAGAL(client)
    prs = await EMO.PROSES(client)
    
    try:
        await client.send_chat_action(message.chat.id, ChatAction.TYPING)
        
        args = message.text.split(maxsplit=1)
        
        # Jika tanpa argumen, tampilkan daftar negara
        if len(args) < 2:
            processing = await message.reply_text(f"{prs} <b>Mengambil daftar negara...</b>")
            
            countries = await get_countries()
            
            if not countries:
                await processing.edit_text(f"{ggl} <b>Gagal mengambil daftar negara!</b>")
                return
            
            # Kelompokkan berdasarkan abjad
            countries.sort(key=lambda x: x["title"])
            
            text = "<blockquote><b>🌍 DAFTAR NEGARA</b>\n\n"
            
            # Tampilkan per baris
            for i, country in enumerate(countries, 1):
                text += f"{i}. <b>{country['title']}</b> (<code>{country['id']}</code>)\n"
            
            text += f"\n<b>📊 Total:</b> {len(countries)} negara\n\n"
            text += "<b>Contoh:</b>\n"
            text += "<code>.fakenumber id</code> (Indonesia)\n"
            text += "<code>.fakenumber us</code> (USA)</blockquote>"
            
            await processing.delete()
            await message.reply_text(text)
            return
        
        # Dengan argumen negara
        country_id = args[1].strip().lower()
        
        processing = await message.reply_text(f"{prs} <b>Mencari nomor untuk {country_id}...</b>")
        
        numbers = await get_numbers(country_id)
        
        if not numbers:
            await processing.edit_text(
                f"{ggl} <b>Negara '{country_id}' tidak ditemukan!</b>\n\n"
                f"Gunakan <code>.fakenumber</code> untuk lihat daftar negara."
            )
            return
        
        # Ambil 10 nomor random
        import random
        sample_numbers = random.sample(numbers, min(10, len(numbers)))
        
        # Cari info negara
        countries = await get_countries()
        country_name = country_id.upper()
        if countries:
            for c in countries:
                if c["id"] == country_id:
                    country_name = c["title"]
                    break
        
        text = f"<blockquote><b>📱 NOMOR TEMPORARY - {country_name}</b>\n\n"
        text += f"<b>Total tersedia:</b> {len(numbers)} nomor\n\n"
        
        for i, item in enumerate(sample_numbers, 1):
            number = item.get("number", "-")
            text += f"{i}. <code>{number}</code>\n"
        
        text += f"\n<b>Cara lihat pesan:</b>\n"
        text += f"<code>.lihatpesan [nomor]</code>\n\n"
        text += f"<b>Contoh:</b>\n"
        text += f"<code>.lihatpesan {sample_numbers[0]['number']}</code></blockquote>"
        
        await processing.delete()
        await message.reply_text(text)
        
    except Exception as e:
        await message.reply_text(f"{ggl} <b>Error: {str(e)[:100]}</b>")

@PY.UBOT("lihatpesan")
async def lihat_pesan(client: Client, message: Message):
    ggl = await EMO.GAGAL(client)
    prs = await EMO.PROSES(client)
    
    try:
        args = message.text.split(maxsplit=1)
        if len(args) < 2:
            await message.reply_text(
                f"<blockquote><b>❌ Format salah!</b>\n\n"
                f"<b>Contoh:</b>\n"
                f"<code>.lihatpesan +4368110717331</code>\n"
                f"<code>.lihatpesan 6281234567890</code></blockquote>"
            )
            return
        
        number = args[1].strip()
        
        processing = await message.reply_text(f"{prs} <b>Mencari pesan untuk {number}...</b>")
        
        messages = await get_messages(number)
        
        if not messages:
            await processing.edit_text(
                f"{ggl} <b>Tidak ada pesan untuk nomor {number}</b>\n\n"
                f"Coba nomor lain dengan <code>.fakenumber [negara]</code>"
            )
            return
        
        # Ambil 10 pesan terbaru
        messages = messages[:10]
        
        text = f"<blockquote><b>📨 PESAN MASUK - {number}</b>\n\n"
        
        for i, msg in enumerate(messages, 1):
            sender = msg.get("from", "Unknown")
            content = msg.get("content", "-")
            time_wib = format_time_wib(msg.get("time_wib", ""))
            
            # Batasi panjang pesan
            if len(content) > 50:
                content = content[:50] + "..."
            
            text += f"<b>{i}. {sender}</b> ({time_wib})\n"
            text += f"<code>{content}</code>\n\n"
        
        if len(messages) == 0:
            text += "<i>Belum ada pesan masuk</i>\n"
        
        text += "<b>Note:</b> Pesan akan hilang setelah beberapa waktu</blockquote>"
        
        await processing.delete()
        await message.reply_text(text)
        
    except Exception as e:
        await message.reply_text(f"{ggl} <b>Error: {str(e)[:100]}</b>")

@PY.UBOT("fakenumberinfo")
async def fake_number_info(client: Client, message: Message):
    """Info fitur fake number"""
    
    text = """
<blockquote><b>📱 INFO FAKE NUMBER</b>

<b>Sumber:</b> api.vreden.my.id
<b>Update:</b> Real-time

<b>Fitur:</b>
• 40+ negara tersedia
• Nomor temporary
• Lihat pesan masuk
• Support OTP verification

<b>Cara pakai:</b>
1. <code>.fakenumber</code> - Lihat daftar negara
2. <code>.fakenumber [id]</code> - Dapatkan nomor
3. <code>.lihatpesan [nomor]</code> - Cek pesan

<b>Contoh:</b>
<code>.fakenumber id</code> (Indonesia)
<code>.fakenumber us</code> (USA)
<code>.lihatpesan +4368110717331</code>

<b>Catatan:</b>
• Nomor aktif sementara
• Gunakan untuk verifikasi akun
• Jangan untuk spam/kejahatan</blockquote>"""
    
    await message.reply_text(text)