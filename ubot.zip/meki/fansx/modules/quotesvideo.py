import aiohttp
import filetype
import os
import requests
import random
from pyrogram import Client, filters
from pyrogram.types import Message
from fansx import *

# Daftar API keys By Zyura (12 key)
API_KEYS = [
    "eIxUwMpn",
    "keoCFdc6",
    "bv7m372F",
    "iAiB9QKT",
    "JP7Cy8Y2",
    "GI4vPxYv",
    "HRPga9TN",
    "PDwqhVsj",
    "m8jpBeZR",
    "PXkxh5hw",
    "MFnlpM6A",
    "u299UiOF"
]

def get_random_apikey():
    """Mengambil API key secara random dari daftar"""
    return random.choice(API_KEYS)

__MODULE__ = "ϙᴜᴏᴛᴇs ᴠɪᴅᴇᴏ"
__HELP__ = """
<b>⦪ ʙᴀɴᴛᴜᴀɴ ᴜɴᴛᴜᴋ ϙᴜᴏᴛᴇs ᴠɪᴅᴇᴏ ⦫</b>
<blockquote>
⎆ perintah :
ᚗ <code>{0}qvideo</code> [teks] (dengan reply ke video)

⎆ ᴘᴇɴᴊᴇʟᴀsᴀɴ:
⊶ Membuat Quotes video seperti tiktok dengan teks kustom

📌 Contoh:
• Reply ke video dengan caption: <code>.qvideo Makan Ayam</code>
• Reply ke video dengan caption: <code>.qvideo Cinta itu buta</code>
</blockquote>
"""

async def upload_media(m: Message):
    """Upload video ke catbox.moe"""
    media = await m.reply_to_message.download()
    try:
        with open(media, "rb") as file:
            file_data = file.read()
            ext = filetype.guess_extension(file_data) or "mp4"
        
        form_data = aiohttp.FormData()
        form_data.add_field("fileToUpload", open(media, "rb"), filename=f"video.{ext}")
        form_data.add_field("reqtype", "fileupload")
        
        async with aiohttp.ClientSession() as session:
            async with session.post("https://catbox.moe/user/api.php", data=form_data, timeout=30) as res:
                if res.status == 200:
                    url = await res.text()
                    return url.strip()
                else:
                    print(f"Upload failed: {res.status}")
                    return None
    except Exception as e:
        print(f"Upload error: {e}")
        return None
    finally:
        try:
            os.remove(media)
        except:
            pass

@PY.UBOT("qvideo")
async def quotesvideo_handler(client, message: Message):
    # Validasi: harus reply ke video
    if not message.reply_to_message or not message.reply_to_message.video:
        return await message.reply(
            "<blockquote><b>❌ Silakan balas ke sebuah video!</b>\n\n"
            "Cara penggunaan:\n"
            "1. Reply ke video\n"
            "2. Ketik: <code>.qvideo [teks]</code>\n\n"
            "Contoh: <code>.qvideo Makan Ayam</code></blockquote>"
        )

    # Ambil teks quotes
    query = " ".join(message.command[1:])
    if not query:
        return await message.reply(
            "<blockquote><b>❌ Silakan masukkan teks untuk quotes video!</b>\n\n"
            "Contoh: <code>.qvideo Makan Ayam</code></blockquote>"
        )

    msg = await message.reply("<blockquote><b>🔄 Mengunggah video ke server...</b></blockquote>")
    
    # Upload video ke catbox.moe
    video_url = await upload_media(message)

    if not video_url:
        return await msg.edit("<blockquote><b>❌ Gagal mengunggah video ke server!</b></blockquote>")

    await msg.edit("<blockquote><b>🎥 Membuat Quotes Video...</b></blockquote>")
    
    # Coba dengan beberapa API key
    success = False
    used_keys = set()
    max_attempts = min(3, len(API_KEYS))
    
    for attempt in range(max_attempts):
        available_keys = [key for key in API_KEYS if key not in used_keys]
        if not available_keys:
            break
            
        apikey = random.choice(available_keys)
        used_keys.add(apikey)
        
        try:
            # Buat URL API dengan key random
            api_url = f"https://api.botcahx.eu.org/api/maker/quotesvideo"
            params = {
                "url": video_url,
                "text": query,
                "apikey": apikey
            }
            
            print(f"Mencoba dengan key: {apikey[:8]}... (percobaan {attempt+1})")
            res = requests.get(api_url, params=params, timeout=30)

            if res.status_code == 200:
                data = res.json()
                
                if data.get("status") and "result" in data:
                    video_result_url = data["result"]
                    
                    # Kirim video hasil
                    await message.reply_video(
                        video_result_url,
                        caption=f"<blockquote><b>✅ Quotes Video Berhasil Dibuat!</b>\n\n"
                                f"📝 <b>Teks:</b> {query[:50]}{'...' if len(query) > 50 else ''}\n"
                                f"🔑 <b>Key:</b> <code>{apikey[:8]}...</code></blockquote>"
                    )
                    
                    await msg.delete()
                    success = True
                    break
                else:
                    # Jika response tidak valid, coba key lain
                    continue
            else:
                # Jika HTTP error, coba key lain
                continue
                
        except requests.exceptions.Timeout:
            continue
        except requests.exceptions.ConnectionError:
            continue
        except Exception as e:
            print(f"Error attempt {attempt+1}: {e}")
            continue
    
    if not success:
        await msg.edit(
            "<blockquote><b>❌ Gagal membuat quotes video setelah beberapa percobaan!</b>\n\n"
            "🔴 Kemungkinan penyebab:\n"
            "• API key habis limit\n"
            "• Server sedang sibuk\n"
            "• Video tidak valid\n\n"
            "🔄 Silakan coba lagi nanti.</blockquote>"
        )

@PY.BOT("qvideo")
async def quotesvideo_handler_bot(client, message: Message):
    # Validasi: harus reply ke video
    if not message.reply_to_message or not message.reply_to_message.video:
        return await message.reply(
            "❌ Silakan balas ke sebuah video!\n"
            "Cara: /qvideo [teks] (reply ke video)"
        )

    query = " ".join(message.command[1:])
    if not query:
        return await message.reply("❌ Masukkan teks quotes!\nContoh: /qvideo Makan Ayam")

    msg = await message.reply("🔄 Mengunggah video...")
    
    # Upload video ke catbox.moe
    video_url = await upload_media(message)

    if not video_url:
        return await msg.edit("❌ Gagal mengunggah video!")

    await msg.edit("🎥 Membuat Quotes Video...")
    
    # Coba dengan beberapa API key
    success = False
    used_keys = set()
    max_attempts = min(3, len(API_KEYS))
    
    for attempt in range(max_attempts):
        available_keys = [key for key in API_KEYS if key not in used_keys]
        if not available_keys:
            break
            
        apikey = random.choice(available_keys)
        used_keys.add(apikey)
        
        try:
            api_url = f"https://api.botcahx.eu.org/api/maker/quotesvideo"
            params = {
                "url": video_url,
                "text": query,
                "apikey": apikey
            }
            
            res = requests.get(api_url, params=params, timeout=30)

            if res.status_code == 200:
                data = res.json()
                
                if data.get("status") and "result" in data:
                    video_result_url = data["result"]
                    
                    await message.reply_video(
                        video_result_url,
                        caption=f"✅ Quotes Video: {query[:100]}"
                    )
                    
                    await msg.delete()
                    success = True
                    break
                else:
                    continue
            else:
                continue
                
        except Exception:
            continue
    
    if not success:
        await msg.edit("❌ Gagal membuat quotes video.")