from fansx import *
import requests
import os
import aiohttp
import asyncio
from pyrogram.enums import ChatAction, ParseMode
from pyrogram.types import Message
from urllib.parse import quote

__MODULE__ = "ᴇ-ᴋᴛᴘ"
__HELP__ = """
<blockquote><b>『 E-KTP MAKER 』</b>

<b>⌲ Perintah:</b>
ᚗ <code>{0}ektp [data]</code> 
⊶ Membuat E-KTP custom dengan foto profil

<b>⌲ Format Data:</b>
<code>key:value|key:value|key:value</code>

<b>⌲ Keys yang tersedia:</b>
• provinsi, kota, nik, nama, ttl, jk, gol
• alamat, rtrw, desa, kecamatan, agama
• status, kerja, warga, berlaku

<b>⌲ Contoh:</b>
<code>.ektp nik:1234567890|nama:John Doe|ttl:20-12-2000</code>
<code>.ektp nama:Budi Santoso|nik:3305123456|kota:JAKARTA</code>

<b>⌲ Catatan:</b>
• Reply ke gambar untuk pakai foto custom
• Tanpa reply akan pakai foto profil Telegram</blockquote>
"""

# Default PP jika gagal ambil foto
DEFAULT_PP = "https://i.ibb.co/6bWvFpg/avatar.jpg"

# Base URL API
API_URL = "https://zelapioffciall.koyeb.app/canvas/ektp"

# Default values untuk E-KTP
DEFAULTS = {
    'provinsi': 'JAWA TENGAH',
    'kota': 'KEBUMEN',
    'nik': '3305123456789012',
    'nama': 'JOHN DOE',
    'ttl': 'KEBUMEN, 01-01-2000',
    'jk': 'LAKI-LAKI',
    'gol': 'O',
    'alamat': 'JL. MERDEKA NO. 1',
    'rtrw': '001/002',
    'desa': 'DESA MAJU',
    'kecamatan': 'KEC. JAYA',
    'agama': 'ISLAM',
    'status': 'BELUM KAWIN',
    'kerja': 'PELAJAR/MAHASISWA',
    'warga': 'WNI',
    'berlaku': 'SEUMUR HIDUP'
}

# Mapping key input ke key yang benar
KEY_MAPPING = {
    'provinsi': 'provinsi',
    'kota': 'kota',
    'nik': 'nik',
    'nama': 'nama',
    'ttl': 'ttl',
    'jk': 'jenis_kelamin',
    'gol': 'golongan_darah',
    'alamat': 'alamat',
    'rtrw': 'rt_rw',
    'desa': 'kel_desa',
    'kecamatan': 'kecamatan',
    'agama': 'agama',
    'status': 'status',
    'kerja': 'pekerjaan',
    'warga': 'kewarganegaraan',
    'berlaku': 'masa_berlaku'
}

async def upload_to_uguu(file_path):
    """Upload gambar ke uguu.se"""
    try:
        async with aiohttp.ClientSession() as session:
            data = aiohttp.FormData()
            data.add_field('file', 
                          open(file_path, 'rb'),
                          filename='image.jpg',
                          content_type='image/jpeg')
            
            async with session.post('https://uguu.se/upload', data=data, timeout=30) as resp:
                if resp.status == 200:
                    result = await resp.json()
                    if result.get('files') and len(result['files']) > 0:
                        return result['files'][0]['url']
    except Exception as e:
        print(f"Upload error: {e}")
    return None

async def get_profile_pic(client, user_id):
    """Ambil foto profil Telegram user"""
    try:
        photos = await client.get_chat_photos(user_id, limit=1)
        if photos and len(photos) > 0:
            file_path = await client.download_media(photos[0].file_id)
            url = await upload_to_uguu(file_path)
            if os.path.exists(file_path):
                os.remove(file_path)
            return url or DEFAULT_PP
    except Exception as e:
        print(f"Profile pic error: {e}")
    return DEFAULT_PP

def parse_input(text):
    """Parse input dari user dengan format key:value"""
    data = DEFAULTS.copy()
    
    if not text:
        return data
    
    pairs = text.split('|')
    for pair in pairs:
        if ':' in pair:
            key, value = pair.split(':', 1)
            key = key.strip().lower()
            value = value.strip().upper()
            
            if key in KEY_MAPPING:
                data[key] = value
    
    return data

@PY.UBOT("ektp")
async def ektp_maker(client: Client, message: Message):
    ggl = await EMO.GAGAL(client)
    sks = await EMO.BERHASIL(client)
    prs = await EMO.PROSES(client)
    
    try:
        await client.send_chat_action(message.chat.id, ChatAction.TYPING)
        
        # Ambil input data
        args = message.text.split(maxsplit=1)
        input_data = args[1] if len(args) > 1 else ""
        
        # Tampilkan help kalo gaada input
        if not input_data:
            keys_list = ", ".join(KEY_MAPPING.keys())
            await message.reply_text(
                f"<blockquote><b>🪪 E-KTP MAKER</b>\n\n"
                f"<b>Format:</b> <code>.ektp key:value|key:value</code>\n\n"
                f"<b>Keys tersedia:</b>\n"
                f"<code>{keys_list}</code>\n\n"
                f"<b>Contoh:</b>\n"
                f"<code>.ektp nik:1234567890|nama:John Doe|ttl:20-12-2000</code>\n\n"
                f"<b>Catatan:</b>\n"
                f"• Reply ke gambar untuk pakai foto custom\n"
                f"• Tanpa reply akan pakai foto profil Telegram</blockquote>"
            )
            return
        
        # Kirim pesan processing
        processing = await message.reply_text(f"{prs} <b>Membuat E-KTP...</b>")
        
        # Parse input
        data = parse_input(input_data)
        
        # Cek apakah ada reply gambar
        photo_url = DEFAULT_PP
        has_reply_image = False
        
        if message.reply_to_message:
            if message.reply_to_message.photo:
                has_reply_image = True
                # Download foto
                file_path = await message.reply_to_message.download()
                await processing.edit_text(f"{prs} <b>Mengupload foto ke server...</b>")
                photo_url = await upload_to_uguu(file_path)
                if os.path.exists(file_path):
                    os.remove(file_path)
            elif message.reply_to_message.sticker:
                has_reply_image = True
                # Download sticker
                file_path = await message.reply_to_message.download()
                await processing.edit_text(f"{prs} <b>Mengupload sticker ke server...</b>")
                photo_url = await upload_to_uguu(file_path)
                if os.path.exists(file_path):
                    os.remove(file_path)
        
        # Kalo gaada reply gambar, ambil foto profil
        if not has_reply_image:
            await processing.edit_text(f"{prs} <b>Mengambil foto profil...</b>")
            photo_url = await get_profile_pic(client, message.from_user.id)
        
        if not photo_url:
            photo_url = DEFAULT_PP
        
        # Build URL API
        await processing.edit_text(f"{prs} <b>Menggenerate E-KTP...</b>")
        
        params = {
            'provinsi': data['provinsi'],
            'kota': data['kota'],
            'nik': data['nik'],
            'nama': data['nama'],
            'ttl': data['ttl'],
            'jenis_kelamin': data['jk'],
            'golongan_darah': data['gol'],
            'alamat': data['alamat'],
            'rt_rw': data['rtrw'],
            'kel_desa': data['desa'],
            'kecamatan': data['kecamatan'],
            'agama': data['agama'],
            'status': data['status'],
            'pekerjaan': data['kerja'],
            'kewarganegaraan': data['warga'],
            'masa_berlaku': data['berlaku'],
            'terbuat': data['kota'],
            'pas_photo': photo_url
        }
        
        # Encode parameters
        query_string = '&'.join([f"{k}={quote(str(v))}" for k, v in params.items()])
        full_url = f"{API_URL}?{query_string}"
        
        # Download hasil E-KTP
        async with aiohttp.ClientSession() as session:
            async with session.get(full_url, timeout=30) as resp:
                if resp.status == 200:
                    image_data = await resp.read()
                    
                    # Simpan sementara
                    file_path = f"ektp_{message.from_user.id}.jpg"
                    with open(file_path, 'wb') as f:
                        f.write(image_data)
                    
                    # Kirim gambar
                    await client.send_photo(
                        chat_id=message.chat.id,
                        photo=file_path,
                        caption=f"<blockquote><b>🪪 E-KTP BERHASIL DIBUAT</b>\n\n"
                                f"👤 <b>Nama:</b> {data['nama']}\n"
                                f"🆔 <b>NIK:</b> {data['nik']}\n"
                                f"📍 <b>Kota:</b> {data['kota']}</blockquote>"
                    )
                    
                    # Hapus file
                    if os.path.exists(file_path):
                        os.remove(file_path)
                    
                    await processing.delete()
                else:
                    await processing.edit_text(
                        f"{ggl} <b>Gagal membuat E-KTP! HTTP {resp.status}</b>"
                    )
        
    except requests.exceptions.Timeout:
        await message.reply_text(f"{ggl} <b>Timeout! Server sedang sibuk.</b>")
    except requests.exceptions.ConnectionError:
        await message.reply_text(f"{ggl} <b>Gagal terhubung ke server!</b>")
    except Exception as e:
        await message.reply_text(f"{ggl} <b>Error: {str(e)[:100]}</b>")

@PY.UBOT("ektphelp")
async def ektp_help(client: Client, message: Message):
    """Menampilkan bantuan lengkap E-KTP"""
    keys_list = "\n".join([f"• <code>{key}</code>" for key in KEY_MAPPING.keys()])
    
    await message.reply_text(
        f"<blockquote><b>🪪 PANDUAN E-KTP MAKER</b>\n\n"
        f"<b>Format perintah:</b>\n"
        f"<code>.ektp key:value|key:value</code>\n\n"
        f"<b>Keys yang tersedia:</b>\n"
        f"{keys_list}\n\n"
        f"<b>Contoh lengkap:</b>\n"
        f"<code>.ektp provinsi:JAWA TIMUR|kota:SURABAYA|nik:3515123456789012|nama:BUDI SANTOSO|ttl:SURABAYA, 17-08-2000|jk:LAKI-LAKI|gol:O|alamat:JL. MERDEKA NO. 10|rtrw:003/004|desa:SUKAMAJU|kecamatan:SUKOLILO|agama:ISLAM|status:BELUM KAWIN|kerja:PELAJAR|warga:WNI|berlaku:SEUMUR HIDUP</code>\n\n"
        f"<b>Catatan:</b>\n"
        f"• Reply ke gambar untuk pakai foto custom\n"
        f"• Tanpa reply akan pakai foto profil Telegram\n"
        f"• Semua value akan otomatis diubah ke UPPERCASE</blockquote>"
    )

@PY.BOT("ektp")
async def ektp_bot(client: Client, message: Message):
    """Handler untuk bot"""
    try:
        args = message.text.split(maxsplit=1)
        input_data = args[1] if len(args) > 1 else ""
        
        if not input_data:
            await message.reply_text(
                "🪪 *E-KTP MAKER*\n\n"
                "Format: /ektp key:value|key:value\n\n"
                "Keys: provinsi, kota, nik, nama, ttl, jk, gol, alamat, rtrw, desa, kecamatan, agama, status, kerja, warga, berlaku\n\n"
                "Contoh: /ektp nik:1234567890|nama:John Doe"
            )
            return
        
        processing = await message.reply_text("⏳ Membuat E-KTP...")
        
        # Parse input
        data = parse_input(input_data)
        
        # Ambil foto profil kalo ada
        photo_url = DEFAULT_PP
        if message.reply_to_message and message.reply_to_message.photo:
            file_path = await message.reply_to_message.download()
            photo_url = await upload_to_uguu(file_path)
            if os.path.exists(file_path):
                os.remove(file_path)
        else:
            photo_url = await get_profile_pic(client, message.from_user.id)
        
        # Build URL
        params = {
            'provinsi': data['provinsi'],
            'kota': data['kota'],
            'nik': data['nik'],
            'nama': data['nama'],
            'ttl': data['ttl'],
            'jenis_kelamin': data['jk'],
            'golongan_darah': data['gol'],
            'alamat': data['alamat'],
            'rt_rw': data['rtrw'],
            'kel_desa': data['desa'],
            'kecamatan': data['kecamatan'],
            'agama': data['agama'],
            'status': data['status'],
            'pekerjaan': data['kerja'],
            'kewarganegaraan': data['warga'],
            'masa_berlaku': data['berlaku'],
            'terbuat': data['kota'],
            'pas_photo': photo_url
        }
        
        query_string = '&'.join([f"{k}={quote(str(v))}" for k, v in params.items()])
        full_url = f"{API_URL}?{query_string}"
        
        async with aiohttp.ClientSession() as session:
            async with session.get(full_url, timeout=30) as resp:
                if resp.status == 200:
                    image_data = await resp.read()
                    file_path = f"ektp_bot_{message.from_user.id}.jpg"
                    with open(file_path, 'wb') as f:
                        f.write(image_data)
                    
                    await client.send_photo(
                        chat_id=message.chat.id,
                        photo=file_path,
                        caption=f"🪪 E-KTP: {data['nama']}"
                    )
                    
                    if os.path.exists(file_path):
                        os.remove(file_path)
                    
                    await processing.delete()
                else:
                    await processing.edit_text(f"❌ Gagal: HTTP {resp.status}")
        
    except Exception as e:
        await message.reply_text(f"❌ Error: {str(e)[:100]}")