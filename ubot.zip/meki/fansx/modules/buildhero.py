from fansx import *
import aiohttp
import asyncio
import os
import random
from pyrogram.enums import ChatAction, ParseMode
from pyrogram.types import Message

__MODULE__ = "sᴇᴀʀᴄʜ ʙᴜɪʟᴅ"
__HELP__ = """
<blockquote><b>⚔️ SEARCH BUILD MLBB</b>

<b>⌲ Perintah:</b>
ᚗ <code>{0}searchbuild [hero]</code> - Cari build terbaru untuk hero tertentu
ᚗ <code>{0}sb [hero]</code> - Singkatan

<b>⌲ Contoh:</b>
<code>.searchbuild zilong</code>
<code>.sb zilong</code></blockquote>
"""

# ============================================
# KONFIGURASI
# ============================================
API_BASE = "https://api.theresav.biz.id/game/ml/build"
API_KEY = "UYGSg"

# Daftar hero MLBB yang tersedia (bisa ditambah sendiri)
HERO_LIST = [
    "zilong", "layla", "balmond", "tigreal", "miya", "saber", "alucard", "franco",
    "karina", "chou", "clint", "nana", "akai", "rafaela", "eudora", "fanny",
    "lancelot", "gusion", "harley", "lesley", "grock", "selena", "aldous",
    "guinevere", "granger", "khufra", "ling", "lunox", "leomord", "harith"
]

async def search_hero_build(hero_name):
    """Cari build untuk hero tertentu"""
    url = f"{API_BASE}?hero={hero_name.lower()}&apikey={API_KEY}"
    
    try:
        async with aiohttp.ClientSession() as session:
            async with session.get(url, timeout=15) as response:
                if response.status == 200:
                    data = await response.json()
                    
                    if data.get("status") and data.get("builds"):
                        builds = data["builds"]
                        hero_info = data.get("hero", {})
                        
                        # Urutkan build berdasarkan created_at (paling baru)
                        sorted_builds = sorted(
                            builds, 
                            key=lambda x: x.get("created_at", ""), 
                            reverse=True
                        )
                        
                        return {
                            "success": True,
                            "hero": hero_info,
                            "builds": sorted_builds,
                            "total": len(sorted_builds)
                        }
                    else:
                        return {"success": False, "error": f"Hero '{hero_name}' tidak ditemukan"}
                else:
                    return {"success": False, "error": f"HTTP {response.status}"}
    except asyncio.TimeoutError:
        return {"success": False, "error": "Timeout - server terlalu lambat"}
    except Exception as e:
        return {"success": False, "error": str(e)}

def format_build_message(build_data, index=1):
    """Format pesan build biar rapi"""
    build = build_data
    author = build.get("author", {})
    emblem = build.get("emblem", {})
    battle_spell = build.get("battle_spell", {})
    items = build.get("items", [])
    patch = build.get("patch", {})
    
    # Format tanggal
    created_at = build.get("created_at", "")
    date_str = created_at[:10] if created_at else "Unknown"
    
    # Nama hero dari build (ambil dari data hero di luar)
    hero_name = "Unknown"
    
    message = f"<blockquote><b>⚔️ BUILD #{index}</b>\n\n"
    message += f"<b>📌 Judul:</b> {build.get('title', 'Untitled')}\n"
    message += f"<b>👤 Author:</b> {author.get('username', 'Unknown')}"
    if author.get("is_verified"):
        message += " ✓"
    message += f"\n"
    message += f"<b>📝 Deskripsi:</b> {build.get('description', 'Tidak ada deskripsi') or 'Tidak ada deskripsi'}\n"
    message += f"<b>📅 Patch:</b> {patch.get('version', 'Unknown')} - {patch.get('description', '')}\n"
    message += f"<b>🗓️ Dibuat:</b> {date_str}\n"
    message += f"<b>❤️ Likes:</b> {build.get('likes', 0)}\n\n"
    
    # Battle Spell
    message += f"<b>⚡ Battle Spell:</b> {battle_spell.get('name', 'Unknown')}\n"
    
    # Emblem
    message += f"<b>🛡️ Emblem:</b> {emblem.get('name', 'Unknown')}\n"
    if emblem.get("selected_tiers"):
        tiers = emblem["selected_tiers"]
        tier1 = tiers.get("tier1", {})
        tier2 = tiers.get("tier2", {})
        tier3 = tiers.get("tier3", {})
        message += f"  └ Tier 1: {tier1.get('name', '')}\n"
        message += f"  └ Tier 2: {tier2.get('name', '')}\n"
        message += f"  └ Tier 3: {tier3.get('name', '')}\n"
    
    # Items
    message += f"\n<b>📦 Items:</b>\n"
    for i, item in enumerate(items[:6], 1):
        message += f"  {i}. {item.get('name', 'Unknown')}\n"
    
    # Conditional items (opsional)
    cond_items = build.get("conditional_items", [])
    if cond_items:
        message += f"\n<b>🔄 Conditional Items:</b>\n"
        for item in cond_items[:3]:
            message += f"  • {item.get('name', 'Unknown')}\n"
    
    message += f"</blockquote>"
    
    return message

@PY.UBOT("searchbuild")
@PY.UBOT("sb")
async def search_build_command(client: Client, message: Message):
    ggl = await EMO.GAGAL(client)
    sks = await EMO.BERHASIL(client)
    prs = await EMO.PROSES(client)
    
    # Parse argumen (nama hero)
    args = message.text.split()
    if len(args) < 2:
        # Tampilkan daftar hero yang tersedia
        hero_list_text = "\n".join([f"ᚗ <code>{h}</code>" for h in sorted(HERO_LIST)[:30]])
        await message.reply_text(
            f"<blockquote><b>⚠️ FORMAT SALAH</b>\n\n"
            f"<b>Cara pakai:</b> <code>.searchbuild [nama_hero]</code>\n"
            f"<b>Contoh:</b> <code>.searchbuild zilong</code>\n\n"
            f"<b>📋 Daftar hero tersedia:</b>\n{hero_list_text}</blockquote>"
        )
        return
    
    hero_name = args[1].lower()
    
    try:
        await client.send_chat_action(message.chat.id, ChatAction.TYPING)
        
        processing = await message.reply_text(f"{prs} <b>Mencari build untuk {hero_name}...</b>")
        
        result = await search_hero_build(hero_name)
        
        await processing.delete()
        
        if result.get("success"):
            builds = result.get("builds", [])
            hero_info = result.get("hero", {})
            total = result.get("total", 0)
            
            if not builds:
                await message.reply_text(f"{ggl} <b>Tidak ada build ditemukan untuk {hero_name}</b>")
                return
            
            # Ambil maksimal 3 build terbaru
            max_builds = min(3, len(builds))
            sent_count = 0
            
            # Kirim info hero dulu
            hero_name_disp = hero_info.get("name", hero_name.title())
            hero_roles = ", ".join(hero_info.get("roles", []))
            hero_img = hero_info.get("image_url", "")
            
            info_text = f"<blockquote><b>⚔️ {hero_name_disp.upper()}</b>"
            if hero_roles:
                info_text += f"\n<b>Role:</b> {hero_roles}"
            info_text += f"\n<b>Total Build:</b> {total}"
            info_text += f"\n<b>Menampilkan:</b> {max_builds} build terbaru</blockquote>"
            
            await message.reply_text(info_text)
            
            # Kirim build satu per satu
            for i in range(max_builds):
                build = builds[i]
                build_msg = format_build_message(build, i+1)
                await message.reply_text(build_msg)
                await asyncio.sleep(0.5)  # Jeda biar gak kena flood
            
            await message.reply_text(f"{sks} <b>Berhasil menampilkan {max_builds} build terbaru untuk {hero_name_disp}</b>")
            
        else:
            error_msg = result.get("error", "Unknown error")
            await message.reply_text(
                f"<blockquote><b>❌ GAGAL MENCARI BUILD</b>\n\n"
                f"Error: {error_msg}</blockquote>"
            )
        
    except Exception as e:
        await message.reply_text(f"{ggl} <b>Error: {str(e)[:100]}</b>")
