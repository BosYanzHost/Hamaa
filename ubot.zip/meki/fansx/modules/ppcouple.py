from fansx import *
import aiohttp
import asyncio
import random
import os
from pyrogram.enums import ChatAction, ParseMode
from pyrogram.types import Message, InputMediaPhoto

__MODULE__ = "ᴘᴘ ᴄᴏᴜᴘʟᴇ"
__HELP__ = """
<blockquote><b>💑 RANDOM PP COUPLE</b>

<b>⌲ Perintah:</b>
ᚗ <code>{0}ppcouple</code> - Ambil random PP couple
ᚗ <code>{0}ppcp</code> - Singkatan

<b>⌲ Contoh:</b>
<code>.ppcouple</code>
<code>.ppcp</code>

<b>⌲ Hasil:</b>
• Foto profil cowok
• Foto profil cewek
• Bisa didownload berdua</blockquote>
"""

# ============================================
# KONFIGURASI
# ============================================
API_URL = "https://api.deline.web.id/random/ppcouple"

async def get_pp_couple():
    """Ambil random PP couple dari API"""
    try:
        async with aiohttp.ClientSession() as session:
            async with session.get(API_URL, timeout=15) as response:
                if response.status == 200:
                    data = await response.json()
                    if data.get("status") and data.get("result"):
                        result = data["result"]
                        return {
                            "cowo": result.get("cowo", ""),
                            "cewe": result.get("cewe", "")
                        }
    except Exception as e:
        print(f"Error get PP couple: {e}")
    return None

@PY.UBOT("ppcouple")
@PY.UBOT("ppcp")
async def random_pp_couple(client: Client, message: Message):
    ggl = await EMO.GAGAL(client)
    sks = await EMO.BERHASIL(client)
    prs = await EMO.PROSES(client)
    
    try:
        await client.send_chat_action(message.chat.id, ChatAction.UPLOAD_PHOTO)
        
        processing = await message.reply_text(f"{prs} <b>Mencari random PP couple...</b>")
        
        pp_data = await get_pp_couple()
        
        if not pp_data:
            await processing.edit_text(f"{ggl} <b>Gagal mengambil PP couple!</b>")
            return
        
        cowo_url = pp_data.get("cowo")
        cewe_url = pp_data.get("cewe")
        
        await processing.delete()
        
        # Kirim sebagai media group
        media_group = []
        
        if cowo_url:
            media_group.append(InputMediaPhoto(
                media=cowo_url,
                caption="👦 <b>PP Cowok</b>"
            ))
        
        if cewe_url:
            media_group.append(InputMediaPhoto(
                media=cewe_url,
                caption="👧 <b>PP Cewek</b>"
            ))
        
        if media_group:
            await client.send_media_group(
                chat_id=message.chat.id,
                media=media_group
            )
            
            await message.reply_text(
                f"<blockquote><b>✅ RANDOM PP COUPLE</b>\n\n"
                f"👦 <b>Cowok:</b> [Download]({cowo_url})\n"
                f"👧 <b>Cewek:</b> [Download]({cewe_url})\n\n"
                f"Ketik <code>.ppcouple</code> lagi untuk coba yang lain!</blockquote>",
                disable_web_page_preview=True
            )
        else:
            await message.reply_text(f"{ggl} <b>Gagal mendapatkan gambar!</b>")
        
    except Exception as e:
        await message.reply_text(f"{ggl} <b>Error: {str(e)[:100]}</b>")

@PY.UBOT("ppcowo")
async def pp_cowok(client: Client, message: Message):
    """Ambil PP cowok aja"""
    await get_single_pp(client, message, "cowo", "👦")

@PY.UBOT("ppcewe")
async def pp_cewek(client: Client, message: Message):
    """Ambil PP cewek aja"""
    await get_single_pp(client, message, "cewe", "👧")

async def get_single_pp(client: Client, message: Message, gender: str, emoji: str):
    ggl = await EMO.GAGAL(client)
    prs = await EMO.PROSES(client)
    
    try:
        processing = await message.reply_text(f"{prs} <b>Mencari PP {gender}...</b>")
        
        pp_data = await get_pp_couple()
        
        if not pp_data:
            await processing.edit_text(f"{ggl} <b>Gagal mengambil PP!</b>")
            return
        
        url = pp_data.get(gender)
        
        if not url:
            await processing.edit_text(f"{ggl} <b>Gagal mendapatkan URL!</b>")
            return
        
        await processing.delete()
        
        await client.send_photo(
            chat_id=message.chat.id,
            photo=url,
            caption=f"{emoji} <b>PP {gender.title()}</b>\n\nDownload: {url}"
        )
        
    except Exception as e:
        await message.reply_text(f"{ggl} <b>Error: {str(e)[:100]}</b>")

@PY.UBOT("ppinfocouple")
async def pp_couple_info(client: Client, message: Message):
    """Info fitur PP couple"""
    
    text = """
<blockquote><b>💑 INFO PP COUPLE</b>

<b>Sumber:</b> API Deline
<b>Update:</b> Random setiap request

<b>Fitur:</b>
• <code>.ppcouple</code> - Dapatkan PP cowok + cewek
• <code>.ppcp</code> - Singkatan
• <code>.ppcowo</code> - PP cowok aja
• <code>.ppcewe</code> - PP cewek aja

<b>Cara pakai:</b>
<code>.ppcouple</code>
<code>.ppcowo</code>
<code>.ppcewe</code>

<b>Hasil:</b>
2 foto dikirim sekaligus dalam 1 pesan
Cocok buat pasangan yang mau ganti PP bareng</blockquote>"""
    
    await message.reply_text(text)