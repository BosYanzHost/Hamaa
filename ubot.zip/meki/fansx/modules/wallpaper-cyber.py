from fansx import *
import aiohttp
import asyncio
import random
import os
from pyrogram.enums import ChatAction
from pyrogram.types import Message

__MODULE__ = "ᴡᴀʟʟᴘᴀᴘᴇʀ ᴄʏʙᴇʀsᴘᴀᴄᴇ"
__HELP__ = """
<blockquote><b>💻 WALLPAPER CYBERSPACE</b>

<b>⌲ Perintah:</b>
ᚗ <code>{0}cyber</code> - Ambil random wallpaper cyberspace
ᚗ <code>{0}cyberwall</code> - Singkatan

<b>⌲ Contoh:</b>
<code>.cyber</code>
<code>.cyberwall</code></blockquote>
"""

# ============================================
# DAFTAR API KEYS (13 KEY)
# ============================================
API_KEYS = [
    "eIxUwMpn",
    "keoCFdc6",
    "bv7m372F",
    "iAiB9QKT",
    "JP7Cy8Y2",
    "GI4vPxYv",
    "HRPga9TN",
    "PDwqhVsj",
    "m8jpBeZR",
    "PXkxh5hw",
    "MFnlpM6A",
    "u299UiOF",
    "vQs76jBD"
]

# Base URL
BASE_URL = "https://api.botcahx.eu.org/api/wallpaper/cyberspace"

def get_random_apikey():
    """Mengambil API key random dari daftar"""
    return random.choice(API_KEYS)

async def get_cyber_wallpaper(retry_count=0, max_retries=3):
    """Ambil wallpaper cyberspace dari API dengan retry"""
    
    api_key = get_random_apikey()
    url = f"{BASE_URL}?apikey={api_key}"
    
    print(f"🔄 Mencoba dengan key {api_key[:8]}... (percobaan ke-{retry_count + 1})")
    
    try:
        async with aiohttp.ClientSession() as session:
            async with session.get(url, timeout=15) as response:
                if response.status == 200:
                    # Cek content-type
                    content_type = response.headers.get("Content-Type", "").lower()
                    
                    if "image" in content_type:
                        # Jika langsung gambar
                        return {
                            "success": True,
                            "image": await response.read(),
                            "api_key": api_key
                        }
                    else:
                        # Mungkin JSON response dengan URL gambar
                        try:
                            data = await response.json()
                            if data.get("status") and data.get("result"):
                                img_url = data["result"]
                                # Download gambar dari URL
                                async with session.get(img_url, timeout=15) as img_resp:
                                    if img_resp.status == 200:
                                        return {
                                            "success": True,
                                            "image": await img_resp.read(),
                                            "api_key": api_key
                                        }
                        except:
                            pass
                        
                        # Jika bukan gambar
                        return {
                            "success": False,
                            "error": "API tidak mengembalikan gambar",
                            "api_key": api_key
                        }
                else:
                    raise Exception(f"HTTP {response.status}")
                    
    except Exception as e:
        if retry_count < max_retries - 1:
            print(f"❌ Gagal dengan key {api_key[:8]}..., coba key lain...")
            await asyncio.sleep(1)
            return await get_cyber_wallpaper(retry_count + 1, max_retries)
        
        return {
            "success": False,
            "error": str(e),
            "api_key": api_key
        }

@PY.UBOT("cyber")
@PY.UBOT("cyberwall")
async def cyber_wallpaper_command(client: Client, message: Message):
    ggl = await EMO.GAGAL(client)
    sks = await EMO.BERHASIL(client)
    prs = await EMO.PROSES(client)
    
    try:
        await client.send_chat_action(message.chat.id, ChatAction.UPLOAD_PHOTO)
        
        processing = await message.reply_text(f"{prs} <b>Mencari wallpaper cyberspace...</b>")
        
        result = await get_cyber_wallpaper()
        
        await processing.delete()
        
        if result.get("success") and result.get("image"):
            # Simpan gambar sementara
            file_path = f"cyber_{message.from_user.id}_{random.randint(1000,9999)}.jpg"
            with open(file_path, "wb") as f:
                f.write(result["image"])
            
            # Kirim gambar
            await client.send_photo(
                chat_id=message.chat.id,
                photo=file_path,
                caption=f"<blockquote><b>💻 WALLPAPER CYBERSPACE</b>\n\n</blockquote>"
            )
            
            # Hapus file
            if os.path.exists(file_path):
                os.remove(file_path)
        else:
            error_msg = result.get("error", "Unknown error")
            api_key = result.get("api_key", "?")
            
            await message.reply_text(
                f"<blockquote><b>❌ GAGAL MENGAMBIL WALLPAPER</b>\n\n"
                f"Error: {error_msg}\n</blockquote>"
            )
        
    except Exception as e:
        await message.reply_text(f"{ggl} <b>Error: {str(e)[:100]}</b>")

