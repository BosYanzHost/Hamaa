import requests
from datetime import datetime, timedelta
from pyrogram import Client, filters
from pyrogram.types import InlineKeyboardMarkup, InlineKeyboardButton
from bs4 import BeautifulSoup
import random
from fansx import *

__MODULE__ = "ᴛᴇᴍᴘ ᴍᴀɪʟ"
__HELP__ = """
<b>⦪ ʙᴀɴᴛᴜᴀɴ ᴜɴᴛᴜᴋ ᴛᴇᴍᴘ ᴍᴀɪʟ ⦫</b>
<blockquote>⎆ perintah :
ᚗ <code>{0}tempmail</code>
⊶ untuk untuk membuat email gratis

ᚗ <code>{0}cekmail</code>
⊶ untuk mengecek pesan masuk email

ᚗ <code>{0}resetmail</code>
⊶ untuk mereset email</blockquote>
"""

# Daftar API keys By Zyura kalau exp buat sendiri yah🗿
API_KEYS = [
    "eIxUwMpn",
    "keoCFdc6",
    "bv7m372F",
    "iAiB9QKT",
    "JP7Cy8Y2",
    "GI4vPxYv",
    "HRPga9TN",
    "PDwqhVsj",
    "m8jpBeZR",
    "PXkxh5hw",
    "MFnlpM6A",
    "u299UiOF"
]

def get_random_apikey():
    """Mengambil API key secara random dari daftar"""
    return random.choice(API_KEYS)

sessions_mail = {}

def fetch_json(url):
    try:
        resp = requests.get(url, timeout=10)
        print(f"Response: {resp.text[:200]}...")  # Print preview response
        return resp.json()
    except requests.exceptions.Timeout:
        return {"error": "timeout", "status": False}
    except requests.exceptions.ConnectionError:
        return {"error": "connection_error", "status": False}
    except requests.exceptions.RequestException as e:
        return {"error": str(e), "status": False}
    except ValueError as e:
        return {"error": f"Invalid JSON: {str(e)}", "status": False}

def extract_text(html):
    try:
        soup = BeautifulSoup(html, "html.parser")
        return soup.get_text().strip()
    except Exception as e:
        return html.strip() if isinstance(html, str) else str(html)

@PY.UBOT("tempmail")
async def temp_mail(client, message):
    user_id = message.from_user.id

    # Bersihkan sesi yang expired (lebih dari 30 menit)
    expired_sessions = [uid for uid, data in sessions_mail.items() if datetime.utcnow() - data["created_at"] > timedelta(minutes=30)]
    for uid in expired_sessions:
        del sessions_mail[uid]

    # Jika user sudah punya email aktif
    if user_id in sessions_mail:
        email = sessions_mail[user_id]["email"]
        created_at = sessions_mail[user_id]["created_at"]
        remaining_time = 30 - int((datetime.utcnow() - created_at).total_seconds() / 60)
        if remaining_time < 0:
            remaining_time = 0
            
        return await message.reply_text(
            f"<blockquote><b>✅ Temp Mail Aktif</b>\n\n"
            f"📩 <b>Email:</b> <code>{email}</code>\n"
            f"⏳ <b>Sisa Waktu:</b> {remaining_time} menit\n\n"
            f"➡️ Gunakan <code>.cekmail</code> untuk cek pesan\n"
            f"➡️ Gunakan <code>.resetmail</code> untuk email baru</blockquote>"
        )

    # Kirim pesan processing
    processing = await message.reply_text("<blockquote><b>⏳ Membuat email sementara...</b></blockquote>")
    
    # Coba dengan beberapa API key
    success = False
    used_keys = set()
    max_attempts = min(3, len(API_KEYS))
    
    for attempt in range(max_attempts):
        available_keys = [key for key in API_KEYS if key not in used_keys]
        if not available_keys:
            break
            
        apikey = random.choice(available_keys)
        used_keys.add(apikey)
        
        try:
            url = f"https://api.botcahx.eu.org/api/tools/create-temp-mail?apikey={apikey}"
            data = fetch_json(url)
            
            if data.get("status") and "result" in data:
                email = data["result"]
                sessions_mail[user_id] = {
                    "email": email,
                    "created_at": datetime.utcnow(),
                    "last_checked_at": datetime.utcnow(),
                    "apikey": apikey  # Simpan key yang berhasil
                }
                
                await processing.edit_text(
                    f"<blockquote><b>✅ Temp Mail Berhasil Dibuat!</b>\n\n"
                    f"📩 <b>Email:</b> <code>{email}</code>\n"
                    f"⏳ <b>Masa Aktif:</b> 30 menit\n"
                    f"🔑 <b>Key:</b> <code>{apikey[:8]}...</code>\n\n"
                    f"➡️ Gunakan <code>.cekmail</code> untuk cek pesan\n"
                    f"➡️ Gunakan <code>.resetmail</code> untuk email baru</blockquote>"
                )
                success = True
                break
            else:
                continue
                
        except Exception as e:
            print(f"Error attempt {attempt+1}: {str(e)}")
            continue
    
    if not success:
        await processing.edit_text(
            "<blockquote><b>❌ Gagal membuat email sementara!</b>\n\n"
            "🔴 Semua API key mungkin habis limit atau server error.\n"
            "🔄 Silakan coba lagi nanti.</blockquote>"
        )

@PY.UBOT("cekmail")
async def check_mail(client, message):
    user_id = message.from_user.id

    if user_id not in sessions_mail:
        return await message.reply_text(
            "<blockquote><b>⚠️ Anda belum memiliki Temp Mail!</b>\n"
            "Gunakan <code>.tempmail</code> untuk membuatnya.</blockquote>"
        )

    email = sessions_mail[user_id]["email"]
    created_at = sessions_mail[user_id]["created_at"]
    
    # Cek apakah email sudah expired
    if datetime.utcnow() - created_at > timedelta(minutes=30):
        del sessions_mail[user_id]
        return await message.reply_text(
            "<blockquote><b>⚠️ Email Anda sudah expired (30 menit)!</b>\n"
            "Gunakan <code>.tempmail</code> untuk membuat email baru.</blockquote>"
        )
    
    sessions_mail[user_id]["last_checked_at"] = datetime.utcnow()
    
    processing = await message.reply_text("<blockquote><b>🔍 Mengecek pesan masuk...</b></blockquote>")
    
    # Ambil API key yang tersimpan atau random
    apikey = sessions_mail[user_id].get("apikey", get_random_apikey())
    
    url = f"https://api.botcahx.eu.org/api/tools/cek-msg-tmp-mail?email={email}&apikey={apikey}"
    data = fetch_json(url)

    if not data.get("status"):
        # Coba dengan key lain jika gagal
        apikey = get_random_apikey()
        url = f"https://api.botcahx.eu.org/api/tools/cek-msg-tmp-mail?email={email}&apikey={apikey}"
        data = fetch_json(url)
        
        if not data.get("status"):
            return await processing.edit_text(
                "<blockquote><b>⚠️ Gagal mengambil pesan email!</b>\n"
                "🔄 Silakan coba lagi nanti.</blockquote>"
            )

    messages = data.get("result", [])
    
    if not messages:
        remaining_time = 30 - int((datetime.utcnow() - created_at).total_seconds() / 60)
        return await processing.edit_text(
            f"<blockquote><b>📭 Belum Ada Pesan</b>\n\n"
            f"📩 <b>Email:</b> <code>{email}</code>\n"
            f"⏳ <b>Sisa Waktu:</b> {remaining_time} menit\n\n"
            f"💡 Coba cek lagi nanti setelah mengirim email ke alamat ini.</blockquote>"
        )

    pesan_list = []
    for i, msg in enumerate(messages[:5], 1):  # Batasi 5 pesan teratas
        pengirim = msg.get("sf", "Tidak diketahui")
        subjek = msg.get("s", "Tidak diketahui")
        waktu = msg.get("cr", "Waktu tidak tersedia")
        isi_pesan = msg.get("html") or msg.get("text") or "Tidak ada isi"
        isi_pesan = str(isi_pesan).strip()
        isi_pesan = extract_text(isi_pesan)[:200] + "..." if len(isi_pesan) > 200 else isi_pesan

        pesan_list.append(
            f"<b>📬 Pesan #{i}</b>\n"
            f"┣ 💌 <b>Dari:</b> <code>{pengirim}</code>\n"
            f"┣ 🕒 <b>Waktu:</b> <code>{waktu}</code>\n"
            f"┣ 📚 <b>Subjek:</b> {subjek}\n"
            f"┗ 📜 <b>Isi:</b> <i>{isi_pesan}</i>"
        )

    hasil = "<blockquote>\n" + "\n\n".join(pesan_list) + "\n</blockquote>"
    
    remaining_time = 30 - int((datetime.utcnow() - created_at).total_seconds() / 60)
    footer = f"\n<blockquote><b>📩 Email:</b> <code>{email}</code>\n⏳ <b>Sisa Waktu:</b> {remaining_time} menit</blockquote>"
    
    await processing.edit_text(hasil + footer, disable_web_page_preview=True)

@PY.UBOT("resetmail")
async def reset_mail(client, message):
    user_id = message.from_user.id

    processing = await message.reply_text("<blockquote><b>⏳ Mereset email...</b></blockquote>")
    
    # Hapus sesi lama
    if user_id in sessions_mail:
        del sessions_mail[user_id]
    
    # Coba dengan beberapa API key
    success = False
    used_keys = set()
    max_attempts = min(3, len(API_KEYS))
    
    for attempt in range(max_attempts):
        available_keys = [key for key in API_KEYS if key not in used_keys]
        if not available_keys:
            break
            
        apikey = random.choice(available_keys)
        used_keys.add(apikey)
        
        try:
            url = f"https://api.botcahx.eu.org/api/tools/create-temp-mail?apikey={apikey}"
            data = fetch_json(url)
            
            if data.get("status") and "result" in data:
                email = data["result"]
                sessions_mail[user_id] = {
                    "email": email,
                    "created_at": datetime.utcnow(),
                    "last_checked_at": datetime.utcnow(),
                    "apikey": apikey
                }
                
                await processing.edit_text(
                    f"<blockquote><b>✅ Email Baru Berhasil Dibuat!</b>\n\n"
                    f"📩 <b>Email:</b> <code>{email}</code>\n"
                    f"⏳ <b>Masa Aktif:</b> 30 menit\n"
                    f"🔑 <b>Key:</b> <code>{apikey[:8]}...</code>\n\n"
                    f"➡️ Gunakan <code>.cekmail</code> untuk cek pesan</blockquote>"
                )
                success = True
                break
            else:
                continue
                
        except Exception as e:
            print(f"Error attempt {attempt+1}: {str(e)}")
            continue
    
    if not success:
        await processing.edit_text(
            "<blockquote><b>❌ Gagal membuat email baru!</b>\n\n"
            "🔴 Semua API key mungkin habis limit.\n"
            "🔄 Silakan coba lagi nanti.</blockquote>"
        )