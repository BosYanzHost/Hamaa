from fansx import *
import random
import asyncio
from pyrogram.enums import ChatAction
from pyrogram.types import Message

__MODULE__ = "ᴄᴇᴋ ʙᴀɪᴋ"
__HELP__ = """
<blockquote><b>『 CEK TINGKAT KEBAIKAN 』</b>

<b>⌲ Perintah:</b>
ᚗ <code>{0}baik [nama]</code> 
⊶ Mengecek seberapa baik seseorang

<b>⌲ Contoh:</b>
<code>.baik</code> (untuk cek diri sendiri)
<code>.baik Budi</code> (untuk cek orang lain)
<code>.baik @username</code></blockquote>
"""

def get_description(percent):
    """Mendapatkan deskripsi berdasarkan persentase"""
    if percent >= 90:
        return "MALAIKAT! Baik banget! 😇✨"
    elif percent >= 70:
        return "Baik hati banget! 💝"
    elif percent >= 50:
        return "Lumayan baik 😊"
    elif percent >= 30:
        return "Sedikit baik 🙂"
    else:
        return "Hmm, perlu introspeksi? 🤔"

@PY.UBOT("baik")
async def cek_baik(client: Client, message: Message):
    ggl = await EMO.GAGAL(client)
    sks = await EMO.BERHASIL(client)
    prs = await EMO.PROSES(client)
    
    try:
        await client.send_chat_action(message.chat.id, ChatAction.TYPING)
        
        # Ambil nama dari input atau reply
        nama = "Kamu"
        
        # Cek apakah reply ke user
        if message.reply_to_message and message.reply_to_message.from_user:
            user = message.reply_to_message.from_user
            nama = user.first_name
            if user.last_name:
                nama += f" {user.last_name}"
        
        # Cek dari argumen
        args = message.text.split(maxsplit=1)
        if len(args) > 1:
            input_nama = args[1].strip()
            
            # Cek apakah mention @username
            if input_nama.startswith('@'):
                try:
                    user = await client.get_users(input_nama)
                    nama = user.first_name
                    if user.last_name:
                        nama += f" {user.last_name}"
                except:
                    nama = input_nama
            else:
                nama = input_nama
        
        # Jika tidak ada input dan tidak reply, pakai nama sender
        elif nama == "Kamu":
            nama = message.from_user.first_name
            if message.from_user.last_name:
                nama += f" {message.from_user.last_name}"
        
        # Generate random persentase
        percent = random.randint(0, 100)
        desc = get_description(percent)
        
        # Buat progress bar visual
        bar_length = 20
        filled_length = int(bar_length * percent / 100)
        bar = '█' * filled_length + '░' * (bar_length - filled_length)
        
        # Kirim pesan processing dulu (biar ada efek)
        processing = await message.reply_text(f"{prs} <b>Mengecek tingkat kebaikan {nama}...</b>")
        
        # Tunggu bentar biar keliatan prosesnya
        await asyncio.sleep(1)
        
        # Format pesan
        txt = f"""
<blockquote><b>😇 CEK TINGKAT KEBAIKAN</b>

<b>👤 Nama:</b> <code>{nama}</code>
<b>📊 Tingkat:</b> <code>{percent}%</code>

<code>{bar}</code>

<b>💬 {desc}</b></blockquote>
"""
        
        await processing.edit_text(txt)
        
    except Exception as e:
        await message.reply_text(f"{ggl} <b>Error: {str(e)[:100]}</b>")

@PY.UBOT("cekbaik")
async def cek_baik_alias(client: Client, message: Message):
    """Alias untuk baik"""
    await cek_baik(client, message)

@PY.UBOT("kind")
async def kind_alias(client: Client, message: Message):
    """Alias untuk baik"""
    await cek_baik(client, message)

@PY.BOT("baik")
async def cek_baik_bot(client: Client, message: Message):
    """Handler untuk bot"""
    try:
        nama = "Kamu"
        
        if message.reply_to_message and message.reply_to_message.from_user:
            user = message.reply_to_message.from_user
            nama = user.first_name
            if user.last_name:
                nama += f" {user.last_name}"
        
        args = message.text.split(maxsplit=1)
        if len(args) > 1:
            input_nama = args[1].strip()
            if input_nama.startswith('@'):
                try:
                    user = await client.get_users(input_nama)
                    nama = user.first_name
                    if user.last_name:
                        nama += f" {user.last_name}"
                except:
                    nama = input_nama
            else:
                nama = input_nama
        
        percent = random.randint(0, 100)
        desc = get_description(percent)
        
        bar_length = 15
        filled_length = int(bar_length * percent / 100)
        bar = '█' * filled_length + '░' * (bar_length - filled_length)
        
        txt = f"""
😇 *CEK KEBAIKAN*

👤 Nama: {nama}
📊 Tingkat: {percent}%

{bar}

💬 {desc}
"""
        await message.reply_text(txt)
        
    except Exception as e:
        await message.reply_text(f"❌ Error: {str(e)[:100]}")