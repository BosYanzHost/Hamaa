import requests
import qrcode
import random
import string
import time
import os
import json
from datetime import datetime
from pyrogram import Client, filters
from pyrogram.types import InlineKeyboardMarkup, InlineKeyboardButton
from fansx import PY

__MODULE__ = "ǫʀɪs ɢᴇɴᴇʀᴀᴛᴏʀ"
__HELP__ = """
<blockquote><b>Bantuan Untuk QRIS Generator</b>

Perintah:
<code>{0}qris [nominal]</code> → Membuat QRIS sesuai nominal
<code>{0}cekqris [order_id]</code> → Cek status transaksi
<code>{0}cancelqris [order_id]</code> → Batalkan transaksi
<code>{0}settqris</code> → Mengatur konfigurasi Pakasir (Owner only)

Fitur:
• Generate QRIS Pembayaran
• Cek Status Transaksi
• Cancel Transaksi
• Konfigurasi dinamis

Sumber: API Pakasir.</blockquote>
"""

# File untuk menyimpan konfigurasi
CONFIG_FILE = "pakasir_config.json"

# Default config
DEFAULT_CONFIG = {
    "project_slug": "bot-auto-order-kedua",
    "api_key": "g8FaRZx34fMTINlSqF8nh83efy6yoTts"
}
# Database sementara untuk menyimpan transaksi
transactions = {}

def load_config():
    """Load konfigurasi dari file"""
    try:
        if os.path.exists(CONFIG_FILE):
            with open(CONFIG_FILE, 'r') as f:
                return json.load(f)
    except Exception as e:
        print(f"Error loading config: {e}")
    return DEFAULT_CONFIG.copy()

def save_config(config):
    """Simpan konfigurasi ke file"""
    try:
        with open(CONFIG_FILE, 'w') as f:
            json.dump(config, f, indent=4)
        return True
    except Exception as e:
        print(f"Error saving config: {e}")
        return False

# Load config saat startup
pakasir_config = load_config()

def generate_order_id():
    """Generate random order ID"""
    timestamp = datetime.now().strftime("%y%m%d")
    random_chars = ''.join(random.choices(string.ascii_uppercase + string.digits, k=6))
    return f"{timestamp}{random_chars}"

@PY.UBOT("settqris")
async def set_pakasir(client, message):
    """Mengatur konfigurasi Pakasir"""
    args = message.text.split()
    if len(args) < 3:
        # Tampilkan form pengaturan
        buttons = InlineKeyboardMarkup([
            [InlineKeyboardButton("🔄 Reset ke Default", callback_data="reset_pakasir")],
            [InlineKeyboardButton("❌ Batal", callback_data="close")]
        ])
        
        current = pakasir_config
        await message.reply(
            f"<blockquote><b>⚙️ KONFIGURASI PAKASIR</b>\n\n"
            f"📌 <b>Project Slug:</b> <code>{current['project_slug']}</code>\n"
            f"🔑 <b>API Key:</b> <code>{current['api_key'][:10]}...{current['api_key'][-5:]}</code>\n\n"
            f"<b>Cara mengubah:</b>\n"
            f"<code>.settqris [slug] [api_key]</code>\n\n"
            f"<b>Contoh:</b>\n"
            f"<code>.settqris projekbaru xxxxxxxx</code></blockquote>",
            reply_markup=buttons
        )
        return
    
    slug = args[1]
    api_key = args[2]
    
    # Update config
    pakasir_config["project_slug"] = slug
    pakasir_config["api_key"] = api_key
    
    if save_config(pakasir_config):
        await message.reply(
            f"<blockquote><b>✅ Konfigurasi Pakasir berhasil diupdate!</b>\n\n"
            f"📌 <b>Project Slug:</b> <code>{slug}</code>\n"
            f"🔑 <b>API Key:</b> <code>{api_key[:10]}...{api_key[-5:]}</code></blockquote>"
        )
    else:
        await message.reply("❌ Gagal menyimpan konfigurasi!")

@PY.UBOT("qris")
@PY.TOP_CMD
async def create_qris(client, message):
    # Bisa digunakan oleh semua user atau hanya owner (sesuaikan)
    # if not is_owner(message.from_user.id):
    #     return await message.reply("❌ Anda tidak memiliki izin untuk menggunakan fitur ini!")
    
    msg = await message.reply("⏳ Sedang memproses QRIS...")

    # Ambil nominal dari pesan
    args = message.text.split()
    if len(args) < 2:
        return await msg.edit("❌ Format salah! Gunakan: <code>.qris [nominal]</code>\nContoh: <code>.qris 10000</code>")
    
    try:
        NOMINAL = int(args[1])
        if NOMINAL < 1000:
            return await msg.edit("❌ Minimal nominal Rp1.000!")
    except ValueError:
        return await msg.edit("❌ Nominal harus berupa angka!")

    # Generate order_id
    order_id = generate_order_id()
    
    # Kirim request ke API Pakasir untuk create transaction
    url = f"https://app.pakasir.com/api/transactioncreate/qris"
    
    payload = {
        "project": pakasir_config["project_slug"],
        "order_id": order_id,
        "amount": NOMINAL,
        "api_key": pakasir_config["api_key"]
    }

    try:
        response = requests.post(url, json=payload, timeout=15)
        
        if response.status_code == 200:
            data = response.json()
            
            if "payment" in data:
                payment_data = data["payment"]
                qris_code = payment_data.get("payment_number", "")
                total_payment = payment_data.get("total_payment", NOMINAL)
                fee = payment_data.get("fee", 0)
                expired_at = payment_data.get("expired_at", "")
                
                # Simpan transaksi
                transactions[order_id] = {
                    "order_id": order_id,
                    "amount": NOMINAL,
                    "total_payment": total_payment,
                    "fee": fee,
                    "qris_code": qris_code,
                    "expired_at": expired_at,
                    "status": "pending",
                    "created_at": datetime.now().isoformat(),
                    "user_id": message.from_user.id,
                    "chat_id": message.chat.id,
                    "username": message.from_user.username or message.from_user.first_name
                }
                
                # Generate QR Code dari qris_code
                qr = qrcode.QRCode(version=1, box_size=10, border=5)
                qr.add_data(qris_code)
                qr.make(fit=True)
                
                # Simpan QR ke file
                qr_filename = f"qris_{order_id}.png"
                img = qr.make_image(fill="black", back_color="white")
                img.save(qr_filename)
                
                # Format waktu expired
                try:
                    expired_dt = datetime.fromisoformat(expired_at.replace('Z', '+00:00'))
                    expired_str = expired_dt.strftime("%d/%m/%Y %H:%M:%S")
                except:
                    expired_str = expired_at
                
                caption = f"""
<blockquote><b>✅ QRIS BERHASIL DIBUAT</b>

💰 <b>Nominal:</b> Rp{NOMINAL:,}
💳 <b>Total Bayar:</b> Rp{total_payment:,}
📊 <b>Fee:</b> Rp{fee:,}
🆔 <b>Order ID:</b> <code>{order_id}</code>
⏰ <b>Expired:</b> {expired_str}

📌 <b>Scan QRIS di atas untuk membayar</b>

🔍 <b>Cek Status:</b> <code>.cekqris {order_id}</code>
❌ <b>Batalkan:</b> <code>.cancelqris {order_id}</code>
</blockquote>"""
                
                # Tambahkan button untuk cek status
                buttons = InlineKeyboardMarkup([
                    [
                        InlineKeyboardButton("🔄 Cek Status", callback_data=f"cek_{order_id}"),
                        InlineKeyboardButton("❌ Batalkan", callback_data=f"cancel_{order_id}")
                    ]
                ])
                
                await client.send_photo(
                    chat_id=message.chat.id,
                    photo=qr_filename,
                    caption=caption,
                    reply_markup=buttons
                )
                
                # Hapus file QR
                os.remove(qr_filename)
                
                await msg.delete()
                
            else:
                await msg.edit(f"❌ Gagal membuat QRIS: Response tidak valid")
                
        else:
            error_text = response.text
            if "invalid api key" in error_text.lower():
                await msg.edit("❌ API Key tidak valid! Gunakan <code>.setpakasir</code> untuk mengatur ulang.")
            elif "project" in error_text.lower():
                await msg.edit("❌ Project Slug tidak valid! Gunakan <code>.setpakasir</code> untuk mengatur ulang.")
            else:
                await msg.edit(f"❌ Gagal membuat QRIS: HTTP {response.status_code}\n{error_text[:200]}")

    except requests.exceptions.Timeout:
        await msg.edit("❌ Timeout! Server sedang sibuk.")
    except requests.exceptions.ConnectionError:
        await msg.edit("❌ Gagal terhubung ke server Pakasir!")
    except Exception as e:
        await msg.edit(f"❌ Error: {str(e)}")

@PY.UBOT("cekqris")
async def check_qris(client, message):
    """Cek status transaksi QRIS"""
    msg = await message.reply("⏳ Mengecek status transaksi...")
    
    args = message.text.split()
    if len(args) < 2:
        return await msg.edit("❌ Format salah! Gunakan: <code>.cekqris [order_id]</code>")
    
    order_id = args[1]
    
    # Cek di database lokal dulu
    if order_id not in transactions:
        return await msg.edit(f"❌ Order ID <code>{order_id}</code> tidak ditemukan!")
    
    trans = transactions[order_id]
    amount = trans["amount"]
    
    # Request ke API Pakasir untuk cek status
    url = f"https://app.pakasir.com/api/transactiondetail"
    params = {
        "project": pakasir_config["project_slug"],
        "amount": amount,
        "order_id": order_id,
        "api_key": pakasir_config["api_key"]
    }
    
    try:
        response = requests.get(url, params=params, timeout=10)
        
        if response.status_code == 200:
            data = response.json()
            
            if "transaction" in data:
                tx_data = data["transaction"]
                status = tx_data.get("status", "unknown")
                payment_method = tx_data.get("payment_method", "qris")
                completed_at = tx_data.get("completed_at", "")
                
                # Update status di database lokal
                transactions[order_id]["status"] = status
                
                status_emoji = "✅" if status == "completed" else "⏳" if status == "pending" else "❌"
                status_text = status.upper()
                
                msg_text = f"""
<blockquote><b>{status_emoji} STATUS TRANSAKSI</b>

🆔 <b>Order ID:</b> <code>{order_id}</code>
💰 <b>Nominal:</b> Rp{amount:,}
💳 <b>Metode:</b> {payment_method.upper()}
📊 <b>Status:</b> {status_text}
"""
                
                if completed_at and status == "completed":
                    msg_text += f"⏰ <b>Selesai:</b> {completed_at}\n"
                
                msg_text += "</blockquote>"
                
                await msg.edit(msg_text)
            else:
                await msg.edit("❌ Gagal mendapatkan detail transaksi!")
        else:
            await msg.edit(f"❌ Gagal cek status: HTTP {response.status_code}")
            
    except Exception as e:
        await msg.edit(f"❌ Error: {str(e)}")

@PY.UBOT("cancelqris")
async def cancel_qris(client, message):
    """Membatalkan transaksi QRIS"""
    msg = await message.reply("⏳ Membatalkan transaksi...")
    
    args = message.text.split()
    if len(args) < 2:
        return await msg.edit("❌ Format salah! Gunakan: <code>.cancelqris [order_id]</code>")
    
    order_id = args[1]
    
    # Cek di database lokal
    if order_id not in transactions:
        return await msg.edit(f"❌ Order ID <code>{order_id}</code> tidak ditemukan!")
    
    trans = transactions[order_id]
    amount = trans["amount"]
    
    # Request ke API Pakasir untuk cancel transaksi
    url = f"https://app.pakasir.com/api/transactioncancel"
    
    payload = {
        "project": pakasir_config["project_slug"],
        "order_id": order_id,
        "amount": amount,
        "api_key": pakasir_config["api_key"]
    }
    
    try:
        response = requests.post(url, json=payload, timeout=10)
        
        if response.status_code == 200:
            # Update status
            transactions[order_id]["status"] = "cancelled"
            
            await msg.edit(f"""
<blockquote><b>✅ TRANSAKSI DIBATALKAN</b>

🆔 <b>Order ID:</b> <code>{order_id}</code>
💰 <b>Nominal:</b> Rp{amount:,}
📊 <b>Status:</b> CANCELLED
</blockquote>""")
        else:
            await msg.edit(f"❌ Gagal membatalkan: HTTP {response.status_code}")
            
    except Exception as e:
        await msg.edit(f"❌ Error: {str(e)}")

# Callback query handler
@PY.CALLBACK("cek_")
async def callback_cek_qris(client, callback_query):
    order_id = callback_query.data.replace("cek_", "")
    
    if order_id not in transactions:
        await callback_query.answer("Order ID tidak ditemukan!", show_alert=True)
        return
    
    trans = transactions[order_id]
    amount = trans["amount"]
    
    # Cek status
    url = f"https://app.pakasir.com/api/transactiondetail"
    params = {
        "project": pakasir_config["project_slug"],
        "amount": amount,
        "order_id": order_id,
        "api_key": pakasir_config["api_key"]
    }
    
    try:
        response = requests.get(url, params=params, timeout=10)
        
        if response.status_code == 200:
            data = response.json()
            
            if "transaction" in data:
                tx_data = data["transaction"]
                status = tx_data.get("status", "unknown")
                
                # Update status
                transactions[order_id]["status"] = status
                
                status_emoji = "✅" if status == "completed" else "⏳" if status == "pending" else "❌"
                
                await callback_query.answer(f"Status: {status.upper()}", show_alert=True)
                
                # Edit message jika perlu
                await callback_query.message.reply(f"✅ Status: {status_emoji} {status.upper()}")
            else:
                await callback_query.answer("Gagal mendapatkan detail!", show_alert=True)
        else:
            await callback_query.answer(f"Error: HTTP {response.status_code}", show_alert=True)
            
    except Exception as e:
        await callback_query.answer(f"Error: {str(e)[:50]}", show_alert=True)

@PY.CALLBACK("cancel_")
async def callback_cancel_qris(client, callback_query):
    order_id = callback_query.data.replace("cancel_", "")
    
    if order_id not in transactions:
        await callback_query.answer("Order ID tidak ditemukan!", show_alert=True)
        return
    
    trans = transactions[order_id]
    amount = trans["amount"]
    
    # Cancel transaksi
    url = f"https://app.pakasir.com/api/transactioncancel"
    
    payload = {
        "project": pakasir_config["project_slug"],
        "order_id": order_id,
        "amount": amount,
        "api_key": pakasir_config["api_key"]
    }
    
    try:
        response = requests.post(url, json=payload, timeout=10)
        
        if response.status_code == 200:
            transactions[order_id]["status"] = "cancelled"
            await callback_query.answer("Transaksi dibatalkan!", show_alert=True)
            await callback_query.message.reply(f"✅ Transaksi <code>{order_id}</code> dibatalkan.")
        else:
            await callback_query.answer("Gagal membatalkan!", show_alert=True)
            
    except Exception as e:
        await callback_query.answer(f"Error: {str(e)[:50]}", show_alert=True)

@PY.CALLBACK("reset_pakasir")
async def callback_reset_pakasir(client, callback_query):
    # Reset ke default
    global pakasir_config
    pakasir_config = DEFAULT_CONFIG.copy()
    save_config(pakasir_config)
    
    await callback_query.answer("✅ Konfigurasi direset ke default!", show_alert=True)
    await callback_query.message.edit(
        f"<blockquote><b>✅ Konfigurasi direset ke default!</b>\n\n"
        f"📌 <b>Project Slug:</b> <code>{DEFAULT_CONFIG['project_slug']}</code>\n"
        f"🔑 <b>API Key:</b> <code>{DEFAULT_CONFIG['api_key'][:10]}...{DEFAULT_CONFIG['api_key'][-5:]}</code></blockquote>"
    )

@PY.CALLBACK("close")
async def callback_close(client, callback_query):
    await callback_query.message.delete()