from fansx import *
import aiohttp
import asyncio
import json
import os
import re
from pyrogram.enums import ChatAction, ParseMode
from pyrogram.types import Message

__MODULE__ = "ᴄᴏᴅᴇ ʀᴜɴɴᴇʀ"
__HELP__ = """
<blockquote><b>『 CODE RUNNER 』</b>

<b>⌲ Jalankan kode berbagai bahasa:</b>
ᚗ <code>{0}run [bahasa] [kode]</code> - Jalankan kode langsung
ᚗ <code>{0}run [bahasa]</code> - Reply ke file kode

<b>⌲ Bahasa yang didukung (50+):</b>
• <code>python</code> - Python 3.10
• <code>javascript</code> - Node.js 18
• <code>java</code> - Java 17
• <code>cpp</code> - C++ 20
• <code>c</code> - C 18
• <code>php</code> - PHP 8.2
• <code>ruby</code> - Ruby 3.2
• <code>go</code> - Go 1.21
• <code>rust</code> - Rust 1.70
• <code>swift</code> - Swift 5.8

<b>⌲ Contoh:</b>
<code>.run python print('Hello World')</code>
<code>.run javascript console.log('Hello')</code>
<code>.run java public class Main {public static void main(String[] args) {System.out.println("Hello");}}</code>

<b>⌲ Reply ke file:</b>
Reply ke file .py, .js, .java, dll dengan <code>.run [bahasa]</code></blockquote>
"""

# ============================================
# KONFIGURASI
# ============================================

# API Piston untuk menjalankan kode
PISTON_API = "https://emkc.org/api/v2/piston"

# Daftar bahasa yang didukung (lengkap)
SUPPORTED_LANGUAGES = {
    "python": "3.10.0",
    "javascript": "18.15.0",
    "java": "17.0.7",
    "cpp": "10.2.0",
    "c": "10.2.0",
    "php": "8.2.3",
    "ruby": "3.2.2",
    "go": "1.21.0",
    "rust": "1.70.0",
    "swift": "5.8.0",
    "kotlin": "1.8.20",
    "typescript": "5.0.3",
    "bash": "5.2.15",
    "perl": "5.36.0",
    "r": "4.3.0",
    "dart": "3.0.0",
    "csharp": "6.12.0",
    "lua": "5.4.4",
    "haskell": "9.4.4",
}

# Ekstensi file ke bahasa
EXTENSION_MAP = {
    ".py": "python",
    ".js": "javascript",
    ".java": "java",
    ".cpp": "cpp",
    ".c": "c",
    ".php": "php",
    ".rb": "ruby",
    ".go": "go",
    ".rs": "rust",
    ".swift": "swift",
    ".kt": "kotlin",
    ".ts": "typescript",
    ".sh": "bash",
    ".pl": "perl",
    ".r": "r",
    ".dart": "dart",
    ".cs": "csharp",
    ".lua": "lua",
    ".hs": "haskell",
}

async def execute_code(language: str, code: str):
    """Jalankan kode menggunakan API Piston"""
    
    # Cek apakah bahasa didukung
    if language not in SUPPORTED_LANGUAGES:
        return {
            "success": False,
            "error": f"Bahasa '{language}' tidak didukung.\nBahasa yang didukung: {', '.join(SUPPORTED_LANGUAGES.keys())}"
        }
    
    version = SUPPORTED_LANGUAGES[language]
    
    # Prepare request
    url = f"{PISTON_API}/execute"
    payload = {
        "language": language,
        "version": version,
        "files": [
            {
                "name": f"main.{language}",
                "content": code
            }
        ],
        "stdin": "",
        "args": [],
        "compile_timeout": 10000,
        "run_timeout": 3000
    }
    
    try:
        async with aiohttp.ClientSession() as session:
            async with session.post(url, json=payload, timeout=30) as response:
                if response.status == 200:
                    data = await response.json()
                    
                    # Ambil output
                    output = ""
                    run_data = data.get("run", {})
                    
                    if run_data.get("stdout"):
                        output += run_data["stdout"]
                    
                    if run_data.get("stderr"):
                        if output:
                            output += "\n\n"
                        output += f"⚠️ STDERR:\n{run_data['stderr']}"
                    
                    if not output and run_data.get("code") == 0:
                        output = "✅ Program selesai (tidak ada output)"
                    
                    return {
                        "success": True,
                        "output": output.strip(),
                        "language": language,
                        "version": data.get("language", language),
                        "time": run_data.get("time"),
                        "memory": run_data.get("memory")
                    }
                else:
                    error_text = await response.text()
                    return {
                        "success": False,
                        "error": f"HTTP {response.status}: {error_text[:100]}"
                    }
    except asyncio.TimeoutError:
        return {"success": False, "error": "Timeout - kode mungkin terlalu lama"}
    except Exception as e:
        return {"success": False, "error": str(e)}

def detect_language_from_file(filename):
    """Deteksi bahasa dari ekstensi file"""
    import os
    ext = os.path.splitext(filename)[1].lower()
    return EXTENSION_MAP.get(ext)

@PY.UBOT("run")
async def run_code(client: Client, message: Message):
    ggl = await EMO.GAGAL(client)
    sks = await EMO.BERHASIL(client)
    prs = await EMO.PROSES(client)
    
    try:
        await client.send_chat_action(message.chat.id, ChatAction.TYPING)
        
        # Parse arguments
        text = message.text
        parts = text.split(maxsplit=2)
        
        if len(parts) < 2:
            # Tampilkan help
            langs = ", ".join(list(SUPPORTED_LANGUAGES.keys())[:10])
            await message.reply_text(
                f"<blockquote><b>🚀 CODE RUNNER</b>\n\n"
                f"<b>Format:</b> <code>.run [bahasa] [kode]</code>\n"
                f"<b>Atau reply ke file kode:</b> <code>.run [bahasa]</code>\n\n"
                f"<b>Bahasa didukung:</b>\n"
                f"• {langs}, ...\n"
                f"<i>Total {len(SUPPORTED_LANGUAGES)} bahasa</i>\n\n"
                f"<b>Contoh:</b>\n"
                f"<code>.run python print('Hello World')</code>\n"
                f"<code>.run javascript console.log('Hello')</code>\n\n"
                f"<b>Reply ke file:</b>\n"
                f"<code>.run python</code> (reply ke file .py)</blockquote>"
            )
            return
        
        command_parts = text.split(maxsplit=1)
        args = command_parts[1].strip() if len(command_parts) > 1 else ""
        
        language = None
        code = None
        source_type = ""
        
        # Cek apakah ada reply file
        if message.reply_to_message and message.reply_to_message.document:
            doc = message.reply_to_message.document
            file_name = doc.file_name or ""
            
            # Deteksi bahasa dari argumen atau ekstensi
            if args:
                language = args.split()[0].lower()
            else:
                language = detect_language_from_file(file_name)
            
            if not language:
                await message.reply_text(
                    f"{ggl} <b>Gagal mendeteksi bahasa!</b>\n"
                    f"Gunakan: <code>.run [bahasa]</code> (reply ke file)"
                )
                return
            
            # Download file
            file_path = await message.reply_to_message.download()
            with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                code = f.read()
            
            if os.path.exists(file_path):
                os.remove(file_path)
            
            source_type = f"📄 File: {file_name}"
        
        # Cek dari teks langsung
        else:
            # Format: .run python print('hello')
            parts = text.split(maxsplit=2)
            if len(parts) >= 3:
                language = parts[1].lower()
                code = parts[2]
                source_type = "📝 Teks"
            else:
                await message.reply_text(
                    f"{ggl} <b>Format salah!</b>\n"
                    f"Contoh: <code>.run python print('Hello')</code>"
                )
                return
        
        if not language or not code:
            await message.reply_text(f"{ggl} <b>Bahasa atau kode tidak ditemukan!</b>")
            return
        
        # Validasi bahasa
        if language not in SUPPORTED_LANGUAGES:
            langs = ", ".join(list(SUPPORTED_LANGUAGES.keys())[:15])
            await message.reply_text(
                f"{ggl} <b>Bahasa '{language}' tidak didukung!</b>\n\n"
                f"<b>Bahasa yang didukung:</b>\n{langs}\n\n"
                f"<i>Total {len(SUPPORTED_LANGUAGES)} bahasa</i>"
            )
            return
        
        # Batasi panjang kode
        if len(code) > 5000:
            await message.reply_text(f"{ggl} <b>Kode terlalu panjang! Maksimal 5000 karakter.</b>")
            return
        
        # Kirim pesan processing
        processing = await message.reply_text(
            f"{prs} <b>Menjalankan kode...</b>\n"
            f"🔤 Bahasa: {language}\n"
            f"{source_type}\n"
            f"📊 Panjang: {len(code)} karakter"
        )
        
        # Jalankan kode
        result = await execute_code(language, code)
        
        await processing.delete()
        
        if result.get("success"):
            output = result["output"]
            version = result.get("version", language)
            exec_time = result.get("time")
            memory = result.get("memory")
            
            # Batasi output
            if len(output) > 3500:
                output = output[:3500] + "...\n\n⚠️ Output dipotong (terlalu panjang)"
            
            # Format output
            if not output.strip():
                output = "✅ Program selesai (tidak ada output)"
            
            # Tambah info waktu
            time_info = ""
            if exec_time:
                time_info += f"⏱️ Waktu: {exec_time:.3f}s"
            if memory:
                time_info += f" | 💾 Memori: {memory} KB"
            
            reply_text = f"""
<blockquote><b>✅ HASIL EKSEKUSI</b>

🔤 <b>Bahasa:</b> {language} ({version})
📦 <b>Input:</b> {source_type or '📝 Teks'}
{time_info}

<b>📤 Output:</b>
<code>{output}</code></blockquote>"""
            
            await message.reply_text(reply_text)
        else:
            error_msg = result.get("error", "Unknown error")
            await message.reply_text(
                f"<blockquote><b>❌ ERROR</b>\n\n"
                f"🔤 <b>Bahasa:</b> {language}\n\n"
                f"<code>{error_msg}</code></blockquote>"
            )
        
    except Exception as e:
        await message.reply_text(f"{ggl} <b>Error: {str(e)[:100]}</b>")

@PY.UBOT("execute")
async def execute_alias(client: Client, message: Message):
    """Alias untuk run"""
    await run_code(client, message)

@PY.UBOT("py")
async def python_shortcut(client: Client, message: Message):
    """Shortcut untuk Python"""
    await run_with_language(client, message, "python")

@PY.UBOT("js")
async def js_shortcut(client: Client, message: Message):
    """Shortcut untuk JavaScript"""
    await run_with_language(client, message, "javascript")

@PY.UBOT("java")
async def java_shortcut(client: Client, message: Message):
    """Shortcut untuk Java"""
    await run_with_language(client, message, "java")

@PY.UBOT("cpp")
async def cpp_shortcut(client: Client, message: Message):
    """Shortcut untuk C++"""
    await run_with_language(client, message, "cpp")

@PY.UBOT("c")
async def c_shortcut(client: Client, message: Message):
    """Shortcut untuk C"""
    await run_with_language(client, message, "c")

@PY.UBOT("php")
async def php_shortcut(client: Client, message: Message):
    """Shortcut untuk PHP"""
    await run_with_language(client, message, "php")

async def run_with_language(client: Client, message: Message, language: str):
    """Helper untuk shortcut per bahasa"""
    ggl = await EMO.GAGAL(client)
    
    try:
        await client.send_chat_action(message.chat.id, ChatAction.TYPING)
        
        # Ambil kode dari argumen atau reply
        text = message.text
        parts = text.split(maxsplit=1)
        
        code = None
        source_type = ""
        
        # Cek reply file
        if message.reply_to_message and message.reply_to_message.document:
            doc = message.reply_to_message.document
            file_path = await message.reply_to_message.download()
            with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                code = f.read()
            
            if os.path.exists(file_path):
                os.remove(file_path)
            
            source_type = f"📄 File: {doc.file_name}"
        
        # Cek dari teks
        elif len(parts) >= 2:
            code = parts[1]
            source_type = "📝 Teks"
        
        if not code:
            await message.reply_text(
                f"<blockquote><b>❌ Masukkan kode!</b>\n\n"
                f"Contoh: <code>.{language} print('Hello')</code>\n"
                f"Atau reply ke file .{language}</blockquote>"
            )
            return
        
        # Jalankan kode
        # Ubah command jadi format .run
        message.text = f".run {language} {code[:100]}"
        await run_code(client, message)
        
    except Exception as e:
        await message.reply_text(f"{ggl} <b>Error: {str(e)[:100]}</b>")

@PY.UBOT("langs")
async def list_languages(client: Client, message: Message):
    """Lihat daftar bahasa yang didukung"""
    
    # Kelompokkan bahasa
    languages = list(SUPPORTED_LANGUAGES.keys())
    languages.sort()
    
    # Bagi menjadi beberapa kolom
    per_row = 4
    rows = [languages[i:i+per_row] for i in range(0, len(languages), per_row)]
    
    text = "<blockquote><b>📋 BAHASA YANG DIDUKUNG</b>\n\n"
    
    for row in rows:
        text += " • " + " | ".join(row) + "\n"
    
    text += f"\n<b>📊 Total:</b> {len(languages)} bahasa\n\n"
    text += "<b>💡 Cara pakai:</b>\n"
    text += "<code>.run python print('Hello')</code>\n"
    text += "<code>.py print('Hello')</code> (shortcut)</blockquote>"
    
    await message.reply_text(text)

@PY.UBOT("runhelp")
async def run_help(client: Client, message: Message):
    """Help detail untuk code runner"""
    
    text = f"""
<blockquote><b>📚 PANDUAN CODE RUNNER</b>

<b>1. Jalankan kode langsung:</b>
<code>.run python print('Hello World')</code>
<code>.run javascript console.log('Hello')</code>

<b>2. Jalankan file:</b>
Reply ke file .py dengan <code>.run python</code>
Reply ke file .js dengan <code>.run javascript</code>

<b>3. Shortcut per bahasa:</b>
<code>.py print('Hello')</code> - Python
<code>.js console.log('Hello')</code> - JavaScript
<code>.java public class Main {{...}}</code> - Java
<code>.cpp #include <iostream> ...</code> - C++
<code>.php echo 'Hello';</code> - PHP

<b>4. Lihat daftar bahasa:</b>
<code>.langs</code>

<b>5. Limitasi:</b>
• Maksimal 5000 karakter
• Timeout 30 detik
• Output dipotong jika >3500 karakter</blockquote>"""
    
    await message.reply_text(text)