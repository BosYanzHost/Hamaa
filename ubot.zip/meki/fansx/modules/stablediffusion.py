import os
import random
import requests
from fansx import *

__MODULE__ = "sᴛᴀʙʟᴇᴅɪғғᴜsɪᴏɴ"
__HELP__ = """
<b>⦪ ʙᴀɴᴛᴜᴀɴ ᴜɴᴛᴜᴋ sᴛᴀʙʟᴇᴅɪғғᴜsɪᴏɴ ⦫</b>
<blockquote><b>
⎆ Perintah :
ᚗ <code>{0}sd</code> [prompt]
⊶ Untuk Membuat Gambar Menggunakan Text.

⎆ Contoh :
ᚗ <code>{0}sd</code> cat riding a motorcycle
ᚗ <code>{0}sd</code> beautiful sunset anime style</b></blockquote>
"""

# Daftar API keys By Zyura
API_KEYS = [
    "eIxUwMpn",
    "keoCFdc6",
    "bv7m372F",
    "iAiB9QKT",
    "JP7Cy8Y2",
    "GI4vPxYv",
    "HRPga9TN",
    "PDwqhVsj",
    "m8jpBeZR",
    "PXkxh5hw",
    "MFnlpM6A",
    "u299UiOF"
]

def get_random_apikey():
    """Mengambil API key secara random dari daftar"""
    return random.choice(API_KEYS)

def get_stablediffusion_image(text):
    """Mengambil gambar dari API Stable Diffusion dengan random API key"""
    
    # Coba dengan beberapa API key
    max_attempts = min(3, len(API_KEYS))
    used_keys = set()
    
    for attempt in range(max_attempts):
        available_keys = [key for key in API_KEYS if key not in used_keys]
        if not available_keys:
            break
            
        apikey = random.choice(available_keys)
        used_keys.add(apikey)
        
        url = "https://api.botcahx.eu.org/api/search/stablediffusion"
        params = {
            "text": text,
            "apikey": apikey
        }
        
        try:
            print(f"Mencoba dengan key: {apikey[:8]}... (percobaan {attempt+1})")
            response = requests.get(url, params=params, timeout=30)
            
            if response.status_code == 200:
                # Cek apakah response berupa gambar
                content_type = response.headers.get("Content-Type", "").lower()
                
                if content_type.startswith("image/"):
                    print(f"Berhasil mendapatkan gambar dengan key: {apikey[:8]}...")
                    return response.content, apikey
                else:
                    # Coba lihat apakah response JSON dengan error
                    try:
                        error_data = response.json()
                        if "message" in error_data:
                            print(f"Error dari API: {error_data['message']}")
                    except:
                        pass
                    continue
            else:
                print(f"HTTP Error {response.status_code} dengan key {apikey[:8]}...")
                continue
                
        except requests.exceptions.Timeout:
            print(f"Timeout dengan key {apikey[:8]}...")
            continue
        except requests.exceptions.ConnectionError:
            print(f"Connection Error dengan key {apikey[:8]}...")
            continue
        except Exception as e:
            print(f"Error dengan key {apikey[:8]}...: {str(e)}")
            continue
    
    return None, None

@PY.UBOT("sd")
async def stablediffusion_handler(client, message):
    # Cek apakah ada argumen
    args = message.text.split(" ", 1)
    if len(args) < 2:
        await message.reply_text(
            "<blockquote><b>❌ Gunakan perintah:</b> <code>.sd [prompt]</code>\n\n"
            "<b>Contoh:</b>\n"
            "<code>.sd cat riding a motorcycle</code>\n"
            "<code>.sd beautiful sunset anime style</code></blockquote>"
        )
        return

    # Ambil prompt
    request_text = args[1]
    
    # Kirim pesan processing
    processing = await message.reply_text(
        "<blockquote><b>🎨 Stable Diffusion sedang menggambar...</b>\n\n"
        f"📝 <b>Prompt:</b> <code>{request_text[:50]}{'...' if len(request_text) > 50 else ''}</code>\n"
        f"⏳ Mohon tunggu ±30 detik</blockquote>"
    )

    # Generate gambar
    image_content, used_key = get_stablediffusion_image(request_text)
    
    if image_content:
        # Simpan gambar ke file temporary
        temp_file = f"sd_{random.randint(1000,9999)}.jpg"
        with open(temp_file, "wb") as f:
            f.write(image_content)

        # Buat caption
        caption = f"""
<blockquote><b>✅ STABLE DIFFUSION GENERATOR</b>

📝 <b>Prompt:</b> <code>{request_text[:100]}{'...' if len(request_text) > 100 else ''}</code>
🔑 <b>Key:</b> <code>{used_key[:8]}...</code>
⚡ <b>Powered by:</b> Ubot Premium Zyura</blockquote>
"""
        
        # Kirim gambar
        await client.send_photo(
            chat_id=message.chat.id,
            photo=temp_file,
            caption=caption
        )
        
        # Hapus file temporary
        if os.path.exists(temp_file):
            os.remove(temp_file)
        
        await processing.delete()
        
    else:
        await processing.edit_text(
            "<blockquote><b>❌ Gagal membuat gambar setelah beberapa percobaan!</b>\n\n"
            "🔴 Kemungkinan penyebab:\n"
            "• API key habis limit\n"
            "• Server sedang sibuk\n"
            "• Prompt tidak sesuai\n\n"
            "🔄 Silakan coba lagi nanti dengan prompt berbeda.</blockquote>"
        )

@PY.BOT("sd")
async def stablediffusion_handler_bot(client, message):
    # Cek apakah ada argumen
    args = message.text.split(" ", 1)
    if len(args) < 2:
        await message.reply_text(
            "<blockquote><b>❌ Gunakan perintah:</b> <code>/sd [prompt]</code>\n\n"
            "<b>Contoh:</b>\n"
            "<code>/sd cat riding a motorcycle</code>\n"
            "<code>/sd beautiful sunset anime style</code></blockquote>"
        )
        return

    # Ambil prompt
    request_text = args[1]
    
    # Kirim pesan processing
    processing = await message.reply_text(
        "<blockquote><b>🎨 Stable Diffusion sedang menggambar...</b>\n\n"
        f"📝 <b>Prompt:</b> <code>{request_text[:50]}{'...' if len(request_text) > 50 else ''}</code>\n"
        f"⏳ Mohon tunggu ±30 detik</blockquote>"
    )

    # Generate gambar
    image_content, used_key = get_stablediffusion_image(request_text)
    
    if image_content:
        # Simpan gambar ke file temporary
        temp_file = f"sd_{random.randint(1000,9999)}.jpg"
        with open(temp_file, "wb") as f:
            f.write(image_content)

        # Buat caption
        caption = f"""
<blockquote><b>✅ STABLE DIFFUSION GENERATOR</b>

📝 <b>Prompt:</b> <code>{request_text[:100]}{'...' if len(request_text) > 100 else ''}</code>
⚡ <b>Powered by:</b> Ubot Premium Zyura</blockquote>
"""
        
        # Kirim gambar
        await client.send_photo(
            chat_id=message.chat.id,
            photo=temp_file,
            caption=caption
        )
        
        # Hapus file temporary
        if os.path.exists(temp_file):
            os.remove(temp_file)
        
        await processing.delete()
        
    else:
        await processing.edit_text(
            "<blockquote><b>❌ Gagal membuat gambar!</b>\n\n"
            "🔄 Silakan coba lagi nanti dengan prompt berbeda.</blockquote>"
        )