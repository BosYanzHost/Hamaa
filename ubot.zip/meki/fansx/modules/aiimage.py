from fansx import *
import aiohttp
import asyncio
import os
import random
from pyrogram.enums import ChatAction, ParseMode
from pyrogram.types import Message

__MODULE__ = "ᴅᴀʟʟ-ᴇ 𝟹"
__HELP__ = """
<blockquote><b>🎨 DALL-E 3 AI IMAGE GENERATOR</b>

<b>⌲ Perintah:</b>
ᚗ <code>{0}dalle [prompt]</code> - Buat gambar dengan AI
ᚗ <code>{0}dalle [prompt] | [negative]</code> - Dengan negative prompt

<b>⌲ Contoh:</b>
<code>.dalle cat playing football</code>
<code>.dalle cat playing football | blurry, low quality</code></blockquote>
"""

# ============================================
# KONFIGURASI
# ============================================
DALLE_API = "https://anabot.my.id/api/ai/dalle3"
API_KEY = "freeApikey"  # Bisa diganti nanti

# Default negative prompt
DEFAULT_NEGATIVE = "normal quality, blurry, low quality, bad anatomy"

async def create_dalle_image(prompt, negative=DEFAULT_NEGATIVE):
    """Buat gambar dengan DALL-E 3"""
    
    # Encode semua parameter
    url = (f"{DALLE_API}?prompt={prompt}"
           f"&negative={negative}"
           f"&apikey={API_KEY}")
    
    try:
        async with aiohttp.ClientSession() as session:
            async with session.get(url, timeout=60) as response:  # Timeout lebih lama karena generate gambar
                if response.status == 200:
                    # Cek content-type
                    content_type = response.headers.get("Content-Type", "")
                    
                    if "image" in content_type:
                        # Langsung gambar
                        return {
                            "success": True,
                            "image": await response.read(),
                            "direct": True
                        }
                    else:
                        # Mungkin JSON dengan URL gambar
                        try:
                            data = await response.json()
                            
                            # Cek berbagai format respons
                            if data.get("status") == "success" and data.get("result"):
                                img_url = data["result"]
                            elif data.get("image_url"):
                                img_url = data["image_url"]
                            elif data.get("url"):
                                img_url = data["url"]
                            elif data.get("images") and len(data["images"]) > 0:
                                img_url = data["images"][0]
                            else:
                                return {"success": False, "error": "Format respons tidak dikenali", "data": data}
                            
                            # Download gambar dari URL
                            async with session.get(img_url, timeout=30) as img_resp:
                                if img_resp.status == 200:
                                    return {
                                        "success": True,
                                        "image": await img_resp.read()
                                    }
                                else:
                                    return {"success": False, "error": f"Gagal download gambar: HTTP {img_resp.status}"}
                        except:
                            return {"success": False, "error": "API tidak mengembalikan gambar"}
                elif response.status == 401:
                    return {"success": False, "error": "API Key tidak valid atau habis quota"}
                elif response.status == 402:
                    return {"success": False, "error": "Quota API habis, perlu isi ulang"}
                elif response.status == 429:
                    return {"success": False, "error": "Terlalu banyak request, coba lagi nanti"}
                else:
                    return {"success": False, "error": f"HTTP {response.status}"}
    except asyncio.TimeoutError:
        return {"success": False, "error": "Timeout - server terlalu lama merespon (mungkin lagi sibuk)"}
    except Exception as e:
        return {"success": False, "error": str(e)}

def parse_dalle_args(args):
    """Parse argumen dengan format: prompt | negative"""
    if not args:
        return None
    
    # Format: prompt | negative
    full_text = " ".join(args)
    parts = [p.strip() for p in full_text.split("|")]
    
    result = {
        "prompt": parts[0],
        "negative": DEFAULT_NEGATIVE
    }
    
    # Parse negative prompt
    if len(parts) >= 2 and parts[1]:
        result["negative"] = parts[1]
    
    return result

@PY.UBOT("dalle")
async def dalle_command(client: Client, message: Message):
    ggl = await EMO.GAGAL(client)
    sks = await EMO.BERHASIL(client)
    prs = await EMO.PROSES(client)
    
    # Parse argumen
    args = message.text.split()[1:]
    
    if not args:
        # Tampilkan help
        help_text = f"""
<blockquote><b>Cara pakai:</b>
ᚗ <code>.dalle [prompt]</code>
ᚗ <code>.dalle [prompt] | [negative prompt]</code>

<b>Contoh sederhana:</b>
<code>.dalle cat playing football</code>
<code>.dalle anime girl with katana</code>

<b>Contoh dengan negative prompt:</b>
<code>.dalle cat playing football | blurry, low quality, bad anatomy</code>
<code>.dalle beautiful landscape | ugly, distorted, low quality</code>

<b>💡 Tips prompt:</b>
• Semakin detail semakin bagus
• Sebutkan style (anime, realistic, 3D, etc)
• Sebutkan warna, lighting, composition
• Negative prompt buat hindarin hal yang gak diinginkan

<b>⏱️ Waktu:</b> ±30-60 detik tergantung antrian</blockquote>"""
        
        await message.reply_text(help_text)
        return
    
    parsed = parse_dalle_args(args)
    if not parsed:
        await message.reply_text(f"{ggl} <b>Format salah! Gunakan .dalle [prompt]</b>")
        return
    
    try:
        await client.send_chat_action(message.chat.id, ChatAction.UPLOAD_PHOTO)
        
        processing = await message.reply_text(
            f"{prs} <b>DALL-E 3 sedang menggambar...</b>\n"
            f"<b>Prompt:</b> {parsed['prompt'][:50]}{'...' if len(parsed['prompt']) > 50 else ''}\n"
            f"<i>Ini bakal makan waktu ±30-60 detik, harap sabar...</i>"
        )
        
        # Buat gambar
        result = await create_dalle_image(
            prompt=parsed['prompt'],
            negative=parsed['negative']
        )
        
        await processing.delete()
        
        if result.get("success") and result.get("image"):
            # Simpan gambar sementara
            file_path = f"dalle_{message.from_user.id}_{random.randint(1000,9999)}.png"
            with open(file_path, "wb") as f:
                f.write(result["image"])
            
            # Buat caption dengan info
            caption = f"<blockquote><b>🎨 DALL-E 3 GENERATED</b>\n\n"
            caption += f"<b>💬 Prompt:</b> {parsed['prompt']}\n"
            caption += f"<b>🚫 Negative:</b> {parsed['negative']}\n"
            caption += f"\n⚡ Powered by: Ubot Premium Zyura</blockquote>"
            
            # Kirim gambar
            await client.send_photo(
                chat_id=message.chat.id,
                photo=file_path,
                caption=caption
            )
            
            # Hapus file
            if os.path.exists(file_path):
                os.remove(file_path)
            
        else:
            error_msg = result.get("error", "Unknown error")
            
            # Pesan error yang lebih friendly
            if "401" in error_msg or "API Key" in error_msg:
                user_friendly = "API Key error atau quota habis. Hubungi admin bot."
            elif "429" in error_msg:
                user_friendly = "Server lagi sibuk, coba lagi nanti."
            else:
                user_friendly = error_msg
            
            await message.reply_text(
                f"<blockquote><b>❌ GAGAL MEMBUAT GAMBAR</b>\n\n"
                f"<b>Prompt:</b> {parsed['prompt']}\n"
                f"<b>Error:</b> {user_friendly}</blockquote>"
            )
        
    except Exception as e:
        await message.reply_text(f"{ggl} <b>Error: {str(e)[:100]}</b>")

