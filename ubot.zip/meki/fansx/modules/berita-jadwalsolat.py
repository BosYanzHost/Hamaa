from fansx import *
import aiohttp
import asyncio
import json
import os
from datetime import datetime
from pyrogram.enums import ChatAction, ParseMode
from pyrogram.types import Message

__MODULE__ = "ᴊᴀᴅᴡᴀʟ sʜᴏʟᴀᴛ"
__HELP__ = """
<blockquote><b>🕌 JADWAL SHOLAT</b>

<b>⌲ Perintah:</b>
ᚗ <code>{0}jadwalsholat [kota]</code> - Cek jadwal sholat
ᚗ <code>{0}sholat [kota]</code> - Cek jadwal sholat
ᚗ <code>{0}imsak [kota]</code> - Cek waktu imsak saja

<b>⌲ Contoh:</b>
<code>.jadwalsholat Jakarta</code>
<code>.sholat Surabaya</code>
<code>.imsak Bandung</code>

<b>⌲ Catatan:</b>
• Default kota: Jakarta
• Data berdasarkan lokasi Indonesia
• Waktu dalam format WIB (UTC+7)</blockquote>
"""

# ============================================
# KONFIGURASI
# ============================================
API_URL = "https://api.deline.web.id/info/jadwalsholat"

# Daftar kota populer (bisa ditambah)
POPULAR_CITIES = [
    "Jakarta", "Surabaya", "Bandung", "Medan", "Semarang",
    "Palembang", "Makassar", "Yogyakarta", "Depok", "Tangerang",
    "Bekasi", "Solo", "Malang", "Denpasar", "Pekanbaru"
]

async def get_prayer_times(city: str):
    """Ambil jadwal sholat dari API"""
    try:
        async with aiohttp.ClientSession() as session:
            params = {"kota": city}
            async with session.get(API_URL, params=params, timeout=15) as response:
                if response.status == 200:
                    data = await response.json()
                    if data.get("status") and data.get("result"):
                        return data.get("result")
    except Exception as e:
        print(f"Error get prayer times: {e}")
    return None

def get_current_time():
    """Dapatkan waktu sekarang"""
    now = datetime.now()
    return now.strftime("%H:%M")

def get_next_prayer(times, current_time):
    """Tentukan waktu sholat berikutnya"""
    prayers = [
        ("Imsak", times.get("Imsak", "")),
        ("Fajr", times.get("Fajr", "")),
        ("Sunrise", times.get("Sunrise", "")),
        ("Dhuhr", times.get("Dhuhr", "")),
        ("Asr", times.get("Asr", "")),
        ("Maghrib", times.get("Maghrib", "")),
        ("Isha", times.get("Isha", ""))
    ]
    
    # Konversi ke menit untuk perbandingan
    def to_minutes(time_str):
        if not time_str:
            return 9999
        try:
            h, m = map(int, time_str.split(':'))
            return h * 60 + m
        except:
            return 9999
    
    current_minutes = to_minutes(current_time)
    
    next_prayer = None
    min_diff = 9999
    
    for prayer_name, prayer_time in prayers:
        if prayer_time:
            prayer_minutes = to_minutes(prayer_time)
            if prayer_minutes > current_minutes:
                diff = prayer_minutes - current_minutes
                if diff < min_diff:
                    min_diff = diff
                    next_prayer = (prayer_name, prayer_time)
    
    return next_prayer

@PY.UBOT("jadwalsholat")
@PY.UBOT("sholat")
async def prayer_times(client: Client, message: Message):
    ggl = await EMO.GAGAL(client)
    prs = await EMO.PROSES(client)
    
    try:
        await client.send_chat_action(message.chat.id, ChatAction.TYPING)
        
        # Ambil nama kota
        args = message.text.split(maxsplit=1)
        city = args[1].strip() if len(args) > 1 else "Jakarta"
        
        processing = await message.reply_text(f"{prs} <b>Mencari jadwal sholat untuk {city}...</b>")
        
        data = await get_prayer_times(city)
        
        if not data:
            await processing.edit_text(
                f"{ggl} <b>Kota '{city}' tidak ditemukan!</b>\n\n"
                f"Kota populer: {', '.join(POPULAR_CITIES[:10])}\n\n"
                f"Contoh: <code>.sholat Jakarta</code>"
            )
            return
        
        # Ambil data
        location = data.get("lokasi", f"{city}, Indonesia")
        date = data.get("tanggal", "-")
        hijri = data.get("hijri", "-")
        times = data.get("waktu", {})
        
        # Waktu sekarang
        current = get_current_time()
        next_prayer = get_next_prayer(times, current)
        
        # Format jadwal
        text = f"""
<blockquote><b>🕌 JADWAL SHOLAT</b>

📍 <b>Lokasi:</b> {location}
📅 <b>Tanggal:</b> {date}
🌙 <b>Hijri:</b> {hijri}
⏰ <b>Sekarang:</b> {current} WIB

<b>📋 Waktu Sholat:</b>
• Imsak    : {times.get('Imsak', '-')}
• Subuh    : {times.get('Fajr', '-')}
• Terbit   : {times.get('Sunrise', '-')}
• Dzuhur   : {times.get('Dhuhr', '-')}
• Ashar    : {times.get('Asr', '-')}
• Maghrib  : {times.get('Maghrib', '-')}
• Isya     : {times.get('Isha', '-')}"""
        
        if next_prayer:
            prayer_name, prayer_time = next_prayer
            text += f"\n\n<b>⏳ Sholat berikutnya:</b>\n{prayer_name} pukul {prayer_time} WIB"
        
        text += "</blockquote>"
        
        await processing.delete()
        await message.reply_text(text)
        
    except Exception as e:
        await message.reply_text(f"{ggl} <b>Error: {str(e)[:100]}</b>")

@PY.UBOT("imsak")
async def imsak_time(client: Client, message: Message):
    """Cek waktu imsak saja (khusus Ramadhan)"""
    ggl = await EMO.GAGAL(client)
    prs = await EMO.PROSES(client)
    
    try:
        args = message.text.split(maxsplit=1)
        city = args[1].strip() if len(args) > 1 else "Jakarta"
        
        processing = await message.reply_text(f"{prs} <b>Mencari waktu imsak untuk {city}...</b>")
        
        data = await get_prayer_times(city)
        
        if not data:
            await processing.edit_text(f"{ggl} <b>Kota '{city}' tidak ditemukan!</b>")
            return
        
        location = data.get("lokasi", f"{city}, Indonesia")
        date = data.get("tanggal", "-")
        hijri = data.get("hijri", "-")
        imsak = data.get("waktu", {}).get("Imsak", "-")
        fajr = data.get("waktu", {}).get("Fajr", "-")
        
        # Waktu sekarang
        current = get_current_time()
        
        # Hitung sisa waktu imsak
        def to_minutes(time_str):
            if not time_str:
                return 0
            try:
                h, m = map(int, time_str.split(':'))
                return h * 60 + m
            except:
                return 0
        
        imsak_minutes = to_minutes(imsak)
        current_minutes = to_minutes(current)
        
        if current_minutes < imsak_minutes:
            remaining = imsak_minutes - current_minutes
            hours = remaining // 60
            minutes = remaining % 60
            status = f"⏳ Sisa {hours} jam {minutes} menit"
        else:
            status = "❌ Waktu imsak sudah lewat"
        
        text = f"""
<blockquote><b>🌙 WAKTU IMSAK</b>

📍 <b>Lokasi:</b> {location}
📅 <b>Tanggal:</b> {date}
🌙 <b>Hijri:</b> {hijri}

⏰ <b>Waktu Imsak:</b> {imsak} WIB
🕌 <b>Subuh:</b> {fajr} WIB
🕐 <b>Sekarang:</b> {current} WIB

<b>{status}</b></blockquote>"""
        
        await processing.delete()
        await message.reply_text(text)
        
    except Exception as e:
        await message.reply_text(f"{ggl} <b>Error: {str(e)[:100]}</b>")

@PY.UBOT("kotasholat")
async def list_cities(client: Client, message: Message):
    """Tampilkan daftar kota populer"""
    
    text = "<blockquote><b>📍 DAFTAR KOTA POPULER</b>\n\n"
    
    # Tampilkan 5 kota per baris
    rows = [POPULAR_CITIES[i:i+5] for i in range(0, len(POPULAR_CITIES), 5)]
    for row in rows:
        text += " • " + " • ".join(row) + "\n"
    
    text += f"\n<b>Total:</b> {len(POPULAR_CITIES)} kota\n\n"
    text += "<b>Contoh:</b>\n"
    text += "<code>.sholat Jakarta</code>\n"
    text += "<code>.imsak Bandung</code></blockquote>"
    
    await message.reply_text(text)

@PY.UBOT("infosholat")
async def info_prayer(client: Client, message: Message):
    """Info fitur jadwal sholat"""
    
    text = """
<blockquote><b>🕌 INFO JADWAL SHOLAT</b>

<b>Sumber:</b> API Deline
<b>Update:</b> Real-time
<b>Zona:</b> WIB (UTC+7)

<b>Fitur:</b>
• Jadwal lengkap 5 waktu + imsak
• Waktu sekarang
• Sholat berikutnya
• Khusus imsak (Ramadhan)
• 15+ kota populer

<b>Cara pakai:</b>
• <code>.sholat [kota]</code> - Jadwal lengkap
• <code>.imsak [kota]</code> - Waktu imsak
• <code>.kotasholat</code> - Daftar kota

<b>Contoh:</b>
<code>.sholat Jakarta</code>
<code>.imsak Surabaya</code></blockquote>"""
    
    await message.reply_text(text)