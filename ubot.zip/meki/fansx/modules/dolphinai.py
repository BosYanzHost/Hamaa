from fansx import *
import aiohttp
import asyncio
from urllib.parse import quote
from pyrogram.enums import ChatAction, ParseMode
from pyrogram.types import Message

__MODULE__ = "ᴅᴏʟᴘʜɪɴ ᴀɪ"
__HELP__ = """
<blockquote><b> DOLPHIN AI</b>

<b>⌲ Perintah:</b>
ᚗ <code>{0}dolphin [pertanyaan]</code> - Tanya Dolphin AI
ᚗ <code>{0}aidol [pertanyaan]</code> - Alias

<b>⌲ Contoh:</b>
<code>.dolphin apa itu AI?</code>
<code>.dolphin halo</code>
<code>.aidol bagaimana cara membuat kue?</code></blockquote>
"""

# ============================================
# KONFIGURASI
# ============================================
BASE_URL = "https://api-faa.my.id/faa/dolphin-ai"

async def ask_dolphin(query: str):
    """Tanya Dolphin AI"""
    try:
        encoded_query = quote(query)
        url = f"{BASE_URL}?text={encoded_query}"
        
        async with aiohttp.ClientSession() as session:
            async with session.get(url, timeout=30) as response:
                if response.status == 200:
                    data = await response.json()
                    
                    if data.get("status") and data.get("result"):
                        return {
                            "success": True,
                            "result": data["result"],
                            "template": data.get("template", "logical")
                        }
                    else:
                        return {
                            "success": False,
                            "error": "Response tidak valid"
                        }
                else:
                    return {
                        "success": False,
                        "error": f"HTTP {response.status}"
                    }
    except asyncio.TimeoutError:
        return {"success": False, "error": "Timeout"}
    except Exception as e:
        return {"success": False, "error": str(e)}

@PY.UBOT("dolphin")
@PY.UBOT("aidol")
async def dolphin_ai(client: Client, message: Message):
    ggl = await EMO.GAGAL(client)
    sks = await EMO.BERHASIL(client)
    prs = await EMO.PROSES(client)
    
    try:
        await client.send_chat_action(message.chat.id, ChatAction.TYPING)
        
        # Ambil pertanyaan
        args = message.text.split(maxsplit=1)
        if len(args) < 2:
            await message.reply_text(
                f"<blockquote><b>❌ Masukkan pertanyaan!</b>\n\n"
                f"<b>Contoh:</b>\n"
                f"<code>.dolphin apa itu AI?</code>\n"
                f"<code>.aidol bagaimana cara membuat kue?</code></blockquote>"
            )
            return
        
        query = args[1].strip()
        
        # Kirim pesan processing
        processing = await message.reply_text(f"{prs} <b>Dolphin AI sedang berpikir...</b>")
        
        # Tanya AI
        result = await ask_dolphin(query)
        
        await processing.delete()
        
        if result.get("success"):
            answer = result["result"]
            template = result.get("template", "logical")
            
            # Format jawaban
            reply_text = f"""
<blockquote><b>🐬 DOLPHIN AI</b> (mode: {template})

{answer}

⚡ <b>Powered by:</b>Ubot Premium Zyura</blockquote>"""
            
            await message.reply_text(reply_text)
        else:
            error_msg = result.get("error", "Unknown error")
            await message.reply_text(
                f"<blockquote><b>❌ GAGAL</b>\n\n{error_msg}</blockquote>"
            )
        
    except Exception as e:
        await message.reply_text(f"{ggl} <b>Error: {str(e)[:100]}</b>")

