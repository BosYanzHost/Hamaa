from fansx import *
import aiohttp
import asyncio
import os
import re
from pyrogram.enums import ChatAction, ParseMode
from pyrogram.types import Message

__MODULE__ = "ᴄʜᴀɴɴᴇʟ ᴡᴀ sᴛᴀʟᴋ"
__HELP__ = """
<blockquote><b>⌲ Perintah:</b>
ᚗ <code>{0}channelwastalk [link_channel]</code> - Stalk channel WA
ᚗ <code>{0}cwastalk [link_channel]</code> - Singkatan

<b>⌲ Contoh:</b>
<code>.channelwastalk https://whatsapp.com/channel/0029Vb7fWF61CYoQMRaXBM1X</code>
<code>.cwastalk 0029Vb7fWF61CYoQMRaXBM1X</code></blockquote>
"""

# ============================================
# KONFIGURASI
# ============================================
WASTALK_API = "https://www.sankavollerei.com/stalk/whatsapp"
API_KEY = "planaai"  # API key dari Sanka Vollerei

def extract_channel_id(text):
    """Ekstrak channel ID dari link atau teks"""
    # Pattern untuk link WhatsApp channel
    pattern = r'(?:https?://)?(?:www\.)?whatsapp\.com/channel/([a-zA-Z0-9_-]+)'
    match = re.search(pattern, text)
    
    if match:
        return f"https://whatsapp.com/channel/{match.group(1)}"
    
    # Cek apakah teks langsung berupa ID
    if re.match(r'^[a-zA-Z0-9_-]{20,}$', text.strip()):
        return f"https://whatsapp.com/channel/{text.strip()}"
    
    return None

async def stalk_wa_channel(channel_url):
    """Stalk WhatsApp Channel"""
    
    # Encode parameter
    url = f"{WASTALK_API}?apikey={API_KEY}&url={channel_url}"
    
    try:
        async with aiohttp.ClientSession() as session:
            async with session.get(url, timeout=30) as response:
                if response.status == 200:
                    data = await response.json()
                    
                    if data.get("status") and data.get("result"):
                        result = data["result"]
                        creator = data.get("creator", "Sanka Vollerei")
                        
                        # Download gambar profile
                        image_url = result.get("image")
                        image_data = None
                        
                        if image_url:
                            try:
                                async with session.get(image_url, timeout=15) as img_resp:
                                    if img_resp.status == 200:
                                        image_data = await img_resp.read()
                            except:
                                pass
                        
                        return {
                            "success": True,
                            "name": result.get("name", "Unknown"),
                            "description": result.get("description", "Tidak ada deskripsi"),
                            "image": image_data,
                            "image_url": image_url,
                            "channel_id": result.get("channelId", "Unknown"),
                            "channel_url": result.get("channelUrl", channel_url),
                            "creator": creator
                        }
                    else:
                        return {"success": False, "error": "Channel tidak ditemukan atau API error"}
                elif response.status == 401:
                    return {"success": False, "error": "API Key tidak valid"}
                elif response.status == 404:
                    return {"success": False, "error": "Channel tidak ditemukan"}
                else:
                    return {"success": False, "error": f"HTTP {response.status}"}
    except asyncio.TimeoutError:
        return {"success": False, "error": "Timeout - server terlalu lambat"}
    except Exception as e:
        return {"success": False, "error": str(e)}

def format_description(desc):
    """Format deskripsi biar rapi"""
    if len(desc) > 500:
        return desc[:500] + "..."
    return desc

@PY.UBOT("channelwastalk")
@PY.UBOT("cwastalk")
async def channelwastalk_command(client: Client, message: Message):
    ggl = await EMO.GAGAL(client)
    sks = await EMO.BERHASIL(client)
    prs = await EMO.PROSES(client)
    
    # Parse argumen
    args = message.text.split()[1:]
    
    if not args:
        # Tampilkan help
        help_text = f"""
<blockquote><b>Cara pakai:</b>
ᚗ <code>.channelwastalk [link_channel]</code>
ᚗ <code>.cwastalk [link_channel]</code>

<b>Contoh dengan link:</b>
<code>.channelwastalk https://whatsapp.com/channel/0029Vb7fWF61CYoQMRaXBM1X</code>

<b>Contoh dengan ID:</b>
<code>.cwastalk 0029Vb7fWF61CYoQMRaXBM1X</code>

<b>📌 Fitur:</b>
• Melihat info channel WhatsApp
• Nama, deskripsi, followers
• Foto profile channel
• Link-channel

<b>💡 Tips:</b>
Bisa pakai link atau ID channel aja</blockquote>"""
        
        await message.reply_text(help_text)
        return
    
    # Ekstrak channel URL
    input_text = " ".join(args)
    channel_url = extract_channel_id(input_text)
    
    if not channel_url:
        await message.reply_text(
            f"{ggl} <b>Link/ID channel tidak valid!</b>\n"
            f"Contoh link: <code>https://whatsapp.com/channel/0029Vb7fWF61CYoQMRaXBM1X</code>\n"
            f"Contoh ID: <code>0029Vb7fWF61CYoQMRaXBM1X</code>"
        )
        return
    
    try:
        await client.send_chat_action(message.chat.id, ChatAction.TYPING)
        
        processing = await message.reply_text(f"{prs} <b>Mencari info channel...</b>")
        
        # Stalk channel
        result = await stalk_wa_channel(channel_url)
        
        await processing.delete()
        
        if result.get("success"):
            # Format pesan
            text = f"<blockquote><b>📌 Nama:</b> {result['name']}\n"
            text += f"<b>🆔 ID:</b> <code>{result['channel_id']}</code>\n"
            text += f"<b>🔗 Link:</b> <a href='{result['channel_url']}'>Klik disini</a>\n"
            text += f"<b>📝 Deskripsi:</b>\n<code>{format_description(result['description'])}</code>\n"
            text += f"\n👤 <b>Creator:</b> Ubot Premium Zyura</blockquote>"
            
            # Kirim foto profile kalo ada
            if result.get("image"):
                # Simpan gambar sementara
                file_path = f"wastalk_{message.from_user.id}_{random.randint(1000,9999)}.jpg"
                with open(file_path, "wb") as f:
                    f.write(result["image"])
                
                # Kirim foto dengan caption
                await client.send_photo(
                    chat_id=message.chat.id,
                    photo=file_path,
                    caption=text
                )
                
                # Hapus file
                if os.path.exists(file_path):
                    os.remove(file_path)
            else:
                # Kirim pesan aja kalo gak ada foto
                await message.reply_text(text)
            
        else:
            error_msg = result.get("error", "Unknown error")
            await message.reply_text(
                f"<blockquote><b>❌ GAGAL STALK CHANNEL</b>\n\n"
                f"<b>Error:</b> {error_msg}</blockquote>"
            )
        
    except Exception as e:
        await message.reply_text(f"{ggl} <b>Error: {str(e)[:100]}</b>")

