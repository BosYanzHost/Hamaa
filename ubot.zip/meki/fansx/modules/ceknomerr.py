from fansx import *
import aiohttp
import asyncio
import re
from pyrogram.enums import ChatAction, ParseMode
from pyrogram.types import Message

__MODULE__ = "ᴄᴇᴋ ɴᴏᴍᴏʀ ᴠ𝟸"
__HELP__ = """
<blockquote><b>⌲ Perintah:</b>
ᚗ <code>{0}ceknomorv2 [nomor]</code> - Cek operator nomor HP
ᚗ <code>{0}cn2 [nomor]</code> - Singkatan

<b>⌲ Contoh:</b>
<code>.ceknomorv2 099999898</code>
<code>.cn2 08889999</code></blockquote>
"""

# ============================================
# KONFIGURASI
# ============================================
CEK_API = "https://www.sankavollerei.com/random/cek-nomor"
API_KEY = "planaai"

# Database prefix operator Indonesia (lebih lengkap)
OPERATOR_PREFIX = {
    "Telkomsel": ["0811", "0812", "0813", "0821", "0822", "0823", "0852", "0853", "0851"],
    "Indosat": ["0814", "0815", "0816", "0855", "0856", "0857", "0858"],
    "XL": ["0817", "0818", "0819", "0859", "0877", "0878", "0879"],
    "Axis": ["0831", "0832", "0833", "0838", "0839"],
    "Tri": ["0895", "0896", "0897", "0898", "0899"],
    "Smart": ["0881", "0882", "0883", "0884", "0885", "0886", "0887", "0888", "0889"],
    "By.U": ["0851"],  # By.U pakai prefix Telkomsel
}

def clean_phone_number(nomor):
    """Bersihin nomor telepon dari karakter aneh"""
    # Hapus semua karakter non-digit
    cleaned = re.sub(r'\D', '', nomor)
    
    # Kalo diawali 0, biarin aja
    # Kalo diawali 62, ubah jadi 0
    if cleaned.startswith('62'):
        cleaned = '0' + cleaned[2:]
    
    return cleaned

def get_operator_from_prefix(nomor):
    """Coba deteksi operator dari prefix (fallback)"""
    nomor_bersih = clean_phone_number(nomor)
    
    # Ambil 4 digit pertama (prefix)
    prefix = nomor_bersih[:4] if len(nomor_bersih) >= 4 else nomor_bersih
    
    for operator, prefixes in OPERATOR_PREFIX.items():
        if any(prefix.startswith(p) for p in prefixes):
            return operator
    
    return "Tidak diketahui (deteksi manual)"

async def cek_nomor_hp_v2(nomor):
    """Cek informasi nomor HP versi 2"""
    
    # Bersihin nomor dulu
    nomor_bersih = clean_phone_number(nomor)
    
    # Validasi panjang nomor
    if len(nomor_bersih) < 10 or len(nomor_bersih) > 13:
        return {
            "success": False, 
            "error": f"Nomor tidak valid (panjang: {len(nomor_bersih)} digit). Panjang nomor Indonesia biasanya 10-13 digit."
        }
    
    # Encode parameter
    url = f"{CEK_API}?apikey={API_KEY}&nomor={nomor_bersih}"
    
    try:
        async with aiohttp.ClientSession() as session:
            async with session.get(url, timeout=15) as response:
                if response.status == 200:
                    data = await response.json()
                    
                    if data.get("status") and data.get("data"):
                        result = data["data"]
                        creator = data.get("creator", "Sanka Vollerei")
                        
                        # Deteksi operator dari prefix (sebagai informasi tambahan)
                        operator_manual = get_operator_from_prefix(nomor_bersih)
                        
                        return {
                            "success": True,
                            "nomor": result.get("nomor", nomor_bersih),
                            "operator": result.get("operator", "Tidak diketahui"),
                            "operator_manual": operator_manual,
                            "tipe": result.get("tipe", "Tidak diketahui"),
                            "lokasi": result.get("lokasi_perkiraan", "Tidak diketahui"),
                            "catatan": result.get("catatan", ""),
                            "creator": creator,
                            "valid": True,
                            "panjang": len(nomor_bersih)
                        }
                    else:
                        # Kalo API gagal, kita kasih data dari deteksi manual aja
                        operator_manual = get_operator_from_prefix(nomor_bersih)
                        
                        return {
                            "success": True,
                            "nomor": nomor_bersih,
                            "operator": operator_manual,
                            "operator_manual": operator_manual,
                            "tipe": "Tidak diketahui (deteksi manual)",
                            "lokasi": "Tidak diketahui (deteksi manual)",
                            "catatan": "Data dari deteksi prefix manual. API utama tidak merespon.",
                            "creator": "Sistem (Manual Detection)",
                            "valid": True,
                            "panjang": len(nomor_bersih),
                            "api_fallback": True
                        }
                elif response.status == 401:
                    return {"success": False, "error": "API Key tidak valid"}
                else:
                    # Fallback ke deteksi manual
                    operator_manual = get_operator_from_prefix(nomor_bersih)
                    
                    return {
                        "success": True,
                        "nomor": nomor_bersih,
                        "operator": operator_manual,
                        "operator_manual": operator_manual,
                        "tipe": "Tidak diketahui (deteksi manual)",
                        "lokasi": "Tidak diketahui (deteksi manual)",
                        "catatan": f"Data dari deteksi prefix manual. API error: HTTP {response.status}",
                        "creator": "Sistem (Manual Detection)",
                        "valid": True,
                        "panjang": len(nomor_bersih),
                        "api_fallback": True
                    }
    except asyncio.TimeoutError:
        # Fallback ke deteksi manual
        operator_manual = get_operator_from_prefix(nomor_bersih)
        
        return {
            "success": True,
            "nomor": nomor_bersih,
            "operator": operator_manual,
            "operator_manual": operator_manual,
            "tipe": "Tidak diketahui (deteksi manual)",
            "lokasi": "Tidak diketahui (deteksi manual)",
            "catatan": "Data dari deteksi prefix manual. API timeout.",
            "creator": "Sistem (Manual Detection)",
            "valid": True,
            "panjang": len(nomor_bersih),
            "api_fallback": True
        }
    except Exception as e:
        return {"success": False, "error": str(e)}

@PY.UBOT("ceknomorv2")
@PY.UBOT("cn2")
async def ceknomorv2_command(client: Client, message: Message):
    ggl = await EMO.GAGAL(client)
    sks = await EMO.BERHASIL(client)
    prs = await EMO.PROSES(client)
    
    # Parse argumen
    args = message.text.split()[1:]
    
    if not args:
        # Tampilkan help
        help_text = f"""
<blockquote><b>Cara pakai:</b>
ᚗ <code>.ceknomorv2 [nomor]</code>
ᚗ <code>.cn2 [nomor]</code>

<b>Contoh:</b>
<code>.ceknomorv2 083838383888</code>
<code>.cn2 0283838383838</code>
<code>.cn2 62839393933</code>

<b>📌 Fitur V2:</b>
• Deteksi operator lebih akurat
• Fallback ke deteksi manual kalo API error
• Validasi panjang nomor
• Database prefix lengkap

<b>📡 Operator support:</b>
• Telkomsel (0811,0812,0813,0821,0822,0823,0852,0853,0851)
• Indosat (0814,0815,0816,0855,0856,0857,0858)
• XL (0817,0818,0819,0859,0877,0878,0879)
• Axis (0831,0832,0833,0838,0839)
• Tri (0895,0896,0897,0898,0899)
• Smart (0881-0889)
• By.U (0851 - Telkomsel)</blockquote>"""
        
        await message.reply_text(help_text)
        return
    
    nomor = " ".join(args)
    
    try:
        await client.send_chat_action(message.chat.id, ChatAction.TYPING)
        
        processing = await message.reply_text(f"{prs} <b>Mengecek nomor {nomor} (V2)...</b>")
        
        # Cek nomor
        result = await cek_nomor_hp_v2(nomor)
        
        await processing.delete()
        
        if result.get("success"):
            # Format pesan
            text = f"<blockquote><b>📞 Nomor:</b> <code>{result['nomor']}</code>\n"
            text += f"<b>📏 Panjang:</b> {result['panjang']} digit\n"
            text += f"<b>📡 Operator:</b> {result['operator']}\n"
            
            # Tampilkan deteksi manual kalo beda
            if result.get('operator_manual') and result['operator_manual'] != result['operator']:
                text += f"<b>🔍 Deteksi manual:</b> {result['operator_manual']}\n"
            
            text += f"<b>💳 Tipe:</b> {result['tipe']}\n"
            text += f"<b>📍 Lokasi:</b> {result['lokasi']}\n"
            
            if result.get('catatan'):
                text += f"\n<i>📌 Catatan: {result['catatan']}</i>\n"
            
            if result.get('api_fallback'):
                text += f"\n⚠️ <b>Mode Fallback:</b> Menggunakan deteksi manual karena API utama bermasalah.\n"
            
            text += f"\n👤 <b>Creator:</b> Ubot Premium Zyura</blockquote>"
            
            await message.reply_text(text)
            
        else:
            error_msg = result.get("error", "Unknown error")
            await message.reply_text(
                f"<blockquote><b>❌ GAGAL CEK NOMOR V2</b>\n\n"
                f"<b>Nomor:</b> {nomor}\n"
                f"<b>Error:</b> {error_msg}</blockquote>"
            )
        
    except Exception as e:
        await message.reply_text(f"{ggl} <b>Error: {str(e)[:100]}</b>")

