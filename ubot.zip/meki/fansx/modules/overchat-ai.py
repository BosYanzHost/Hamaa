from fansx import *
import requests
import aiohttp
import asyncio
import json
import uuid
from pyrogram.enums import ChatAction, ParseMode
from pyrogram.types import Message

__MODULE__ = "ᴏᴠᴇʀᴄʜᴀᴛ ᴀɪ"
__HELP__ = """
<blockquote><b>『 OVERCHAT AI 』</b>

<b>⌲ Perintah:</b>
ᚗ <code>{0}overchat [pertanyaan]</code> 
ᚗ <code>{0}aioverchat [pertanyaan]</code>
⊶ Bertanya dengan AI Overchat (GPT-4o)

<b>⌲ Contoh:</b>
<code>.overchat jelaskan apa itu plankton</code>
<code>.aioverchat apa itu AI?</code></blockquote>
"""

# API Endpoint
API_URL = "https://api.overchat.ai/v1/chat/completions"

# Headers default
HEADERS = {
    'Content-Type': 'application/json',
    'Accept': '*/*',
    'X-Device-Platform': 'web',
    'X-Device-Language': 'id-ID',
    'Origin': 'https://overchat.ai',
    'Referer': 'https://overchat.ai/chat/best-free-ai-chat',
    'User-Agent': 'Mozilla/5.0 (Android 12; Mobile; rv:146.0) Gecko/146.0 Firefox/146.0'
}

async def overchat_request(query: str):
    """Melakukan request ke API Overchat"""
    
    # Generate UUIDs
    chat_id = str(uuid.uuid4())
    message_id = str(uuid.uuid4())
    device_uuid = str(uuid.uuid4())
    
    # Update headers dengan device UUID
    headers = HEADERS.copy()
    headers['X-Device-Uuid'] = device_uuid
    headers['X-Device-Version'] = '1.0.44'
    
    # Payload
    payload = {
        "chatId": chat_id,
        "model": "openai/gpt-4o",
        "messages": [
            {
                "id": message_id,
                "role": "user",
                "content": query
            }
        ],
        "personaId": "gpt-4o-landing",
        "frequency_penalty": 0,
        "max_tokens": 4000,
        "presence_penalty": 0,
        "stream": True,
        "temperature": 0.5,
        "top_p": 0.95
    }
    
    try:
        async with aiohttp.ClientSession() as session:
            async with session.post(API_URL, json=payload, headers=headers, timeout=60) as response:
                if response.status != 200:
                    return {'success': False, 'error': f'HTTP {response.status}'}
                
                # Proses streaming response
                result = ""
                buffer = ""
                
                async for chunk in response.content.iter_chunked(1024):
                    buffer += chunk.decode('utf-8', errors='ignore')
                    
                    # Split by newline
                    lines = buffer.split('\n')
                    buffer = lines.pop()  # Simpan yang belum lengkap
                    
                    for line in lines:
                        line = line.strip()
                        if not line.startswith('data:'):
                            continue
                        
                        data = line.replace('data:', '').strip()
                        if not data:
                            continue
                        
                        if data == '[DONE]':
                            break
                        
                        try:
                            json_data = json.loads(data)
                            delta = json_data.get('choices', [{}])[0].get('delta', {}).get('content')
                            if delta:
                                result += delta
                        except:
                            continue
                
                if not result.strip():
                    return {'success': False, 'error': 'Tidak ada jawaban'}
                
                return {'success': True, 'result': result.strip()}
    
    except asyncio.TimeoutError:
        return {'success': False, 'error': 'Timeout'}
    except Exception as e:
        return {'success': False, 'error': str(e)}

@PY.UBOT("overchat")
async def overchat_handler(client: Client, message: Message):
    await process_overchat(client, message)

@PY.UBOT("aioverchat")
async def aioverchat_handler(client: Client, message: Message):
    await process_overchat(client, message)

async def process_overchat(client: Client, message: Message):
    ggl = await EMO.GAGAL(client)
    sks = await EMO.BERHASIL(client)
    prs = await EMO.PROSES(client)
    
    try:
        await client.send_chat_action(message.chat.id, ChatAction.TYPING)
        
        # Ambil pertanyaan
        args = message.text.split(maxsplit=1)
        if len(args) < 2:
            await message.reply_text(
                f"<blockquote><b>❌ Masukkan pertanyaan!</b>\n\n"
                f"<b>Contoh:</b>\n"
                f"<code>.overchat jelaskan apa itu plankton</code>\n"
                f"<code>.aioverchat apa itu AI?</code></blockquote>"
            )
            return
        
        query = args[1].strip()
        
        # Kirim pesan processing
        processing = await message.reply_text(f"{prs} <b>Overchat AI sedang berpikir...</b>")
        
        # Panggil API
        result = await overchat_request(query)
        
        if result.get('success'):
            await processing.delete()
            
            # Format jawaban
            answer = result['result']
            
            # Batasi panjang jawaban (max 4000 karakter)
            if len(answer) > 4000:
                answer = answer[:4000] + "...\n\n(Jawaban dipotong karena terlalu panjang)"
            
            # Kirim jawaban
            await message.reply_text(
                f"<blockquote><b>🤖 Overchat AI</b>\n\n"
                f"{answer}\n\n"
                f"⚡ <b>Powered by:</b> Ubot Premium Zyura</blockquote>"
            )
        else:
            error_msg = result.get('error', 'Unknown error')
            await processing.edit_text(
                f"{ggl} <b>Gagal mendapatkan jawaban!</b>\n\n"
                f"Error: {error_msg}"
            )
        
    except Exception as e:
        await message.reply_text(f"{ggl} <b>Error: {str(e)[:100]}</b>")

@PY.BOT("overchat")
async def overchat_bot_handler(client: Client, message: Message):
    """Handler untuk bot"""
    try:
        args = message.text.split(maxsplit=1)
        if len(args) < 2:
            await message.reply_text(
                "❌ Masukkan pertanyaan!\n"
                "Contoh: /overchat jelaskan apa itu plankton"
            )
            return
        
        query = args[1].strip()
        
        processing = await message.reply_text("🔍 Overchat AI sedang berpikir...")
        
        result = await overchat_request(query)
        
        await processing.delete()
        
        if result.get('success'):
            answer = result['result']
            if len(answer) > 4000:
                answer = answer[:4000] + "..."
            
            await message.reply_text(answer)
        else:
            await message.reply_text(f"❌ Gagal: {result.get('error', 'Unknown error')}")
        
    except Exception as e:
        await message.reply_text(f"❌ Error: {str(e)[:100]}")