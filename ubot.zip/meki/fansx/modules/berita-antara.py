from fansx import *
import aiohttp
import asyncio
import random
import json
import os
from datetime import datetime
from pyrogram.enums import ChatAction, ParseMode
from pyrogram.types import Message

__MODULE__ = "ʙᴇʀɪᴛᴀ ᴀɴᴛᴀʀᴀ"
__HELP__ = """
<blockquote><b>📰 BERITA ANTARA NEWS</b>

<b>⌲ Perintah:</b>
ᚗ <code>{0}berita</code> - Ambil 1 berita random
ᚗ <code>{0}news</code> - Ambil 1 berita random
ᚗ <code>{0}antara</code> - Ambil 1 berita random

<b>⌲ Kategori berita:</b>
• Metro, Dunia, Ekonomi, Sepakbola
• Berita terkini dari Antara News

<b>⌲ Contoh:</b>
<code>.berita</code>
<code>.news</code></blockquote>
"""

# ============================================
# KONFIGURASI
# ============================================
API_URL = "https://api.deline.web.id/berita/antara"

async def get_news():
    """Ambil daftar berita dari API"""
    try:
        async with aiohttp.ClientSession() as session:
            async with session.get(API_URL, timeout=15) as response:
                if response.status == 200:
                    data = await response.json()
                    if data.get("status") and data.get("data"):
                        return data.get("data", [])
    except Exception as e:
        print(f"Error get news: {e}")
    return None

def truncate_text(text, limit=200):
    """Potong teks jika terlalu panjang"""
    if len(text) > limit:
        return text[:limit] + "..."
    return text

@PY.UBOT("berita")
@PY.UBOT("news")
@PY.UBOT("antara")
async def get_random_news(client: Client, message: Message):
    ggl = await EMO.GAGAL(client)
    prs = await EMO.PROSES(client)
    
    try:
        await client.send_chat_action(message.chat.id, ChatAction.TYPING)
        
        processing = await message.reply_text(f"{prs} <b>Mengambil berita terkini...</b>")
        
        news_list = await get_news()
        
        if not news_list:
            await processing.edit_text(f"{ggl} <b>Gagal mengambil berita!</b>")
            return
        
        # Ambil 1 berita random
        news = random.choice(news_list)
        
        title = news.get("title", "Judul tidak tersedia")
        link = news.get("link", "#")
        image = news.get("image", "")
        category = news.get("category", "Umum")
        
        await processing.delete()
        
        # Coba ambil thumbnail
        if image:
            try:
                await client.send_photo(
                    chat_id=message.chat.id,
                    photo=image,
                    caption=f"<blockquote><b>📰 {title}</b>\n\n"
                            f"📌 <b>Kategori:</b> {category}\n"
                            f"🔗 <b>Baca selengkapnya:</b>\n{link}</blockquote>"
                )
                return
            except:
                # Fallback kalo gagal kirim foto
                pass
        
        # Kirim tanpa foto
        await message.reply_text(
            f"<blockquote><b>📰 {title}</b>\n\n"
            f"📌 <b>Kategori:</b> {category}\n"
            f"🔗 <b>Baca selengkapnya:</b>\n{link}</blockquote>"
        )
        
    except Exception as e:
        await message.reply_text(f"{ggl} <b>Error: {str(e)[:100]}</b>")

@PY.UBOT("beritakategori")
async def news_by_category(client: Client, message: Message):
    """Ambil berita berdasarkan kategori"""
    ggl = await EMO.GAGAL(client)
    prs = await EMO.PROSES(client)
    
    try:
        args = message.text.split(maxsplit=1)
        if len(args) < 2:
            await message.reply_text(
                f"<blockquote><b>📰 BERITA PER KATEGORI</b>\n\n"
                f"<b>Format:</b> <code>.beritakategori [kategori]</code>\n\n"
                f"<b>Kategori tersedia:</b>\n"
                f"• Metro\n"
                f"• Dunia\n"
                f"• Ekonomi\n"
                f"• Sepakbola\n\n"
                f"<b>Contoh:</b> <code>.beritakategori Metro</code></blockquote>"
            )
            return
        
        category_input = args[1].strip().lower()
        
        processing = await message.reply_text(f"{prs} <b>Mencari berita kategori {category_input}...</b>")
        
        news_list = await get_news()
        
        if not news_list:
            await processing.edit_text(f"{ggl} <b>Gagal mengambil berita!</b>")
            return
        
        # Filter berdasarkan kategori
        filtered = [n for n in news_list if n.get("category", "").lower() == category_input]
        
        if not filtered:
            await processing.edit_text(
                f"{ggl} <b>Tidak ada berita untuk kategori '{category_input}'</b>\n\n"
                f"Kategori tersedia: Metro, Dunia, Ekonomi, Sepakbola"
            )
            return
        
        # Ambil 1 random dari kategori
        news = random.choice(filtered)
        
        title = news.get("title", "Judul tidak tersedia")
        link = news.get("link", "#")
        image = news.get("image", "")
        category = news.get("category", "Umum")
        
        await processing.delete()
        
        # Coba kirim dengan foto
        if image:
            try:
                await client.send_photo(
                    chat_id=message.chat.id,
                    photo=image,
                    caption=f"<blockquote><b>📰 {title}</b>\n\n"
                            f"📌 <b>Kategori:</b> {category}\n"
                            f"🔗 <b>Baca selengkapnya:</b>\n{link}</blockquote>"
                )
                return
            except:
                pass
        
        # Kirim tanpa foto
        await message.reply_text(
            f"<blockquote><b>📰 {title}</b>\n\n"
            f"📌 <b>Kategori:</b> {category}\n"
            f"🔗 <b>Baca selengkapnya:</b>\n{link}</blockquote>"
        )
        
    except Exception as e:
        await message.reply_text(f"{ggl} <b>Error: {str(e)[:100]}</b>")

@PY.UBOT("beritainfo")
async def news_info(client: Client, message: Message):
    """Info fitur berita"""
    
    text = """
<blockquote><b>📰 INFO FITUR BERITA</b>

<b>Sumber:</b> Antara News (ANTARA)
<b>Update:</b> Real-time dari API

<b>Cara pakai:</b>
• <code>.berita</code> - Berita random
• <code>.news</code> - Berita random
• <code>.antara</code> - Berita random
• <code>.beritakategori [nama]</code> - Berita per kategori

<b>Kategori tersedia:</b>
• Metro - Berita Jakarta & sekitarnya
• Dunia - Berita internasional
• Ekonomi - Berita bisnis & ekonomi
• Sepakbola - Berita sepakbola

<b>Contoh:</b>
<code>.berita</code>
<code>.beritakategori Dunia</code></blockquote>"""
    
    await message.reply_text(text)