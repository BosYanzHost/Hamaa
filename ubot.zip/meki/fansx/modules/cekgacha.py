from fansx import *
import random
import asyncio
from pyrogram.enums import ChatAction
from pyrogram.types import Message

__MODULE__ = "ᴄᴇᴋ ʜᴏᴋɪ ɢᴀᴄʜᴀ"
__HELP__ = """
<blockquote><b>『 CEK HOKI GACHA 』</b>

<b>⌲ Perintah:</b>
ᚗ <code>{0}hoki [nama]</code> 
⊶ Mengecek tingkat keberuntungan gacha seseorang

<b>⌲ Contoh:</b>
<code>.hoki</code> (untuk cek diri sendiri)
<code>.hoki Budi</code> (untuk cek orang lain)
<code>.hoki @username</code></blockquote>
"""

def get_description(percent):
    """Mendapatkan deskripsi berdasarkan persentase hoki gacha"""
    if percent >= 90:
        return "HOKI PARAH! SSR GUARANTEED! ✨💎"
    elif percent >= 70:
        return "Lucky! Pasti dapet SR keatas! 🍀"
    elif percent >= 50:
        return "Hoki-hoki dikit 😊"
    elif percent >= 30:
        return "Hmm... pray harder! 🙏"
    else:
        return "SIAL! Nanti aja gachanya! 💔"

@PY.UBOT("hoki")
async def cek_hoki(client: Client, message: Message):
    ggl = await EMO.GAGAL(client)
    sks = await EMO.BERHASIL(client)
    prs = await EMO.PROSES(client)
    
    try:
        await client.send_chat_action(message.chat.id, ChatAction.TYPING)
        
        # Ambil nama dari input atau reply
        nama = "Kamu"
        
        # Cek apakah reply ke user
        if message.reply_to_message and message.reply_to_message.from_user:
            user = message.reply_to_message.from_user
            nama = user.first_name
            if user.last_name:
                nama += f" {user.last_name}"
        
        # Cek dari argumen
        args = message.text.split(maxsplit=1)
        if len(args) > 1:
            input_nama = args[1].strip()
            
            # Cek apakah mention @username
            if input_nama.startswith('@'):
                try:
                    user = await client.get_users(input_nama)
                    nama = user.first_name
                    if user.last_name:
                        nama += f" {user.last_name}"
                except:
                    nama = input_nama
            else:
                nama = input_nama
        
        # Jika tidak ada input dan tidak reply, pakai nama sender
        elif nama == "Kamu":
            nama = message.from_user.first_name
            if message.from_user.last_name:
                nama += f" {message.from_user.last_name}"
        
        # Generate random persentase hoki
        percent = random.randint(0, 100)
        desc = get_description(percent)
        
        # Buat progress bar visual dengan emoji gacha
        bar_length = 20
        filled_length = int(bar_length * percent / 100)
        bar = '✨' * filled_length + '💔' * (bar_length - filled_length)
        
        # Kirim pesan processing dulu (biar ada efek)
        processing = await message.reply_text(f"{prs} <b>Mengecek hoki gacha {nama}...</b>")
        
        # Tunggu bentar biar keliatan prosesnya
        await asyncio.sleep(1)
        
        # Format pesan
        txt = f"""
<blockquote><b>🎰 CEK HOKI GACHA</b>

<b>👤 Nama:</b> <code>{nama}</code>
<b>📊 Tingkat Hoki:</b> <code>{percent}%</code>

<code>{bar}</code>

<b>💬 {desc}</b></blockquote>
"""
        
        await processing.edit_text(txt)
        
    except Exception as e:
        await message.reply_text(f"{ggl} <b>Error: {str(e)[:100]}</b>")

@PY.UBOT("gacha")
async def gacha_alias(client: Client, message: Message):
    """Alias untuk hoki"""
    await cek_hoki(client, message)

@PY.UBOT("cekhoki")
async def cek_hoki_alias(client: Client, message: Message):
    """Alias untuk hoki"""
    await cek_hoki(client, message)

@PY.UBOT("luck")
async def luck_alias(client: Client, message: Message):
    """Alias untuk hoki"""
    await cek_hoki(client, message)

@PY.BOT("hoki")
async def cek_hoki_bot(client: Client, message: Message):
    """Handler untuk bot"""
    try:
        nama = "Kamu"
        
        if message.reply_to_message and message.reply_to_message.from_user:
            user = message.reply_to_message.from_user
            nama = user.first_name
            if user.last_name:
                nama += f" {user.last_name}"
        
        args = message.text.split(maxsplit=1)
        if len(args) > 1:
            input_nama = args[1].strip()
            if input_nama.startswith('@'):
                try:
                    user = await client.get_users(input_nama)
                    nama = user.first_name
                    if user.last_name:
                        nama += f" {user.last_name}"
                except:
                    nama = input_nama
            else:
                nama = input_nama
        
        # Generate random persentase hoki
        percent = random.randint(0, 100)
        desc = get_description(percent)
        
        # Buat progress bar sederhana
        bar_length = 15
        filled_length = int(bar_length * percent / 100)
        bar = '✨' * filled_length + '💔' * (bar_length - filled_length)
        
        txt = f"""
🎰 *CEK HOKI GACHA*

👤 Nama: {nama}
📊 Tingkat Hoki: {percent}%

{bar}

💬 {desc}
"""
        await message.reply_text(txt)
        
    except Exception as e:
        await message.reply_text(f"❌ Error: {str(e)[:100]}")