from fansx import *
import aiohttp
import asyncio
import os
import random
from pyrogram.enums import ChatAction, ParseMode
from pyrogram.types import Message

__MODULE__ = "ɪᴍᴀɢᴇ ᴛᴏ ᴘʀᴏᴍᴘᴛ"
__HELP__ = """
<blockquote><b>🖼️ IMAGE TO PROMPT</b>

<b>⌲ Perintah:</b>
ᚗ <code>{0}img2prompt</code> - Reply ke foto, AI akan membuat prompt deskripsi
ᚗ <code>{0}describe</code> - Alias

<b>⌲ Contoh:</b>
<code>.img2prompt</code> (reply ke foto)
<code>.describe</code> (reply ke foto)</blockquote>
"""

# ============================================
# KONFIGURASI
# ============================================
BASE_URL = "https://api.siputzx.my.id/api/ai/duckai"
MODEL = "gpt-4o-mini"

# System prompt khusus untuk image to prompt
SYSTEM_PROMPT = """Anda adalah seorang ahli dalam mendeskripsikan gambar dengan sangat detail.
Tugas Anda adalah menganalisis gambar yang diberikan dan membuat deskripsi/prompt yang akurat.
Prompt harus mencakup:

1. Subjek utama (apa yang ada di gambar)
2. Gaya visual (realistis, anime, kartun, lukisan, dll)
3. Warna dominan
4. Komposisi (close-up, wide shot, dll)
5. Pencahayaan
6. Latar belakang
7. Ekspresi atau emosi yang ditampilkan
8. Detail teknis (resolusi, kualitas, dll)

Berikan deskripsi dalam bahasa Indonesia yang detail dan informatif."""

async def upload_to_catbox(file_path):
    """Upload gambar ke catbox.moe"""
    try:
        async with aiohttp.ClientSession() as session:
            data = aiohttp.FormData()
            data.add_field('fileToUpload', 
                          open(file_path, 'rb'),
                          filename='image.jpg',
                          content_type='image/jpeg')
            data.add_field('reqtype', 'fileupload')
            
            async with session.post('https://catbox.moe/user/api.php', data=data, timeout=30) as resp:
                if resp.status == 200:
                    url = await resp.text()
                    return url.strip()
    except Exception as e:
        print(f"Catbox upload error: {e}")
    return None

async def analyze_image(image_url):
    """Analisis gambar menggunakan Duck AI"""
    
    # Prompt untuk analisis gambar
    user_message = f"Analisis gambar ini dan buat deskripsi detail: {image_url}"
    
    # Encode parameter
    import urllib.parse
    encoded_prompt = urllib.parse.quote(SYSTEM_PROMPT)
    encoded_message = urllib.parse.quote(user_message)
    
    url = f"{BASE_URL}?message={encoded_message}&model={MODEL}&systemPrompt={encoded_prompt}"
    
    try:
        async with aiohttp.ClientSession() as session:
            async with session.get(url, timeout=60) as response:
                if response.status == 200:
                    data = await response.json()
                    
                    if data.get("status") and data.get("data"):
                        message = data["data"].get("message", "")
                        return {
                            "success": True,
                            "description": message.strip()
                        }
                    else:
                        return {"success": False, "error": "Response tidak valid"}
                else:
                    return {"success": False, "error": f"HTTP {response.status}"}
    except asyncio.TimeoutError:
        return {"success": False, "error": "Timeout - gambar terlalu kompleks"}
    except Exception as e:
        return {"success": False, "error": str(e)}

@PY.UBOT("img2prompt")
@PY.UBOT("describe")
async def image_to_prompt(client: Client, message: Message):
    ggl = await EMO.GAGAL(client)
    sks = await EMO.BERHASIL(client)
    prs = await EMO.PROSES(client)
    
    try:
        await client.send_chat_action(message.chat.id, ChatAction.TYPING)
        
        # Cek apakah ada reply gambar
        if not message.reply_to_message or not message.reply_to_message.photo:
            await message.reply_text(
                f"<blockquote><b>❌ Reply ke foto yang mau dianalisis!</b>\n\n"
                f"<b>Contoh:</b>\n"
                f"<code>.img2prompt</code> (reply ke foto)</blockquote>"
            )
            return
        
        # Download gambar
        processing = await message.reply_text(f"{prs} <b>Mendownload gambar...</b>")
        
        file_path = await message.reply_to_message.download()
        
        await processing.edit_text(f"{prs} <b>Mengupload ke catbox.moe...</b>")
        
        # Upload ke catbox
        image_url = await upload_to_catbox(file_path)
        
        # Hapus file lokal
        if os.path.exists(file_path):
            os.remove(file_path)
        
        if not image_url:
            await processing.edit_text(f"{ggl} <b>Gagal upload ke catbox!</b>")
            return
        
        await processing.edit_text(f"{prs} <b>Sedang menganalisis gambar...</b>")
        
        # Analisis gambar
        result = await analyze_image(image_url)
        
        await processing.delete()
        
        if result.get("success"):
            description = result["description"]
            
            # Format output
            formatted = f"""
<blockquote><b>🖼️ ANALISIS GAMBAR</b>

{description}

🔗 <a href='{image_url}'>Lihat Gambar</a>
⚡ <b>Powered by:</b> Ubot Premium Zyura</blockquote>"""
            
            await message.reply_text(formatted)
        else:
            error_msg = result.get("error", "Unknown error")
            await message.reply_text(
                f"<blockquote><b>❌ GAGAL MENGANALISIS GAMBAR</b>\n\n"
                f"Error: {error_msg}</blockquote>"
            )
        
    except Exception as e:
        await message.reply_text(f"{ggl} <b>Error: {str(e)[:100]}</b>")

