from fansx import *
import requests
import aiohttp
import asyncio
import os
from io import BytesIO
from pyrogram.enums import ChatAction, ParseMode
from pyrogram.types import Message
from urllib.parse import quote

__MODULE__ = "ᴄᴏᴅᴇ sɴᴀᴘ"
__HELP__ = """
<blockquote><b>『 CODE SNAPSHOT 』</b>

<b>⌲ Perintah:</b>
ᚗ <code>{0}codesnap [kode]</code> 
⊶ Membuat gambar kode aesthetic

<b>⌲ Contoh:</b>
<code>.codesnap print('Hello World')</code>
<code>.codesnap def hello(): return 'Hi'</code>

<b>⌲ Bisa juga reply ke pesan yang berisi kode:</b>
Reply ke pesan kode lalu ketik <code>.codesnap</code></blockquote>
"""

# Base URL API
BASE_URL = "https://api-faa.my.id/faa/codesnap"

async def download_image(url):
    """Download gambar dari URL"""
    async with aiohttp.ClientSession() as session:
        async with session.get(url, timeout=30) as response:
            if response.status == 200:
                return await response.read()
    return None

@PY.UBOT("codesnap")
async def code_snap(client: Client, message: Message):
    ggl = await EMO.GAGAL(client)
    sks = await EMO.BERHASIL(client)
    prs = await EMO.PROSES(client)
    
    try:
        await client.send_chat_action(message.chat.id, ChatAction.TYPING)
        
        # Ambil kode dari reply atau argumen
        code = None
        
        # Cek apakah reply ke pesan
        if message.reply_to_message and message.reply_to_message.text:
            code = message.reply_to_message.text
        
        # Cek dari argumen
        if not code:
            args = message.text.split(maxsplit=1)
            if len(args) > 1:
                code = args[1].strip()
        
        if not code:
            await message.reply_text(
                f"<blockquote><b>❌ Masukkan kode atau reply ke pesan!</b>\n\n"
                f"<b>Contoh:</b>\n"
                f"<code>.codesnap print('Hello World')</code>\n"
                f"Atau reply ke pesan yang berisi kode.</blockquote>"
            )
            return
        
        # Batasi panjang kode (biar gak kepanjangan)
        if len(code) > 1000:
            await message.reply_text(f"{ggl} <b>Kode terlalu panjang! Maksimal 1000 karakter.</b>")
            return
        
        # Kirim pesan processing
        processing = await message.reply_text(f"{prs} <b>Membuat code snapshot...</b>")
        
        # Buat URL dengan parameter
        url = f"{BASE_URL}?text={quote(code)}"
        
        # Download gambar
        image_data = await download_image(url)
        
        if image_data:
            # Simpan sementara
            file_path = f"codesnap_{message.from_user.id}.png"
            with open(file_path, 'wb') as f:
                f.write(image_data)
            
            await processing.delete()
            
            # Kirim gambar
            await client.send_photo(
                chat_id=message.chat.id,
                photo=file_path,
                caption=f"<blockquote><b>📸 CODE SNAPSHOT</b>\n\n"
                        f"<code>{code[:50]}{'...' if len(code) > 50 else ''}</code></blockquote>"
            )
            
            # Hapus file
            if os.path.exists(file_path):
                os.remove(file_path)
        else:
            await processing.edit_text(f"{ggl} <b>Gagal membuat code snapshot!</b>")
        
    except asyncio.TimeoutError:
        await message.reply_text(f"{ggl} <b>Timeout! Server sedang sibuk.</b>")
    except aiohttp.ClientError as e:
        await message.reply_text(f"{ggl} <b>Gagal terhubung ke server: {str(e)[:100]}</b>")
    except Exception as e:
        await message.reply_text(f"{ggl} <b>Error: {str(e)[:100]}</b>")

@PY.UBOT("cs")
async def cs_alias(client: Client, message: Message):
    """Alias pendek untuk codesnap"""
    await code_snap(client, message)

@PY.BOT("codesnap")
async def code_snap_bot(client: Client, message: Message):
    """Handler untuk bot"""
    try:
        code = None
        
        if message.reply_to_message and message.reply_to_message.text:
            code = message.reply_to_message.text
        
        if not code:
            args = message.text.split(maxsplit=1)
            if len(args) > 1:
                code = args[1].strip()
        
        if not code:
            await message.reply_text(
                "❌ Masukkan kode atau reply ke pesan!\n"
                "Contoh: /codesnap print('Hello')"
            )
            return
        
        if len(code) > 1000:
            await message.reply_text("❌ Kode terlalu panjang! Maksimal 1000 karakter.")
            return
        
        processing = await message.reply_text("🔍 Membuat code snapshot...")
        
        url = f"{BASE_URL}?text={quote(code)}"
        
        async with aiohttp.ClientSession() as session:
            async with session.get(url, timeout=30) as response:
                if response.status == 200:
                    image_data = await response.read()
                    file_path = f"codesnap_bot_{message.from_user.id}.png"
                    
                    with open(file_path, 'wb') as f:
                        f.write(image_data)
                    
                    await processing.delete()
                    
                    await client.send_photo(
                        chat_id=message.chat.id,
                        photo=file_path,
                        caption=f"📸 Code Snapshot"
                    )
                    
                    if os.path.exists(file_path):
                        os.remove(file_path)
                else:
                    await processing.edit_text(f"❌ HTTP Error: {response.status}")
        
    except Exception as e:
        await message.reply_text(f"❌ Error: {str(e)[:100]}")