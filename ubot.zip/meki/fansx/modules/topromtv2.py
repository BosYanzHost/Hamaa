from fansx import *
import aiohttp
import asyncio
import os
import random
from urllib.parse import quote
from pyrogram.enums import ChatAction, ParseMode
from pyrogram.types import Message

__MODULE__ = "ɪᴍᴀɢᴇ ᴛᴏ ᴘʀᴏᴍᴘᴛ ᴠ2"
__HELP__ = """
<blockquote><b>🖼️ IMAGE TO PROMPT V2</b>

<b>⌲ Perintah:</b>
ᚗ <code>{0}img2promptv2</code> - Reply ke foto, AI akan membuat prompt deskripsi

<b>⌲ Contoh:</b>
<code>.img2promptv2</code> (reply ke foto)

<b>⌲ Hasil:</b>
• Original prompt (English)
• Translated prompt (Indonesia)</blockquote>
"""

# ============================================
# KONFIGURASI
# ============================================
BASE_URL = "https://api.deline.web.id/ai/toprompt"

async def upload_to_catbox(file_path):
    """Upload gambar ke catbox.moe"""
    try:
        async with aiohttp.ClientSession() as session:
            data = aiohttp.FormData()
            data.add_field('fileToUpload', 
                          open(file_path, 'rb'),
                          filename='image.jpg',
                          content_type='image/jpeg')
            data.add_field('reqtype', 'fileupload')
            
            async with session.post('https://catbox.moe/user/api.php', data=data, timeout=30) as resp:
                if resp.status == 200:
                    url = await resp.text()
                    return url.strip()
    except Exception as e:
        print(f"Catbox upload error: {e}")
    return None

async def get_prompt_from_api(image_url):
    """Ambil prompt dari API deline"""
    try:
        encoded_url = quote(image_url, safe='')
        api_url = f"{BASE_URL}?url={encoded_url}"
        
        async with aiohttp.ClientSession() as session:
            async with session.get(api_url, timeout=30) as response:
                if response.status == 200:
                    data = await response.json()
                    
                    if data.get("status") and data.get("result"):
                        result = data["result"]
                        return {
                            "success": True,
                            "original": result.get("original", ""),
                            "translated": result.get("translated", "")
                        }
                    else:
                        return {"success": False, "error": "Response tidak valid"}
                else:
                    return {"success": False, "error": f"HTTP {response.status}"}
    except asyncio.TimeoutError:
        return {"success": False, "error": "Timeout"}
    except Exception as e:
        return {"success": False, "error": str(e)}

@PY.UBOT("img2promptv2")
async def image_to_prompt_v2(client: Client, message: Message):
    ggl = await EMO.GAGAL(client)
    sks = await EMO.BERHASIL(client)
    prs = await EMO.PROSES(client)
    
    try:
        await client.send_chat_action(message.chat.id, ChatAction.TYPING)
        
        # Cek apakah ada reply gambar
        if not message.reply_to_message or not message.reply_to_message.photo:
            await message.reply_text(
                f"<blockquote><b>❌ Reply ke foto yang mau dianalisis!</b>\n\n"
                f"<b>Contoh:</b>\n"
                f"<code>.img2promptv2</code> (reply ke foto)</blockquote>"
            )
            return
        
        # Download gambar
        processing = await message.reply_text(f"{prs} <b>Mendownload gambar...</b>")
        
        file_path = await message.reply_to_message.download()
        
        await processing.edit_text(f"{prs} <b>Mengupload ke catbox.moe...</b>")
        
        # Upload ke catbox
        image_url = await upload_to_catbox(file_path)
        
        # Hapus file lokal
        if os.path.exists(file_path):
            os.remove(file_path)
        
        if not image_url:
            await processing.edit_text(f"{ggl} <b>Gagal upload ke catbox!</b>")
            return
        
        await processing.edit_text(f"{prs} <b>AI sedang menganalisis gambar...</b>")
        
        # Dapatkan prompt dari API
        result = await get_prompt_from_api(image_url)
        
        await processing.delete()
        
        if result.get("success"):
            original = result["original"]
            translated = result["translated"]
            
            # Format output
            formatted = f"""
<blockquote><b>🖼️ IMAGE TO PROMPT V2</b>

<b>🔤 Original Prompt (English):</b>
<code>{original}</code>

<b>🇮🇩 Translated Prompt (Indonesia):</b>
<code>{translated}</code>

🔗 <a href='{image_url}'>Lihat Gambar</a>
⚡ <b>Powered by:</b> Ubot Premium Zyura</blockquote>"""
            
            await message.reply_text(formatted)
        else:
            error_msg = result.get("error", "Unknown error")
            await message.reply_text(
                f"<blockquote><b>❌ GAGAL MENGANALISIS GAMBAR</b>\n\n"
                f"Error: {error_msg}</blockquote>"
            )
        
    except Exception as e:
        await message.reply_text(f"{ggl} <b>Error: {str(e)[:100]}</b>")

