from fansx import *
import random
import asyncio
from pyrogram.enums import ChatAction
from pyrogram.types import Message

__MODULE__ = "ᴄᴇᴋ ᴋᴀʀᴍᴀ"
__HELP__ = """
<blockquote><b>『 CEK TINGKAT KARMA 』</b>

<b>⌲ Perintah:</b>
ᚗ <code>{0}karma [nama]</code> 
⊶ Mengecek tingkat karma/ kebaikan seseorang

<b>⌲ Contoh:</b>
<code>.karma</code> (untuk cek diri sendiri)
<code>.karma Budi</code> (untuk cek orang lain)
<code>.karma @username</code></blockquote>
"""

def get_description(percent):
    """Mendapatkan deskripsi berdasarkan persentase karma"""
    if percent >= 80:
        return "Karma baik! Surga menantimu~ ✨"
    elif percent >= 60:
        return "Cukup baik, terus tingkatkan! 🙏"
    elif percent >= 40:
        return "Netral, perbanyak kebaikan~ ⚖️"
    elif percent >= 20:
        return "Hati-hati dengan karma buruk! ⚠️"
    else:
        return "Wah perlu banyak tobat nih... 😱"

@PY.UBOT("karma")
async def cek_karma(client: Client, message: Message):
    ggl = await EMO.GAGAL(client)
    sks = await EMO.BERHASIL(client)
    prs = await EMO.PROSES(client)
    
    try:
        await client.send_chat_action(message.chat.id, ChatAction.TYPING)
        
        # Ambil nama dari input atau reply
        nama = "Kamu"
        
        # Cek apakah reply ke user
        if message.reply_to_message and message.reply_to_message.from_user:
            user = message.reply_to_message.from_user
            nama = user.first_name
            if user.last_name:
                nama += f" {user.last_name}"
        
        # Cek dari argumen
        args = message.text.split(maxsplit=1)
        if len(args) > 1:
            input_nama = args[1].strip()
            
            # Cek apakah mention @username
            if input_nama.startswith('@'):
                try:
                    user = await client.get_users(input_nama)
                    nama = user.first_name
                    if user.last_name:
                        nama += f" {user.last_name}"
                except:
                    nama = input_nama
            else:
                nama = input_nama
        
        # Jika tidak ada input dan tidak reply, pakai nama sender
        elif nama == "Kamu":
            nama = message.from_user.first_name
            if message.from_user.last_name:
                nama += f" {message.from_user.last_name}"
        
        # Generate random persentase karma
        percent = random.randint(0, 100)
        desc = get_description(percent)
        
        # Buat progress bar visual dengan emoji karma
        bar_length = 20
        filled_length = int(bar_length * percent / 100)
        bar = '✨' * filled_length + '⚡' * (bar_length - filled_length)
        
        # Kirim pesan processing dulu (biar ada efek)
        processing = await message.reply_text(f"{prs} <b>Menghitung karma {nama}...</b>")
        
        # Tunggu bentar biar keliatan prosesnya
        await asyncio.sleep(1)
        
        # Format pesan
        txt = f"""
<blockquote><b>☯️ CEK TINGKAT KARMA</b>

<b>👤 Nama:</b> <code>{nama}</code>
<b>📊 Karma:</b> <code>{percent}%</code>

<code>{bar}</code>

<b>💬 {desc}</b></blockquote>
"""
        
        await processing.edit_text(txt)
        
    except Exception as e:
        await message.reply_text(f"{ggl} <b>Error: {str(e)[:100]}</b>")

@PY.UBOT("karmacheck")
async def karma_check_alias(client: Client, message: Message):
    """Alias untuk karma"""
    await cek_karma(client, message)

@PY.UBOT("cekkarma")
async def cek_karma_alias(client: Client, message: Message):
    """Alias untuk karma"""
    await cek_karma(client, message)

@PY.UBOT("karmalevel")
async def karma_level_alias(client: Client, message: Message):
    """Alias untuk karma"""
    await cek_karma(client, message)

@PY.BOT("karma")
async def cek_karma_bot(client: Client, message: Message):
    """Handler untuk bot"""
    try:
        nama = "Kamu"
        
        if message.reply_to_message and message.reply_to_message.from_user:
            user = message.reply_to_message.from_user
            nama = user.first_name
            if user.last_name:
                nama += f" {user.last_name}"
        
        args = message.text.split(maxsplit=1)
        if len(args) > 1:
            input_nama = args[1].strip()
            if input_nama.startswith('@'):
                try:
                    user = await client.get_users(input_nama)
                    nama = user.first_name
                    if user.last_name:
                        nama += f" {user.last_name}"
                except:
                    nama = input_nama
            else:
                nama = input_nama
        
        # Generate random persentase karma
        percent = random.randint(0, 100)
        desc = get_description(percent)
        
        # Buat progress bar sederhana
        bar_length = 15
        filled_length = int(bar_length * percent / 100)
        bar = '✨' * filled_length + '⚡' * (bar_length - filled_length)
        
        txt = f"""
☯️ *CEK TINGKAT KARMA*

👤 Nama: {nama}
📊 Karma: {percent}%

{bar}

💬 {desc}
"""
        await message.reply_text(txt)
        
    except Exception as e:
        await message.reply_text(f"❌ Error: {str(e)[:100]}")