from pyrogram import Client, filters
import requests
import random
from fansx import *

__MODULE__ = "ᴀʀᴛɪ ɴᴀᴍᴀ"
__HELP__ = """
<blockquote><b>Bantuan Untuk Arti Nama</b>

Perintah:
<code>{0}artinama [nama]</code> → Mengartikan nama</blockquote>
"""

# Daftar API keys By Zyura kalau exp buat sendiri yah🗿
API_KEYS = [
    "eIxUwMpn",
    "keoCFdc6",
    "bv7m372F",
    "iAiB9QKT",
    "JP7Cy8Y2",
    "GI4vPxYv",
    "HRPga9TN",
    "PDwqhVsj",
    "m8jpBeZR",
    "PXkxh5hw",
    "MFnlpM6A",
    "u299UiOF"
]

def get_random_apikey():
    """Mengambil API key secara random dari daftar"""
    return random.choice(API_KEYS)

# Base URL API
BASE_URL = "https://api.botcahx.eu.org/api/primbon/artinama"

@PY.UBOT("artinama")
async def _(client, message):
    if len(message.command) < 2:
        await message.reply_text(
            "<blockquote><b>❌ Gunakan perintah:</b> <code>.artinama [nama]</code>\n\n"
            "<b>Contoh:</b> <code>.artinama putu</code></blockquote>"
        )
        return

    nama = " ".join(message.command[1:])
    
    # Kirim pesan processing
    processing_msg = await message.reply_text(
        "<blockquote><b>⏳ Mencari arti nama...</b></blockquote>"
    )
    
    try:
        # Coba dengan beberapa API key
        success = False
        used_keys = set()  # Untuk melacak key yang sudah dicoba
        max_attempts = min(3, len(API_KEYS))  # Maksimal 3 percobaan
        
        for attempt in range(max_attempts):
            # Ambil API key yang belum dicoba
            available_keys = [key for key in API_KEYS if key not in used_keys]
            if not available_keys:
                break
                
            apikey = random.choice(available_keys)
            used_keys.add(apikey)
            
            try:
                # Buat URL dengan parameter
                params = {
                    "nama": nama,
                    "apikey": apikey
                }
                
                # Request ke API dengan timeout
                response = requests.get(BASE_URL, params=params, timeout=10)
                
                if response.status_code == 200:
                    data = response.json()
                    
                    # Cek status response
                    if data.get("status") and data.get("result", {}).get("status"):
                        result = data["result"]["message"]
                        
                        # Ambil data dari response
                        nama_res = result.get("nama", nama).title()
                        arti_res = result.get("arti", "Tidak ditemukan")
                        catatan_res = result.get("catatan", "")
                        
                        # Format pesan
                        reply_text = (
                            f"<blockquote><b>🔍 Arti Nama: {nama_res}</b>\n\n"
                            f"📖 {arti_res}</blockquote>"
                        )
                        
                        if catatan_res:
                            reply_text += f"\n\n<blockquote><b>💡 {catatan_res}</b></blockquote>"
                        
                        await processing_msg.edit_text(reply_text)
                        success = True
                        break
                    else:
                        # Jika API merespon tapi data tidak ditemukan
                        continue
                else:
                    # Jika status code error
                    continue
                    
            except requests.exceptions.Timeout:
                # Timeout, coba dengan key lain
                continue
            except requests.exceptions.ConnectionError:
                # Connection error, coba dengan key lain
                continue
            except Exception as e:
                # Error lain, coba dengan key lain
                continue
        
        if not success:
            await processing_msg.edit_text(
                "<blockquote><b>❌ Maaf, tidak dapat menemukan arti nama tersebut.\n"
                "Silakan coba lagi nanti dengan nama yang berbeda.</b></blockquote>"
            )
            
    except Exception as e:
        await processing_msg.edit_text(
            f"<blockquote><b>⚠️ Terjadi kesalahan:\n{str(e)[:100]}</b></blockquote>"
        )