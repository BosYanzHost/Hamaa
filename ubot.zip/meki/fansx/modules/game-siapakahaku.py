from fansx import *
import aiohttp
import asyncio
import random
import json
import os
from datetime import datetime, timedelta
from pyrogram.enums import ChatAction, ParseMode
from pyrogram.types import Message

__MODULE__ = "ꜱɪᴀᴘᴀᴋᴀʜ ᴀᴋᴜ"
__HELP__ = """
<blockquote><b>🎮 GAME: SIAPAKAH AKU?</b>

<b>⌲ Perintah:</b>
ᚗ <code>{0}siapakahaku</code> - Mulai game baru
ᚗ <code>{0}sah</code> - Mulai game (singkatan)
ᚗ <code>{0}jawab [jawaban]</code> - Jawab pertanyaan
ᚗ <code>{0}skip</code> - Lewati pertanyaan
ᚗ <code>{0}leaderboard</code> - Lihat papan peringkat

<b>⌲ Cara main:</b>
1. Ketik <code>.siapakahaku</code> untuk mulai
2. Bot kasih clue/pertanyaan
3. Ketik <code>.jawab [jawabanmu]</code>
4. Bot kasih tau bener atau salah
5. Dapet skor kalo bener!

<b>⌲ Contoh:</b>
<code>.siapakahaku</code>
<code>.jawab antartika</code></blockquote>
"""

# ============================================
# KONFIGURASI
# ============================================
API_URL = "https://api.deline.web.id/game/siapakahaku"

# Database sederhana untuk menyimpan state game per user
game_sessions = {}
leaderboard = {}

async def get_question():
    """Ambil soal dari API"""
    try:
        async with aiohttp.ClientSession() as session:
            async with session.get(API_URL, timeout=10) as response:
                if response.status == 200:
                    data = await response.json()
                    if data.get("status") and data.get("result"):
                        result = data["result"]
                        return {
                            "question": result.get("soal", ""),
                            "answer": result.get("jawaban", "").strip().lower()
                        }
    except Exception as e:
        print(f"Error get question: {e}")
    return None

def normalize_answer(answer):
    """Normalisasi jawaban"""
    return " ".join(answer.lower().split())

@PY.UBOT("siapakahaku")
@PY.UBOT("sah")
async def start_game(client: Client, message: Message):
    ggl = await EMO.GAGAL(client)
    prs = await EMO.PROSES(client)
    
    user_id = message.from_user.id
    user_name = message.from_user.first_name
    
    try:
        await client.send_chat_action(message.chat.id, ChatAction.TYPING)
        
        processing = await message.reply_text(f"{prs} <b>Menyiapkan pertanyaan...</b>")
        
        question_data = await get_question()
        
        if not question_data:
            await processing.edit_text(f"{ggl} <b>Gagal mengambil pertanyaan!</b>")
            return
        
        question = question_data["question"]
        answer = question_data["answer"]
        
        game_sessions[user_id] = {
            "question": question,
            "answer": answer,
            "start_time": datetime.now(),
            "attempts": 0
        }
        
        await processing.delete()
        
        await message.reply_text(
            f"<blockquote><b>🎮 SIAPAKAH AKU?</b>\n\n"
            f"<b>Soal:</b>\n<code>{question}</code>\n\n"
            f"<b>Jawab dengan:</b> <code>.jawab [jawaban]</code>\n"
            f"<b>Lewati:</b> <code>.skip</code></blockquote>"
        )
        
    except Exception as e:
        await message.reply_text(f"{ggl} <b>Error: {str(e)[:100]}</b>")

@PY.UBOT("jawab")
async def answer_game(client: Client, message: Message):
    ggl = await EMO.GAGAL(client)
    sks = await EMO.BERHASIL(client)
    
    user_id = message.from_user.id
    user_name = message.from_user.first_name
    
    try:
        if user_id not in game_sessions:
            await message.reply_text(
                f"{ggl} <b>Ketik .siapakahaku dulu!</b>"
            )
            return
        
        args = message.text.split(maxsplit=1)
        if len(args) < 2:
            await message.reply_text(
                f"{ggl} <b>Contoh: .jawab antartika</b>"
            )
            return
        
        user_answer = normalize_answer(args[1])
        correct_answer = game_sessions[user_id]["answer"]
        attempts = game_sessions[user_id]["attempts"] + 1
        game_sessions[user_id]["attempts"] = attempts
        
        if user_answer == correct_answer or user_answer in correct_answer.split():
            score = max(10 - (attempts - 1) * 2, 1)
            
            if user_id in leaderboard:
                leaderboard[user_id]["score"] += score
            else:
                leaderboard[user_id] = {"name": user_name, "score": score}
            
            del game_sessions[user_id]
            
            await message.reply_text(
                f"<blockquote><b>✅ BENAR!</b>\n\n"
                f"⭐ Skor: +{score}\n"
                f"🏆 Total: {leaderboard[user_id]['score']}\n\n"
                f"Main lagi: <code>.siapakahaku</code></blockquote>"
            )
        else:
            if attempts >= 3:
                await message.reply_text(
                    f"<blockquote><b>❌ GAME OVER</b>\n\n"
                    f"Jawaban: <b>{correct_answer.title()}</b>\n\n"
                    f"Main lagi: <code>.siapakahaku</code></blockquote>"
                )
                del game_sessions[user_id]
            else:
                await message.reply_text(
                    f"<blockquote><b>❌ SALAH</b>\n\n"
                    f"📊 Percobaan: {attempts}/3\n\n"
                    f"Coba lagi: <code>.jawab [jawaban]</code></blockquote>"
                )
        
    except Exception as e:
        await message.reply_text(f"{ggl} <b>Error: {str(e)[:100]}</b>")

@PY.UBOT("skip")
async def skip_question(client: Client, message: Message):
    ggl = await EMO.GAGAL(client)
    
    user_id = message.from_user.id
    
    if user_id in game_sessions:
        answer = game_sessions[user_id]["answer"]
        await message.reply_text(
            f"<blockquote><b>⏭️ SKIP</b>\n\n"
            f"Jawaban: <b>{answer.title()}</b>\n\n"
            f"Main baru: <code>.siapakahaku</code></blockquote>"
        )
        del game_sessions[user_id]
    else:
        await message.reply_text(f"{ggl} <b>Belum mulai game!</b>")

@PY.UBOT("leaderboard")
@PY.UBOT("skor")
async def show_leaderboard(client: Client, message: Message):
    if not leaderboard:
        await message.reply_text(
            "<blockquote><b>🏆 LEADERBOARD</b>\n\n"
            "Belum ada skor. Ayo main dulu!</blockquote>"
        )
        return
    
    sorted_users = sorted(leaderboard.items(), key=lambda x: x[1]["score"], reverse=True)
    
    text = "<blockquote><b>🏆 LEADERBOARD</b>\n\n"
    for i, (user_id, data) in enumerate(sorted_users[:10], 1):
        medal = "🥇" if i == 1 else "🥈" if i == 2 else "🥉" if i == 3 else f"{i}."
        text += f"{medal} <b>{data['name']}</b> - {data['score']} poin\n"
    
    text += "\nMain: <code>.siapakahaku</code></blockquote>"
    
    await message.reply_text(text)

@PY.UBOT("gameinfo")
async def game_info(client: Client, message: Message):
    text = """
<blockquote><b>🎮 INFO GAME</b>

<b>Cara main:</b>
• <code>.siapakahaku</code> - Mulai game
• <code>.jawab [jawaban]</code> - Jawab soal
• <code>.skip</code> - Lewati soal
• <code>.leaderboard</code> - Lihat peringkat

<b>Aturan:</b>
• 3x kesempatan menjawab
• Makin cepat jawab, makin tinggi skor</blockquote>"""
    
    await message.reply_text(text)