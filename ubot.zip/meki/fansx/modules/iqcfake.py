from fansx import *
import requests
import aiohttp
import os
import random
from datetime import datetime
from pyrogram.enums import ChatAction
from pyrogram.types import Message
from io import BytesIO
from PIL import Image, ImageDraw, ImageFont

__MODULE__ = "ɪǫᴄ ᴄʜᴀᴛ"
__HELP__ = """
<blockquote><b>『 IQC CHAT MAKER 』</b>

<b>⌲ Perintah:</b>
ᚗ <code>{0}iqc [teks]</code> 
⊶ Membuat gambar chat bubble ala iMessage

<b>⌲ Contoh:</b>
<code>.iqc amel cantik</code>
<code>.iqc halo apa kabar</code></blockquote>
"""

# Warna-warna iMessage
IMESSAGE_COLORS = {
    "bg": (30, 30, 30),  # Dark mode background
    "user_bubble": (10, 132, 255),  # Blue bubble
    "other_bubble": (52, 52, 52),  # Gray bubble
    "text": (255, 255, 255),
    "time": (150, 150, 150)
}

async def create_iqc_image(text):
    """Membuat gambar chat bubble iMessage"""
    
    # Ukuran gambar
    width = 500
    height = 300
    padding = 20
    bubble_radius = 15
    
    # Generate waktu random (jam sekarang ± random)
    now = datetime.now()
    random_hour = random.randint(0, 23)
    random_minute = random.randint(0, 59)
    chat_time = f"{random_hour:02d}:{random_minute:02d}"
    
    # Buat canvas
    img = Image.new('RGB', (width, height), color=IMESSAGE_COLORS["bg"])
    draw = ImageDraw.Draw(img)
    
    # Load font
    try:
        # Coba pake font system
        font = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf", 20)
        font_small = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf", 14)
    except:
        font = ImageFont.load_default()
        font_small = ImageFont.load_default()
    
    # Hitung ukuran teks
    bbox = draw.textbbox((0, 0), text, font=font)
    text_width = bbox[2] - bbox[0]
    text_height = bbox[3] - bbox[1]
    
    # Bubble width = text width + padding
    bubble_width = min(text_width + 40, width - 100)
    bubble_height = text_height + 30
    
    # Posisi bubble (user bubble di kanan)
    bubble_x = width - bubble_width - padding
    bubble_y = height - bubble_height - padding - 30
    
    # Draw bubble (rounded rectangle)
    draw.rounded_rectangle(
        [bubble_x, bubble_y, bubble_x + bubble_width, bubble_y + bubble_height],
        radius=bubble_radius,
        fill=IMESSAGE_COLORS["user_bubble"]
    )
    
    # Draw text
    text_x = bubble_x + 20
    text_y = bubble_y + 15
    draw.text((text_x, text_y), text, font=font, fill=IMESSAGE_COLORS["text"])
    
    # Draw time di bawah bubble
    time_x = bubble_x + bubble_width - 40
    time_y = bubble_y + bubble_height + 5
    draw.text((time_x, time_y), chat_time, font=font_small, fill=IMESSAGE_COLORS["time"])
    
    # Simpan ke bytes
    img_bytes = BytesIO()
    img.save(img_bytes, format='PNG')
    img_bytes.seek(0)
    
    return img_bytes

@PY.UBOT("iqc")
async def iqc_maker(client: Client, message: Message):
    ggl = await EMO.GAGAL(client)
    sks = await EMO.BERHASIL(client)
    prs = await EMO.PROSES(client)
    
    try:
        await client.send_chat_action(message.chat.id, ChatAction.TYPING)
        
        # Ambil teks dari argumen atau reply
        text = None
        
        # Cek reply ke pesan
        if message.reply_to_message and message.reply_to_message.text:
            text = message.reply_to_message.text
        
        # Cek dari argumen
        if not text:
            args = message.text.split(maxsplit=1)
            if len(args) > 1:
                text = args[1].strip()
        
        if not text:
            await message.reply_text(
                f"<blockquote><b>❌ Masukkan teks!</b>\n\n"
                f"<b>Contoh:</b>\n"
                f"<code>.iqc amel cantik</code>\n"
                f"Atau reply ke pesan</blockquote>"
            )
            return
        
        # Batasi panjang teks
        if len(text) > 200:
            await message.reply_text(f"{ggl} <b>Teks terlalu panjang! Maksimal 200 karakter.</b>")
            return
        
        # Kirim pesan processing
        processing = await message.reply_text(f"{prs} <b>Membuat gambar chat...</b>")
        
        # Buat gambar
        img_bytes = await create_iqc_image(text)
        
        await processing.delete()
        
        # Kirim gambar
        await client.send_photo(
            chat_id=message.chat.id,
            photo=img_bytes,
            caption=f"<blockquote><b>💬 IQC CHAT</b>\n\n<code>{text}</code></blockquote>"
        )
        
    except Exception as e:
        await message.reply_text(f"{ggl} <b>Error: {str(e)[:100]}</b>")

@PY.UBOT("iqc2")
async def iqc2_maker(client: Client, message: Message):
    """Versi dengan dua chat bubble (alternating)"""
    ggl = await EMO.GAGAL(client)
    
    try:
        args = message.text.split(maxsplit=1)
        if len(args) < 2:
            await message.reply_text(
                f"<blockquote><b>❌ Format: .iqc2 teks1|teks2</b>\n\n"
                f"Contoh: <code>.iqc2 halo|hai juga</code></blockquote>"
            )
            return
        
        input_text = args[1]
        
        if '|' in input_text:
            parts = input_text.split('|', 1)
            text1 = parts[0].strip()
            text2 = parts[1].strip()
        else:
            text1 = input_text
            text2 = "Hai juga!"
        
        # Ukuran gambar
        width = 500
        height = 400
        padding = 20
        bubble_radius = 15
        
        # Generate waktu
        now = datetime.now()
        time1 = f"{now.hour:02d}:{now.minute:02d}"
        time2 = f"{(now.hour + random.randint(0, 2)) % 24:02d}:{random.randint(0, 59):02d}"
        
        # Buat canvas
        img = Image.new('RGB', (width, height), color=IMESSAGE_COLORS["bg"])
        draw = ImageDraw.Draw(img)
        
        try:
            font = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf", 20)
            font_small = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf", 14)
        except:
            font = ImageFont.load_default()
            font_small = ImageFont.load_default()
        
        # Bubble 1 (user)
        bbox1 = draw.textbbox((0, 0), text1, font=font)
        text1_width = bbox1[2] - bbox1[0]
        text1_height = bbox1[3] - bbox1[1]
        
        bubble1_width = min(text1_width + 40, width - 100)
        bubble1_height = text1_height + 30
        
        bubble1_x = width - bubble1_width - padding
        bubble1_y = height - bubble1_height - padding - 60
        
        draw.rounded_rectangle(
            [bubble1_x, bubble1_y, bubble1_x + bubble1_width, bubble1_y + bubble1_height],
            radius=bubble_radius,
            fill=IMESSAGE_COLORS["user_bubble"]
        )
        
        draw.text((bubble1_x + 20, bubble1_y + 15), text1, font=font, fill=IMESSAGE_COLORS["text"])
        draw.text((bubble1_x + bubble1_width - 40, bubble1_y + bubble1_height + 5), time1, font=font_small, fill=IMESSAGE_COLORS["time"])
        
        # Bubble 2 (other)
        bbox2 = draw.textbbox((0, 0), text2, font=font)
        text2_width = bbox2[2] - bbox2[0]
        text2_height = bbox2[3] - bbox2[1]
        
        bubble2_width = min(text2_width + 40, width - 100)
        bubble2_height = text2_height + 30
        
        bubble2_x = padding
        bubble2_y = bubble1_y - bubble2_height - 20
        
        draw.rounded_rectangle(
            [bubble2_x, bubble2_y, bubble2_x + bubble2_width, bubble2_y + bubble2_height],
            radius=bubble_radius,
            fill=IMESSAGE_COLORS["other_bubble"]
        )
        
        draw.text((bubble2_x + 20, bubble2_y + 15), text2, font=font, fill=IMESSAGE_COLORS["text"])
        draw.text((bubble2_x + 20, bubble2_y + bubble2_height + 5), time2, font=font_small, fill=IMESSAGE_COLORS["time"])
        
        # Simpan
        img_bytes = BytesIO()
        img.save(img_bytes, format='PNG')
        img_bytes.seek(0)
        
        await client.send_photo(
            chat_id=message.chat.id,
            photo=img_bytes,
            caption=f"<blockquote><b>💬 IQC CHAT</b>\n\n{text1} | {text2}</blockquote>"
        )
        
    except Exception as e:
        await message.reply_text(f"{ggl} <b>Error: {str(e)[:100]}</b>")