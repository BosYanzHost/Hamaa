from fansx import *
import random
import asyncio
from pyrogram.enums import ChatAction
from pyrogram.types import Message

__MODULE__ = "ᴄᴇᴋ ᴊᴀʜᴀᴛ"
__HELP__ = """
<blockquote><b>『 CEK TINGKAT KEJAHATAN 』</b>

<b>⌲ Perintah:</b>
ᚗ <code>{0}jahat [nama]</code> 
⊶ Mengecek seberapa jahat seseorang (versi lucu)

<b>⌲ Contoh:</b>
<code>.jahat</code> (untuk cek diri sendiri)
<code>.jahat Budi</code> (untuk cek orang lain)
<code>.jahat @username</code></blockquote>
"""

def get_description(percent):
    """Mendapatkan deskripsi berdasarkan persentase kejahatan"""
    if percent >= 90:
        return "VILLAIN LEVEL! 😈👿"
    elif percent >= 70:
        return "Jahat banget! 💀"
    elif percent >= 50:
        return "Lumayan jahat 😏"
    elif percent >= 30:
        return "Sedikit nakal 😊"
    else:
        return "Baik kok, gak jahat! 😇"

@PY.UBOT("jahat")
async def cek_jahat(client: Client, message: Message):
    ggl = await EMO.GAGAL(client)
    sks = await EMO.BERHASIL(client)
    prs = await EMO.PROSES(client)
    
    try:
        await client.send_chat_action(message.chat.id, ChatAction.TYPING)
        
        # Ambil nama dari input atau reply
        nama = "Kamu"
        
        # Cek apakah reply ke user
        if message.reply_to_message and message.reply_to_message.from_user:
            user = message.reply_to_message.from_user
            nama = user.first_name
            if user.last_name:
                nama += f" {user.last_name}"
        
        # Cek dari argumen
        args = message.text.split(maxsplit=1)
        if len(args) > 1:
            input_nama = args[1].strip()
            
            # Cek apakah mention @username
            if input_nama.startswith('@'):
                try:
                    user = await client.get_users(input_nama)
                    nama = user.first_name
                    if user.last_name:
                        nama += f" {user.last_name}"
                except:
                    nama = input_nama
            else:
                nama = input_nama
        
        # Jika tidak ada input dan tidak reply, pakai nama sender
        elif nama == "Kamu":
            nama = message.from_user.first_name
            if message.from_user.last_name:
                nama += f" {message.from_user.last_name}"
        
        # Generate random persentase kejahatan
        percent = random.randint(0, 100)
        desc = get_description(percent)
        
        # Buat progress bar visual dengan emoji jahat vs baik
        bar_length = 20
        filled_length = int(bar_length * percent / 100)
        bar = '😈' * filled_length + '😇' * (bar_length - filled_length)
        
        # Kirim pesan processing dulu (biar ada efek)
        processing = await message.reply_text(f"{prs} <b>Mengecek tingkat kejahatan {nama}...</b>")
        
        # Tunggu bentar biar keliatan prosesnya
        await asyncio.sleep(1)
        
        # Format pesan
        txt = f"""
<blockquote><b>👿 CEK TINGKAT KEJAHATAN</b>

<b>👤 Nama:</b> <code>{nama}</code>
<b>📊 Tingkat Jahat:</b> <code>{percent}%</code>

<code>{bar}</code>

<b>💬 {desc}</b></blockquote>
"""
        
        await processing.edit_text(txt)
        
    except Exception as e:
        await message.reply_text(f"{ggl} <b>Error: {str(e)[:100]}</b>")

@PY.UBOT("evil")
async def evil_alias(client: Client, message: Message):
    """Alias untuk jahat"""
    await cek_jahat(client, message)

@PY.UBOT("cekjahat")
async def cek_jahat_alias(client: Client, message: Message):
    """Alias untuk jahat"""
    await cek_jahat(client, message)

@PY.UBOT("villain")
async def villain_alias(client: Client, message: Message):
    """Alias untuk jahat"""
    await cek_jahat(client, message)

@PY.BOT("jahat")
async def cek_jahat_bot(client: Client, message: Message):
    """Handler untuk bot"""
    try:
        nama = "Kamu"
        
        if message.reply_to_message and message.reply_to_message.from_user:
            user = message.reply_to_message.from_user
            nama = user.first_name
            if user.last_name:
                nama += f" {user.last_name}"
        
        args = message.text.split(maxsplit=1)
        if len(args) > 1:
            input_nama = args[1].strip()
            if input_nama.startswith('@'):
                try:
                    user = await client.get_users(input_nama)
                    nama = user.first_name
                    if user.last_name:
                        nama += f" {user.last_name}"
                except:
                    nama = input_nama
            else:
                nama = input_nama
        
        # Generate random persentase kejahatan
        percent = random.randint(0, 100)
        desc = get_description(percent)
        
        # Buat progress bar sederhana
        bar_length = 15
        filled_length = int(bar_length * percent / 100)
        bar = '😈' * filled_length + '😇' * (bar_length - filled_length)
        
        txt = f"""
👿 *CEK TINGKAT KEJAHATAN*

👤 Nama: {nama}
📊 Tingkat Jahat: {percent}%

{bar}

💬 {desc}
"""
        await message.reply_text(txt)
        
    except Exception as e:
        await message.reply_text(f"❌ Error: {str(e)[:100]}")