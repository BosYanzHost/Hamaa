from fansx import *
import requests
import aiohttp
import asyncio
import json
from pyrogram.enums import ChatAction, ParseMode
from pyrogram.types import Message

__MODULE__ = "ᴢᴀʜᴀɴᴀᴛ ᴀɪ"
__HELP__ = """
<blockquote><b>『 ZAHANAT AI 』</b>

<b>⌲ Perintah:</b>
ᚗ <code>{0}zahanat [pertanyaan]</code> 
ᚗ <code>{0}zahanatai [pertanyaan]</code>
⊶ Bertanya dengan Zahanat AI

<b>⌲ Contoh:</b>
<code>.zahanat Halo, apa kabar?</code>
<code>.zahanatai Jelaskan tentang AI</code></blockquote>
"""

# API Endpoint
API_URL = "https://api.zahanat.ai/conversation/messagesV1/"

# Token Authorization
AUTH_TOKEN = "Token 798a27b3ef685534277b5bcba6b6b815de94ca58"

# Headers default
HEADERS = {
    'Content-Type': 'application/json',
    'Authorization': AUTH_TOKEN,
    'User-Agent': 'Mozilla/5.0 (Linux; Android 16)',
    'Origin': 'https://chat.zahanat.ai',
    'Referer': 'https://chat.zahanat.ai/'
}

# Dictionary untuk menyimpan conversation per user
user_conversations = {}
# User ID tetap untuk Zahanat (dari contoh)
ZAHANAT_USER_ID = 417

async def zahanat_request(user_id: str, query: str, is_new: bool, conv_id: int = 0):
    """Melakukan request ke API Zahanat"""
    
    payload = {
        "user_id": ZAHANAT_USER_ID,
        "sender": "user",
        "message": query,
        "new_conversation": is_new,
        "conversation_id": conv_id,
        "web_search": True
    }
    
    try:
        async with aiohttp.ClientSession() as session:
            async with session.post(API_URL, json=payload, headers=HEADERS, timeout=30) as response:
                if response.status != 200:
                    return {'success': False, 'error': f'HTTP {response.status}'}
                
                # Baca response sebagai text (streaming)
                raw_text = await response.text()
                
                # Parse streaming response
                full_message = ""
                new_conversation_id = conv_id
                
                for line in raw_text.split('\n'):
                    if not line.startswith('data: '):
                        continue
                    
                    try:
                        data_str = line[6:]  # Hapus 'data: '
                        data = json.loads(data_str)
                        
                        if data.get('chunk'):
                            full_message += data['chunk']
                        
                        if data.get('conversation_id'):
                            new_conversation_id = data['conversation_id']
                            # Simpan conversation ID untuk user
                            user_conversations[user_id] = new_conversation_id
                    except:
                        continue
                
                if not full_message.strip():
                    return {'success': False, 'error': 'Tidak ada jawaban'}
                
                return {
                    'success': True, 
                    'result': full_message.strip(),
                    'conversation_id': new_conversation_id
                }
    
    except asyncio.TimeoutError:
        return {'success': False, 'error': 'Timeout'}
    except aiohttp.ClientError as e:
        return {'success': False, 'error': f'Connection error: {str(e)}'}
    except Exception as e:
        return {'success': False, 'error': str(e)}

@PY.UBOT("zahanat")
async def zahanat_handler(client: Client, message: Message):
    await process_zahanat(client, message)

@PY.UBOT("zahanatai")
async def zahanatai_handler(client: Client, message: Message):
    await process_zahanat(client, message)

async def process_zahanat(client: Client, message: Message):
    ggl = await EMO.GAGAL(client)
    sks = await EMO.BERHASIL(client)
    prs = await EMO.PROSES(client)
    
    try:
        await client.send_chat_action(message.chat.id, ChatAction.TYPING)
        
        # Ambil pertanyaan
        args = message.text.split(maxsplit=1)
        if len(args) < 2:
            await message.reply_text(
                f"<blockquote><b>❌ Masukkan pertanyaan!</b>\n\n"
                f"<b>Contoh:</b>\n"
                f"<code>.zahanat Halo, apa kabar?</code>\n"
                f"<code>.zahanatai Jelaskan tentang AI</code></blockquote>"
            )
            return
        
        query = args[1].strip()
        
        # Kirim pesan processing
        processing = await message.reply_text(f"{prs} <b>Zahanat AI sedang berpikir...</b>")
        
        # Cek apakah ada percakapan sebelumnya
        user_id = str(message.from_user.id)
        is_new = user_id not in user_conversations
        conv_id = user_conversations.get(user_id, 0)
        
        # Panggil API
        result = await zahanat_request(user_id, query, is_new, conv_id)
        
        if result.get('success'):
            await processing.delete()
            
            # Format jawaban
            answer = result['result']
            
            # Batasi panjang jawaban (max 4000 karakter)
            if len(answer) > 4000:
                answer = answer[:4000] + "...\n\n(Jawaban dipotong karena terlalu panjang)"
            
            # Kirim jawaban
            await message.reply_text(
                f"<blockquote><b>🤖 Zahanat AI</b>\n\n"
                f"{answer}\n\n"
                f"⚡ <b>Powered by:</b> Ubot Premium Zyura</blockquote>"
            )
        else:
            error_msg = result.get('error', 'Unknown error')
            await processing.edit_text(
                f"{ggl} <b>Gagal mendapatkan jawaban!</b>\n\n"
                f"Error: {error_msg}"
            )
        
    except Exception as e:
        await message.reply_text(f"{ggl} <b>Error: {str(e)[:100]}</b>")

@PY.UBOT("zahanatreset")
async def zahanat_reset(client: Client, message: Message):
    """Reset percakapan Zahanat AI"""
    ggl = await EMO.GAGAL(client)
    sks = await EMO.BERHASIL(client)
    
    user_id = str(message.from_user.id)
    
    if user_id in user_conversations:
        del user_conversations[user_id]
        await message.reply_text(f"{sks} <b>Percakapan Zahanat AI berhasil direset!</b>")
    else:
        await message.reply_text(f"{ggl} <b>Tidak ada percakapan yang aktif!</b>")

@PY.BOT("zahanat")
async def zahanat_bot_handler(client: Client, message: Message):
    """Handler untuk bot"""
    try:
        args = message.text.split(maxsplit=1)
        if len(args) < 2:
            await message.reply_text(
                "❌ Masukkan pertanyaan!\n"
                "Contoh: /zahanat Halo, apa kabar?"
            )
            return
        
        query = args[1].strip()
        
        processing = await message.reply_text("🔍 Zahanat AI sedang berpikir...")
        
        user_id = str(message.from_user.id)
        is_new = user_id not in user_conversations
        conv_id = user_conversations.get(user_id, 0)
        
        result = await zahanat_request(user_id, query, is_new, conv_id)
        
        await processing.delete()
        
        if result.get('success'):
            answer = result['result']
            if len(answer) > 4000:
                answer = answer[:4000] + "..."
            
            await message.reply_text(answer)
        else:
            await message.reply_text(f"❌ Gagal: {result.get('error', 'Unknown error')}")
        
    except Exception as e:
        await message.reply_text(f"❌ Error: {str(e)[:100]}")