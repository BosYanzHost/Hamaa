from fansx import *
import aiohttp
import asyncio
import random
import string
import json
import os
from datetime import datetime
from pyrogram.enums import ChatAction, ParseMode
from pyrogram.types import Message

__MODULE__ = "ᴅɪɢɪᴛᴀʟ ᴏᴄᴇᴀɴ"
__HELP__ = """
<blockquote><b>『 CREATE VPS DIGITAL OCEAN 』</b>

<b>⌲ Setting Token:</b>
ᚗ <code>{0}setdo [token]</code> - Set Digital Ocean API token

<b>⌲ Buat Droplet (format):</b>
ᚗ <code>{0}do [size] [name] [region] [image]</code>

<b>⌲ Size:</b> 1gb, 2gb, 4gb, 8gb, 16gb, 32gb, 48gb, 64gb
<b>⌲ Region:</b> sgp1 (Singapore), nyc1 (New York), lon1 (London)
<b>⌲ Image:</b> ubuntu20, ubuntu22, debian11, debian12, centos7

<b>⌲ Contoh:</b>
<code>.do 1gb vpsku sgp1 ubuntu22</code>
<code>.do 4gb database nyc1 ubuntu20</code>
<code>.do 2gb testing lon1 debian11</code>

<b>⌲ Manajemen:</b>
ᚗ <code>{0}dolist</code> - Lihat semua droplet
ᚗ <code>{0}doinfo [id]</code> - Detail droplet
ᚗ <code>{0}doon [id]</code> - Power on
ᚗ <code>{0}dooff [id]</code> - Power off
ᚗ <code>{0}doreboot [id]</code> - Reboot
ᚗ <code>{0}dodelete [id]</code> - Hapus droplet

<b>⌲ Informasi:</b>
ᚗ <code>{0}doregions</code> - Daftar region
ᚗ <code>{0}doaccount</code> - Info akun</blockquote>
"""

# ============================================
# KONFIGURASI
# ============================================
DO_CONFIG_FILE = "do_config.json"

DO_API = "https://api.digitalocean.com/v2"

# Mapping size (slug Digital Ocean)
DO_SIZES = {
    "1gb": "s-1vcpu-1gb",
    "2gb": "s-1vcpu-2gb", 
    "4gb": "s-2vcpu-4gb",
    "8gb": "s-4vcpu-8gb",
    "16gb": "s-8vcpu-16gb",
    "32gb": "s-16vcpu-32gb",
    "48gb": "s-24vcpu-48gb",
    "64gb": "s-32vcpu-64gb"
}

# Mapping image OS
DO_IMAGES = {
    "ubuntu20": "ubuntu-20-04-x64",
    "ubuntu22": "ubuntu-22-04-x64",
    "debian11": "debian-11-x64",
    "debian12": "debian-12-x64",
    "centos7": "centos-7-x64",
    "centos8": "centos-8-x64",
    "rocky8": "rockylinux-8-x64",
    "rocky9": "rockylinux-9-x64",
}

# Region populer
POPULAR_REGIONS = ["sgp1", "nyc1", "lon1", "fra1", "tor1", "blr1"]

def load_config():
    """Load config dari file"""
    try:
        if os.path.exists(DO_CONFIG_FILE):
            with open(DO_CONFIG_FILE, 'r') as f:
                return json.load(f)
    except:
        pass
    return {"token": None}

def save_config(config):
    """Simpan config ke file"""
    try:
        with open(DO_CONFIG_FILE, 'w') as f:
            json.dump(config, f, indent=4)
        return True
    except:
        return False

# Load config
do_config = load_config()

def random_password(length=12):
    """Generate random password"""
    chars = string.ascii_letters + string.digits + "!@#$%^&*"
    return ''.join(random.choice(chars) for _ in range(length))

async def do_request(method, endpoint, data=None):
    """Request ke API Digital Ocean"""
    
    token = do_config.get("token")
    if not token:
        return {"error": "Token belum diset!"}, 401
    
    url = f"{DO_API}/{endpoint}"
    headers = {
        "Content-Type": "application/json",
        "Authorization": f"Bearer {token}"
    }
    
    try:
        async with aiohttp.ClientSession() as session:
            if method == "GET":
                async with session.get(url, headers=headers, timeout=15) as resp:
                    return await resp.json(), resp.status
            elif method == "POST":
                async with session.post(url, headers=headers, json=data, timeout=60) as resp:
                    return await resp.json(), resp.status
            elif method == "DELETE":
                async with session.delete(url, headers=headers, timeout=15) as resp:
                    if resp.status == 204:
                        return {}, 204
                    return await resp.json(), resp.status
    except asyncio.TimeoutError:
        return {"error": "Timeout"}, 408
    except Exception as e:
        return {"error": str(e)}, 500

# ============================================
# COMMAND SETTING
# ============================================

@PY.UBOT("setdo")
async def set_do_token(client: Client, message: Message):
    """Set Digital Ocean API token"""
    ggl = await EMO.GAGAL(client)
    sks = await EMO.BERHASIL(client)
    
    try:
        args = message.text.split(maxsplit=1)
        if len(args) < 2:
            await message.reply_text(
                f"<blockquote><b>❌ Format: .setdo [token]</b>\n\n"
                f"Ambil token di:\n"
                f"https://cloud.digitalocean.com/account/api/tokens</blockquote>"
            )
            return
        
        token = args[1].strip()
        
        await message.reply_text(f"⏳ <b>Testing token...</b>")
        
        data, status = await do_request("GET", "account")
        
        if status == 200:
            do_config["token"] = token
            save_config(do_config)
            
            email = data.get("account", {}).get("email", "-")
            
            await message.reply_text(
                f"<blockquote><b>✅ TOKEN VALID</b>\n\n"
                f"📧 <b>Email:</b> {email}\n"
                f"🔑 <b>Token:</b> <code>{token[:8]}...{token[-5:]}</code></blockquote>"
            )
        else:
            await message.reply_text(f"{ggl} <b>Token tidak valid!</b>")
            
    except Exception as e:
        await message.reply_text(f"{ggl} <b>Error: {str(e)[:100]}</b>")

# ============================================
# COMMAND BUAT DROPLET (FORMAT: size name region image)
# ============================================

@PY.UBOT("do")
async def create_droplet(client: Client, message: Message):
    ggl = await EMO.GAGAL(client)
    sks = await EMO.BERHASIL(client)
    prs = await EMO.PROSES(client)
    
    try:
        # Cek token
        if not do_config.get("token"):
            await message.reply_text(
                f"{ggl} <b>Token belum diset!</b>\n"
                f"Gunakan .setdo [token] dulu"
            )
            return
        
        # Parse args: size name region image
        args = message.text.split()
        if len(args) < 5:
            await message.reply_text(
                f"<blockquote><b>❌ Format: .do [size] [name] [region] [image]</b>\n\n"
                f"<b>Contoh:</b>\n"
                f"<code>.do 1gb vpsku sgp1 ubuntu22</code>\n"
                f"<code>.do 4gb database nyc1 ubuntu20</code>\n"
                f"<code>.do 2gb testing lon1 debian11</code>\n\n"
                f"<b>Size:</b> 1gb, 2gb, 4gb, 8gb, 16gb, 32gb\n"
                f"<b>Region:</b> sgp1, nyc1, lon1, fra1, tor1, blr1\n"
                f"<b>Image:</b> ubuntu20, ubuntu22, debian11, debian12, centos7</blockquote>"
            )
            return
        
        size_key = args[1].lower()
        name = args[2]
        region = args[3].lower()
        image_key = args[4].lower()
        
        # Validasi size
        if size_key not in DO_SIZES:
            sizes = ", ".join(DO_SIZES.keys())
            await message.reply_text(f"{ggl} <b>Size tidak valid!</b>\nPilih: {sizes}")
            return
        
        # Validasi region (opsional, kalo gak ada di popular tetap bisa diproses)
        if region not in POPULAR_REGIONS:
            await message.reply_text(f"⚠️ <b>Region '{region}' mungkin tidak tersedia, tetap dilanjutkan...</b>")
        
        # Validasi image
        if image_key not in DO_IMAGES:
            images = ", ".join(DO_IMAGES.keys())
            await message.reply_text(f"{ggl} <b>Image tidak valid!</b>\nPilih: {images}")
            return
        
        # Generate password
        password = random_password()
        
        # Data untuk create droplet
        droplet_data = {
            "name": name,
            "region": region,
            "size": DO_SIZES[size_key],
            "image": DO_IMAGES[image_key],
            "user_data": f"""#!/bin/bash
hostnamectl set-hostname {name}
echo "root:{password}" | chpasswd
sed -i 's/PasswordAuthentication no/PasswordAuthentication yes/' /etc/ssh/sshd_config
systemctl restart sshd
""",
            "backups": False,
            "ipv6": False,
            "monitoring": True,
            "tags": ["telegram-bot", f"size-{size_key}", f"os-{image_key}"]
        }
        
        # Kirim processing
        processing = await message.reply_text(
            f"{prs} <b>Membuat droplet...</b>\n"
            f"📛 Nama: {name}\n"
            f"📊 Size: {size_key}\n"
            f"📍 Region: {region}\n"
            f"🖼️ OS: {image_key}"
        )
        
        # Request ke API
        response, status = await do_request("POST", "droplets", droplet_data)
        
        if status not in [200, 201, 202]:
            error_msg = response.get("message", "Unknown error")
            await processing.edit_text(f"{ggl} <b>Gagal membuat droplet!</b>\n{error_msg}")
            return
        
        droplet = response.get("droplet", {})
        droplet_id = droplet.get("id")
        
        await processing.edit_text(
            f"{prs} <b>Droplet dibuat! Menunggu IP aktif (45 detik)...</b>"
        )
        
        # Tunggu 45 detik
        await asyncio.sleep(45)
        
        # Ambil info terbaru
        info, info_status = await do_request("GET", f"droplets/{droplet_id}")
        
        ip_address = "0.0.0.0"
        status_text = "active"
        
        if info_status == 200:
            droplet_info = info.get("droplet", {})
            networks = droplet_info.get("networks", {}).get("v4", [])
            for net in networks:
                if net.get("type") == "public":
                    ip_address = net.get("ip_address", "0.0.0.0")
                    break
            status_text = droplet_info.get("status", "active")
        
        await processing.delete()
        
        # Hasil
        result = f"""
<blockquote><b>✅ VPS BERHASIL DIBUAT</b>

📛 <b>Nama:</b> {name}
🆔 <b>ID:</b> <code>{droplet_id}</code>
🌐 <b>IP:</b> <code>{ip_address}</code>
🔑 <b>Password:</b> <code>{password}</code>
📊 <b>Size:</b> {size_key} ({DO_SIZES[size_key]})
📍 <b>Region:</b> {region}
🖼️ <b>OS:</b> {image_key} ({DO_IMAGES[image_key]})
🔰 <b>Status:</b> {status_text}

📌 <b>SSH:</b> <code>ssh root@{ip_address}</code>
⚠️ <b>Ganti password setelah login!</b></blockquote>"""
        
        await message.reply_text(result)
        
    except Exception as e:
        await message.reply_text(f"{ggl} <b>Error: {str(e)[:100]}</b>")

# ============================================
# COMMAND LIHAT DAFTAR DROPLET
# ============================================

@PY.UBOT("dolist")
async def list_droplets(client: Client, message: Message):
    ggl = await EMO.GAGAL(client)
    prs = await EMO.PROSES(client)
    
    if not do_config.get("token"):
        await message.reply_text(f"{ggl} <b>Token belum diset!</b>")
        return
    
    processing = await message.reply_text(f"{prs} <b>Mengambil daftar droplet...</b>")
    
    data, status = await do_request("GET", "droplets?per_page=200")
    
    if status == 200:
        droplets = data.get("droplets", [])
        
        if not droplets:
            await processing.edit_text("<b>📭 Belum ada droplet.</b>")
            return
        
        text = "<blockquote><b>📋 DAFTAR DROPLET</b>\n\n"
        
        for d in droplets:
            # Cari IP
            ip = "-"
            for net in d.get("networks", {}).get("v4", []):
                if net.get("type") == "public":
                    ip = net.get("ip_address", "-")
                    break
            
            text += f"📛 <b>{d.get('name')}</b>\n"
            text += f"🆔 <code>{d.get('id')}</code> | {ip}\n"
            text += f"🔰 {d.get('status')} | {d.get('size_slug')} | {d.get('region', {}).get('slug')}\n"
            text += f"━━━━━━━━━━━━━━━\n"
        
        text += f"\n📊 Total: {len(droplets)} droplet</blockquote>"
        
        await processing.edit_text(text)
    else:
        await processing.edit_text(f"{ggl} <b>Gagal mengambil data!</b>")

# ============================================
# COMMAND DETAIL DROPLET
# ============================================

@PY.UBOT("doinfo")
async def droplet_info(client: Client, message: Message):
    ggl = await EMO.GAGAL(client)
    prs = await EMO.PROSES(client)
    
    if not do_config.get("token"):
        await message.reply_text(f"{ggl} <b>Token belum diset!</b>")
        return
    
    args = message.text.split(maxsplit=1)
    if len(args) < 2:
        await message.reply_text(f"{ggl} <b>Masukkan ID droplet!</b>\nContoh: .doinfo 12345678")
        return
    
    droplet_id = args[1].strip()
    
    processing = await message.reply_text(f"{prs} <b>Mengambil info droplet...</b>")
    
    data, status = await do_request("GET", f"droplets/{droplet_id}")
    
    if status == 200:
        d = data.get("droplet", {})
        
        # Cari IP
        ip_public = "-"
        ip_private = "-"
        for net in d.get("networks", {}).get("v4", []):
            if net.get("type") == "public":
                ip_public = net.get("ip_address", "-")
            elif net.get("type") == "private":
                ip_private = net.get("ip_address", "-")
        
        text = f"""
<blockquote><b>📊 DETAIL DROPLET</b>

📛 <b>Nama:</b> {d.get('name', '-')}
🆔 <b>ID:</b> <code>{d.get('id')}</code>
🔰 <b>Status:</b> {d.get('status', '-')}
🌐 <b>Public IP:</b> {ip_public}
🌐 <b>Private IP:</b> {ip_private}
📍 <b>Region:</b> {d.get('region', {}).get('name', '-')} ({d.get('region', {}).get('slug', '-')})
📊 <b>Size:</b> {d.get('size_slug', '-')}
⚙️ <b>vCPUs:</b> {d.get('vcpus', '0')}
💾 <b>Memory:</b> {d.get('memory', '0')} MB
💽 <b>Disk:</b> {d.get('disk', '0')} GB
🖼️ <b>Image:</b> {d.get('image', {}).get('distribution', '-')} {d.get('image', {}).get('name', '-')}
📅 <b>Created:</b> {d.get('created_at', '-')[:10]}</blockquote>"""
        
        await processing.edit_text(text)
    else:
        await processing.edit_text(f"{ggl} <b>Droplet tidak ditemukan!</b>")

# ============================================
# COMMAND POWER MANAGEMENT
# ============================================

@PY.UBOT("doon")
async def do_power_on(client: Client, message: Message):
    await power_action(client, message, "power_on", "menghidupkan")

@PY.UBOT("dooff")
async def do_power_off(client: Client, message: Message):
    await power_action(client, message, "shutdown", "mematikan")

@PY.UBOT("doreboot")
async def do_reboot(client: Client, message: Message):
    await power_action(client, message, "reboot", "merestart")

async def power_action(client: Client, message: Message, action: str, action_name: str):
    ggl = await EMO.GAGAL(client)
    prs = await EMO.PROSES(client)
    
    if not do_config.get("token"):
        await message.reply_text(f"{ggl} <b>Token belum diset!</b>")
        return
    
    args = message.text.split(maxsplit=1)
    if len(args) < 2:
        await message.reply_text(f"{ggl} <b>Masukkan ID droplet!</b>")
        return
    
    droplet_id = args[1].strip()
    
    processing = await message.reply_text(f"{prs} <b>{action_name.title()} droplet...</b>")
    
    data, status = await do_request("POST", f"droplets/{droplet_id}/actions", {"type": action})
    
    if status in [200, 201, 202]:
        await processing.edit_text(f"<b>✅ Droplet berhasil {action_name}!</b>")
    else:
        await processing.edit_text(f"{ggl} <b>Gagal {action_name} droplet!</b>")

# ============================================
# COMMAND DELETE DROPLET
# ============================================

@PY.UBOT("dodelete")
async def delete_droplet(client: Client, message: Message):
    ggl = await EMO.GAGAL(client)
    prs = await EMO.PROSES(client)
    
    if not do_config.get("token"):
        await message.reply_text(f"{ggl} <b>Token belum diset!</b>")
        return
    
    args = message.text.split(maxsplit=1)
    if len(args) < 2:
        await message.reply_text(f"{ggl} <b>Masukkan ID droplet!</b>")
        return
    
    droplet_id = args[1].strip()
    
    # Konfirmasi
    confirm = await message.reply_text(
        f"⚠️ <b>Yakin hapus droplet {droplet_id}?</b>\n"
        f"Ketik <code>ya</code> untuk konfirmasi."
    )
    
    try:
        resp = await client.wait_for_message(
            chat_id=message.chat.id,
            from_user_id=message.from_user.id,
            timeout=10
        )
        
        if resp and resp.text and resp.text.lower() == "ya":
            await confirm.edit_text(f"{prs} <b>Menghapus droplet...</b>")
            
            _, status = await do_request("DELETE", f"droplets/{droplet_id}")
            
            if status == 204:
                await confirm.edit_text(f"<b>✅ Droplet dihapus!</b>")
            else:
                await confirm.edit_text(f"{ggl} <b>Gagal menghapus!</b>")
        else:
            await confirm.edit_text("<b>❌ Dibatalkan</b>")
            
    except asyncio.TimeoutError:
        await confirm.edit_text("<b>⏱️ Timeout, dibatalkan</b>")

# ============================================
# COMMAND INFO AKUN
# ============================================

@PY.UBOT("doaccount")
async def account_info(client: Client, message: Message):
    ggl = await EMO.GAGAL(client)
    prs = await EMO.PROSES(client)
    
    if not do_config.get("token"):
        await message.reply_text(f"{ggl} <b>Token belum diset!</b>")
        return
    
    processing = await message.reply_text(f"{prs} <b>Mengambil info akun...</b>")
    
    # Get account
    acc_data, acc_status = await do_request("GET", "account")
    
    # Get balance
    bal_data, bal_status = await do_request("GET", "customers/my/balance")
    
    # Get droplets count
    droplet_data, droplet_status = await do_request("GET", "droplets?per_page=1")
    
    if acc_status == 200:
        acc = acc_data.get("account", {})
        email = acc.get("email", "-")
        uuid = acc.get("uuid", "-")
        status_acc = acc.get("status", "-")
        limit = acc.get("droplet_limit", 0)
        
        balance = bal_data.get("month_to_date_balance", "0.00") if bal_status == 200 else "?"
        droplet_count = droplet_data.get("meta", {}).get("total", 0) if droplet_status == 200 else "?"
        
        text = f"""
<blockquote><b>📊 INFO AKUN DIGITAL OCEAN</b>

📧 <b>Email:</b> {email}
🆔 <b>UUID:</b> <code>{uuid}</code>
🔰 <b>Status:</b> {status_acc}
📦 <b>Droplet:</b> {droplet_count}/{limit}
💰 <b>Balance:</b> ${balance}</blockquote>"""
        
        await processing.edit_text(text)
    else:
        await processing.edit_text(f"{ggl} <b>Gagal ambil info akun!</b>")

# ============================================
# COMMAND LIHAT REGIONS
# ============================================

@PY.UBOT("doregions")
async def list_regions(client: Client, message: Message):
    ggl = await EMO.GAGAL(client)
    prs = await EMO.PROSES(client)
    
    if not do_config.get("token"):
        await message.reply_text(f"{ggl} <b>Token belum diset!</b>")
        return
    
    processing = await message.reply_text(f"{prs} <b>Mengambil daftar region...</b>")
    
    data, status = await do_request("GET", "regions")
    
    if status == 200:
        regions = data.get("regions", [])
        
        text = "<blockquote><b>🌍 REGION TERSEDIA</b>\n\n"
        
        for r in regions[:15]:
            if r.get("available"):
                text += f"• <code>{r.get('slug')}</code> - {r.get('name')}\n"
        
        text += "\n<b>Populer:</b> sgp1, nyc1, lon1, fra1, tor1</blockquote>"
        
        await processing.edit_text(text)
    else:
        await processing.edit_text(f"{ggl} <b>Gagal ambil region!</b>")