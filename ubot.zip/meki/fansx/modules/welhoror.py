from fansx import *
import aiohttp
import asyncio
import os
import random
from pyrogram.enums import ChatAction, ParseMode
from pyrogram.types import Message
from pyrogram.types import InlineKeyboardMarkup, InlineKeyboardButton

__MODULE__ = "ʜᴏʀʀᴏʀ ᴡᴇʟᴄᴏᴍᴇ"
__HELP__ = """
<blockquote><b>👻 HORROR WELCOME CANVAS</b>

<b>⌲ Perintah:</b>
ᚗ <code>{0}horror [nama]</code> - Buat welcome card horror
ᚗ <code>{0}hr [nama]</code> - Singkatan

<b>⌲ Contoh:</b>
<code>.horror Najmy</code>
<code>.hr Najmy | Member | Grup Ku</code></blockquote>
"""

# ============================================
# KONFIGURASI
# ============================================
HORROR_API = "https://anabot.my.id/api/canvas/horror"
API_KEY = "freeApikey"  # Bisa diganti nanti

# Default values
DEFAULT_ROLE = "Member"
DEFAULT_GROUP = "My Group"

async def create_horror_welcome(image_url, name, role=DEFAULT_ROLE, group_name=DEFAULT_GROUP):
    """Buat gambar welcome horror"""
    
    # Encode semua parameter
    url = (f"{HORROR_API}?image={image_url}"
           f"&name={name}"
           f"&role={role}"
           f"&groupName={group_name}"
           f"&apikey={API_KEY}")
    
    try:
        async with aiohttp.ClientSession() as session:
            async with session.get(url, timeout=30) as response:
                if response.status == 200:
                    # Cek content-type
                    content_type = response.headers.get("Content-Type", "")
                    
                    if "image" in content_type:
                        # Langsung gambar
                        return {
                            "success": True,
                            "image": await response.read(),
                            "direct": True
                        }
                    else:
                        # Mungkin JSON dengan URL gambar
                        try:
                            data = await response.json()
                            
                            # Cek berbagai format respons
                            if data.get("status") == "success" and data.get("result"):
                                img_url = data["result"]
                            elif data.get("image_url"):
                                img_url = data["image_url"]
                            elif data.get("url"):
                                img_url = data["url"]
                            else:
                                return {"success": False, "error": "Format respons tidak dikenali", "data": data}
                            
                            # Download gambar dari URL
                            async with session.get(img_url, timeout=15) as img_resp:
                                if img_resp.status == 200:
                                    return {
                                        "success": True,
                                        "image": await img_resp.read()
                                    }
                                else:
                                    return {"success": False, "error": f"Gagal download gambar: HTTP {img_resp.status}"}
                        except:
                            return {"success": False, "error": "API tidak mengembalikan gambar"}
                else:
                    return {"success": False, "error": f"HTTP {response.status}"}
    except asyncio.TimeoutError:
        return {"success": False, "error": "Timeout - server terlalu lambat"}
    except Exception as e:
        return {"success": False, "error": str(e)}

def parse_horror_args(args, user_full_name):
    """Parse argumen dengan format: nama | role | group"""
    if not args:
        return {
            "name": user_full_name,
            "role": DEFAULT_ROLE,
            "group": DEFAULT_GROUP
        }
    
    # Format: nama | role | group
    full_text = " ".join(args)
    parts = [p.strip() for p in full_text.split("|")]
    
    result = {
        "name": user_full_name,
        "role": DEFAULT_ROLE,
        "group": DEFAULT_GROUP
    }
    
    # Parse nama
    if len(parts) >= 1 and parts[0]:
        result["name"] = parts[0]
    
    # Parse role
    if len(parts) >= 2 and parts[1]:
        result["role"] = parts[1]
    
    # Parse group
    if len(parts) >= 3 and parts[2]:
        result["group"] = parts[2]
    
    return result

@PY.UBOT("horror")
@PY.UBOT("hr")
async def horror_command(client: Client, message: Message):
    ggl = await EMO.GAGAL(client)
    sks = await EMO.BERHASIL(client)
    prs = await EMO.PROSES(client)
    
    # Parse argumen
    args = message.text.split()[1:]
    
    # Dapatkan info user
    user = message.from_user
    user_name = user.first_name or ""
    if user.last_name:
        user_name += f" {user.last_name}"
    
    # Dapatkan foto profil user
    user_photo = None
    user_photo_url = "https://picsum.photos/200"  # Default
    
    try:
        photos = await client.get_chat_photos(user.id, limit=1)
        if photos:
            # Dapatkan file_id foto
            photo_file_id = photos[0].file_id
            
            # Download foto
            photo_path = await client.download_media(photo_file_id)
            
            if photo_path and os.path.exists(photo_path):
                # Upload ke tempat penyimpanan sementara (gunakan layanan gratis)
                # Alternatif: upload ke telegra.ph atau langsung kirim file
                # TAPI untuk sekarang kita pake foto default dulu
                # Nanti bisa ditambah fitur upload ke server
                user_photo_url = "https://picsum.photos/200"  # Ganti dengan URL foto setelah diupload
                
                # Hapus file sementara
                os.remove(photo_path)
    except Exception as e:
        print(f"Error ambil foto: {e}")
        user_photo_url = "https://picsum.photos/200"
    
    # Parse argumen
    parsed = parse_horror_args(args, user_name)
    
    # Cek apakah user reply ke pesan
    reply_to = message.reply_to_message
    if reply_to and reply_to.from_user:
        target_user = reply_to.from_user
        target_name = target_user.first_name or ""
        if target_user.last_name:
            target_name += f" {target_user.last_name}"
        
        # Ganti dengan data user yang direply
        parsed["name"] = target_name
        
        # Coba ambil foto user yang direply
        try:
            target_photos = await client.get_chat_photos(target_user.id, limit=1)
            if target_photos:
                photo_file_id = target_photos[0].file_id
                photo_path = await client.download_media(photo_file_id)
                if photo_path and os.path.exists(photo_path):
                    user_photo_url = "https://picsum.photos/200"  # Ganti dengan URL setelah diupload
                    os.remove(photo_path)
        except:
            pass
    
    if not args:
        # Tampilkan help
        help_text = f"""
<blockquote><b>Cara pakai:</b>
ᚗ <code>.horror [nama]</code>
ᚗ <code>.horror [nama] | [role] | [group]</code>

<b>Contoh sederhana:</b>
<code>.horror {user_name}</code>
<code>.hr {user_name}</code>

<b>Contoh lengkap:</b>
<code>.horror {user_name} | Admin | Grup Horor</code>
<code>.hr {user_name} | Member | My Group</code>

<b>📌 Fitur:</b>
• Theme horror seram
• Auto ambil foto profil
• Bisa reply ke user lain
• Kustom role dan nama grup

<b>✨ Tips:</b>
Reply ke pesan orang lain buat buatin welcome card horror buat dia!</blockquote>"""
        
        await message.reply_text(help_text)
        return
    
    try:
        await client.send_chat_action(message.chat.id, ChatAction.UPLOAD_PHOTO)
        
        processing = await message.reply_text(
            f"{prs} <b>Membuat welcome card horror...</b>\n"
            f"<b>Untuk:</b> {parsed['name']}"
        )
        
        # Buat welcome card horror
        result = await create_horror_welcome(
            image_url=user_photo_url,
            name=parsed['name'],
            role=parsed['role'],
            group_name=parsed['group']
        )
        
        await processing.delete()
        
        if result.get("success") and result.get("image"):
            # Simpan gambar sementara
            file_path = f"horror_{message.from_user.id}_{random.randint(1000,9999)}.png"
            with open(file_path, "wb") as f:
                f.write(result["image"])
            
            # Buat caption dengan info
            caption = f"<blockquote><b>SUKSES CREATING ⚡</b>\n\n"
            caption += f"<b>👤 Nama:</b> {parsed['name']}\n"
            caption += f"<b>📌 Role:</b> {parsed['role']}\n"
            caption += f"<b>👥 Grup:</b> {parsed['group']}\n"
            caption += f"\n⚡ Powered by: Ubot Premium Zyura</blockquote>"
            
            # Kirim gambar
            await client.send_photo(
                chat_id=message.chat.id,
                photo=file_path,
                caption=caption
            )
            
            # Hapus file
            if os.path.exists(file_path):
                os.remove(file_path)
            
        else:
            error_msg = result.get("error", "Unknown error")
            await message.reply_text(
                f"<blockquote><b>❌ GAGAL MEMBUAT GAMBAR</b>\n\n"
                f"<b>Error:</b> {error_msg}</blockquote>"
            )
        
    except Exception as e:
        await message.reply_text(f"{ggl} <b>Error: {str(e)[:100]}</b>")