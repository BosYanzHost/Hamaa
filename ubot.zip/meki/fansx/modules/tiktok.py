from fansx import *
import requests

__MODULE__ = "ᴛɪᴋᴛᴏᴋ"
__HELP__ = """
<blockquote> <b>ʙᴀɴᴛᴜᴀɴ ᴜɴᴛᴜᴋ ᴛɪᴋᴛᴏᴋ

ᴘᴇʀɪɴᴛᴀʜ : <code>{0}tiktok</code> tiktok <b>[link nya]</b>
ᴘᴇɴᴊᴇʟᴀsᴀɴ : ᴅᴏᴡɴʟᴏᴀᴅ ᴠᴛ ɴᴏ ᴡᴍ , ᴠɪᴅɪᴏ ᴜɴᴛᴜᴋ ᴠɪᴅᴇᴏ ᴍᴜsɪᴄ ᴜɴᴛᴜᴋ ᴍᴜsɪᴋ.</b></blockquote>
"""

# Base URL API vreden
BASE_URL = "https://api.vreden.my.id/api/v1/download/tiktok"

@PY.UBOT("tiktok")
@PY.TOP_CMD
async def tiktok_handler(client, message):
    if len(message.command) < 2:
        await message.reply("❌ Linknya mana? Contoh: .tiktok https://vm.tiktok.com/xxxxx")
        return

    url = message.command[1]
    proses_message = await message.reply("```\n⏳ Processing Kingz...```")

    try:
        # Request ke API vreden
        response = requests.get(f"{BASE_URL}?url={url}", timeout=15)
        data = response.json()

        if data.get("status") and data.get("result"):
            result = data["result"]
            
            # Cek apakah ini adalah slideshow (gambar) atau video
            if "images" in result:  # Untuk slideshow
                for img_url in result["images"]:
                    await client.send_photo(message.chat.id, img_url)
            else:
                # Ambil video URL (pilih yang HD jika ada)
                video_url = None
                for item in result.get("data", []):
                    if item["type"] == "nowatermark_hd":
                        video_url = item["url"]
                        break
                if not video_url:
                    for item in result.get("data", []):
                        if item["type"] == "nowatermark":
                            video_url = item["url"]
                            break
                
                if video_url:
                    # Buat caption dengan informasi video
                    title = result.get("title", "TikTok Video")
                    stats = result.get("stats", {})
                    author = result.get("author", {})
                    
                    caption = f"""
<blockquote><b>✅ TIKTOK DOWNLOADER</b>

📹 <b>Judul:</b> {title[:100]}...
👤 <b>Uploader:</b> {author.get('nickname', 'Unknown')} (@{author.get('fullname', 'Unknown')})
👁️ <b>Views:</b> {stats.get('views', '0')}
❤️ <b>Likes:</b> {stats.get('likes', '0')}
💬 <b>Comments:</b> {stats.get('comment', '0')}
🔄 <b>Shares:</b> {stats.get('share', '0')}
⏱️ <b>Durasi:</b> {result.get('duration', '0')}

⚡ Powered by: Ubot Premium Zyura</blockquote>"""
                    
                    await client.send_video(
                        message.chat.id, 
                        video_url, 
                        caption=caption,
                        supports_streaming=True
                    )

                # Kirim audio
                music_info = result.get("music_info", {})
                if music_info and music_info.get("url"):
                    audio_url = music_info["url"]
                    audio_title = music_info.get("title", "TikTok Music")
                    audio_author = music_info.get("author", "Unknown")
                    audio_cover = result.get("cover")

                    await client.send_audio(
                        message.chat.id,
                        audio_url,
                        title=audio_title[:50],
                        performer=audio_author[:50],
                        thumb=audio_cover if audio_cover else None,
                        caption=f"🎵 {audio_title}\n👤 {audio_author}"
                    )

            await proses_message.delete()
        else:
            await proses_message.delete()
            await message.reply("❌ Gagal mengambil data TikTok. Pastikan link valid.")

    except requests.exceptions.Timeout:
        await proses_message.delete()
        await message.reply("⏱️ Timeout! Server sedang sibuk.")
    except requests.exceptions.ConnectionError:
        await proses_message.delete()
        await message.reply("❌ Gagal terhubung ke server!")
    except Exception as e:
        await proses_message.delete()
        await message.reply(f"❌ Error: {str(e)[:100]}")

@PY.BOT("tiktok")
async def tiktok_handler_bot(client, message):
    if len(message.command) < 2:
        await message.reply("❌ Linknya mana? Contoh: /tiktok https://vm.tiktok.com/xxxxx")
        return

    url = message.command[1]
    proses_message = await message.reply("```\n⏳ Processing Kingz...```")

    try:
        # Request ke API vreden
        response = requests.get(f"{BASE_URL}?url={url}", timeout=15)
        data = response.json()

        if data.get("status") and data.get("result"):
            result = data["result"]
            
            # Cek apakah ini adalah slideshow (gambar) atau video
            if "images" in result:
                for img_url in result["images"]:
                    await client.send_photo(message.chat.id, img_url)
            else:
                # Ambil video URL
                video_url = None
                for item in result.get("data", []):
                    if item["type"] == "nowatermark_hd":
                        video_url = item["url"]
                        break
                if not video_url:
                    for item in result.get("data", []):
                        if item["type"] == "nowatermark":
                            video_url = item["url"]
                            break
                
                if video_url:
                    # Buat caption
                    title = result.get("title", "TikTok Video")
                    stats = result.get("stats", {})
                    author = result.get("author", {})
                    
                    caption = f"""
<blockquote><b>✅ TIKTOK DOWNLOADER</b>

📹 <b>Judul:</b> {title[:100]}...
👤 <b>Uploader:</b> {author.get('nickname', 'Unknown')} (@{author.get('fullname', 'Unknown')})
👁️ <b>Views:</b> {stats.get('views', '0')}
❤️ <b>Likes:</b> {stats.get('likes', '0')}
💬 <b>Comments:</b> {stats.get('comment', '0')}
🔄 <b>Shares:</b> {stats.get('share', '0')}
⏱️ <b>Durasi:</b> {result.get('duration', '0')}

⚡ Powered by: Ubot Premium Zyura</blockquote>"""
                    
                    await client.send_video(
                        message.chat.id, 
                        video_url, 
                        caption=caption,
                        supports_streaming=True
                    )

                # Kirim audio
                music_info = result.get("music_info", {})
                if music_info and music_info.get("url"):
                    audio_url = music_info["url"]
                    audio_title = music_info.get("title", "TikTok Music")
                    audio_author = music_info.get("author", "Unknown")
                    audio_cover = result.get("cover")

                    await client.send_audio(
                        message.chat.id,
                        audio_url,
                        title=audio_title[:50],
                        performer=audio_author[:50],
                        thumb=audio_cover if audio_cover else None,
                        caption=f"🎵 {audio_title}\n👤 {audio_author}"
                    )

            await proses_message.delete()
        else:
            await proses_message.delete()
            await message.reply("❌ Gagal mengambil data TikTok. Pastikan link valid.")

    except Exception as e:
        await proses_message.delete()
        await message.reply(f"❌ Error: {str(e)[:100]}")