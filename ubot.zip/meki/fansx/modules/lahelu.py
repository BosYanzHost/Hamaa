from fansx import *
import aiohttp
import asyncio
import random
from urllib.parse import quote
from pyrogram.enums import ChatAction, ParseMode
from pyrogram.types import Message

__MODULE__ = "ʟᴀʜᴇʟᴜ sᴇᴀʀᴄʜ"
__HELP__ = """
<blockquote><b>🤣 LAHELU SEARCH</b>

<b>⌲ Perintah:</b>
ᚗ <code>{0}lahelu [kata kunci]</code> - Cari meme di Lahelu
ᚗ <code>{0}lahelurand</code> - Random meme (pakai kata kunci random)

<b>⌲ Contoh:</b>
<code>.lahelu sakura</code>
<code>.lahelu kucing</code>
<code>.lahelurand</code></blockquote>
"""

# ============================================
# KONFIGURASI
# ============================================
BASE_URL = "https://api.theresav.biz.id/search/lahelu"
API_KEY = "UYGSg"  # API Key dari contoh

async def search_lahelu(query: str):
    """Mencari postingan di Lahelu"""
    try:
        encoded_query = quote(query)
        url = f"{BASE_URL}?query={encoded_query}&apikey={API_KEY}"
        
        async with aiohttp.ClientSession() as session:
            async with session.get(url, timeout=15) as response:
                if response.status == 200:
                    data = await response.json()
                    
                    if data.get("status") and data.get("results"):
                        return {
                            "success": True,
                            "total": data.get("total", 0),
                            "results": data.get("results", [])
                        }
                    else:
                        return {"success": False, "error": "Tidak ada hasil"}
                else:
                    return {"success": False, "error": f"HTTP {response.status}"}
    except asyncio.TimeoutError:
        return {"success": False, "error": "Timeout"}
    except Exception as e:
        return {"success": False, "error": str(e)}

def get_file_extension(url):
    """Mendapatkan ekstensi file dari URL"""
    if '.mp4' in url:
        return 'video'
    elif '.webp' in url or '.jpg' in url or '.jpeg' in url or '.png' in url:
        return 'image'
    else:
        return 'unknown'

@PY.UBOT("lahelu")
async def lahelu_search(client: Client, message: Message):
    ggl = await EMO.GAGAL(client)
    sks = await EMO.BERHASIL(client)
    prs = await EMO.PROSES(client)
    
    try:
        await client.send_chat_action(message.chat.id, ChatAction.TYPING)
        
        # Ambil kata kunci
        args = message.text.split(maxsplit=1)
        if len(args) < 2:
            await message.reply_text(
                f"<blockquote><b>❌ Masukkan kata kunci!</b>\n\n"
                f"<b>Contoh:</b>\n"
                f"<code>.lahelu sakura</code>\n"
                f"<code>.lahelu kucing</code></blockquote>"
            )
            return
        
        query = args[1].strip()
        
        # Kirim pesan processing
        processing = await message.reply_text(f"{prs} <b>Mencari '{query}' di Lahelu...</b>")
        
        # Cari di Lahelu
        result = await search_lahelu(query)
        
        if not result.get("success") or not result.get("results"):
            await processing.edit_text(
                f"<blockquote><b>❌ TIDAK ADA HASIL</b>\n\n"
                f"Kata Kunci: {query}\n"
                f"Coba kata kunci lain.</blockquote>"
            )
            return
        
        results = result.get("results", [])
        total = result.get("total", len(results))
        
        # Pilih random 1 dari hasil
        selected = random.choice(results)
        
        title = selected.get("title", "Tanpa Judul")
        author = selected.get("author", "Unknown")
        media_url = selected.get("media", "")
        post_id = selected.get("post_id", "")
        hashtags = selected.get("hashtags", [])
        
        # Format hashtags
        hashtag_text = ""
        if hashtags:
            hashtag_text = "\n🏷️ " + " ".join([f"#{tag}" for tag in hashtags[:5]])
        
        # Deteksi tipe media
        media_type = get_file_extension(media_url)
        
        await processing.delete()
        
        caption = f"""
<blockquote><b>🤣 LAHELU MEME</b>

📌 <b>Judul:</b> {title}
👤 <b>Author:</b> {author}
🆔 <b>Post ID:</b> <code>{post_id}</code>
📊 <b>Total Ditemukan:</b> {total}{hashtag_text}

⚡ <b>Powered by:</b> Ubot Premium Zyura</blockquote>"""
        
        # Kirim sesuai tipe media
        if media_type == 'video':
            await client.send_video(
                chat_id=message.chat.id,
                video=media_url,
                caption=caption
            )
        else:
            # Coba kirim sebagai foto
            try:
                await client.send_photo(
                    chat_id=message.chat.id,
                    photo=media_url,
                    caption=caption
                )
            except:
                # Fallback kirim link
                await message.reply_text(
                    f"{caption}\n\n🔗 Link: {media_url}"
                )
        
    except Exception as e:
        await message.reply_text(f"{ggl} <b>Error: {str(e)[:100]}</b>")

@PY.UBOT("lahelurand")
async def lahelu_random(client: Client, message: Message):
    """Cari meme random di Lahelu dengan kata kunci random"""
    
    # Kata kunci random
    random_keywords = [
        "sakura", "kucing", "anjing", "naruto", "makan", "tidur",
        "kerja", "kuliah", "dosen", "boss", "mie", "ayam",
        "robot", "game", "meme", "lucu", "random", "ga jelas"
    ]
    
    random_query = random.choice(random_keywords)
    
    # Panggil fungsi search
    message.text = f".lahelu {random_query}"
    await lahelu_search(client, message)

