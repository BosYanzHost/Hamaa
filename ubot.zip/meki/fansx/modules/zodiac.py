import random
from pyrogram.enums import ChatAction, ParseMode
from pyrogram.types import Message
from pyrogram import Client, filters
import requests
from fansx import *

__MODULE__ = "ᴢᴏᴅɪᴀᴋ"
__HELP__ = """
<b>⦪ ʙᴀɴᴛᴜᴀɴ ᴜɴᴛᴜᴋ ᴢᴏᴅɪᴀᴋ ⦫</b>

<blockquote><b>⎆ ᴘᴇʀɪɴᴛᴀʜ :
ᚗ <code>{0}zodiak</code> [zodiak]

⌭ ᴘᴇɴᴊᴇʟᴀsᴀɴ:
ᚗ meramal zodiak

⌭ ᴅᴀꜰᴛᴀʀ ᴢᴏᴅɪᴀᴋ:
aries, taurus, gemini, cancer, leo, virgo, libra, scorpio, sagitarius, capricorn, aquarius, pisces</blockquote>
"""

# Daftar API keys lolhuman (bisa ditambah sendiri)
API_KEYS = [
    "323e6584f28690c6c376622c",  # Key default
    # Tambahkan key lain jika punya
]

def get_random_apikey():
    """Mengambil API key secara random dari daftar"""
    return random.choice(API_KEYS)

# Mapping zodiak Indonesia ke Inggris untuk API
ZODIAK_MAP = {
    "aries": "aries",
    "taurus": "taurus",
    "gemini": "gemini",
    "cancer": "cancer",
    "leo": "leo",
    "virgo": "virgo",
    "libra": "libra",
    "scorpio": "scorpio",
    "sagitarius": "sagitarius",
    "capricorn": "capricorn",
    "aquarius": "aquarius",
    "pisces": "pisces"
}

def parse_result(result_text):
    """Parse result text dari API menjadi bagian-bagian"""
    lines = result_text.split('\n')
    
    # Inisialisasi default
    data = {
        "zodiak": "",
        "tanggal": "",
        "sifat": "",
        "nomor": "",
        "aroma": "",
        "planet": "",
        "bunga": "",
        "warna": "",
        "batu": "",
        "elemen": "",
        "pasangan": "",
        "deskripsi": "",
        "asmara": ""
    }
    
    try:
        # Ambil baris pertama untuk zodiak dan tanggal
        if len(lines) > 0:
            first_line = lines[0].strip()
            if " - " in first_line:
                zodiak_part, tanggal_part = first_line.split(" - ", 1)
                data["zodiak"] = zodiak_part.strip()
                data["tanggal"] = tanggal_part.strip()
            else:
                data["zodiak"] = first_line
        
        # Parsing bagian-bagian
        current_section = "sifat"
        description_started = False
        asmara_started = False
        
        for line in lines[1:]:
            line = line.strip()
            if not line:
                continue
                
            if line.startswith("Nomor Keberuntungan:"):
                data["nomor"] = line.replace("Nomor Keberuntungan:", "").strip()
                current_section = "nomor"
            elif line.startswith("Aroma Keberuntungan:"):
                data["aroma"] = line.replace("Aroma Keberuntungan:", "").strip()
                current_section = "aroma"
            elif line.startswith("Planet Yang Mengitari:"):
                data["planet"] = line.replace("Planet Yang Mengitari:", "").strip()
                current_section = "planet"
            elif line.startswith("Bunga Keberuntungan:"):
                data["bunga"] = line.replace("Bunga Keberuntungan:", "").strip()
                current_section = "bunga"
            elif line.startswith("Warna Keberuntungan:"):
                data["warna"] = line.replace("Warna Keberuntungan:", "").strip()
                current_section = "warna"
            elif line.startswith("Batu Keberuntungan:"):
                data["batu"] = line.replace("Batu Keberuntungan:", "").strip()
                current_section = "batu"
            elif line.startswith("Elemen Keberuntungan:"):
                data["elemen"] = line.replace("Elemen Keberuntungan:", "").strip()
                current_section = "elemen"
            elif line.startswith("Pasangan Serasi:"):
                data["pasangan"] = line.replace("Pasangan Serasi:", "").strip()
                current_section = "pasangan"
            elif line.startswith("Asmara para"):
                asmara_started = True
                data["asmara"] = line + "\n"
            else:
                if not description_started and not asmara_started:
                    # Ini adalah bagian sifat (bisa multiple lines)
                    if data["sifat"]:
                        data["sifat"] += " " + line
                    else:
                        data["sifat"] = line
                elif asmara_started:
                    data["asmara"] += line + "\n"
                else:
                    # Deskripsi
                    if data["deskripsi"]:
                        data["deskripsi"] += " " + line
                    else:
                        data["deskripsi"] = line
                        description_started = True
    except Exception as e:
        print(f"Error parsing: {e}")
    
    return data

@PY.UBOT("zodiak")
async def zodiak_handler(client, message):
    if len(message.command) < 2:
        zodiak_list = ", ".join(ZODIAK_MAP.keys())
        await message.reply_text(
            f"<blockquote><b>❌ Gunakan perintah:</b> <code>.zodiak [zodiak]</code>\n\n"
            f"<b>Contoh:</b> <code>.zodiak leo</code>\n\n"
            f"<b>Daftar zodiak:</b>\n{zodiak_list}</blockquote>"
        )
        return

    # Ambil input zodiak
    zodiak_input = message.command[1].lower().strip()
    
    # Validasi zodiak
    if zodiak_input not in ZODIAK_MAP:
        zodiak_list = ", ".join(ZODIAK_MAP.keys())
        return await message.reply_text(
            f"<blockquote><b>❌ Zodiak tidak valid!</b>\n\n"
            f"<b>Daftar zodiak:</b>\n{zodiak_list}</blockquote>"
        )
    
    # Kirim pesan processing
    processing_msg = await message.reply_text(
        "<blockquote><b>🔮 Mencari ramalan zodiak...</b></blockquote>"
    )
    
    # Ambil API key random
    apikey = get_random_apikey()
    zodiak_en = ZODIAK_MAP[zodiak_input]
    
    # Buat URL API
    api_url = f"https://api.lolhuman.xyz/api/zodiak/{zodiak_en}?apikey={apikey}"

    try:
        # Request ke API
        response = requests.get(api_url, timeout=10)
        
        if response.status_code != 200:
            return await processing_msg.edit_text(
                f"<blockquote><b>❌ Gagal terhubung ke API! Kode: {response.status_code}</b></blockquote>"
            )
        
        data = response.json()
        
        if data.get("status") == 200 and data.get("result"):
            result_text = data["result"]
            
            # Parse result text
            parsed = parse_result(result_text)
            
            # Format pesan
            reply_text = f"""
<blockquote><b>🔮 RAMALAN ZODIAK {parsed['zodiak'].upper()}</b>

📅 <b>Tanggal:</b> {parsed['tanggal']}

<b>✨ SIFAT UMUM:</b>
{parsed['sifat']}

<b>🍀 KEBERUNTUNGAN:</b>
• <b>Nomor:</b> {parsed['nomor']}
• <b>Aroma:</b> {parsed['aroma']}
• <b>Planet:</b> {parsed['planet']}
• <b>Bunga:</b> {parsed['bunga']}
• <b>Warna:</b> {parsed['warna']}
• <b>Batu:</b> {parsed['batu']}
• <b>Elemen:</b> {parsed['elemen']}
• <b>Pasangan Serasi:</b> {parsed['pasangan']}
</blockquote>"""

            # Tambahkan deskripsi jika ada
            if parsed['deskripsi']:
                # Potong deskripsi jika terlalu panjang
                deskripsi = parsed['deskripsi']
                if len(deskripsi) > 500:
                    deskripsi = deskripsi[:500] + "..."
                reply_text += f"\n<blockquote><b>📖 DESKRIPSI:</b>\n{deskripsi}</blockquote>"
            
            # Tambahkan asmara jika ada
            if parsed['asmara']:
                asmara = parsed['asmara']
                if len(asmara) > 300:
                    asmara = asmara[:300] + "..."
                reply_text += f"\n<blockquote><b>❤️ ASMARA:</b>\n{asmara}</blockquote>"
            
            # Tambahkan footer
            reply_text += f"\n<blockquote><b>🔑 Key:</b> <code>{apikey[:8]}...</code></blockquote>"
            
            await processing_msg.edit_text(reply_text)
            
        else:
            error_msg = data.get("message", "Unknown error")
            await processing_msg.edit_text(
                f"<blockquote><b>❌ Gagal mengambil data zodiak!</b>\n\n{error_msg}</blockquote>"
            )
            
    except requests.exceptions.Timeout:
        await processing_msg.edit_text(
            "<blockquote><b>⏱️ Timeout! Server sedang sibuk.</b></blockquote>"
        )
    except requests.exceptions.ConnectionError:
        await processing_msg.edit_text(
            "<blockquote><b>❌ Gagal terhubung ke server!</b></blockquote>"
        )
    except Exception as e:
        await processing_msg.edit_text(
            f"<blockquote><b>❌ Error:</b> <code>{str(e)[:100]}</code></blockquote>"
        )

@PY.BOT("zodiak")
async def zodiak_handler_bot(client, message):
    if len(message.command) < 2:
        zodiak_list = ", ".join(ZODIAK_MAP.keys())
        await message.reply_text(
            f"<blockquote><b>❌ Gunakan perintah:</b> <code>/zodiak [zodiak]</code>\n\n"
            f"<b>Contoh:</b> <code>/zodiak leo</code>\n\n"
            f"<b>Daftar zodiak:</b>\n{zodiak_list}</blockquote>"
        )
        return

    # Ambil input zodiak
    zodiak_input = message.command[1].lower().strip()
    
    # Validasi zodiak
    if zodiak_input not in ZODIAK_MAP:
        zodiak_list = ", ".join(ZODIAK_MAP.keys())
        return await message.reply_text(
            f"<blockquote><b>❌ Zodiak tidak valid!</b>\n\n"
            f"<b>Daftar zodiak:</b>\n{zodiak_list}</blockquote>"
        )
    
    # Kirim pesan processing
    processing_msg = await message.reply_text(
        "<blockquote><b>🔮 Mencari ramalan zodiak...</b></blockquote>"
    )
    
    # Ambil API key random
    apikey = get_random_apikey()
    zodiak_en = ZODIAK_MAP[zodiak_input]
    
    # Buat URL API
    api_url = f"https://api.lolhuman.xyz/api/zodiak/{zodiak_en}?apikey={apikey}"

    try:
        response = requests.get(api_url, timeout=10)
        
        if response.status_code != 200:
            return await processing_msg.edit_text(
                f"<blockquote><b>❌ Gagal terhubung ke API! Kode: {response.status_code}</b></blockquote>"
            )
        
        data = response.json()
        
        if data.get("status") == 200 and data.get("result"):
            result_text = data["result"]
            
            # Parse result text
            parsed = parse_result(result_text)
            
            # Format pesan
            reply_text = f"""
<blockquote><b>🔮 RAMALAN ZODIAK {parsed['zodiak'].upper()}</b>

📅 <b>Tanggal:</b> {parsed['tanggal']}

<b>✨ SIFAT UMUM:</b>
{parsed['sifat']}

<b>🍀 KEBERUNTUNGAN:</b>
• <b>Nomor:</b> {parsed['nomor']}
• <b>Aroma:</b> {parsed['aroma']}
• <b>Planet:</b> {parsed['planet']}
• <b>Bunga:</b> {parsed['bunga']}
• <b>Warna:</b> {parsed['warna']}
• <b>Batu:</b> {parsed['batu']}
• <b>Elemen:</b> {parsed['elemen']}
• <b>Pasangan Serasi:</b> {parsed['pasangan']}
</blockquote>"""

            # Tambahkan deskripsi jika ada
            if parsed['deskripsi']:
                deskripsi = parsed['deskripsi']
                if len(deskripsi) > 500:
                    deskripsi = deskripsi[:500] + "..."
                reply_text += f"\n<blockquote><b>📖 DESKRIPSI:</b>\n{deskripsi}</blockquote>"
            
            # Tambahkan asmara jika ada
            if parsed['asmara']:
                asmara = parsed['asmara']
                if len(asmara) > 300:
                    asmara = asmara[:300] + "..."
                reply_text += f"\n<blockquote><b>❤️ ASMARA:</b>\n{asmara}</blockquote>"
            
            await processing_msg.edit_text(reply_text)
            
        else:
            error_msg = data.get("message", "Unknown error")
            await processing_msg.edit_text(
                f"<blockquote><b>❌ Gagal mengambil data zodiak!</b>\n\n{error_msg}</blockquote>"
            )
            
    except Exception as e:
        await processing_msg.edit_text(
            f"<blockquote><b>❌ Error:</b> <code>{str(e)[:100]}</code></blockquote>"
        )