import requests
import re
from pyrogram import Client, filters
from pyrogram.enums import ChatAction
from fansx import *

__MODULE__ = "ᴠᴄᴄ ɢᴇɴᴇʀᴀᴛᴏʀ"
__HELP__ = """
<b>⦪ ʙᴀɴᴛᴜᴀɴ ᴜɴᴛᴜᴋ ᴠᴄᴄ ɢᴇɴᴇʀᴀᴛᴏʀ ⦫</b>
<blockquote>⎆ perintah :
ᚗ <code>{0}vcc</code> [jumlah]
⊶ untuk membuat fake vcc (default 5, maksimal 10)

⎆ contoh :
ᚗ <code>{0}vcc</code> → membuat 5 VCC
ᚗ <code>{0}vcc 3</code> → membuat 3 VCC</blockquote>
"""

# API Key statis
API_KEY = "iyNntkdC"
BASE_URL = "https://api.botcahx.eu.org/api/tools/vccgen"

def parse_vcc_result(result_text):
    """Parse hasil VCC dari format teks ke list dictionary"""
    vcc_list = []
    
    # Split berdasarkan newline
    lines = result_text.strip().split('\n')
    
    current_vcc = {}
    
    for line in lines:
        line = line.strip()
        if not line:
            continue
            
        # Deteksi nomor urut (1., 2., dst)
        if re.match(r'^\*?\d+\.\*?\s+', line):
            # Jika ada VCC sebelumnya, simpan
            if current_vcc:
                vcc_list.append(current_vcc)
                current_vcc = {}
            
            # Ambil nama (hapus nomor dan asterisk)
            name_part = re.sub(r'^\*?\d+\.\*?\s+', '', line)
            current_vcc['name'] = name_part.strip()
        
        # Deteksi card number
        elif 'Number :' in line or '• Number :' in line:
            number = line.split(':')[1].strip()
            current_vcc['number'] = number
        
        # Deteksi CVV
        elif 'CVV :' in line or '• CVV :' in line:
            cvv = line.split(':')[1].strip()
            current_vcc['cvv'] = cvv
        
        # Deteksi expired
        elif 'Expired :' in line or '• Expired :' in line:
            expired = line.split(':')[1].strip()
            current_vcc['expired'] = expired
    
    # Tambahkan VCC terakhir
    if current_vcc:
        vcc_list.append(current_vcc)
    
    return vcc_list

@PY.UBOT("vcc")
async def generate_vcc(client, message):
    await client.send_chat_action(message.chat.id, ChatAction.TYPING)
    
    # Ambil jumlah dari pesan
    args = message.text.split()
    jumlah = 5  # default
    
    if len(args) > 1:
        try:
            jumlah = int(args[1])
            if jumlah < 1:
                jumlah = 1
            elif jumlah > 10:
                jumlah = 10  # batasi maksimal 10
        except ValueError:
            pass
    
    # Kirim pesan processing
    proses_msg = await message.reply_text(
        f"<blockquote><b>⏳ Generating {jumlah} VCC...</b></blockquote>"
    )
    
    # Buat URL dengan parameter
    params = {
        "apikey": API_KEY,
        "jumlah": jumlah
    }
    
    try:
        # Request ke API
        response = requests.get(BASE_URL, params=params, timeout=15)
        
        if response.status_code != 200:
            return await proses_msg.edit_text(
                f"<blockquote><b>❌ Gagal terhubung ke server! Kode: {response.status_code}</b></blockquote>"
            )
        
        data = response.json()
        
        if data.get("status") and data.get("result"):
            result_text = data["result"]
            
            # Parse hasil
            vcc_list = parse_vcc_result(result_text)
            
            # Format pesan
            result_msg = f"<blockquote><b>💳 GENERATED VCC (MasterCard)</b>\n"
            result_msg += f"📊 <b>Jumlah:</b> {len(vcc_list)} kartu\n"
            result_msg += f"🔑 <b>API Key:</b> <code>{API_KEY[:8]}...</code>\n"
            result_msg += "─────────────────────</blockquote>\n\n"
            
            for i, vcc in enumerate(vcc_list, 1):
                result_msg += f"<blockquote><b>{i}. {vcc.get('name', 'Unknown')}</b>\n"
                result_msg += f"💳 <b>Number:</b> <code>{vcc.get('number', 'N/A')}</code>\n"
                result_msg += f"🔐 <b>CVV:</b> <code>{vcc.get('cvv', 'N/A')}</code>\n"
                result_msg += f"📅 <b>Expired:</b> {vcc.get('expired', 'N/A')}\n"
                result_msg += "─────────────────────</blockquote>\n"
            
            # Tambahan informasi
            result_msg += "\n<blockquote><b>⚠️ Catatan:</b>\n"
            result_msg += "• VCC ini hanya untuk testing/development\n"
            result_msg += "• Tidak dapat digunakan untuk transaksi real\n"
            result_msg += "• Gunakan dengan bijak</blockquote>"
            
            await proses_msg.edit_text(result_msg)
            
        else:
            error_msg = data.get("message", "Unknown error")
            await proses_msg.edit_text(
                f"<blockquote><b>❌ Gagal generate VCC!</b>\n\n{error_msg}</blockquote>"
            )
            
    except requests.exceptions.Timeout:
        await proses_msg.edit_text(
            "<blockquote><b>⏱️ Waktu permintaan habis! Server sedang sibuk.</b></blockquote>"
        )
    except requests.exceptions.ConnectionError:
        await proses_msg.edit_text(
            "<blockquote><b>❌ Gagal terhubung ke server! Periksa koneksi internet.</b></blockquote>"
        )
    except Exception as e:
        await proses_msg.edit_text(
            f"<blockquote><b>❌ Error:</b> <code>{str(e)[:100]}</code></blockquote>"
        )

@PY.BOT("vcc")
async def generate_vcc_bot(client, message):
    await client.send_chat_action(message.chat.id, ChatAction.TYPING)
    
    # Ambil jumlah dari pesan
    args = message.text.split()
    jumlah = 5  # default
    
    if len(args) > 1:
        try:
            jumlah = int(args[1])
            if jumlah < 1:
                jumlah = 1
            elif jumlah > 10:
                jumlah = 10
        except ValueError:
            pass
    
    # Kirim pesan processing
    proses_msg = await message.reply_text(
        f"<blockquote><b>⏳ Generating {jumlah} VCC...</b></blockquote>"
    )
    
    # Buat URL dengan parameter
    params = {
        "apikey": API_KEY,
        "jumlah": jumlah
    }
    
    try:
        # Request ke API
        response = requests.get(BASE_URL, params=params, timeout=15)
        
        if response.status_code != 200:
            return await proses_msg.edit_text(
                f"<blockquote><b>❌ Gagal terhubung ke server! Kode: {response.status_code}</b></blockquote>"
            )
        
        data = response.json()
        
        if data.get("status") and data.get("result"):
            result_text = data["result"]
            
            # Parse hasil
            vcc_list = parse_vcc_result(result_text)
            
            # Format pesan
            result_msg = f"<blockquote><b>💳 GENERATED VCC (MasterCard)</b>\n"
            result_msg += f"📊 <b>Jumlah:</b> {len(vcc_list)} kartu\n"
            result_msg += "─────────────────────</blockquote>\n\n"
            
            for i, vcc in enumerate(vcc_list, 1):
                result_msg += f"<blockquote><b>{i}. {vcc.get('name', 'Unknown')}</b>\n"
                result_msg += f"💳 <b>Number:</b> <code>{vcc.get('number', 'N/A')}</code>\n"
                result_msg += f"🔐 <b>CVV:</b> <code>{vcc.get('cvv', 'N/A')}</code>\n"
                result_msg += f"📅 <b>Expired:</b> {vcc.get('expired', 'N/A')}\n"
                result_msg += "─────────────────────</blockquote>\n"
            
            # Tambahan informasi
            result_msg += "\n<blockquote><b>⚠️ Catatan:</b>\n"
            result_msg += "• VCC ini hanya untuk testing/development\n"
            result_msg += "• Tidak dapat digunakan untuk transaksi real\n"
            result_msg += "• Gunakan dengan bijak</blockquote>"
            
            await proses_msg.edit_text(result_msg)
            
        else:
            error_msg = data.get("message", "Unknown error")
            await proses_msg.edit_text(
                f"<blockquote><b>❌ Gagal generate VCC!</b>\n\n{error_msg}</blockquote>"
            )
            
    except Exception as e:
        await proses_msg.edit_text(
            f"<blockquote><b>❌ Error:</b> <code>{str(e)[:100]}</code></blockquote>"
        )