from fansx import *
import aiohttp
import asyncio
import os
import random
from urllib.parse import quote
from pyrogram.enums import ChatAction, ParseMode
from pyrogram.types import Message

__MODULE__ = "ᴛᴏ ʙʟᴜʀ"
__HELP__ = """
<blockquote><b>💤 TO BLUR EDITOR</b>

<b>⌲ Perintah:</b>
ᚗ <code>{0}toblur</code> - Reply ke foto, buat efek blur

<b>⌲ Contoh:</b>
<code>.toblur</code> (reply ke foto)

<b>⌲ Hasil:</b>
• Gambar dengan efek blur
• Cocok untuk background atau stiker blur</blockquote>
"""

# ============================================
# KONFIGURASI
# ============================================
BASE_URL = "https://api.baguss.xyz/api/edits/tompls"

async def upload_to_catbox(file_path):
    """Upload gambar ke catbox.moe"""
    try:
        async with aiohttp.ClientSession() as session:
            data = aiohttp.FormData()
            data.add_field('fileToUpload', 
                          open(file_path, 'rb'),
                          filename='image.png',
                          content_type='image/png')
            data.add_field('reqtype', 'fileupload')
            
            async with session.post('https://catbox.moe/user/api.php', data=data, timeout=30) as resp:
                if resp.status == 200:
                    url = await resp.text()
                    return url.strip()
    except Exception as e:
        print(f"Catbox upload error: {e}")
    return None

async def process_toblur(image_url):
    """Proses gambar dengan efek blur"""
    try:
        encoded_url = quote(image_url, safe='')
        api_url = f"{BASE_URL}?image={encoded_url}"
        
        async with aiohttp.ClientSession() as session:
            async with session.get(api_url, timeout=30) as response:
                if response.status == 200:
                    data = await response.json()
                    
                    if data.get("success") and data.get("result"):
                        result_url = data["result"]
                        size = data.get("size", "?")
                        
                        # Download hasil
                        async with session.get(result_url, timeout=30) as img_resp:
                            if img_resp.status == 200:
                                return {
                                    "success": True,
                                    "image": await img_resp.read(),
                                    "size": size,
                                    "url": result_url
                                }
                    else:
                        return {"success": False, "error": "Response tidak valid"}
                else:
                    return {"success": False, "error": f"HTTP {response.status}"}
    except asyncio.TimeoutError:
        return {"success": False, "error": "Timeout"}
    except Exception as e:
        return {"success": False, "error": str(e)}

@PY.UBOT("toblur")
async def to_blur_editor(client: Client, message: Message):
    ggl = await EMO.GAGAL(client)
    sks = await EMO.BERHASIL(client)
    prs = await EMO.PROSES(client)
    
    try:
        await client.send_chat_action(message.chat.id, ChatAction.UPLOAD_PHOTO)
        
        # Cek apakah ada reply gambar
        if not message.reply_to_message or not message.reply_to_message.photo:
            await message.reply_text(
                f"<blockquote><b>❌ Reply ke foto yang mau diblur!</b>\n\n"
                f"<b>Contoh:</b>\n"
                f"<code>.toblur</code> (reply ke foto)</blockquote>"
            )
            return
        
        # Download gambar
        processing = await message.reply_text(f"{prs} <b>Mendownload gambar...</b>")
        
        file_path = await message.reply_to_message.download()
        
        await processing.edit_text(f"{prs} <b>Mengupload ke catbox.moe...</b>")
        
        # Upload ke catbox
        image_url = await upload_to_catbox(file_path)
        
        # Hapus file lokal
        if os.path.exists(file_path):
            os.remove(file_path)
        
        if not image_url:
            await processing.edit_text(f"{ggl} <b>Gagal upload gambar!</b>")
            return
        
        await processing.edit_text(f"{prs} <b>Memproses efek blur...</b>")
        
        # Proses dengan API
        result = await process_toblur(image_url)
        
        if result.get("success"):
            image_data = result["image"]
            size = result["size"]
            
            # Simpan sementara
            file_path = f"toblur_{message.from_user.id}_{random.randint(1000,9999)}.png"
            with open(file_path, 'wb') as f:
                f.write(image_data)
            
            await processing.delete()
            
            # Kirim hasil
            await client.send_photo(
                chat_id=message.chat.id,
                photo=file_path,
                caption=f"<blockquote><b>✅ GAMBAR BLUR BERHASIL</b>\n\n"
                        f"📊 Ukuran: {size}\n"
                        f"⚡ <b>Powered by:</b> Ubot Premium Zyura</blockquote>"
            )
            
            # Hapus file
            if os.path.exists(file_path):
                os.remove(file_path)
        else:
            await processing.edit_text(
                f"<blockquote><b>❌ GAGAL MEMPROSES GAMBAR</b>\n\n"
                f"Error: {result.get('error', 'Unknown error')}</blockquote>"
            )
        
    except Exception as e:
        await message.reply_text(f"{ggl} <b>Error: {str(e)[:100]}</b>")

