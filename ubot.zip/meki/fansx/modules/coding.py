from fansx import *
import aiohttp
import asyncio
import random
import re
from urllib.parse import quote
from pyrogram.enums import ChatAction, ParseMode
from pyrogram.types import Message

__MODULE__ = "ᴄᴏᴅɪɴɢ ᴀssɪsᴛᴀɴᴛ"
__HELP__ = """
<blockquote><b>💻 AI CODING ASSISTANT</b>

<b>⌲ Perintah:</b>
ᚗ <code>{0}coding [permintaan]</code> - Buat kode sesuai permintaan

<b>⌲ Contoh:</b>
<code>.coding buatin web html simpel dengan form login</code>
<code>.coding buatin bot telegram pake telegraf</code>
<code>.coding fungsi python untuk sortir array</code>
<code>.coding kalkulator sederhana pake javascript</code></blockquote>
"""

# ============================================
# KONFIGURASI
# ============================================
BASE_URL = "https://api.siputzx.my.id/api/ai/duckai"
MODEL = "gpt-4o-mini"

# System prompt khusus untuk coding
SYSTEM_PROMPT = """Anda adalah seorang programmer expert yang sangat ahli dalam semua bahasa pemrograman (Python, JavaScript, HTML/CSS, Java, C++, PHP, Go, Ruby, dll).
Tugas Anda adalah membuat kode berdasarkan permintaan user.

Aturan:
1. Berikan kode yang siap pakai, lengkap, dan bisa langsung dijalankan
2. Sertakan penjelasan singkat tentang cara kerja kode
3. Jika memungkinkan, berikan contoh input dan output
4. Pastikan kode mengikuti best practices dan aman digunakan
5. Untuk web, berikan HTML/CSS/JS yang responsif
6. Untuk bot, berikan struktur yang lengkap
7. Jangan lupa berikan instruksi cara menjalankan

Format respons:
- Mulai dengan penjelasan singkat
- Berikan kode dalam code block dengan bahasa yang sesuai
- Akhiri dengan cara menjalankan/instalasi jika perlu"""

# Daftar ekstensi untuk code block
LANGUAGE_EXT = {
    "python": "py",
    "javascript": "js",
    "html": "html",
    "css": "css",
    "java": "java",
    "cpp": "cpp",
    "c": "c",
    "php": "php",
    "ruby": "rb",
    "go": "go",
    "rust": "rs",
    "swift": "swift",
    "kotlin": "kt",
    "typescript": "ts",
    "sql": "sql",
    "bash": "sh",
    "json": "json"
}

async def generate_code(prompt: str):
    """Generate kode dari Duck AI"""
    
    # Encode parameter
    encoded_prompt = quote(SYSTEM_PROMPT)
    encoded_message = quote(f"Buatkan kode: {prompt}")
    
    url = f"{BASE_URL}?message={encoded_message}&model={MODEL}&systemPrompt={encoded_prompt}"
    
    try:
        async with aiohttp.ClientSession() as session:
            async with session.get(url, timeout=60) as response:  # Timeout lebih lama untuk kode
                if response.status == 200:
                    data = await response.json()
                    
                    if data.get("status") and data.get("data"):
                        message = data["data"].get("message", "")
                        return {
                            "success": True,
                            "code": message.strip()
                        }
                    else:
                        return {"success": False, "error": "Response tidak valid"}
                else:
                    return {"success": False, "error": f"HTTP {response.status}"}
    except asyncio.TimeoutError:
        return {"success": False, "error": "Timeout - kode terlalu kompleks"}
    except Exception as e:
        return {"success": False, "error": str(e)}

def extract_code_blocks(text):
    """Ekstrak code block dari respons AI"""
    # Cari pattern ```language ... ```
    pattern = r'```(\w*)\n(.*?)```'
    matches = re.findall(pattern, text, re.DOTALL)
    
    if matches:
        return matches
    return None

def format_response(text):
    """Format respons untuk dikirim"""
    # Pisahkan bagian non-kode dan kode
    code_blocks = extract_code_blocks(text)
    
    if code_blocks:
        formatted = ""
        remaining = text
        
        for lang, code in code_blocks:
            # Hapus code block dari teks
            remaining = remaining.replace(f"```{lang}\n{code}```", "")
            
            # Tambah ke formatted
            if not lang:
                lang = "text"
            formatted += f"<b>Kode ({lang}):</b>\n<pre><code class='language-{lang}'>{code}</code></pre>\n\n"
        
        # Tambah sisa teks
        remaining = remaining.strip()
        if remaining:
            formatted = f"{remaining}\n\n{formatted}"
        
        return formatted
    else:
        # Jika tidak ada code block, return apa adanya
        return text

@PY.UBOT("coding")
async def coding_assistant(client: Client, message: Message):
    ggl = await EMO.GAGAL(client)
    sks = await EMO.BERHASIL(client)
    prs = await EMO.PROSES(client)
    
    try:
        await client.send_chat_action(message.chat.id, ChatAction.TYPING)
        
        # Ambil prompt
        args = message.text.split(maxsplit=1)
        if len(args) < 2:
            await message.reply_text(
                f"<blockquote><b>❌ Masukkan permintaan coding!</b>\n\n"
                f"<b>Contoh:</b>\n"
                f"<code>.coding buatin web html simpel dengan form login</code>\n"
                f"<code>.coding fungsi python untuk sortir array</code>\n"
                f"<code>.coding kalkulator sederhana pake javascript</code></blockquote>"
            )
            return
        
        prompt = args[1].strip()
        
        # Kirim pesan processing
        processing = await message.reply_text(
            f"{prs} <b>AI sedang menulis kode...</b>\n"
            f"📝 <code>{prompt[:50]}{'...' if len(prompt) > 50 else ''}</code>"
        )
        
        # Generate kode
        result = await generate_code(prompt)
        
        await processing.delete()
        
        if result.get("success"):
            code_response = result["code"]
            formatted = format_response(code_response)
            
            # Cek panjang pesan
            if len(formatted) > 4000:
                # Kirim sebagai file
                import os
                file_name = f"code_{message.from_user.id}_{random.randint(1000,9999)}.txt"
                with open(file_name, "w") as f:
                    f.write(code_response)
                
                await client.send_document(
                    chat_id=message.chat.id,
                    document=file_name,
                    caption=f"<blockquote><b>💻 HASIL CODING</b>\n\n📝 Prompt: {prompt[:100]}</blockquote>"
                )
                
                if os.path.exists(file_name):
                    os.remove(file_name)
            else:
                # Kirim langsung
                await message.reply_text(
                    f"<blockquote>📝 <b>Prompt:</b> {prompt}\n\n"
                    f"{formatted}\n\n"
                    f"⚡ <b>Powered by:</b> Ubot Premium Zyura</blockquote>"
                )
        else:
            error_msg = result.get("error", "Unknown error")
            await message.reply_text(
                f"<blockquote><b>❌ GAGAL GENERATE KODE</b>\n\n"
                f"Error: {error_msg}</blockquote>"
            )
        
    except Exception as e:
        await message.reply_text(f"{ggl} <b>Error: {str(e)[:100]}</b>")

