from fansx import *
import random
import requests
from pyrogram.enums import *
from pyrogram import *
from pyrogram.types import *
from io import BytesIO

__MODULE__ = "ʀᴀɴᴅᴏᴍ ᴋᴜᴄɪɴɢ"
__HELP__ = """
<blockquote><b>『 ғᴏᴛᴏ ʀᴀɴᴅᴏᴍ ᴋᴜᴄɪɴɢ 』</b>

<b>⌲ ᴘᴇʀɪɴᴛᴀʜ:</b> <code>{0}kucing</code>
<b>⌲ ᴘᴇɴᴊᴇʟᴀsᴀɴ:</b> Mengirim foto random kucing dari Pinterest

📌 Contoh:
<code>{0}kucing</code></b></blockquote>
"""

# Base URL API
BASE_URL = "https://api.nvidiabotz.xyz/search/pinterest"

@PY.UBOT("kucing")
@PY.TOP_CMD
async def random_cat(client, message):
    processing_msg = await message.reply("<b>🔍 Mencari foto kucing random...</b>")
    
    try:
        await client.send_chat_action(message.chat.id, ChatAction.UPLOAD_PHOTO)
        
        # Parameter untuk mencari gambar kucing
        params = {
            "q": "Kucing"
        }
        
        # Request ke API
        response = requests.get(BASE_URL, params=params, timeout=15)
        response.raise_for_status()
        
        data = response.json()
        
        # Cek status response
        if data.get("status") and data.get("result"):
            # Ambil list gambar
            images = data["result"]
            
            if images:
                # Pilih satu gambar secara random
                random_image = random.choice(images)
                
                # Download gambar
                img_response = requests.get(random_image, timeout=15)
                
                if img_response.status_code == 200:
                    # Kirim gambar
                    photo = BytesIO(img_response.content)
                    photo.name = 'kucing_random.jpg'
                    
                    await client.send_photo(
                        message.chat.id, 
                        photo,
                        caption="<b>🐱 Nih foto kucingnya! 🐱</b>"
                    )
                    
                    await processing_msg.delete()
                else:
                    await processing_msg.edit_text(
                        "<b>❌ Gagal mendownload gambar. Coba lagi nanti.</b>"
                    )
            else:
                await processing_msg.edit_text(
                    "<b>❌ Tidak ada gambar kucing ditemukan.</b>"
                )
        else:
            await processing_msg.edit_text(
                "<b>❌ Gagal mengambil data dari API.</b>"
            )
            
    except requests.exceptions.Timeout:
        await processing_msg.edit_text(
            "<b>⏱️ Timeout! Server sedang sibuk.</b>"
        )
    except requests.exceptions.ConnectionError:
        await processing_msg.edit_text(
            "<b>❌ Gagal terhubung ke server!</b>"
        )
    except requests.exceptions.RequestException as e:
        await processing_msg.edit_text(
            f"<b>❌ Error mengambil gambar: {str(e)[:100]}</b>"
        )
    except Exception as e:
        await processing_msg.edit_text(
            f"<b>❌ Error: {str(e)[:100]}</b>"
        )

@PY.BOT("kucing")
async def random_cat_bot(client, message):
    processing_msg = await message.reply("🔍 Mencari foto kucing random...")
    
    try:
        params = {
            "q": "Kucing"
        }
        
        response = requests.get(BASE_URL, params=params, timeout=15)
        response.raise_for_status()
        
        data = response.json()
        
        if data.get("status") and data.get("result"):
            images = data["result"]
            
            if images:
                random_image = random.choice(images)
                
                img_response = requests.get(random_image, timeout=15)
                
                if img_response.status_code == 200:
                    photo = BytesIO(img_response.content)
                    photo.name = 'kucing_random.jpg'
                    
                    await client.send_photo(
                        message.chat.id, 
                        photo,
                        caption="🐱 Nih foto kucingnya!"
                    )
                    
                    await processing_msg.delete()
                else:
                    await processing_msg.edit_text("❌ Gagal mendownload gambar.")
            else:
                await processing_msg.edit_text("❌ Tidak ada gambar ditemukan.")
        else:
            await processing_msg.edit_text("❌ Gagal mengambil data.")
            
    except Exception as e:
        await processing_msg.edit_text(f"❌ Error: {str(e)[:100]}")