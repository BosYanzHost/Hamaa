import random
import requests
from fansx import *

__MODULE__ = "𝙻𝚄𝙼𝙸𝙽𝙰𝙸"
__HELP__ = """
<blockquote><b>Bantuan Untuk LuminAI

Perintah : <code>{0}lumin</code>
    Dapat mengobrol dengan AI</b></blockquote>
"""

@PY.UBOT("lumin")
async def _(client, message):
    try:
        if len(message.command) < 2:
            await message.reply_text(
                "<emoji id=5019523782004441717>❌</emoji> Mohon gunakan format yang benar.\nContoh: <code>.lumin halo</code>"
            )
            return

        prs = await message.reply_text("<emoji id=5319230516929502602>🔍</emoji> Menjawab...")
        query = message.text.split(' ', 1)[1]
        
        # CUMA GANTI API INI DOANG
        response = requests.get(f'https://api.nvidiabotz.xyz/ai/blackbox?text={query}')

        try:
            data = response.json()

            # GANTI KEY RESPONSE NYA JUGA
            if data.get("status") and "reply" in data:
                x = data["reply"]
                
                # Hapus bagian <think> kalo ada (biar bersih)
                if "<think>" in x and "</think>" in x:
                    x = x.split("</think>")[-1].strip()
                
                await prs.edit(f"<blockquote>{x}</blockquote>")
            else:
                await prs.edit("❌ Respons API tidak memiliki data yang diharapkan.")
        except Exception as err:
            await prs.edit(f"⚠️ Terjadi kesalahan saat memproses respons API: {err}")

    except Exception as e:
        await message.reply_text(f"⚠️ Terjadi kesalahan: {e}")