from fansx import *
import random
import asyncio
from pyrogram.enums import ChatAction
from pyrogram.types import Message

__MODULE__ = "ᴄᴇᴋ ɪɴᴛʀᴏᴠᴇʀᴛ"
__HELP__ = """
<blockquote><b>『 CEK TINGKAT INTROVERT 』</b>

<b>⌲ Perintah:</b>
ᚗ <code>{0}introvert [nama]</code> 
⊶ Mengecek seberapa introvert seseorang

<b>⌲ Contoh:</b>
<code>.introvert</code> (untuk cek diri sendiri)
<code>.introvert Budi</code> (untuk cek orang lain)
<code>.introvert @username</code></blockquote>
"""

def get_description(percent):
    """Mendapatkan deskripsi berdasarkan persentase introvert"""
    if percent >= 90:
        return "Rumah adalah surga! Stay home~ 🏠"
    elif percent >= 70:
        return "Social battery terbatas 🔋"
    elif percent >= 50:
        return "Ambivert, balance~ ⚖️"
    elif percent >= 30:
        return "Cukup social butterfly 🦋"
    else:
        return "Extrovert mode ON! 🎉"

@PY.UBOT("introvert")
async def cek_introvert(client: Client, message: Message):
    ggl = await EMO.GAGAL(client)
    sks = await EMO.BERHASIL(client)
    prs = await EMO.PROSES(client)
    
    try:
        await client.send_chat_action(message.chat.id, ChatAction.TYPING)
        
        # Ambil nama dari input atau reply
        nama = "Kamu"
        
        # Cek apakah reply ke user
        if message.reply_to_message and message.reply_to_message.from_user:
            user = message.reply_to_message.from_user
            nama = user.first_name
            if user.last_name:
                nama += f" {user.last_name}"
        
        # Cek dari argumen
        args = message.text.split(maxsplit=1)
        if len(args) > 1:
            input_nama = args[1].strip()
            
            # Cek apakah mention @username
            if input_nama.startswith('@'):
                try:
                    user = await client.get_users(input_nama)
                    nama = user.first_name
                    if user.last_name:
                        nama += f" {user.last_name}"
                except:
                    nama = input_nama
            else:
                nama = input_nama
        
        # Jika tidak ada input dan tidak reply, pakai nama sender
        elif nama == "Kamu":
            nama = message.from_user.first_name
            if message.from_user.last_name:
                nama += f" {message.from_user.last_name}"
        
        # Generate random persentase introvert
        percent = random.randint(0, 100)
        desc = get_description(percent)
        
        # Buat progress bar visual dengan emoji introvert vs extrovert
        bar_length = 20
        filled_length = int(bar_length * percent / 100)
        bar = '🏠' * filled_length + '🎉' * (bar_length - filled_length)
        
        # Kirim pesan processing dulu (biar ada efek)
        processing = await message.reply_text(f"{prs} <b>Mengecek tingkat introvert {nama}...</b>")
        
        # Tunggu bentar biar keliatan prosesnya
        await asyncio.sleep(1)
        
        # Format pesan
        txt = f"""
<blockquote><b>🏠 CEK TINGKAT INTROVERT</b>

<b>👤 Nama:</b> <code>{nama}</code>
<b>📊 Tingkat Introvert:</b> <code>{percent}%</code>

<code>{bar}</code>

<b>💬 {desc}</b></blockquote>
"""
        
        await processing.edit_text(txt)
        
    except Exception as e:
        await message.reply_text(f"{ggl} <b>Error: {str(e)[:100]}</b>")

@PY.UBOT("extrovert")
async def extrovert_alias(client: Client, message: Message):
    """Alias untuk introvert (kebalikan)"""
    await cek_introvert(client, message)

@PY.UBOT("cekintrovert")
async def cek_introvert_alias(client: Client, message: Message):
    """Alias untuk introvert"""
    await cek_introvert(client, message)

@PY.UBOT("ambivert")
async def ambivert_alias(client: Client, message: Message):
    """Alias untuk introvert"""
    await cek_introvert(client, message)

@PY.BOT("introvert")
async def cek_introvert_bot(client: Client, message: Message):
    """Handler untuk bot"""
    try:
        nama = "Kamu"
        
        if message.reply_to_message and message.reply_to_message.from_user:
            user = message.reply_to_message.from_user
            nama = user.first_name
            if user.last_name:
                nama += f" {user.last_name}"
        
        args = message.text.split(maxsplit=1)
        if len(args) > 1:
            input_nama = args[1].strip()
            if input_nama.startswith('@'):
                try:
                    user = await client.get_users(input_nama)
                    nama = user.first_name
                    if user.last_name:
                        nama += f" {user.last_name}"
                except:
                    nama = input_nama
            else:
                nama = input_nama
        
        # Generate random persentase introvert
        percent = random.randint(0, 100)
        desc = get_description(percent)
        
        # Buat progress bar sederhana
        bar_length = 15
        filled_length = int(bar_length * percent / 100)
        bar = '🏠' * filled_length + '🎉' * (bar_length - filled_length)
        
        txt = f"""
🏠 *CEK TINGKAT INTROVERT*

👤 Nama: {nama}
📊 Tingkat Introvert: {percent}%

{bar}

💬 {desc}
"""
        await message.reply_text(txt)
        
    except Exception as e:
        await message.reply_text(f"❌ Error: {str(e)[:100]}")