from fansx import *
import requests
import aiohttp
import os
import asyncio
from io import BytesIO
from PIL import Image, ImageDraw, ImageFont
from pyrogram.enums import ChatAction, ParseMode
from pyrogram.types import Message

__MODULE__ = "ꜰᴀᴋᴇ ᴍʟ"
__HELP__ = """
<blockquote><b>『 FAKE ML PROFILE 』</b>

<b>⌲ Perintah:</b>
ᚗ <code>{0}fakeml [nama]</code> 
⊶ Membuat fake profile card Mobile Legends

<b>⌲ Cara Pakai:</b>
1. Kirim foto + caption <code>.fakeml Misaki</code>
2. Reply foto dengan <code>.fakeml Misaki</code>

<b>⌲ Contoh:</b>
<code>.fakeml Misaki</code>
<code>.fakeml Alucard</code>
<code>.fakeml Layla</code></blockquote>
"""

# URL background dan frame
BG_URL = "https://cdn.gimita.id/download/liplnf_1769441635044_cf827938.jpg"
FRAME_URL = "https://cdn.gimita.id/download/2vm2lt_1769441592358_16db3286.png"

# Path font (pastikan file font ada)
FONT_PATH = "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf"  # default font
# Atau bisa pakai font custom kalo ada
# FONT_PATH = "assets/fonts/arialnarrow.ttf"

async def download_image(url):
    """Download gambar dari URL"""
    async with aiohttp.ClientSession() as session:
        async with session.get(url) as resp:
            if resp.status == 200:
                return await resp.read()
    return None

def create_ml_profile(avatar_bytes, name):
    """Membuat fake ML profile card"""
    
    # Load background dan frame
    bg_response = requests.get(BG_URL)
    bg = Image.open(BytesIO(bg_response.content)).convert("RGBA")
    
    frame_response = requests.get(FRAME_URL)
    frame = Image.open(BytesIO(frame_response.content)).convert("RGBA")
    
    # Load avatar
    avatar = Image.open(BytesIO(avatar_bytes)).convert("RGBA")
    
    # Resize avatar ke ukuran frame
    avatar_size = (205, 205)
    avatar = avatar.resize(avatar_size, Image.Resampling.LANCZOS)
    
    # Buat canvas baru
    canvas = Image.new("RGBA", bg.size, (0, 0, 0, 0))
    canvas.paste(bg, (0, 0))
    
    # Hitung posisi avatar dan frame
    frame_size = (293, 293)
    center_x = (bg.width - frame_size[0]) // 2
    center_y = (bg.height - frame_size[1]) // 2 - 282
    
    avatar_x = center_x + (frame_size[0] - avatar_size[0]) // 2
    avatar_y = center_y + (frame_size[1] - avatar_size[1]) // 2 - 3
    
    # Crop avatar menjadi lingkaran (opsional, kalo mau)
    # Buat mask lingkaran
    mask = Image.new("L", avatar_size, 0)
    draw = ImageDraw.Draw(mask)
    draw.ellipse((0, 0, avatar_size[0], avatar_size[1]), fill=255)
    
    # Terapkan mask
    circular_avatar = Image.new("RGBA", avatar_size, (0, 0, 0, 0))
    circular_avatar.paste(avatar, (0, 0), mask)
    
    # Tempel avatar dan frame
    canvas.paste(circular_avatar, (avatar_x, avatar_y), circular_avatar)
    canvas.paste(frame, (center_x, center_y), frame)
    
    # Tambah teks nama
    draw = ImageDraw.Draw(canvas)
    
    # Coba load font
    try:
        # Sesuaikan ukuran font berdasarkan panjang nama
        max_char = 11
        max_font_size = 36
        min_font_size = 24
        
        font_size = max_font_size
        if len(name) > max_char:
            excess = len(name) - max_char
            font_size -= excess * 2
            if font_size < min_font_size:
                font_size = min_font_size
        
        # Coba pakai font custom, fallback ke default
        try:
            if os.path.exists("assets/fonts/arialnarrow.ttf"):
                font = ImageFont.truetype("assets/fonts/arialnarrow.ttf", font_size)
            else:
                font = ImageFont.truetype(FONT_PATH, font_size)
        except:
            font = ImageFont.load_default()
        
        # Posisi teks
        text_x = canvas.width // 2 + 13
        text_y = center_y + frame_size[1] + 15
        
        # Buat outline teks (biar keliatan)
        outline_color = "black"
        text_color = "white"
        
        # Gambar outline
        for offset_x, offset_y in [(-2,-2), (-2,2), (2,-2), (2,2)]:
            draw.text((text_x + offset_x, text_y + offset_y), name.upper(), 
                     font=font, fill=outline_color, anchor="mm")
        
        # Gambar teks utama
        draw.text((text_x, text_y), name.upper(), font=font, fill=text_color, anchor="mm")
        
    except Exception as e:
        print(f"Error adding text: {e}")
    
    # Convert ke RGB untuk dikirim
    result = canvas.convert("RGB")
    
    # Simpan ke bytes
    img_bytes = BytesIO()
    result.save(img_bytes, format="PNG")
    img_bytes.seek(0)
    
    return img_bytes

@PY.UBOT("fakeml")
async def fake_ml(client: Client, message: Message):
    ggl = await EMO.GAGAL(client)
    sks = await EMO.BERHASIL(client)
    prs = await EMO.PROSES(client)
    
    try:
        await client.send_chat_action(message.chat.id, ChatAction.TYPING)
        
        # Ambil nama dari input
        args = message.text.split(maxsplit=1)
        if len(args) < 2:
            await message.reply_text(
                f"<blockquote><b>🎮 FAKE ML PROFILE</b>\n\n"
                f"<b>Cara pakai:</b>\n"
                f"1. Kirim foto + caption <code>.fakeml Nama</code>\n"
                f"2. Reply foto dengan <code>.fakeml Nama</code>\n\n"
                f"<b>Contoh:</b>\n"
                f"<code>.fakeml Misaki</code>\n"
                f"<code>.fakeml Alucard</code></blockquote>"
            )
            return
        
        name = args[1].strip()
        
        if not name:
            await message.reply_text(f"{ggl} <b>Masukkan nama untuk profile!</b>")
            return
        
        # Cek apakah ada gambar
        avatar_bytes = None
        file_path = None
        has_image = False
        
        # Cek reply ke gambar
        if message.reply_to_message:
            if message.reply_to_message.photo:
                has_image = True
                file_path = await message.reply_to_message.download()
            elif message.reply_to_message.sticker:
                has_image = True
                file_path = await message.reply_to_message.download()
            elif message.reply_to_message.document and message.reply_to_message.document.mime_type.startswith('image/'):
                has_image = True
                file_path = await message.reply_to_message.download()
        
        # Cek kalo pesan itu sendiri ada gambar
        elif message.photo:
            has_image = True
            file_path = await message.download()
        
        if not has_image or not file_path:
            await message.reply_text(
                f"{ggl} <b>Kirim atau reply gambar untuk dijadikan avatar!</b>"
            )
            return
        
        # Baca file gambar
        with open(file_path, 'rb') as f:
            avatar_bytes = f.read()
        
        # Hapus file sementara
        if os.path.exists(file_path):
            os.remove(file_path)
        
        # Kirim pesan processing
        processing = await message.reply_text(f"{prs} <b>Membuat Fake ML Profile...</b>")
        
        try:
            # Buat profile card
            result_img = await asyncio.get_event_loop().run_in_executor(
                None, create_ml_profile, avatar_bytes, name
            )
            
            # Kirim hasil
            await client.send_photo(
                chat_id=message.chat.id,
                photo=result_img,
                caption=f"<blockquote><b>🎮 FAKE ML PROFILE</b>\n\n"
                        f"👤 <b>Nama:</b> {name}</blockquote>"
            )
            
            await processing.delete()
            
        except Exception as e:
            await processing.edit_text(f"{ggl} <b>Error: {str(e)[:100]}</b>")
        
    except asyncio.TimeoutError:
        await message.reply_text(f"{ggl} <b>Timeout! Server sedang sibuk.</b>")
    except Exception as e:
        await message.reply_text(f"{ggl} <b>Error: {str(e)[:100]}</b>")

@PY.UBOT("mlfake")
async def mlfake_alias(client: Client, message: Message):
    """Alias untuk fakeml"""
    await fake_ml(client, message)

@PY.UBOT("mlcard")
async def mlcard_alias(client: Client, message: Message):
    """Alias untuk fakeml"""
    await fake_ml(client, message)

@PY.BOT("fakeml")
async def fake_ml_bot(client: Client, message: Message):
    """Handler untuk bot"""
    try:
        args = message.text.split(maxsplit=1)
        if len(args) < 2:
            await message.reply_text(
                "🎮 *FAKE ML PROFILE*\n\n"
                "Cara pakai:\n"
                "1. Reply foto dengan /fakeml Nama\n"
                "2. Kirim foto + caption /fakeml Nama\n\n"
                "Contoh: /fakeml Misaki"
            )
            return
        
        name = args[1].strip()
        
        # Cek apakah ada gambar
        file_path = None
        has_image = False
        
        if message.reply_to_message and message.reply_to_message.photo:
            has_image = True
            file_path = await message.reply_to_message.download()
        elif message.photo:
            has_image = True
            file_path = await message.download()
        
        if not has_image:
            await message.reply_text("❌ Kirim atau reply gambar!")
            return
        
        with open(file_path, 'rb') as f:
            avatar_bytes = f.read()
        
        if os.path.exists(file_path):
            os.remove(file_path)
        
        processing = await message.reply_text("⏳ Membuat Fake ML Profile...")
        
        try:
            result_img = await asyncio.get_event_loop().run_in_executor(
                None, create_ml_profile, avatar_bytes, name
            )
            
            await client.send_photo(
                chat_id=message.chat.id,
                photo=result_img,
                caption=f"🎮 *Fake ML Profile*\n👤 Nama: {name}"
            )
            
            await processing.delete()
            
        except Exception as e:
            await processing.edit_text(f"❌ Error: {str(e)[:100]}")
            
    except Exception as e:
        await message.reply_text(f"❌ Error: {str(e)[:100]}")