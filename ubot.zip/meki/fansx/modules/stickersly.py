from fansx import *
import aiohttp
import asyncio
import random
from urllib.parse import quote
from pyrogram.enums import ChatAction, ParseMode
from pyrogram.types import Message

__MODULE__ = "ꜱᴛɪᴄᴋᴇʀʟʏ ꜱᴇᴀʀᴄʜ"
__HELP__ = """
<blockquote><b>🎨 STICKERLY SEARCH</b>

<b>⌲ Perintah:</b>
ᚗ <code>{0}stickerly [kata kunci]</code> - Cari paket stiker
ᚗ <code>{0}stikerr</code> - Alias

<b>⌲ Contoh:</b>
<code>.stickerly WhatsApp</code>
<code>.stikerr kucing</code></blockquote>
"""

# ============================================
# KONFIGURASI
# ============================================
BASE_URL = "https://api.theresav.biz.id/search/stickerly"
API_KEY = "UYGSg"  # API Key dari contoh

async def search_stickerly(query: str):
    """Mencari paket stiker di Stickerly"""
    try:
        encoded_query = quote(query)
        url = f"{BASE_URL}?apikey={API_KEY}&q={encoded_query}"
        
        async with aiohttp.ClientSession() as session:
            async with session.get(url, timeout=15) as response:
                if response.status == 200:
                    data = await response.json()
                    
                    if data.get("status") and data.get("result"):
                        return {
                            "success": True,
                            "total": data.get("total", 0),
                            "results": data.get("result", [])
                        }
                    else:
                        return {"success": False, "error": "Tidak ada hasil"}
                else:
                    return {"success": False, "error": f"HTTP {response.status}"}
    except asyncio.TimeoutError:
        return {"success": False, "error": "Timeout"}
    except Exception as e:
        return {"success": False, "error": str(e)}

def format_number(num):
    """Format angka dengan ribuan"""
    try:
        return f"{int(num):,}".replace(",", ".")
    except:
        return str(num)

@PY.UBOT("stickerly")
@PY.UBOT("stikerr")
async def stickerly_search(client: Client, message: Message):
    ggl = await EMO.GAGAL(client)
    sks = await EMO.BERHASIL(client)
    prs = await EMO.PROSES(client)
    
    try:
        await client.send_chat_action(message.chat.id, ChatAction.TYPING)
        
        # Ambil kata kunci
        args = message.text.split(maxsplit=1)
        if len(args) < 2:
            await message.reply_text(
                f"<blockquote><b>❌ Masukkan kata kunci!</b>\n\n"
                f"<b>Contoh:</b>\n"
                f"<code>.stickerly WhatsApp</code>\n"
                f"<code>.stikerr kucing</code></blockquote>"
            )
            return
        
        query = args[1].strip()
        
        # Kirim pesan processing
        processing = await message.reply_text(f"{prs} <b>Mencari paket stiker '{query}'...</b>")
        
        # Cari di Stickerly
        result = await search_stickerly(query)
        
        if not result.get("success") or not result.get("results"):
            await processing.edit_text(
                f"<blockquote><b>❌ TIDAK ADA HASIL</b>\n\n"
                f"Kata Kunci: {query}\n"
                f"Coba kata kunci lain.</blockquote>"
            )
            return
        
        results = result.get("results", [])
        total = result.get("total", len(results))
        
        # Pilih random 1 dari hasil
        selected = random.choice(results)
        
        name = selected.get("name", "Tanpa Nama")
        author = selected.get("author", "Unknown")
        sticker_count = selected.get("stickerCount", 0)
        views = format_number(selected.get("viewCount", 0))
        exports = format_number(selected.get("exportCount", 0))
        is_animated = selected.get("isAnimated", False)
        thumbnail_url = selected.get("thumbnailUrl", "")
        sticker_url = selected.get("url", "")
        
        # Tipe stiker
        sticker_type = "🎬 Animasi" if is_animated else "🖼️ Biasa"
        
        await processing.delete()
        
        # Kirim informasi
        caption = f"""
<blockquote><b>🎨 STIKERLY PACK</b>

📌 <b>Nama:</b> {name}
👤 <b>Author:</b> {author}
📊 <b>Jumlah:</b> {sticker_count} stiker
👁️ <b>Dilihat:</b> {views}x
📥 <b>Diekspor:</b> {exports}x
🎭 <b>Tipe:</b> {sticker_type}
🔗 <b>Link:</b> <a href='{sticker_url}'>Buka di Stickerly</a>

📌 <b>Total Ditemukan:</b> {total} paket
⚡ <b>Powered by:</b> Ubot Premium Zyura</blockquote>"""
        
        # Coba kirim thumbnail
        if thumbnail_url:
            try:
                await client.send_photo(
                    chat_id=message.chat.id,
                    photo=thumbnail_url,
                    caption=caption
                )
                return
            except:
                pass
        
        # Fallback kirim teks
        await message.reply_text(caption)
        
    except Exception as e:
        await message.reply_text(f"{ggl} <b>Error: {str(e)[:100]}</b>")

