from fansx import *
import aiohttp
import asyncio
import os
import random
from urllib.parse import quote
from pyrogram.enums import ChatAction, ParseMode
from pyrogram.types import Message

__MODULE__ = "ᴡᴇʟᴄᴏᴍᴇ ᴄᴀʀᴅ ᴠ2"
__HELP__ = """
<blockquote><b>🎉 WELCOME CARD V2</b>

<b>⌲ Perintah:</b>
ᚗ <code>{0}welcome2 [nama]|[grup]|[jumlah]</code> - Format sederhana
ᚗ <code>{0}welcome2 [nama]|[grup]|[jumlah]|[avatar]|[background]|[quality]</code> - Format lengkap

<b>⌲ Parameter:</b>
• <code>nama</code> - Nama user (wajib)
• <code>grup</code> - Nama grup/server (wajib)
• <code>jumlah</code> - Jumlah anggota (wajib)
• <code>avatar</code> - URL foto profil (opsional)
• <code>background</code> - URL background (opsional)
• <code>quality</code> - Kualitas gambar 1-100 (opsional, default 90)

<b>⌲ Contoh:</b>
<code>.welcome5 Zero Two|Siputzx Community|219</code>
<code>.welcome5 Zero Two|Siputzx Community|219|https://i.ibb.co/1s8T3sY/48f7ce63c7aa.jpg|https://i.ibb.co/4YBNyvP/mountain-sunset.jpg|95</code></blockquote>
"""

# ============================================
# KONFIGURASI
# ============================================
BASE_URL = "https://api.siputzx.my.id/api/canvas/welcomev5"

# Default avatar dan background jika tidak disediakan
DEFAULT_AVATAR = "https://i.ibb.co/1s8T3sY/48f7ce63c7aa.jpg"
DEFAULT_BACKGROUND = "https://i.ibb.co/4YBNyvP/mountain-sunset.jpg"
DEFAULT_QUALITY = "90"

async def generate_welcome_card(username: str, guild_name: str, member_count: str, avatar_url: str = None, background_url: str = None, quality: str = None):
    """Generate welcome card dari API v2"""
    try:
        # Gunakan default jika tidak ada
        if not avatar_url:
            avatar_url = DEFAULT_AVATAR
        if not background_url:
            background_url = DEFAULT_BACKGROUND
        if not quality:
            quality = DEFAULT_QUALITY
        
        # Build URL dengan parameter
        params = {
            "username": quote(username),
            "guildName": quote(guild_name),
            "memberCount": str(member_count),
            "avatar": quote(avatar_url, safe=''),
            "background": quote(background_url, safe=''),
            "quality": str(quality)
        }
        
        # Build query string
        query_parts = []
        for key, value in params.items():
            query_parts.append(f"{key}={value}")
        
        url = f"{BASE_URL}?{'&'.join(query_parts)}"
        
        # Download gambar
        async with aiohttp.ClientSession() as session:
            async with session.get(url, timeout=30) as response:
                if response.status == 200:
                    return await response.read()
                else:
                    print(f"HTTP Error: {response.status}")
    except Exception as e:
        print(f"Error generate welcome card v2: {e}")
    return None

def parse_input(input_text):
    """Parse input dari user dengan format | separator"""
    parts = [p.strip() for p in input_text.split('|')]
    
    data = {
        "username": "",
        "guild_name": "",
        "member_count": "",
        "avatar_url": None,
        "background_url": None,
        "quality": None
    }
    
    if len(parts) >= 1:
        data["username"] = parts[0]
    if len(parts) >= 2:
        data["guild_name"] = parts[1]
    if len(parts) >= 3:
        data["member_count"] = parts[2]
    if len(parts) >= 4:
        data["avatar_url"] = parts[3]
    if len(parts) >= 5:
        data["background_url"] = parts[4]
    if len(parts) >= 6:
        data["quality"] = parts[5]
    
    return data

@PY.UBOT("welcome2")
async def welcome_card_v2(client: Client, message: Message):
    ggl = await EMO.GAGAL(client)
    sks = await EMO.BERHASIL(client)
    prs = await EMO.PROSES(client)
    
    try:
        await client.send_chat_action(message.chat.id, ChatAction.UPLOAD_PHOTO)
        
        # Cek apakah command tanpa argumen
        if len(message.text.split()) == 1:
            await message.reply_text(
                f"<blockquote><b>🎉 WELCOME CARD V2</b>\n\n"
                f"<b>Format sederhana:</b>\n"
                f"<code>.welcome2 nama|grup|jumlah</code>\n\n"
                f"<b>Format lengkap:</b>\n"
                f"<code>.welcome2 nama|grup|jumlah|avatar|background|quality</code>\n\n"
                f"<b>Contoh sederhana:</b>\n"
                f"<code>.welcome2 Zero Two|Siputzx Community|219</code>\n\n"
                f"<b>Contoh lengkap:</b>\n"
                f"<code>.welcome2 Zero Two|Siputzx Community|219|https://i.ibb.co/1s8T3sY/48f7ce63c7aa.jpg|https://i.ibb.co/4YBNyvP/mountain-sunset.jpg|95</code>\n\n"
                f"<b>Parameter quality:</b> 1-100 (semakin tinggi, semakin bagus kualitas)</blockquote>"
            )
            return
        
        args = message.text.split(maxsplit=1)
        input_data = args[1]
        
        # Parse data
        data = parse_input(input_data)
        
        # Validasi data wajib
        if not data["username"]:
            await message.reply_text(f"{ggl} <b>Nama user tidak boleh kosong!</b>")
            return
        if not data["guild_name"]:
            await message.reply_text(f"{ggl} <b>Nama grup tidak boleh kosong!</b>")
            return
        if not data["member_count"]:
            await message.reply_text(f"{ggl} <b>Jumlah anggota tidak boleh kosong!</b>")
            return
        
        # Validasi member count (harus angka)
        try:
            int(data["member_count"])
        except ValueError:
            await message.reply_text(f"{ggl} <b>Jumlah anggota harus berupa angka!</b>")
            return
        
        # Validasi quality jika ada
        if data["quality"]:
            try:
                q = int(data["quality"])
                if q < 1 or q > 100:
                    await message.reply_text(f"{ggl} <b>Quality harus antara 1-100!</b>")
                    return
            except ValueError:
                await message.reply_text(f"{ggl} <b>Quality harus berupa angka!</b>")
                return
        
        # Kirim processing
        processing = await message.reply_text(
            f"{prs} <b>Membuat welcome card V2...</b>\n"
            f"👤 Nama: {data['username']}\n"
            f"👥 Grup: {data['guild_name']}\n"
            f"📊 Anggota: {data['member_count']}"
        )
        
        # Generate gambar
        image_data = await generate_welcome_card(
            data["username"],
            data["guild_name"],
            data["member_count"],
            data["avatar_url"],
            data["background_url"],
            data["quality"]
        )
        
        if not image_data:
            await processing.edit_text(f"{ggl} <b>Gagal membuat welcome card!</b>")
            return
        
        # Simpan sementara
        file_path = f"welcome5_{message.from_user.id}_{random.randint(1000,9999)}.jpg"
        with open(file_path, 'wb') as f:
            f.write(image_data)
        
        await processing.delete()
        
        # Kirim foto
        quality_info = f", Kualitas: {data['quality']}" if data['quality'] else ""
        await client.send_photo(
            chat_id=message.chat.id,
            photo=file_path,
            caption=f"<blockquote><b>🎉 WELCOME CARD V2</b>\n\n"
                    f"👤 <b>User:</b> {data['username']}\n"
                    f"👥 <b>Grup:</b> {data['guild_name']}\n"
                    f"📊 <b>Anggota ke-:</b> {data['member_count']}{quality_info}</blockquote>"
        )
        
        # Hapus file
        import os
        if os.path.exists(file_path):
            os.remove(file_path)
        
    except Exception as e:
        await message.reply_text(f"{ggl} <b>Error: {str(e)[:100]}</b>")

