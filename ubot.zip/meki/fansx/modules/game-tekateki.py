from fansx import *
import aiohttp
import asyncio
import random
import json
import os
from datetime import datetime
from pyrogram.enums import ChatAction, ParseMode
from pyrogram.types import Message

__MODULE__ = "ᴛᴇᴋᴀ ᴛᴇᴋɪ"
__HELP__ = """
<blockquote><b>🎯 GAME: TEKA TEKI</b>

<b>⌲ Perintah:</b>
ᚗ <code>{0}tekateki</code> - Mulai game baru
ᚗ <code>{0}tt</code> - Mulai game (singkatan)
ᚗ <code>{0}jawabtt [jawaban]</code> - Jawab teka teki
ᚗ <code>{0}skiptt</code> - Lewati pertanyaan
ᚗ <code>{0}skortt</code> - Lihat papan peringkat

<b>⌲ Cara main:</b>
1. Ketik <code>.tekateki</code> untuk mulai
2. Bot kasih teka teki lucu
3. Ketik <code>.jawabtt [jawabanmu]</code>
4. Bot kasih tau bener atau salah
5. Dapet skor kalo bener!

<b>⌲ Contoh:</b>
<code>.tekateki</code>
<code>.jawabtt bunga bank</code>
<code>.jawabtt anak tangga</code></blockquote>
"""

# ============================================
# KONFIGURASI
# ============================================
API_URL = "https://api.deline.web.id/game/tekateki"

# Database untuk menyimpan state game per user
game_sessions = {}
leaderboard = {}

async def get_question():
    """Ambil teka teki dari API"""
    try:
        async with aiohttp.ClientSession() as session:
            async with session.get(API_URL, timeout=10) as response:
                if response.status == 200:
                    data = await response.json()
                    if data.get("status") and data.get("result"):
                        result = data["result"]
                        return {
                            "question": result.get("soal", ""),
                            "answer": result.get("jawaban", "").strip().lower()
                        }
    except Exception as e:
        print(f"Error get question: {e}")
    return None

def normalize_answer(answer):
    """Normalisasi jawaban"""
    return " ".join(answer.lower().split())

@PY.UBOT("tekateki")
@PY.UBOT("tt")
async def start_game(client: Client, message: Message):
    ggl = await EMO.GAGAL(client)
    prs = await EMO.PROSES(client)
    
    user_id = message.from_user.id
    user_name = message.from_user.first_name
    
    try:
        await client.send_chat_action(message.chat.id, ChatAction.TYPING)
        
        processing = await message.reply_text(f"{prs} <b>Menyiapkan teka teki...</b>")
        
        question_data = await get_question()
        
        if not question_data:
            await processing.edit_text(f"{ggl} <b>Gagal mengambil teka teki!</b>")
            return
        
        question = question_data["question"]
        answer = question_data["answer"]
        
        game_sessions[user_id] = {
            "question": question,
            "answer": answer,
            "start_time": datetime.now(),
            "attempts": 0
        }
        
        await processing.delete()
        
        await message.reply_text(
            f"<blockquote><b>🎯 TEKA TEKI</b>\n\n"
            f"<b>Soal:</b>\n<code>{question}</code>\n\n"
            f"<b>Jawab:</b> <code>.jawabtt [jawaban]</code>\n"
            f"<b>Lewati:</b> <code>.skiptt</code></blockquote>"
        )
        
    except Exception as e:
        await message.reply_text(f"{ggl} <b>Error: {str(e)[:100]}</b>")

@PY.UBOT("jawabtt")
async def answer_game(client: Client, message: Message):
    ggl = await EMO.GAGAL(client)
    sks = await EMO.BERHASIL(client)
    
    user_id = message.from_user.id
    user_name = message.from_user.first_name
    
    try:
        if user_id not in game_sessions:
            await message.reply_text(
                f"{ggl} <b>Ketik .tekateki dulu!</b>"
            )
            return
        
        args = message.text.split(maxsplit=1)
        if len(args) < 2:
            await message.reply_text(
                f"{ggl} <b>Contoh: .jawabtt bunga bank</b>"
            )
            return
        
        user_answer = normalize_answer(args[1])
        correct_answer = game_sessions[user_id]["answer"]
        attempts = game_sessions[user_id]["attempts"] + 1
        game_sessions[user_id]["attempts"] = attempts
        question = game_sessions[user_id]["question"]
        
        # Cek jawaban (bisa exact match atau kata kunci)
        is_correct = False
        if user_answer == correct_answer:
            is_correct = True
        elif len(user_answer) > 3 and user_answer in correct_answer:
            is_correct = True
        elif len(correct_answer) > 3 and correct_answer in user_answer:
            is_correct = True
        
        if is_correct:
            # Skor berdasarkan kesempatan
            score = max(10 - (attempts - 1) * 2, 1)
            
            # Update leaderboard
            if user_id in leaderboard:
                leaderboard[user_id]["score"] += score
                leaderboard[user_id]["correct"] += 1
            else:
                leaderboard[user_id] = {
                    "name": user_name,
                    "score": score,
                    "correct": 1,
                    "total": 0
                }
            
            leaderboard[user_id]["total"] = leaderboard[user_id].get("total", 0) + 1
            
            del game_sessions[user_id]
            
            await message.reply_text(
                f"<blockquote><b>✅ BENAR!</b>\n\n"
                f"📝 <b>Teka teki:</b> <code>{question}</code>\n"
                f"⭐ Skor: +{score}\n"
                f"🏆 Total: {leaderboard[user_id]['score']}\n"
                f"📈 Benar: {leaderboard[user_id]['correct']}/{leaderboard[user_id]['total']}\n\n"
                f"Main lagi: <code>.tekateki</code></blockquote>"
            )
        else:
            if attempts >= 3:
                await message.reply_text(
                    f"<blockquote><b>❌ GAME OVER</b>\n\n"
                    f"📝 <b>Teka teki:</b> <code>{question}</code>\n"
                    f"Jawaban: <b>{correct_answer.title()}</b>\n\n"
                    f"Main lagi: <code>.tekateki</code></blockquote>"
                )
                
                # Update total tapi ga dapet skor
                if user_id in leaderboard:
                    leaderboard[user_id]["total"] = leaderboard[user_id].get("total", 0) + 1
                else:
                    leaderboard[user_id] = {
                        "name": user_name,
                        "score": 0,
                        "correct": 0,
                        "total": 1
                    }
                
                del game_sessions[user_id]
            else:
                await message.reply_text(
                    f"<blockquote><b>❌ SALAH</b>\n\n"
                    f"📝 Percobaan: {attempts}/3\n\n"
                    f"Coba lagi: <code>.jawabtt [jawaban]</code></blockquote>"
                )
        
    except Exception as e:
        await message.reply_text(f"{ggl} <b>Error: {str(e)[:100]}</b>")

@PY.UBOT("skiptt")
async def skip_question(client: Client, message: Message):
    ggl = await EMO.GAGAL(client)
    
    user_id = message.from_user.id
    user_name = message.from_user.first_name
    
    if user_id in game_sessions:
        answer = game_sessions[user_id]["answer"]
        question = game_sessions[user_id]["question"]
        
        # Update total tapi ga dapet skor
        if user_id in leaderboard:
            leaderboard[user_id]["total"] = leaderboard[user_id].get("total", 0) + 1
        else:
            leaderboard[user_id] = {
                "name": user_name,
                "score": 0,
                "correct": 0,
                "total": 1
            }
        
        await message.reply_text(
            f"<blockquote><b>⏭️ SKIP</b>\n\n"
            f"📝 <b>Teka teki:</b> <code>{question}</code>\n"
            f"Jawaban: <b>{answer.title()}</b>\n\n"
            f"Main baru: <code>.tekateki</code></blockquote>"
        )
        del game_sessions[user_id]
    else:
        await message.reply_text(f"{ggl} <b>Belum mulai game!</b>")

@PY.UBOT("skortt")
async def show_leaderboard(client: Client, message: Message):
    """Tampilkan papan peringkat teka teki"""
    
    if not leaderboard:
        await message.reply_text(
            "<blockquote><b>🏆 LEADERBOARD TEKA TEKI</b>\n\n"
            "Belum ada skor. Ayo main <code>.tekateki</code> dulu!</blockquote>"
        )
        return
    
    # Urutkan berdasarkan skor tertinggi
    sorted_users = sorted(leaderboard.items(), key=lambda x: x[1]["score"], reverse=True)
    
    text = "<blockquote><b>🏆 LEADERBOARD TEKA TEKI</b>\n\n"
    
    for i, (user_id, data) in enumerate(sorted_users[:10], 1):
        medal = "🥇" if i == 1 else "🥈" if i == 2 else "🥉" if i == 3 else f"{i}."
        
        # Hitung akurasi
        if data["total"] > 0:
            accuracy = (data["correct"] / data["total"]) * 100
        else:
            accuracy = 0
            
        text += f"{medal} <b>{data['name']}</b>\n"
        text += f"   ⭐ {data['score']} poin | 📊 {accuracy:.1f}%\n"
    
    text += "\nMain: <code>.tekateki</code></blockquote>"
    
    await message.reply_text(text)

@PY.UBOT("infott")
async def game_info(client: Client, message: Message):
    """Info tentang game teka teki"""
    
    text = """
<blockquote><b>🎯 INFO GAME TEKA TEKI</b>

<b>Cara main:</b>
• <code>.tekateki</code> - Mulai game
• <code>.jawabtt [jawaban]</code> - Jawab teka teki
• <code>.skiptt</code> - Lewati soal
• <code>.skortt</code> - Lihat peringkat

<b>Aturan:</b>
• 3x kesempatan menjawab per soal
• Skor berkurang jika salah menjawab
• Makin cepat jawab, makin tinggi skor
• Jawaban tidak case sensitive
• Bisa pakai kata kunci

<b>Skor:</b>
• Percobaan 1: +10 poin
• Percobaan 2: +8 poin
• Percobaan 3: +6 poin
• Salah 3x: 0 poin</blockquote>"""
    
    await message.reply_text(text)