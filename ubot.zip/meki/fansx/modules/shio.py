import requests
import random
from fansx import *

# Daftar API keys By Zyura (12 key)
API_KEYS = [
    "eIxUwMpn",
    "keoCFdc6",
    "bv7m372F",
    "iAiB9QKT",
    "JP7Cy8Y2",
    "GI4vPxYv",
    "HRPga9TN",
    "PDwqhVsj",
    "m8jpBeZR",
    "PXkxh5hw",
    "MFnlpM6A",
    "u299UiOF"
]

def get_random_apikey():
    """Mengambil API key secara random dari daftar"""
    return random.choice(API_KEYS)

__MODULE__ = "sʜɪᴏ"
__HELP__ = """
<b>⦪ ʙᴀɴᴛᴜᴀɴ ᴜɴᴛᴜᴋ sʜɪᴏ ⦫</b>

<blockquote><b>⎆ ᴘᴇʀɪɴᴛᴀʜ :
ᚗ <code>{0}shio</code> [shio] [tanggal] [bulan] [tahun]

⌭ ᴘᴇɴᴊᴇʟᴀsᴀɴ:
ᚗ meramal shio berdasarkan tanggal lahir

📌 Daftar shio:
tikus, kerbau, macan, kelinci, naga, ular, kuda, kambing, monyet, ayam, anjing, babi

📌 Contoh:
<code>.shio naga 12 5 1990</code>
<code>.shio macan 25 8 2000</code></blockquote>
"""

@PY.UBOT("shio")
async def get_shio(client, message):
    args = message.text.split()
    if len(args) < 5:
        daftar_shio = "tikus, kerbau, macan, kelinci, naga, ular, kuda, kambing, monyet, ayam, anjing, babi"
        return await message.reply_text(
            f"<blockquote><b>❌ Format salah!</b>\n\n"
            f"<b>Gunakan format:</b>\n"
            f"<code>.shio [shio] [tanggal] [bulan] [tahun]</code>\n\n"
            f"<b>Contoh:</b>\n"
            f"<code>.shio naga 12 5 1990</code>\n"
            f"<code>.shio macan 25 8 2000</code>\n\n"
            f"<b>Daftar shio:</b>\n{daftar_shio}</blockquote>"
        )

    shio, tanggal, bulan, tahun = args[1].lower(), args[2], args[3], args[4]
    
    # Validasi input angka
    if not (tanggal.isdigit() and bulan.isdigit() and tahun.isdigit()):
        return await message.reply_text(
            "<blockquote><b>❌ Tanggal, bulan, dan tahun harus berupa angka!</b></blockquote>"
        )
    
    # Validasi shio
    shio_list = ["tikus", "kerbau", "macan", "kelinci", "naga", "ular", "kuda", "kambing", "monyet", "ayam", "anjing", "babi"]
    if shio not in shio_list:
        return await message.reply_text(
            f"<blockquote><b>❌ Shio tidak valid!</b>\n\n"
            f"<b>Daftar shio:</b>\n{', '.join(shio_list)}</blockquote>"
        )
    
    # Kirim pesan processing
    prs = await message.reply_text(
        f"<blockquote><b>🔮 Meramal shio {shio} untuk {tanggal}-{bulan}-{tahun}...</b></blockquote>"
    )
    
    # Coba dengan beberapa API key
    success = False
    used_keys = set()
    max_attempts = min(3, len(API_KEYS))
    
    for attempt in range(max_attempts):
        available_keys = [key for key in API_KEYS if key not in used_keys]
        if not available_keys:
            break
            
        apikey = random.choice(available_keys)
        used_keys.add(apikey)
        
        try:
            # Buat URL API dengan key random
            API_URL = f"https://api.botcahx.eu.org/api/primbon/shio?shio={shio}&tanggal={tanggal}&bulan={bulan}&tahun={tahun}&apikey={apikey}"
            
            response = requests.get(API_URL, timeout=10)
            
            if response.status_code == 200:
                data = response.json()
                
                # Cek status response
                if data.get("status") and data.get("result", {}).get("status"):
                    result = data["result"]["message"]
                    nama = result.get("nama", shio.title())
                    arti = result.get("arti", "Tidak ada arti")
                    
                    # Buat teks balasan
                    reply_text = (
                        f"<blockquote><emoji id=6026321200597176575>🃏</emoji> <b>RAMALAN SHIO</b> <emoji id=6026321200597176575>🃏</emoji>\n"
                        f"━━━━━━━━━━━━━━━━━━\n"
                        f"<emoji id=5470088387048266598>🐉</emoji> <b>Shio:</b> <code>{nama}</code>\n"
                        f"<emoji id=5251537301154062376>📆</emoji> <b>Tanggal Lahir:</b> <code>{tanggal}-{bulan}-{tahun}</code>\n"
                        f"━━━━━━━━━━━━━━━━━━\n"
                        f"<emoji id=5226512880362332956>📖</emoji> <b>Arti:</b>\n"
                        f"<code>{arti}</code>\n"
                        f"━━━━━━━━━━━━━━━━━━\n"
                        f"🔑 <b>Key:</b> <code>{apikey[:8]}...</code>\n"
                        f"<emoji id=5080240441882838117>😎</emoji> Semoga harimu menyenangkan! <emoji id=5080240441882838117>😎</emoji></blockquote>"
                    )
                    
                    await prs.edit(reply_text, disable_web_page_preview=True)
                    success = True
                    break
                else:
                    # Jika data tidak ditemukan, coba dengan key lain
                    continue
            else:
                # Jika status code error, coba dengan key lain
                continue
                
        except requests.exceptions.Timeout:
            continue
        except requests.exceptions.ConnectionError:
            continue
        except Exception as e:
            print(f"Error attempt {attempt+1}: {str(e)}")
            continue
    
    if not success:
        await prs.edit(
            "<blockquote><b>❌ Gagal mendapatkan ramalan shio!</b>\n\n"
            "🔴 Kemungkinan penyebab:\n"
            "• Data tidak ditemukan\n"
            "• API key habis limit\n"
            "• Server sedang sibuk\n\n"
            "🔄 Silakan coba lagi nanti dengan data yang berbeda.</blockquote>"
        )

@PY.BOT("shio")
async def get_shio_bot(client, message):
    args = message.text.split()
    if len(args) < 5:
        return await message.reply_text(
            "❌ Gunakan format: /shio [shio] [tanggal] [bulan] [tahun]\n"
            "Contoh: /shio naga 12 5 1990"
        )

    shio, tanggal, bulan, tahun = args[1].lower(), args[2], args[3], args[4]
    
    prs = await message.reply_text(f"🔮 Meramal shio {shio}...")
    
    # Coba dengan beberapa API key
    success = False
    used_keys = set()
    max_attempts = min(3, len(API_KEYS))
    
    for attempt in range(max_attempts):
        available_keys = [key for key in API_KEYS if key not in used_keys]
        if not available_keys:
            break
            
        apikey = random.choice(available_keys)
        used_keys.add(apikey)
        
        try:
            API_URL = f"https://api.botcahx.eu.org/api/primbon/shio?shio={shio}&tanggal={tanggal}&bulan={bulan}&tahun={tahun}&apikey={apikey}"
            
            response = requests.get(API_URL, timeout=10)
            
            if response.status_code == 200:
                data = response.json()
                
                if data.get("status") and data.get("result", {}).get("status"):
                    result = data["result"]["message"]
                    nama = result.get("nama", shio.title())
                    arti = result.get("arti", "Tidak ada arti")
                    
                    reply_text = f"""
<b>🃏 RAMALAN SHIO 🃏</b>

🐉 <b>Shio:</b> {nama}
📆 <b>Tanggal:</b> {tanggal}-{bulan}-{tahun}

📖 <b>Arti:</b>
{arti}
"""
                    
                    await prs.edit(reply_text)
                    success = True
                    break
                else:
                    continue
            else:
                continue
                
        except Exception:
            continue
    
    if not success:
        await prs.edit("❌ Gagal mendapatkan ramalan shio.")