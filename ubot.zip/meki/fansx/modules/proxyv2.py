from fansx import *
import aiohttp
import asyncio
import json
from urllib.parse import quote
from pyrogram.enums import ChatAction, ParseMode
from pyrogram.types import Message

__MODULE__ = "ᴘʀᴏxʏ ᴠ2"
__HELP__ = """
<blockquote><b>🌐 PROXY V2 - INFO SERVER</b>

<b>⌲ Perintah:</b>
ᚗ <code>{0}proxy [url]</code> - Cek URL via proxy server
ᚗ <code>{0}proxyserver</code> - Info server proxy
ᚗ <code>{0}proxycheck</code> - Cek lokasi server proxy

<b>⌲ Contoh:</b>
<code>.proxy https://ipwho.is/?lang=id-ID&region=fr</code>
<code>.proxyserver</code>
<code>.proxycheck</code>

<b>⌲ Catatan:</b>
• Proxy server di Eropa (Scaleway)
• Menampilkan info server & konten</blockquote>
"""

# ============================================
# KONFIGURASI
# ============================================
BASE_URL = "https://api.vreden.my.id/api/v1/tools/proxy"

async def proxy_request(url: str):
    """Request URL via proxy"""
    try:
        # Encode URL
        encoded_url = quote(url, safe='')
        
        async with aiohttp.ClientSession() as session:
            async with session.get(f"{BASE_URL}?url={encoded_url}", timeout=30) as response:
                if response.status == 200:
                    data = await response.json()
                    if data.get("status") and data.get("result"):
                        return data["result"]
    except Exception as e:
        print(f"Error proxy request: {e}")
    return None

@PY.UBOT("proxy")
async def proxy_command(client: Client, message: Message):
    ggl = await EMO.GAGAL(client)
    prs = await EMO.PROSES(client)
    
    try:
        await client.send_chat_action(message.chat.id, ChatAction.TYPING)
        
        args = message.text.split(maxsplit=1)
        if len(args) < 2:
            await message.reply_text(
                f"<blockquote><b>❌ Masukkan URL!</b>\n\n"
                f"<b>Contoh:</b>\n"
                f"<code>.proxy https://ipwho.is/?lang=id-ID&region=fr</code>\n"
                f"<code>.proxy https://api.ipify.org</code></blockquote>"
            )
            return
        
        target_url = args[1].strip()
        
        processing = await message.reply_text(f"{prs} <b>Mengakses {target_url} via proxy...</b>")
        
        result = await proxy_request(target_url)
        
        if not result:
            await processing.edit_text(f"{ggl} <b>Gagal mengakses URL!</b>")
            return
        
        await processing.delete()
        
        # Info server proxy
        server = result.get("server", {})
        server_location = server.get("location", "Unknown")
        server_country = server.get("country", "Unknown")
        server_city = server.get("city", "Unknown")
        server_isp = server.get("connection", {}).get("isp", "Unknown")
        
        # Info konten
        content = result.get("content", {})
        http_code = result.get("http_code", 0)
        
        # Format response
        text = f"""
<blockquote><b>🌐 PROXY RESPONSE</b>

<b>🖥️ SERVER PROXY:</b>
• Lokasi: {server_location}
• Negara: {server_country} ({server_city})
• ISP: {server_isp}

<b>📊 HTTP STATUS:</b> {http_code}

<b>🔍 URL TARGET:</b>
<code>{target_url[:100]}{'...' if len(target_url) > 100 else ''}</code>

<b>📦 HASIL:</b>"""
        
        # Cek tipe konten
        if isinstance(content, dict):
            # Tampilkan info IP dll
            if "ip" in content:
                text += f"\n• IP: <code>{content.get('ip')}</code>"
            if "country" in content:
                flag = content.get("flag", {}).get("emoji", "")
                text += f"\n• Negara: {flag} {content.get('country')}"
            if "city" in content:
                text += f"\n• Kota: {content.get('city')}"
            if "region" in content:
                text += f"\n• Region: {content.get('region')}"
            if "postal" in content:
                text += f"\n• Postal: {content.get('postal')}"
            if "latitude" in content and "longitude" in content:
                text += f"\n• Koordinat: {content.get('latitude')}, {content.get('longitude')}"
            if "timezone" in content:
                tz = content.get("timezone", {})
                text += f"\n• Timezone: {tz.get('id')} ({tz.get('abbr')})"
            if "calling_code" in content:
                text += f"\n• Kode Telepon: +{content.get('calling_code')}"
        else:
            # Tampilkan sebagai teks biasa (dipotong)
            content_str = str(content)[:200]
            text += f"\n<code>{content_str}{'...' if len(str(content)) > 200 else ''}</code>"
        
        text += "\n\n📌 <b>Proxy server di Eropa (Scaleway)</b></blockquote>"
        
        await message.reply_text(text)
        
    except Exception as e:
        await message.reply_text(f"{ggl} <b>Error: {str(e)[:100]}</b>")

@PY.UBOT("proxyserver")
async def proxy_server_info(client: Client, message: Message):
    """Info server proxy"""
    ggl = await EMO.GAGAL(client)
    prs = await EMO.PROSES(client)
    
    try:
        processing = await message.reply_text(f"{prs} <b>Mengambil info server proxy...</b>")
        
        # Test dengan URL sederhana
        result = await proxy_request("https://api.ipify.org")
        
        if not result:
            await processing.edit_text(f"{ggl} <b>Gagal mengambil info server!</b>")
            return
        
        server = result.get("server", {})
        
        server_location = server.get("location", "Unknown")
        server_country = server.get("country", "Unknown")
        server_country_code = server.get("country_code", "")
        server_region = server.get("region", "")
        server_city = server.get("city", "")
        server_lat = server.get("latitude", "")
        server_lon = server.get("longitude", "")
        server_isp = server.get("connection", {}).get("isp", "Unknown")
        server_asn = server.get("connection", {}).get("asn", "Unknown")
        server_org = server.get("connection", {}).get("org", "Unknown")
        
        text = f"""
<blockquote><b>🖥️ INFO SERVER PROXY</b>

<b>📍 Lokasi:</b> {server_location}
<b>🌍 Negara:</b> {server_country} ({server_country_code})
<b>🏙️ Kota:</b> {server_city}, {server_region}
<b>🗺️ Koordinat:</b> {server_lat}, {server_lon}

<b>🔌 Koneksi:</b>
• ISP: {server_isp}
• ASN: {server_asn}
• Organisasi: {server_org}

<b>🌐 Lokasi server di Eropa (Scaleway)</b>
<b>💡 Gunakan:</b> <code>.proxy [url]</code></blockquote>"""
        
        await processing.delete()
        await message.reply_text(text)
        
    except Exception as e:
        await message.reply_text(f"{ggl} <b>Error: {str(e)[:100]}</b>")

@PY.UBOT("proxycheck")
async def proxy_check(client: Client, message: Message):
    """Cek IP server proxy"""
    await proxy_server_info(client, message)

@PY.UBOT("proxyinfo")
async def proxy_info(client: Client, message: Message):
    """Info fitur proxy"""
    
    text = """
<blockquote><b>🌐 INFO PROXY V2</b>

<b>Sumber:</b> api.vreden.my.id
<b>Server:</b> Scaleway (Eropa)
<b>Lokasi:</b> Paris, Prancis

<b>Fitur:</b>
• Akses URL via proxy
• Lihat info server proxy
• Cek IP proxy
• Aman & cepat

<b>Cara pakai:</b>
1. <code>.proxy [url]</code> - Akses URL via proxy
2. <code>.proxyserver</code> - Info server proxy
3. <code>.proxycheck</code> - Cek IP proxy

<b>Contoh:</b>
<code>.proxy https://ipwho.is/</code>
<code>.proxy https://api.ipify.org</code>
<code>.proxyserver</code></blockquote>"""
    
    await message.reply_text(text)