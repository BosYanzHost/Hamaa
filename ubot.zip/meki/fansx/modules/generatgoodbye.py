from fansx import *
import aiohttp
import asyncio
import os
import random
import re
from urllib.parse import quote
from pyrogram.enums import ChatAction, ParseMode
from pyrogram.types import Message

__MODULE__ = "ɢᴏᴏᴅʙʏᴇ ᴄᴀʀᴅ"
__HELP__ = """
<blockquote><b>👋 GOODBYE CARD</b>

<b>⌲ Perintah:</b>
ᚗ <code>{0}goodbye [avatar]|[background]|[title]|[description]|[border]|[avatarBorder]|[opacity]</code>

<b>⌲ Parameter:</b>
• <code>avatar</code> - URL foto profil (wajib)
• <code>background</code> - URL background (wajib)
• <code>title</code> - Judul card (opsional, default: "goodbye")
• <code>description</code> - Deskripsi (opsional, default: "goodbye to the server!")
• <code>border</code> - Warna border (opsional, format HEX #RRGGBB, default: "#2a2e35")
• <code>avatarBorder</code> - Warna border avatar (opsional, format HEX #RRGGBB, default: "#2a2e35")
• <code>opacity</code> - Opasitas overlay 0.0-1.0 (opsional, default: 0.3)

<b>⌲ Contoh:</b>
<code>.goodbye https://i.ibb.co/1s8T3sY/48f7ce63c7aa.jpg|https://i.ibb.co/4YBNyvP/images-76.jpg|goodbye|goodbye to the server|#2a2e35|#2a2e35|0.3</code></blockquote>
"""

# ============================================
# KONFIGURASI
# ============================================
BASE_URL = "https://api.siputzx.my.id/api/canvas/goodbyev4"

# Default values
DEFAULT_TITLE = "goodbye"
DEFAULT_DESCRIPTION = "goodbye to the server!"
DEFAULT_BORDER = "#2a2e35"
DEFAULT_AVATAR_BORDER = "#2a2e35"
DEFAULT_OPACITY = "0.3"

def validate_hex_color(color):
    """Validasi format HEX color (#RRGGBB)"""
    if not color:
        return False
    return bool(re.match(r'^#[0-9A-Fa-f]{6}$', color))

def validate_opacity(opacity):
    """Validasi opacity (0.0 - 1.0)"""
    try:
        o = float(opacity)
        return 0.0 <= o <= 1.0
    except:
        return False

async def generate_goodbye_card(avatar_url: str, background_url: str, title: str = None, description: str = None, border: str = None, avatar_border: str = None, opacity: str = None):
    """Generate goodbye card dari API v4"""
    try:
        # Gunakan default jika tidak ada
        if not title:
            title = DEFAULT_TITLE
        if not description:
            description = DEFAULT_DESCRIPTION
        if not border:
            border = DEFAULT_BORDER
        if not avatar_border:
            avatar_border = DEFAULT_AVATAR_BORDER
        if not opacity:
            opacity = DEFAULT_OPACITY
        
        # Build URL dengan parameter
        params = {
            "avatar": quote(avatar_url, safe=''),
            "background": quote(background_url, safe=''),
            "title": quote(title),
            "description": quote(description),
            "border": quote(border),
            "avatarBorder": quote(avatar_border),
            "overlayOpacity": str(opacity)
        }
        
        # Build query string
        query_parts = []
        for key, value in params.items():
            query_parts.append(f"{key}={value}")
        
        url = f"{BASE_URL}?{'&'.join(query_parts)}"
        
        # Download gambar
        async with aiohttp.ClientSession() as session:
            async with session.get(url, timeout=30) as response:
                if response.status == 200:
                    return await response.read()
                else:
                    print(f"HTTP Error: {response.status}")
    except Exception as e:
        print(f"Error generate goodbye card: {e}")
    return None

def parse_input(input_text):
    """Parse input dari user dengan format | separator"""
    parts = [p.strip() for p in input_text.split('|')]
    
    data = {
        "avatar_url": None,
        "background_url": None,
        "title": None,
        "description": None,
        "border": None,
        "avatar_border": None,
        "opacity": None
    }
    
    if len(parts) >= 1:
        data["avatar_url"] = parts[0]
    if len(parts) >= 2:
        data["background_url"] = parts[1]
    if len(parts) >= 3:
        data["title"] = parts[2]
    if len(parts) >= 4:
        data["description"] = parts[3]
    if len(parts) >= 5:
        data["border"] = parts[4]
    if len(parts) >= 6:
        data["avatar_border"] = parts[5]
    if len(parts) >= 7:
        data["opacity"] = parts[6]
    
    return data

@PY.UBOT("goodbye")
async def goodbye_card_v4(client: Client, message: Message):
    ggl = await EMO.GAGAL(client)
    sks = await EMO.BERHASIL(client)
    prs = await EMO.PROSES(client)
    
    try:
        await client.send_chat_action(message.chat.id, ChatAction.UPLOAD_PHOTO)
        
        # Cek apakah command tanpa argumen
        if len(message.text.split()) == 1:
            await message.reply_text(
                f"<blockquote><b>👋 GOODBYE CARD V4</b>\n\n"
                f"<b>Format:</b>\n"
                f"<code>.goodbye avatar|background|title|description|border|avatarBorder|opacity</code>\n\n"
                f"<b>Parameter wajib:</b> avatar, background\n"
                f"<b>Parameter opsional:</b> title, description, border, avatarBorder, opacity\n\n"
                f"<b>Contoh minimal:</b>\n"
                f"<code>.goodbye https://i.ibb.co/1s8T3sY/48f7ce63c7aa.jpg|https://i.ibb.co/4YBNyvP/images-76.jpg</code>\n\n"
                f"<b>Contoh lengkap:</b>\n"
                f"<code>.goodbye https://i.ibb.co/1s8T3sY/48f7ce63c7aa.jpg|https://i.ibb.co/4YBNyvP/images-76.jpg|goodbye|goodbye to the server|#2a2e35|#2a2e35|0.3</code>\n\n"
                f"<b>Default values:</b>\n"
                f"• title: goodbye\n"
                f"• description: goodbye to the server!\n"
                f"• border: #2a2e35\n"
                f"• avatarBorder: #2a2e35\n"
                f"• opacity: 0.3</blockquote>"
            )
            return
        
        args = message.text.split(maxsplit=1)
        input_data = args[1]
        
        # Parse data
        data = parse_input(input_data)
        
        # Validasi data wajib
        if not data["avatar_url"]:
            await message.reply_text(f"{ggl} <b>URL avatar tidak boleh kosong!</b>")
            return
        if not data["background_url"]:
            await message.reply_text(f"{ggl} <b>URL background tidak boleh kosong!</b>")
            return
        
        # Validasi warna jika ada
        if data["border"] and not validate_hex_color(data["border"]):
            await message.reply_text(f"{ggl} <b>Format border tidak valid! Gunakan format HEX #RRGGBB</b>")
            return
        
        if data["avatar_border"] and not validate_hex_color(data["avatar_border"]):
            await message.reply_text(f"{ggl} <b>Format avatarBorder tidak valid! Gunakan format HEX #RRGGBB</b>")
            return
        
        # Validasi opacity jika ada
        if data["opacity"] and not validate_opacity(data["opacity"]):
            await message.reply_text(f"{ggl} <b>Opacity harus antara 0.0 - 1.0!</b>")
            return
        
        # Kirim processing
        processing = await message.reply_text(
            f"{prs} <b>Membuat goodbye card...</b>\n"
            f"🖼️ Avatar: {data['avatar_url'][:50]}...\n"
            f"🏞️ Background: {data['background_url'][:50]}..."
        )
        
        # Generate gambar
        image_data = await generate_goodbye_card(
            data["avatar_url"],
            data["background_url"],
            data["title"],
            data["description"],
            data["border"],
            data["avatar_border"],
            data["opacity"]
        )
        
        if not image_data:
            await processing.edit_text(f"{ggl} <b>Gagal membuat goodbye card!</b>")
            return
        
        # Simpan sementara
        file_path = f"goodbye_{message.from_user.id}_{random.randint(1000,9999)}.jpg"
        with open(file_path, 'wb') as f:
            f.write(image_data)
        
        await processing.delete()
        
        # Kirim foto
        await client.send_photo(
            chat_id=message.chat.id,
            photo=file_path,
            caption=f"<blockquote><b>👋 GOODBYE CARD</b>\n\n"
                    f"📝 <b>Title:</b> {data['title'] or DEFAULT_TITLE}\n"
                    f"💬 <b>Description:</b> {data['description'] or DEFAULT_DESCRIPTION}</blockquote>"
        )
        
        # Hapus file
        import os
        if os.path.exists(file_path):
            os.remove(file_path)
        
    except Exception as e:
        await message.reply_text(f"{ggl} <b>Error: {str(e)[:100]}</b>")

