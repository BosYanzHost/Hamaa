from fansx import *
import aiohttp
import asyncio
import random
import json
import os
from datetime import datetime
from pyrogram.enums import ChatAction, ParseMode
from pyrogram.types import Message

__MODULE__ = "ᴛᴇʙᴀᴋ ᴋᴀᴛᴀ"
__HELP__ = """
<blockquote><b>📝 GAME: TEBAK KATA</b>

<b>⌲ Perintah:</b>
ᚗ <code>{0}tebakkata</code> - Mulai game baru
ᚗ <code>{0}tk</code> - Mulai game (singkatan)
ᚗ <code>{0}jawabk [jawaban]</code> - Jawab tebakan
ᚗ <code>{0}skipk</code> - Lewati pertanyaan
ᚗ <code>{0}skork</code> - Lihat papan peringkat

<b>⌲ Cara main:</b>
1. Ketik <code>.tebakkata</code> untuk mulai
2. Bot kasih 3 kata petunjuk
3. Tebak 1 kata yang berhubungan
4. Ketik <code>.jawabk [jawaban]</code>
5. Bot kasih tau bener atau salah
6. Dapet skor kalo bener!

<b>⌲ Contoh:</b>
<code>.tebakkata</code>
<code>.jawabk TENTARA</code>
<code>.jawabk DURIAN</code></blockquote>
"""

# ============================================
# KONFIGURASI
# ============================================
API_URL = "https://api.deline.web.id/game/tebakkata"

# Database untuk menyimpan state game per user
game_sessions = {}
leaderboard = {}

async def get_question():
    """Ambil soal dari API"""
    try:
        async with aiohttp.ClientSession() as session:
            async with session.get(API_URL, timeout=10) as response:
                if response.status == 200:
                    data = await response.json()
                    if data.get("status") and data.get("result"):
                        result = data["result"]
                        return {
                            "clues": result.get("soal", "").split(", "),
                            "answer": result.get("jawaban", "").strip().lower()
                        }
    except Exception as e:
        print(f"Error get question: {e}")
    return None

def normalize_answer(answer):
    """Normalisasi jawaban"""
    return " ".join(answer.lower().split())

@PY.UBOT("tebakkata")
@PY.UBOT("tk")
async def start_game(client: Client, message: Message):
    ggl = await EMO.GAGAL(client)
    prs = await EMO.PROSES(client)
    
    user_id = message.from_user.id
    user_name = message.from_user.first_name
    
    try:
        await client.send_chat_action(message.chat.id, ChatAction.TYPING)
        
        processing = await message.reply_text(f"{prs} <b>Menyiapkan tebak kata...</b>")
        
        question_data = await get_question()
        
        if not question_data:
            await processing.edit_text(f"{ggl} <b>Gagal mengambil soal!</b>")
            return
        
        clues = question_data["clues"]
        answer = question_data["answer"]
        
        # Format clues
        clues_text = "\n".join([f"• {clue}" for clue in clues])
        
        game_sessions[user_id] = {
            "clues": clues,
            "answer": answer,
            "start_time": datetime.now(),
            "attempts": 0
        }
        
        await processing.delete()
        
        await message.reply_text(
            f"<blockquote><b>📝 TEBAK KATA</b>\n\n"
            f"<b>Petunjuk:</b>\n{clues_text}\n\n"
            f"<b>Jawab:</b> <code>.jawabk [satu kata]</code>\n"
            f"<b>Lewati:</b> <code>.skipk</code></blockquote>"
        )
        
    except Exception as e:
        await message.reply_text(f"{ggl} <b>Error: {str(e)[:100]}</b>")

@PY.UBOT("jawabk")
async def answer_game(client: Client, message: Message):
    ggl = await EMO.GAGAL(client)
    sks = await EMO.BERHASIL(client)
    
    user_id = message.from_user.id
    user_name = message.from_user.first_name
    
    try:
        if user_id not in game_sessions:
            await message.reply_text(
                f"{ggl} <b>Ketik .tebakkata dulu!</b>"
            )
            return
        
        args = message.text.split(maxsplit=1)
        if len(args) < 2:
            await message.reply_text(
                f"{ggl} <b>Contoh: .jawabk TENTARA</b>"
            )
            return
        
        user_answer = normalize_answer(args[1])
        correct_answer = game_sessions[user_id]["answer"]
        attempts = game_sessions[user_id]["attempts"] + 1
        game_sessions[user_id]["attempts"] = attempts
        clues = game_sessions[user_id]["clues"]
        
        # Cek jawaban (bisa exact match)
        is_correct = (user_answer == correct_answer)
        
        if is_correct:
            # Skor berdasarkan kesempatan
            score = max(10 - (attempts - 1) * 2, 1)
            
            # Update leaderboard
            if user_id in leaderboard:
                leaderboard[user_id]["score"] += score
                leaderboard[user_id]["correct"] += 1
            else:
                leaderboard[user_id] = {
                    "name": user_name,
                    "score": score,
                    "correct": 1,
                    "total": 0
                }
            
            leaderboard[user_id]["total"] = leaderboard[user_id].get("total", 0) + 1
            
            # Format jawaban untuk ditampilkan
            answer_display = correct_answer.upper()
            
            del game_sessions[user_id]
            
            await message.reply_text(
                f"<blockquote><b>✅ BENAR!</b>\n\n"
                f"📝 <b>Jawaban:</b> {answer_display}\n"
                f"⭐ Skor: +{score}\n"
                f"🏆 Total: {leaderboard[user_id]['score']}\n"
                f"📈 Benar: {leaderboard[user_id]['correct']}/{leaderboard[user_id]['total']}\n\n"
                f"Main lagi: <code>.tebakkata</code></blockquote>"
            )
        else:
            if attempts >= 3:
                answer_display = correct_answer.upper()
                await message.reply_text(
                    f"<blockquote><b>❌ GAME OVER</b>\n\n"
                    f"📝 <b>Jawaban:</b> {answer_display}\n\n"
                    f"Main lagi: <code>.tebakkata</code></blockquote>"
                )
                
                # Update total tapi ga dapet skor
                if user_id in leaderboard:
                    leaderboard[user_id]["total"] = leaderboard[user_id].get("total", 0) + 1
                else:
                    leaderboard[user_id] = {
                        "name": user_name,
                        "score": 0,
                        "correct": 0,
                        "total": 1
                    }
                
                del game_sessions[user_id]
            else:
                await message.reply_text(
                    f"<blockquote><b>❌ SALAH</b>\n\n"
                    f"📝 Percobaan: {attempts}/3\n\n"
                    f"Coba lagi: <code>.jawabk [jawaban]</code></blockquote>"
                )
        
    except Exception as e:
        await message.reply_text(f"{ggl} <b>Error: {str(e)[:100]}</b>")

@PY.UBOT("skipk")
async def skip_question(client: Client, message: Message):
    ggl = await EMO.GAGAL(client)
    
    user_id = message.from_user.id
    user_name = message.from_user.first_name
    
    if user_id in game_sessions:
        correct_answer = game_sessions[user_id]["answer"]
        answer_display = correct_answer.upper()
        
        # Update total tapi ga dapet skor
        if user_id in leaderboard:
            leaderboard[user_id]["total"] = leaderboard[user_id].get("total", 0) + 1
        else:
            leaderboard[user_id] = {
                "name": user_name,
                "score": 0,
                "correct": 0,
                "total": 1
            }
        
        await message.reply_text(
            f"<blockquote><b>⏭️ SKIP</b>\n\n"
            f"📝 <b>Jawaban:</b> {answer_display}\n\n"
            f"Main baru: <code>.tebakkata</code></blockquote>"
        )
        del game_sessions[user_id]
    else:
        await message.reply_text(f"{ggl} <b>Belum mulai game!</b>")

@PY.UBOT("skork")
async def show_leaderboard(client: Client, message: Message):
    """Tampilkan papan peringkat tebak kata"""
    
    if not leaderboard:
        await message.reply_text(
            "<blockquote><b>🏆 LEADERBOARD TEBAK KATA</b>\n\n"
            "Belum ada skor. Ayo main <code>.tebakkata</code> dulu!</blockquote>"
        )
        return
    
    # Urutkan berdasarkan skor tertinggi
    sorted_users = sorted(leaderboard.items(), key=lambda x: x[1]["score"], reverse=True)
    
    text = "<blockquote><b>🏆 LEADERBOARD TEBAK KATA</b>\n\n"
    
    for i, (user_id, data) in enumerate(sorted_users[:10], 1):
        medal = "🥇" if i == 1 else "🥈" if i == 2 else "🥉" if i == 3 else f"{i}."
        
        # Hitung akurasi
        if data["total"] > 0:
            accuracy = (data["correct"] / data["total"]) * 100
        else:
            accuracy = 0
            
        text += f"{medal} <b>{data['name']}</b>\n"
        text += f"   ⭐ {data['score']} poin | 📊 {accuracy:.1f}%\n"
    
    text += "\nMain: <code>.tebakkata</code></blockquote>"
    
    await message.reply_text(text)

@PY.UBOT("infok")
async def game_info(client: Client, message: Message):
    """Info tentang game tebak kata"""
    
    text = """
<blockquote><b>📝 INFO GAME TEBAK KATA</b>

<b>Cara main:</b>
• <code>.tebakkata</code> - Mulai game
• <code>.jawabk [jawaban]</code> - Jawab tebakan
• <code>.skipk</code> - Lewati soal
• <code>.skork</code> - Lihat peringkat

<b>Aturan:</b>
• 3x kesempatan menjawab per soal
• Skor berkurang jika salah menjawab
• Makin cepat jawab, makin tinggi skor
• Jawaban harus PERSIS (case tidak sensitif)

<b>Skor:</b>
• Percobaan 1: +10 poin
• Percobaan 2: +8 poin
• Percobaan 3: +6 poin
• Salah 3x: 0 poin</blockquote>"""
    
    await message.reply_text(text)