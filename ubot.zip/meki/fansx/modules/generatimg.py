from fansx import *
import aiohttp
import asyncio
import random
import os
import base64
from io import BytesIO
from pyrogram.enums import ChatAction, ParseMode
from pyrogram.types import Message, InlineKeyboardMarkup, InlineKeyboardButton

__MODULE__ = "ᴀɪ ɪᴍᴀɢᴇ ɢᴇɴᴇʀᴀᴛᴏʀ"
__HELP__ = """
<blockquote><b>『 AI IMAGE GENERATOR 』</b>

<b>⌲ Generate gambar dari teks:</b>
ᚗ <code>{0}gen [prompt]</code> - Generate gambar (model default)
ᚗ <code>{0}gen [prompt] --m [model]</code> - Pilih model tertentu

<b>⌲ Model tersedia:</b>
• <code>sd</code> - Stable Diffusion v1.5
• <code>sdxl</code> - Stable Diffusion XL
• <code>anime</code> - Anime style
• <code>realistic</code> - Realistic style

<b>⌲ Contoh:</b>
<code>.gen cat riding a motorcycle</code>
<code>.gen beautiful sunset anime --m anime</code>
<code>.gen portrait of a woman --m realistic</code>

<b>⌲ Ukuran gambar:</b>
• Default: 1024x1024
• Aspect ratio otomatis menyesuaikan prompt</blockquote>
"""

# ============================================
# API KEYS (12 KEY)
# ============================================
API_KEYS = [
    "eIxUwMpn",
    "keoCFdc6",
    "bv7m372F",
    "iAiB9QKT",
    "JP7Cy8Y2",
    "GI4vPxYv",
    "HRPga9TN",
    "PDwqhVsj",
    "m8jpBeZR",
    "PXkxh5hw",
    "MFnlpM6A",
    "u299UiOF"
]

# ============================================
# KONFIGURASI MODEL
# ============================================
MODELS = {
    "sd": {
        "name": "Stable Diffusion v1.5",
        "url": "https://api.botcahx.eu.org/api/search/stablediffusion",
        "param": "text",
        "default_style": ""
    },
    "sdxl": {
        "name": "Stable Diffusion XL",
        "url": "https://api.botcahx.eu.org/api/search/sdxl",
        "param": "text",
        "default_style": ""
    },
    "anime": {
        "name": "Anime Style",
        "url": "https://api.botcahx.eu.org/api/search/stablediffusion",
        "param": "text",
        "default_style": "anime style, anime artwork, anime"
    },
    "realistic": {
        "name": "Realistic Style",
        "url": "https://api.botcahx.eu.org/api/search/stablediffusion",
        "param": "text",
        "default_style": "photorealistic, 4k, highly detailed, realistic"
    }
}

def get_random_apikey():
    """Ambil API key random dari daftar"""
    return random.choice(API_KEYS)

async def generate_image(prompt: str, model_key: str = "sd", retry_count: int = 0, max_retries: int = 3):
    """Generate gambar dari prompt"""
    
    api_key = get_random_apikey()
    model = MODELS.get(model_key, MODELS["sd"])
    
    # Tambahkan style kalo ada
    if model.get("default_style"):
        full_prompt = f"{prompt}, {model['default_style']}"
    else:
        full_prompt = prompt
    
    params = {
        "apikey": api_key,
        model["param"]: full_prompt
    }
    
    print(f"🔄 [Gen] Mencoba dengan key {api_key[:8]}... (percobaan {retry_count+1}) - Model: {model_key}")
    
    try:
        async with aiohttp.ClientSession() as session:
            async with session.get(model["url"], params=params, timeout=60) as response:
                if response.status == 200:
                    # Cek content-type
                    content_type = response.headers.get("Content-Type", "")
                    
                    if "image" in content_type:
                        # Langsung gambar
                        image_data = await response.read()
                        return {
                            "success": True,
                            "image": image_data,
                            "api_key": api_key,
                            "model": model["name"]
                        }
                    else:
                        # Mungkin JSON response
                        try:
                            data = await response.json()
                            if data.get("status") and data.get("result"):
                                # Ambil URL gambar
                                img_url = data["result"]
                                
                                # Download gambar dari URL
                                async with session.get(img_url, timeout=30) as img_resp:
                                    if img_resp.status == 200:
                                        image_data = await img_resp.read()
                                        return {
                                            "success": True,
                                            "image": image_data,
                                            "api_key": api_key,
                                            "model": model["name"]
                                        }
                        except:
                            pass
                        
                        raise Exception("Response bukan gambar")
                else:
                    raise Exception(f"HTTP {response.status}")
                    
    except Exception as e:
        if retry_count < max_retries - 1:
            print(f"❌ Gagal dengan key {api_key[:8]}..., coba key lain...")
            await asyncio.sleep(1)
            return await generate_image(prompt, model_key, retry_count + 1, max_retries)
        
        return {
            "success": False,
            "error": str(e),
            "api_key": api_key
        }

def parse_prompt(text):
    """Parse prompt untuk opsi model"""
    # Format: .gen prompt --m model
    if " --m " in text.lower():
        parts = text.lower().split(" --m ")
        prompt = parts[0].strip()
        model = parts[1].strip()
        
        if model in MODELS:
            return prompt, model
    
    # Format: .gen prompt --model model
    elif " --model " in text.lower():
        parts = text.lower().split(" --model ")
        prompt = parts[0].strip()
        model = parts[1].strip()
        
        if model in MODELS:
            return prompt, model
    
    # Default
    return text, "sd"

# ============================================
# COMMAND GENERATE
# ============================================

@PY.UBOT("gen")
async def generate_image_command(client: Client, message: Message):
    ggl = await EMO.GAGAL(client)
    sks = await EMO.BERHASIL(client)
    prs = await EMO.PROSES(client)
    
    try:
        await client.send_chat_action(message.chat.id, ChatAction.TYPING)
        
        # Ambil prompt
        args = message.text.split(maxsplit=1)
        if len(args) < 2:
            # Tampilkan model yang tersedia
            models_text = "\n".join([f"• <code>{k}</code> - {v['name']}" for k, v in MODELS.items()])
            
            await message.reply_text(
                f"<blockquote><b>🖼️ AI IMAGE GENERATOR</b>\n\n"
                f"<b>Format:</b> <code>.gen [prompt]</code>\n"
                f"<b>Format dengan model:</b> <code>.gen [prompt] --m [model]</code>\n\n"
                f"<b>Model tersedia:</b>\n"
                f"{models_text}\n\n"
                f"<b>Contoh:</b>\n"
                f"<code>.gen cat riding a motorcycle</code>\n"
                f"<code>.gen beautiful sunset --m anime</code></blockquote>"
            )
            return
        
        raw_input = args[1].strip()
        prompt, model_key = parse_prompt(raw_input)
        model = MODELS.get(model_key, MODELS["sd"])
        
        if not prompt:
            await message.reply_text(f"{ggl} <b>Prompt tidak boleh kosong!</b>")
            return
        
        # Kirim pesan processing
        processing = await message.reply_text(
            f"{prs} <b>AI sedang menggambar...</b>\n"
            f"📝 Prompt: <code>{prompt[:100]}{'...' if len(prompt) > 100 else ''}</code>\n"
            f"🎨 Model: {model['name']}"
        )
        
        # Generate gambar
        result = await generate_image(prompt, model_key)
        
        await processing.delete()
        
        if result.get("success"):
            # Simpan gambar sementara
            file_path = f"gen_{message.from_user.id}_{random.randint(1000,9999)}.png"
            with open(file_path, 'wb') as f:
                f.write(result["image"])
            
            # Kirim gambar
            await client.send_photo(
                chat_id=message.chat.id,
                photo=file_path,
                caption=f"<blockquote><b>🖼️ GENERATION RESULT</b>\n\n"
                        f"📝 <b>Prompt:</b> <code>{prompt[:200]}{'...' if len(prompt) > 200 else ''}</code>\n"
                        f"🎨 <b>Model:</b> {result['model']}\n"
                        f"🔑 <b>Key:</b> <code>{result['api_key'][:8]}...</code></blockquote>"
            )
            
            # Hapus file
            if os.path.exists(file_path):
                os.remove(file_path)
        else:
            error_msg = result.get("error", "Unknown error")
            await message.reply_text(
                f"{ggl} <b>Gagal generate gambar!</b>\n"
                f"Error: {error_msg}\n"
                f"Key: <code>{result.get('api_key', '')[:8]}...</code>"
            )
        
    except Exception as e:
        await message.reply_text(f"{ggl} <b>Error: {str(e)[:100]}</b>")

@PY.UBOT("genimg")
async def genimg_alias(client: Client, message: Message):
    """Alias untuk gen"""
    await generate_image_command(client, message)

@PY.UBOT("imagine")
async def imagine_alias(client: Client, message: Message):
    """Alias untuk gen"""
    await generate_image_command(client, message)

# ============================================
# COMMAND DENGAN MODEL SPESIFIK
# ============================================

@PY.UBOT("gensd")
async def gensd_command(client: Client, message: Message):
    """Generate dengan Stable Diffusion"""
    await generate_with_model(client, message, "sd", "Stable Diffusion")

@PY.UBOT("gensdxl")
async def gensdxl_command(client: Client, message: Message):
    """Generate dengan SDXL"""
    await generate_with_model(client, message, "sdxl", "SDXL")

@PY.UBOT("genanime")
async def genanime_command(client: Client, message: Message):
    """Generate dengan style anime"""
    await generate_with_model(client, message, "anime", "Anime Style")

@PY.UBOT("genreal")
async def genreal_command(client: Client, message: Message):
    """Generate dengan style realistic"""
    await generate_with_model(client, message, "realistic", "Realistic Style")

async def generate_with_model(client: Client, message: Message, model_key: str, model_name: str):
    ggl = await EMO.GAGAL(client)
    prs = await EMO.PROSES(client)
    
    try:
        await client.send_chat_action(message.chat.id, ChatAction.TYPING)
        
        # Ambil prompt
        args = message.text.split(maxsplit=1)
        if len(args) < 2:
            await message.reply_text(
                f"<blockquote><b>❌ Masukkan prompt!</b>\n\n"
                f"Contoh: <code>.{model_key} cat riding a motorcycle</code></blockquote>"
            )
            return
        
        prompt = args[1].strip()
        
        if not prompt:
            await message.reply_text(f"{ggl} <b>Prompt tidak boleh kosong!</b>")
            return
        
        # Kirim pesan processing
        processing = await message.reply_text(
            f"{prs} <b>{model_name} sedang menggambar...</b>\n"
            f"📝 <code>{prompt[:100]}{'...' if len(prompt) > 100 else ''}</code>"
        )
        
        # Generate gambar
        result = await generate_image(prompt, model_key)
        
        await processing.delete()
        
        if result.get("success"):
            file_path = f"gen_{message.from_user.id}_{random.randint(1000,9999)}.png"
            with open(file_path, 'wb') as f:
                f.write(result["image"])
            
            await client.send_photo(
                chat_id=message.chat.id,
                photo=file_path,
                caption=f"<blockquote><b>🖼️ {model_name.upper()}</b>\n\n"
                        f"📝 <b>Prompt:</b> <code>{prompt[:200]}{'...' if len(prompt) > 200 else ''}</code>\n"
                        f"🔑 <b>Key:</b> <code>{result['api_key'][:8]}...</code></blockquote>"
            )
            
            if os.path.exists(file_path):
                os.remove(file_path)
        else:
            error_msg = result.get("error", "Unknown error")
            await message.reply_text(
                f"{ggl} <b>Gagal generate!</b>\n"
                f"Error: {error_msg}"
            )
        
    except Exception as e:
        await message.reply_text(f"{ggl} <b>Error: {str(e)[:100]}</b>")

# ============================================
# COMMAND MODEL LIST
# ============================================

@PY.UBOT("genmodels")
async def gen_models(client: Client, message: Message):
    """Lihat daftar model yang tersedia"""
    
    text = "<blockquote><b>🎨 MODEL AI IMAGE GENERATOR</b>\n\n"
    
    for key, model in MODELS.items():
        text += f"<b>{key}</b> - {model['name']}\n"
        if model.get("default_style"):
            text += f"  ↳ Style: {model['default_style']}\n"
        text += f"  ↳ Command: <code>.gen [prompt] --m {key}</code>\n"
        text += f"  ↳ Shortcut: <code>.gen{key} [prompt]</code>\n\n"
    
    text += "<b>Contoh:</b>\n"
    text += "<code>.gen beautiful girl --m anime</code>\n"
    text += "<code>.genanime beautiful girl</code>\n"
    text += "<code>.genreal portrait of man</code></blockquote>"
    
    await message.reply_text(text)

# ============================================
# COMMAND INFO
# ============================================

@PY.UBOT("geninfo")
async def gen_info(client: Client, message: Message):
    """Info tentang AI Image Generator"""
    
    text = f"""
<blockquote><b>🖼️ AI IMAGE GENERATOR INFO</b>

<b>📊 API Keys:</b> {len(API_KEYS)} keys
<b>🎨 Models:</b> {len(MODELS)} models
<b>⚙️ Retry:</b> 3x percobaan dengan key berbeda
<b>📏 Default Size:</b> 1024x1024

<b>🚀 Tips:</b>
• Prompt yang detail menghasilkan gambar lebih baik
• Tambahkan "--m [model]" untuk ganti style
• Gunakan bahasa Inggris untuk hasil optimal
• Makin panjang prompt, makin spesifik hasilnya

<b>📌 Contoh prompt bagus:</b>
<code>.gen beautiful landscape of a fantasy forest with glowing mushrooms, digital art, 8k</code>
<code>.gen portrait of a cat wearing a wizard hat, detailed, fantasy art --m realistic</code></blockquote>"""
    
    await message.reply_text(text)