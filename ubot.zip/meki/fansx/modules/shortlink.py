from fansx import *
import random
import requests
from pyrogram.enums import ChatAction, ParseMode
from pyrogram import filters
from pyrogram.types import Message

__MODULE__ = "sʜᴏʀᴛ ʟɪɴᴋ"
__HELP__ = """
<b>⦪ ʙᴀɴᴛᴜᴀɴ ᴜɴᴛᴜᴋ sʜᴏʀᴛ ʟɪɴᴋ ⦫</b>
<blockquote>⎆ perintah :
ᚗ <code>{0}tinyurl</code> [link]
⊶ memperpendek tautan menggunakan TinyURL

ᚗ <code>{0}bitly</code> [link]
⊶ memperpendek tautan menggunakan Bitly

📌 Contoh:
<code>{0}tinyurl https://google.com</code>
<code>{0}bitly https://youtu.be/SgW4IKDIqjY</code></blockquote>
"""

# Base URL API Vreden
BASE_URL = "https://api.vreden.my.id/api/v1/tools/shortlink"

def shorten_url(url, short_type):
    """
    Fungsi untuk memperpendek URL menggunakan API Vreden
    short_type: "tinyurl" atau "bitly"
    """
    # Parameter untuk API
    params = {
        "url": url,
        "type": short_type
    }
    
    try:
        print(f"Membuat {short_type} untuk: {url}")
        response = requests.get(BASE_URL, params=params, timeout=10)
        
        if response.status_code == 200:
            data = response.json()
            
            if data.get("status") and data.get("result"):
                short_url = data["result"]
                return short_url, None
            else:
                return None, "Response tidak valid"
        else:
            return None, f"HTTP Error: {response.status_code}"
            
    except requests.exceptions.Timeout:
        return None, "Timeout! Server sedang sibuk"
    except requests.exceptions.ConnectionError:
        return None, "Gagal terhubung ke server"
    except Exception as e:
        return None, str(e)

@PY.UBOT("tinyurl")
@PY.TOP_CMD
async def tinyurl_handler(client, message):
    try:
        await client.send_chat_action(message.chat.id, ChatAction.TYPING)

        if len(message.command) < 2:
            await message.reply_text(
                "<emoji id=5019523782004441717>❌</emoji> mohon gunakan format\n"
                "contoh : <code>.tinyurl https://google.com</code>"
            )
            return

        prs = await message.reply_text("<emoji id=5071138963800982678>😎</emoji> Memperpendek link dengan TinyURL...")
        url = message.text.split(' ', 1)[1]
        
        # Validasi URL
        if not url.startswith(("http://", "https://")):
            url = "https://" + url
        
        # Shorten URL dengan type tinyurl
        short_url, error = shorten_url(url, "tinyurl")
        
        if short_url:
            await prs.edit(
                f"<blockquote><b>✅ TINYURL BERHASIL</b>\n\n"
                f"🔗 <b>Original:</b> <code>{url[:50]}{'...' if len(url) > 50 else ''}</code>\n"
                f"📎 <b>Short:</b> <code>{short_url}</code>\n\n"
                f"⚡ <b>Powered by:</b> Ubot Premium Zyura</blockquote>"
            )
        else:
            await prs.edit(
                f"<emoji id=5019523782004441717>❌</emoji> Gagal memperpendek link!\n"
                f"Error: {error}"
            )
            
    except Exception as e:
        await message.reply_text(f"❌ Error: {str(e)[:100]}")

@PY.UBOT("bitly")
@PY.TOP_CMD
async def bitly_handler(client, message):
    try:
        await client.send_chat_action(message.chat.id, ChatAction.TYPING)

        if len(message.command) < 2:
            await message.reply_text(
                "<emoji id=5019523782004441717>❌</emoji> mohon gunakan format\n"
                "contoh : <code>.bitly https://google.com</code>"
            )
            return

        prs = await message.reply_text("<emoji id=5071138963800982678>😎</emoji> Memperpendek link dengan Bitly...")
        url = message.text.split(' ', 1)[1]
        
        # Validasi URL
        if not url.startswith(("http://", "https://")):
            url = "https://" + url
        
        # Shorten URL dengan type bitly
        short_url, error = shorten_url(url, "bitly")
        
        if short_url:
            await prs.edit(
                f"<blockquote><b>✅ BITLY BERHASIL</b>\n\n"
                f"🔗 <b>Original:</b> <code>{url[:50]}{'...' if len(url) > 50 else ''}</code>\n"
                f"📎 <b>Short:</b> <code>{short_url}</code>\n\n"
                f"⚡ <b>Powered by:</b> Ubot Premium Zyura</blockquote>"
            )
        else:
            await prs.edit(
                f"<emoji id=5019523782004441717>❌</emoji> Gagal memperpendek link!\n"
                f"Error: {error}"
            )
            
    except Exception as e:
        await message.reply_text(f"❌ Error: {str(e)[:100]}")

@PY.BOT("tinyurl")
async def tinyurl_bot(client, message):
    try:
        if len(message.command) < 2:
            await message.reply_text(
                "❌ Gunakan: /tinyurl [link]\n"
                "Contoh: /tinyurl https://google.com"
            )
            return

        prs = await message.reply_text("😎 Processing TinyURL...")
        url = message.text.split(' ', 1)[1]
        
        if not url.startswith(("http://", "https://")):
            url = "https://" + url
        
        short_url, error = shorten_url(url, "tinyurl")
        
        if short_url:
            await prs.edit(f"✅ Short URL: {short_url}")
        else:
            await prs.edit(f"❌ Gagal: {error}")
            
    except Exception as e:
        await message.reply_text(f"❌ Error: {str(e)[:100]}")

@PY.BOT("bitly")
async def bitly_bot(client, message):
    try:
        if len(message.command) < 2:
            await message.reply_text(
                "❌ Gunakan: /bitly [link]\n"
                "Contoh: /bitly https://google.com"
            )
            return

        prs = await message.reply_text("😎 Processing Bitly...")
        url = message.text.split(' ', 1)[1]
        
        if not url.startswith(("http://", "https://")):
            url = "https://" + url
        
        short_url, error = shorten_url(url, "bitly")
        
        if short_url:
            await prs.edit(f"✅ Short URL: {short_url}")
        else:
            await prs.edit(f"❌ Gagal: {error}")
            
    except Exception as e:
        await message.reply_text(f"❌ Error: {str(e)[:100]}")