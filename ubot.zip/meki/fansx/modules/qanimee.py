import requests
import random
from pyrogram import Client, filters
from fansx import *

__MODULE__ = "ϙᴜᴏᴛᴇs ᴀɴɪᴍᴇ"
__HELP__ = """
<b>⦪ ʙᴀɴᴛᴜᴀɴ ᴜɴᴛᴜᴋ ϙᴜᴏᴛᴇs ᴀɴɪᴍᴇ ⦫</b>
<blockquote>⎆ perintah :
ᚗ <code>{0}qanime</code></blockquote>
"""

@PY.UBOT("qanime")
async def quotes_anime(client, message):
    # API Lolhuman
    API_URL = "https://api.lolhuman.xyz/api/random/quotesnime"
    params = {
        "apikey": "323e6584f28690c6c376622c"  # API key langsung di params
    }
    
    try:
        response = requests.get(API_URL, params=params)
        data = response.json()
        
        # Cek status dari API Lolhuman
        if data.get("status") == 200 and data.get("result"):
            result = data["result"]
            
            # Format pesan dengan struktur mirip kode asli
            reply_text = "**Quotes Anime**\n"
            reply_text += f"<blockquote>\n"
            reply_text += f"<emoji id=6206162931663508973>💜</emoji><emoji id=6204012166660494973>💜</emoji> **Karakter :** `{result.get('character', 'Unknown')}`\n"
            reply_text += f"<emoji id=6203909748870354847>💜</emoji><emoji id=6203792139780887891>💜</emoji> **Anime :** `{result.get('anime', 'Unknown')}`\n"
            reply_text += f"<emoji id=6203959201123800232>💜</emoji><emoji id=6204000918141146257>💜</emoji> **Episode :** `{result.get('episode', 'Unknown')}`\n"
            reply_text += f"<emoji id=6203978081800033988>💜</emoji><emoji id=6206004318521267252>💜</emoji> **Quotes :** `{result.get('quote', 'Tidak ada quotes')}`\n"
            # API Lolhuman tidak menyediakan link, jadi bagian link dihilangkan
            reply_text += f"</blockquote>"
            
            await message.reply_text(reply_text)
        else:
            await message.reply_text("Gagal mengambil data Quotes.")
    
    except Exception as e:
        await message.reply_text(f"Terjadi kesalahan: {e}")