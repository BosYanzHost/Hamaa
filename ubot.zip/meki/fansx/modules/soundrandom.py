from fansx import *
import requests
import aiohttp
import os
import random
from pyrogram.enums import ChatAction, ParseMode
from pyrogram.types import Message

__MODULE__ = "sᴏᴜɴᴅ ᴄᴏʟʟᴇᴄᴛɪᴏɴ"
__HELP__ = """
<blockquote><b>『 SOUND COLLECTION 』</b>

<b>⌲ Perintah:</b>
ᚗ <code>{0}sound1</code> - <code>{0}sound250</code> 
⊶ Memutar efek suara dari koleksi

<b>⌲ Contoh:</b>
<code>.sound1</code>
<code>.sound100</code>
<code>.sound250</code></blockquote>
"""

# Base URL untuk sound effects
SOUND_BASE = "https://raw.githubusercontent.com/Leoo7z/Music/main"

# Daftar sound dari sound1 sampai sound250
SOUND_LIST = [f"sound{i}" for i in range(1, 251)]

async def play_sound(client: Client, message: Message, sound_name: str):
    ggl = await EMO.GAGAL(client)
    sks = await EMO.BERHASIL(client)
    prs = await EMO.PROSES(client)
    
    try:
        await client.send_chat_action(message.chat.id, ChatAction.TYPING)
        
        # Cek apakah sound valid
        if sound_name not in SOUND_LIST:
            await message.reply_text(f"{ggl} <b>Sound '{sound_name}' tidak ditemukan!</b>")
            return
        
        # URL sound
        sound_url = f"{SOUND_BASE}/{sound_name}.mp3"
        
        # Kirim pesan processing
        processing = await message.reply_text(f"{prs} <b>Memutar {sound_name}...</b>")
        
        try:
            await processing.delete()
            
            # Kirim audio biasa tanpa thumbnail
            await client.send_audio(
                chat_id=message.chat.id,
                audio=sound_url,
                caption=f"<blockquote><b>🔊 {sound_name}</b></blockquote>"
            )
        except Exception as e:
            # Fallback kalo gagal
            await message.reply_text(f"{ggl} <b>Gagal memutar sound!</b>\n{str(e)[:100]}")
        
    except Exception as e:
        await message.reply_text(f"{ggl} <b>Error: {str(e)[:100]}</b>")

# Generate handler untuk sound1 - sound250
for i in range(1, 251):
    sound_name = f"sound{i}"
    
    # Buat decorator dan fungsi secara dinamis
    exec(f"""
@PY.UBOT("{sound_name}")
async def {sound_name}_handler(client: Client, message: Message):
    await play_sound(client, message, "{sound_name}")
    """)

@PY.UBOT("soundlist")
async def sound_list(client: Client, message: Message):
    """Menampilkan daftar sound yang tersedia"""
    
    text = "<blockquote><b>📋 DAFTAR SOUND EFFECTS</b>\n\n"
    
    # Tampilkan dalam beberapa baris (20 per baris biar ringkas)
    rows = [SOUND_LIST[i:i+20] for i in range(0, len(SOUND_LIST), 20)]
    for row in rows:
        text += " • " + ", ".join(row) + "\n"
    
    text += f"\n<b>📊 Total:</b> {len(SOUND_LIST)} sound\n\n"
    text += "<b>💡 Cara pakai:</b>\n"
    text += "• <code>.sound1</code>\n"
    text += "• <code>.sound100</code>\n"
    text += "• <code>.sound250</code></blockquote>"
    
    await message.reply_text(text)

@PY.UBOT("soundrange")
async def sound_range(client: Client, message: Message):
    """Menampilkan sound berdasarkan range"""
    args = message.text.split()
    
    if len(args) < 3:
        await message.reply_text(
            f"<blockquote><b>❌ Format salah!</b>\n\n"
            f"<b>Contoh:</b>\n"
            f"<code>.soundrange 1 10</code> (menampilkan sound1-sound10)</blockquote>"
        )
        return
    
    try:
        start = int(args[1])
        end = int(args[2])
        
        if start < 1 or end > 250 or start > end:
            await message.reply_text(f"{ggl} <b>Range tidak valid! (1-250)</b>")
            return
        
        sound_range_list = [f"sound{i}" for i in range(start, end+1)]
        
        # Tampilkan 15 per baris
        text = f"<blockquote><b>📋 SOUND {start}-{end}</b>\n\n"
        rows = [sound_range_list[i:i+15] for i in range(0, len(sound_range_list), 15)]
        for row in rows:
            text += " • " + ", ".join(row) + "\n"
        
        text += f"\n<b>📊 Total:</b> {len(sound_range_list)} sound</blockquote>"
        
        await message.reply_text(text)
        
    except ValueError:
        await message.reply_text(f"{ggl} <b>Masukkan angka yang valid!</b>")

@PY.UBOT("soundsearch")
async def sound_search(client: Client, message: Message):
    """Mencari sound berdasarkan keyword"""
    args = message.text.split(maxsplit=1)
    
    if len(args) < 2:
        await message.reply_text(
            f"<blockquote><b>❌ Masukkan keyword!</b>\n\n"
            f"<b>Contoh:</b>\n"
            f"<code>.soundsearch sound1</code></blockquote>"
        )
        return
    
    keyword = args[1].lower()
    
    # Cari sound yang mengandung keyword
    found = [s for s in SOUND_LIST if keyword in s]
    
    if not found:
        await message.reply_text(f"{ggl} <b>Tidak ada sound dengan keyword '{keyword}'</b>")
        return
    
    # Batasi hasil pencarian (max 30)
    if len(found) > 30:
        display = found[:30]
        more = len(found) - 30
        extra = f"\n\n<b>...dan {more} lainnya</b>"
    else:
        display = found
        extra = ""
    
    text = f"<blockquote><b>📋 HASIL PENCARIAN: {keyword}</b>\n\n"
    
    # Tampilkan 15 per baris
    rows = [display[i:i+15] for i in range(0, len(display), 15)]
    for row in rows:
        text += " • " + ", ".join(row) + "\n"
    
    text += f"{extra}\n"
    text += f"<b>📊 Ditemukan:</b> {len(found)} sound</blockquote>"
    
    await message.reply_text(text)

@PY.UBOT("soundrandom")
async def sound_random(client: Client, message: Message):
    """Memutar sound secara random"""
    import random
    
    # Pilih sound random
    random_sound = random.choice(SOUND_LIST)
    
    await play_sound(client, message, random_sound)

@PY.UBOT("soundplay")
async def sound_play(client: Client, message: Message):
    """Memutar sound berdasarkan nomor"""
    args = message.text.split()
    
    if len(args) < 2:
        await message.reply_text(
            f"<blockquote><b>❌ Masukkan nomor sound!</b>\n\n"
            f"<b>Contoh:</b>\n"
            f"<code>.soundplay 25</code> (memutar sound25)</blockquote>"
        )
        return
    
    try:
        num = int(args[1])
        if num < 1 or num > 250:
            await message.reply_text(f"{ggl} <b>Nomor harus antara 1-250!</b>")
            return
        
        sound_name = f"sound{num}"
        await play_sound(client, message, sound_name)
        
    except ValueError:
        await message.reply_text(f"{ggl} <b>Masukkan angka yang valid!</b>")

@PY.BOT("sound1")
async def sound_bot_handler(client: Client, message: Message):
    """Handler untuk bot"""
    sound_name = message.text.split()[0].replace('/', '')
    await play_sound_bot(client, message, sound_name)

async def play_sound_bot(client: Client, message: Message, sound_name: str):
    try:
        if sound_name not in SOUND_LIST:
            await message.reply_text(f"❌ Sound '{sound_name}' tidak ditemukan!")
            return
        
        sound_url = f"{SOUND_BASE}/{sound_name}.mp3"
        
        processing = await message.reply_text(f"🔍 Memutar {sound_name}...")
        
        await processing.delete()
        
        await client.send_audio(
            chat_id=message.chat.id,
            audio=sound_url,
            caption=f"🔊 {sound_name}"
        )
        
    except Exception as e:
        await message.reply_text(f"❌ Error: {str(e)[:100]}")