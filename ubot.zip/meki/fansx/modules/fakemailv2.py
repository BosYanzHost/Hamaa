from fansx import *
import aiohttp
import asyncio
import json
import os
from datetime import datetime, timedelta
from pyrogram.enums import ChatAction, ParseMode
from pyrogram.types import Message

__MODULE__ = "ꜰᴀᴋᴇ ᴇᴍᴀɪʟ ᴠ2"
__HELP__ = """
<blockquote><b>📧 FAKE EMAIL V2 (Temporary)</b>

<b>⌲ Perintah:</b>
ᚗ <code>{0}createemail</code> - Buat email baru
ᚗ <code>{0}myemail</code> - Lihat email aktif
ᚗ <code>{0}inbox</code> - Lihat inbox email
ᚗ <code>{0}refreshmail</code> - Refresh inbox
ᚗ <code>{0}deletemail</code> - Hapus email

<b>⌲ Contoh:</b>
<code>.createemail</code>
<code>.inbox</code>
<code>.refreshmail</code>

<b>⌲ Catatan:</b>
• Email aktif 30 menit
• Inbox otomatis terupdate
• Email tersimpan per user</blockquote>
"""

# ============================================
# KONFIGURASI
# ============================================
BASE_URL = "https://api.vreden.my.id/api/v1/tools/fakemail"

# Database sementara untuk menyimpan email user
# Format: {user_id: {"id": session_id, "email": email, "created_at": timestamp}}
user_sessions = {}

async def create_email():
    """Buat email baru"""
    try:
        async with aiohttp.ClientSession() as session:
            async with session.get(f"{BASE_URL}/create", timeout=15) as response:
                if response.status == 200:
                    data = await response.json()
                    if data.get("status") and data.get("result"):
                        result = data["result"]
                        addresses = result.get("addresses", [])
                        if addresses:
                            return {
                                "id": result.get("id"),
                                "email": addresses[0].get("address"),
                                "expiresAt": result.get("expiresAt")
                            }
    except Exception as e:
        print(f"Error create email: {e}")
    return None

async def get_inbox(session_id: str):
    """Ambil inbox email"""
    try:
        async with aiohttp.ClientSession() as session:
            async with session.get(f"{BASE_URL}/inbox?id={session_id}", timeout=15) as response:
                if response.status == 200:
                    data = await response.json()
                    if data.get("status") and data.get("result"):
                        return data["result"]
    except Exception as e:
        print(f"Error get inbox: {e}")
    return None

def format_expiry(expires_at):
    """Format waktu expired"""
    try:
        if expires_at:
            # Ambil tanggal dan jam saja
            date_part = expires_at[:10]  # YYYY-MM-DD
            time_part = expires_at[11:16]  # HH:MM
            return f"{date_part} {time_part} WIB"
    except:
        pass
    return "Tidak diketahui"

def get_remaining_time(created_at):
    """Hitung sisa waktu (30 menit)"""
    if not created_at:
        return 0, 0, 0
    
    now = datetime.now()
    elapsed = (now - created_at).total_seconds()
    remaining = max(0, 1800 - int(elapsed))  # 30 menit = 1800 detik
    
    if remaining <= 0:
        return 0, 0, 0
    
    minutes = remaining // 60
    seconds = remaining % 60
    return remaining, minutes, seconds

@PY.UBOT("createemail")
@PY.UBOT("buatemail")
async def create_fake_email(client: Client, message: Message):
    ggl = await EMO.GAGAL(client)
    sks = await EMO.BERHASIL(client)
    prs = await EMO.PROSES(client)
    
    user_id = message.from_user.id
    user_name = message.from_user.first_name
    
    try:
        await client.send_chat_action(message.chat.id, ChatAction.TYPING)
        
        # Cek apakah user sudah punya email aktif
        if user_id in user_sessions:
            session_data = user_sessions[user_id]
            created_at = session_data.get("created_at")
            
            # Cek expired (30 menit)
            if created_at and datetime.now() - created_at < timedelta(minutes=30):
                email = session_data.get("email")
                remaining, minutes, seconds = get_remaining_time(created_at)
                
                if remaining > 0:
                    await message.reply_text(
                        f"<blockquote><b>⚠️ EMAIL SUDAH ADA</b>\n\n"
                        f"📩 <b>Email:</b> <code>{email}</code>\n"
                        f"⏳ <b>Sisa waktu:</b> {minutes} menit {seconds} detik\n\n"
                        f"Gunakan:\n"
                        f"• <code>.inbox</code> - Lihat pesan\n"
                        f"• <code>.refreshmail</code> - Refresh inbox\n"
                        f"• <code>.deletemail</code> - Buat email baru</blockquote>"
                    )
                    return
        
        processing = await message.reply_text(f"{prs} <b>Membuat email baru...</b>")
        
        email_data = await create_email()
        
        if not email_data:
            await processing.edit_text(f"{ggl} <b>Gagal membuat email!</b>")
            return
        
        session_id = email_data["id"]
        email = email_data["email"]
        expires_at = email_data["expiresAt"]
        
        # Simpan session
        user_sessions[user_id] = {
            "id": session_id,
            "email": email,
            "expiresAt": expires_at,
            "created_at": datetime.now()
        }
        
        await processing.delete()
        
        await message.reply_text(
            f"<blockquote><b>✅ EMAIL BERHASIL DIBUAT</b>\n\n"
            f"📩 <b>Email:</b> <code>{email}</code>\n"
            f"🆔 <b>Session ID:</b> <code>{session_id[:20]}...</code>\n"
            f"⏳ <b>Aktif hingga:</b> {format_expiry(expires_at)}\n\n"
            f"<b>Perintah:</b>\n"
            f"• <code>.inbox</code> - Lihat pesan masuk\n"
            f"• <code>.refreshmail</code> - Refresh inbox\n"
            f"• <code>.deletemail</code> - Hapus email</blockquote>"
        )
        
    except Exception as e:
        await message.reply_text(f"{ggl} <b>Error: {str(e)[:100]}</b>")

@PY.UBOT("myemail")
async def my_email(client: Client, message: Message):
    """Lihat email aktif"""
    ggl = await EMO.GAGAL(client)
    
    user_id = message.from_user.id
    
    if user_id not in user_sessions:
        await message.reply_text(
            f"{ggl} <b>Belum punya email!</b>\n"
            f"Gunakan <code>.createemail</code> untuk membuat."
        )
        return
    
    session_data = user_sessions[user_id]
    email = session_data.get("email")
    created_at = session_data.get("created_at")
    expires_at = session_data.get("expiresAt")
    
    # Cek expired
    if created_at and datetime.now() - created_at > timedelta(minutes=30):
        del user_sessions[user_id]
        await message.reply_text(
            f"{ggl} <b>Email expired!</b>\n"
            f"Gunakan <code>.createemail</code> untuk membuat baru."
        )
        return
    
    remaining, minutes, seconds = get_remaining_time(created_at)
    
    await message.reply_text(
        f"<blockquote><b>📧 EMAIL AKTIF</b>\n\n"
        f"📩 <b>Email:</b> <code>{email}</code>\n"
        f"⏳ <b>Sisa waktu:</b> {minutes} menit {seconds} detik\n"
        f"📅 <b>Expired:</b> {format_expiry(expires_at)}</blockquote>"
    )

@PY.UBOT("inbox")
async def check_inbox(client: Client, message: Message):
    """Lihat inbox email"""
    ggl = await EMO.GAGAL(client)
    prs = await EMO.PROSES(client)
    
    user_id = message.from_user.id
    
    if user_id not in user_sessions:
        await message.reply_text(
            f"{ggl} <b>Belum punya email!</b>\n"
            f"Gunakan <code>.createemail</code> dulu."
        )
        return
    
    session_data = user_sessions[user_id]
    session_id = session_data.get("id")
    email = session_data.get("email")
    created_at = session_data.get("created_at")
    
    # Cek expired
    if created_at and datetime.now() - created_at > timedelta(minutes=30):
        del user_sessions[user_id]
        await message.reply_text(
            f"{ggl} <b>Email expired!</b>\n"
            f"Gunakan <code>.createemail</code> untuk membuat baru."
        )
        return
    
    processing = await message.reply_text(f"{prs} <b>Mengecek inbox...</b>")
    
    inbox_data = await get_inbox(session_id)
    
    if not inbox_data:
        await processing.edit_text(f"{ggl} <b>Gagal mengambil inbox!</b>")
        return
    
    mails = inbox_data.get("mails", [])
    
    if not mails:
        await processing.edit_text(
            f"<blockquote><b>📭 INBOX KOSONG</b>\n\n"
            f"📩 <b>Email:</b> <code>{email}</code>\n\n"
            f"Belum ada pesan masuk.\n"
            f"Gunakan <code>.refreshmail</code> untuk cek ulang.</blockquote>"
        )
        return
    
    # Ambil 5 pesan terbaru
    recent_mails = mails[:5]
    
    text = f"<blockquote><b>📨 INBOX - {email}</b>\n\n"
    text += f"<b>Total pesan:</b> {len(mails)}\n\n"
    
    for i, mail in enumerate(recent_mails, 1):
        from_email = mail.get("from", {}).get("name", "Unknown")
        subject = mail.get("subject", "No Subject")
        intro = mail.get("intro", "")
        date = mail.get("date", "")
        
        # Format tanggal
        if date and len(date) > 10:
            date = date[:10]  # Ambil YYYY-MM-DD
        
        text += f"<b>{i}. {from_email}</b> ({date})\n"
        text += f"<code>Subject: {subject}</code>\n"
        if intro:
            text += f"<code>{intro[:50]}{'...' if len(intro) > 50 else ''}</code>\n"
        text += "\n"
    
    if len(mails) > 5:
        text += f"<i>...dan {len(mails)-5} pesan lainnya</i>\n\n"
    
    text += f"<b>Refresh:</b> <code>.refreshmail</code></blockquote>"
    
    await processing.delete()
    await message.reply_text(text)

@PY.UBOT("refreshmail")
async def refresh_inbox(client: Client, message: Message):
    """Refresh inbox"""
    await check_inbox(client, message)

@PY.UBOT("deletemail")
async def delete_email(client: Client, message: Message):
    """Hapus email"""
    ggl = await EMO.GAGAL(client)
    sks = await EMO.BERHASIL(client)
    
    user_id = message.from_user.id
    
    if user_id not in user_sessions:
        await message.reply_text(f"{ggl} <b>Belum punya email!</b>")
        return
    
    del user_sessions[user_id]
    
    await message.reply_text(
        f"<blockquote><b>✅ EMAIL DIHAPUS</b>\n\n"
        f"Email berhasil dihapus.\n"
        f"Gunakan <code>.createemail</code> untuk membuat baru.</blockquote>"
    )

@PY.UBOT("emailinfo")
async def email_info(client: Client, message: Message):
    """Info fitur email"""
    
    text = """
<blockquote><b>📧 INFO FAKE EMAIL V2</b>

<b>Sumber:</b> api.vreden.my.id
<b>Update:</b> Real-time
<b>Masa aktif:</b> 30 menit

<b>Fitur:</b>
• Buat email temporary
• Lihat inbox pesan
• Refresh otomatis
• Hapus email

<b>Cara pakai:</b>
1. <code>.createemail</code> - Buat email baru
2. <code>.myemail</code> - Lihat email aktif
3. <code>.inbox</code> - Cek pesan masuk
4. <code>.refreshmail</code> - Refresh inbox
5. <code>.deletemail</code> - Hapus email

<b>Contoh:</b>
<code>.createemail</code>
<code>.inbox</code>
<code>.refreshmail</code></blockquote>"""
    
    await message.reply_text(text)