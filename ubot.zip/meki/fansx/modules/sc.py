__MODULE__ = "ꜱᴏᴜɴᴅᴄʟᴏᴜᴅ"
__HELP__ = """
<blockquote>
<b>「 ꜱᴏᴜɴᴅᴄʟᴏᴜᴅ ᴅᴏᴡɴʟᴏᴀᴅᴇʀ 」</b>

• <b>ᴘᴇʀɪɴᴛᴀʜ:</b> <code>{0}sc</code> <b>[ʟɪɴᴋ]</b>
• <b>ꜰᴜɴɢꜱɪ:</b> ᴍᴇɴɢᴜɴᴅᴜʜ ᴍᴜꜱɪᴋ ᴅᴀʀɪ ꜱᴏᴜɴᴅᴄʟᴏᴜᴅ

• <b>ᴄᴏɴᴛᴏʜ:</b> <code>{0}sc https://soundcloud.com/username/title</code>
</blockquote>
"""

import asyncio
import requests
import os
import time as time_module
import json
import aiohttp
import random
from fansx import *

# Daftar API keys untuk BetaBotz API
API_KEYS = [
    "eIxUwMpn",
    "keoCFdc6",
    "bv7m372F",
    "iAiB9QKT",
    "JP7Cy8Y2",
    "GI4vPxYv",
    "HRPga9TN",
    "PDwqhVsj",
    "m8jpBeZR",
    "PXkxh5hw",
    "MFnlpM6A",
    "u299UiOF"
    
]

def get_random_apikey():
    """Mengambil API key secara random dari daftar"""
    return random.choice(API_KEYS)

async def download_file(url, path):
    """Download file from URL"""
    try:
        async with aiohttp.ClientSession() as session:
            async with session.get(url, timeout=30) as response:
                if response.status == 200:
                    with open(path, 'wb') as f:
                        f.write(await response.read())
                    return True
                return False
    except Exception as e:
        print(f"Error download file: {str(e)}")
        return False

async def extract_data_from_response(data):
    """Extract music URL and metadata from the BetaBotz API response"""
    try:
        # Akses data dari struktur respons BetaBotz API
        if not data.get("status"):
            return "", "ꜱᴏᴜɴᴅᴄʟᴏᴜᴅ ᴛʀᴀᴄᴋ", ""
        
        result = data.get("result", {})
        
        # Ambil URL musik
        music_url = result.get("url", "")
        
        # Ambil metadata
        title = result.get("title", "ꜱᴏᴜɴᴅᴄʟᴏᴜᴅ ᴛʀᴀᴄᴋ")
        thumbnail = result.get("thumbnail", "")
        
        return music_url, title, thumbnail
    except Exception as e:
        print(f"Error extracting data: {str(e)}")
        return "", "ꜱᴏᴜɴᴅᴄʟᴏᴜᴅ ᴛʀᴀᴄᴋ", ""

async def downloader_soundcloud(client, message, url):
    """SoundCloud downloader function with BetaBotz API"""
    process_msg = await message.reply(
        "<blockquote><b>⏳ ꜱᴇᴅᴀɴɢ ᴍᴇᴍᴘʀᴏꜱᴇꜱ ᴘᴇʀᴍɪɴᴛᴀᴀɴ...</b></blockquote>"
    )
    
    # Coba dengan beberapa API key
    success = False
    used_keys = set()
    max_attempts = min(3, len(API_KEYS))
    
    for attempt in range(max_attempts):
        # Ambil API key yang belum dicoba
        available_keys = [key for key in API_KEYS if key not in used_keys]
        if not available_keys:
            break
            
        apikey = random.choice(available_keys)
        used_keys.add(apikey)
        
        # Gunakan BetaBotz API dengan key random
        api_url = f"https://api.betabotz.eu.org/api/download/soundcloud?url={url}&apikey={apikey}"
        
        try:
            await process_msg.edit(
                f"<blockquote><b>🔍 ᴍᴇɴᴄᴏʙᴀ ᴅᴇɴɢᴀɴ ᴋᴇʏ ᴋᴇ-{attempt+1}...</b></blockquote>"
            )
            
            res = requests.get(api_url, timeout=15)
            
            if res.status_code != 200:
                continue
            
            try:
                data = res.json()
            except json.JSONDecodeError:
                continue
            
            music_url, title, thumbnail = await extract_data_from_response(data)
            
            if not music_url:
                continue
            
            await process_msg.edit(
                "<blockquote><b>📥 ᴍᴇɴɢᴜɴᴅᴜʜ ᴍᴜꜱɪᴋ...</b></blockquote>"
            )
            
            music_path = f"soundcloud_music_{int(time_module.time())}.mp3"
            
            if await download_file(music_url, music_path):
                await process_msg.edit(
                    "<blockquote><b>📤 ꜱᴇᴅᴀɴɢ ᴍᴇɴɢɪʀɪᴍ ᴀᴜᴅɪᴏ...</b></blockquote>"
                )
                
                title_short = title[:40] + "..." if len(title) > 40 else title
                
                # Download thumbnail jika tersedia
                thumb_path = None
                if thumbnail:
                    thumb_path = f"soundcloud_thumb_{int(time_module.time())}.jpg"
                    await download_file(thumbnail, thumb_path)
                
                try:
                    await client.send_audio(
                        message.chat.id, 
                        music_path, 
                        thumb=thumb_path if thumb_path else None,
                        caption=f"""
<blockquote>
<b>┏━═━═━═━═━═━═━═━═━┓</b>
<b>┃ 🎵 UBOT PREMIUM ZYURA</b>
<b>┗━═━═━═━═━═━═━═━═━┛</b>

<code>🎵 ᴍᴜꜱɪᴋ ꜱᴏᴜɴᴅᴄʟᴏᴜᴅ</code>
<code>📝 ᴊᴜᴅᴜʟ:</code> <i>{title_short}</i>
<code>🔗 ᴜʀʟ:</code> <code>{url}</code>
<code>⬇️ ᴏʟᴇʜ:</code> {client.me.mention}
<code>⚡️ ᴘᴏᴡᴇʀᴇᴅ ʙʏ:</code> <code>Ubot Premium Zyura</code>
<code>🔑 ᴋᴇʏ:</code> <code>{apikey[:8]}...</code>
</blockquote>"""
                    )
                    
                    success = True
                    break
                finally:
                    # Bersihkan file temporary
                    if os.path.exists(music_path):
                        os.remove(music_path)
                    if thumb_path and os.path.exists(thumb_path):
                        os.remove(thumb_path)
            else:
                continue
                
        except requests.exceptions.Timeout:
            continue
        except requests.exceptions.RequestException:
            continue
        except Exception as e:
            print(f"Error attempt {attempt+1}: {str(e)}")
            continue
    
    if not success:
        await process_msg.edit(
            "<blockquote><b>❌ ɢᴀɢᴀʟ ᴍᴇɴɢᴜɴᴅᴜʜ ᴀᴜᴅɪᴏ ꜱᴇᴛᴇʟᴀʜ ʙᴇʙᴇʀᴀᴘᴀ ᴘᴇʀᴄᴏʙᴀᴀɴ!\n\n"
            "ᴘᴇɴʏᴇʙᴀʙ ᴋᴇᴍᴜɴɢᴋɪɴᴀɴ:\n"
            "• ʟɪɴᴋ ꜱᴏᴜɴᴅᴄʟᴏᴜᴅ ᴛɪᴅᴀᴋ ᴠᴀʟɪᴅ\n"
            "• ꜱᴇʀᴠᴇʀ ᴀᴘɪ ꜱᴇᴅᴀɴɢ ꜱɪʙᴜᴋ\n"
            "• ᴋᴇʏ ᴀᴘɪ ʜᴀʙɪꜱ ʟɪᴍɪᴛ\n\n"
            "ꜱɪʟᴀᴋᴀɴ ᴄᴏʙᴀ ʟᴀɢɪ ɴᴀɴᴛɪ ᴀᴛᴀᴜ ɢᴜɴᴀᴋᴀɴ ʟɪɴᴋ ʟᴀɪɴ.</b></blockquote>"
        )

@PY.UBOT("sc")
async def soundcloud_downloader(client, message):
    """Command handler for SoundCloud downloads"""
    # Hapus pesan perintah pengguna
    try:
        await message.delete()
    except Exception as e:
        pass  # Jika gagal menghapus, lanjutkan saja
    
    if len(message.command) < 2:
        await client.send_message(
            message.chat.id,
            f"""
<blockquote>
<b>❌ ꜰᴏʀᴍᴀᴛ ᴘᴇʀɪɴᴛᴀʜ ᴛɪᴅᴀᴋ ʟᴇɴɢᴋᴀᴘ!</b>

<b>ᴄᴀʀᴀ ᴘᴇɴɢɢᴜɴᴀᴀɴ:</b>
<code>{message.text.split()[0]}</code> <i>[ʟɪɴᴋ ꜱᴏᴜɴᴅᴄʟᴏᴜᴅ]</i> → ᴜɴᴛᴜᴋ ᴍᴇɴɢᴜɴᴅᴜʜ ᴍᴜꜱɪᴋ

<b>ᴄᴏɴᴛᴏʜ:</b>
<code>{message.text.split()[0]} https://soundcloud.com/artist/song</code>
</blockquote>
"""
        )
        return
        
    soundcloud_url = " ".join(message.command[1:])
    
    # Validasi URL SoundCloud sederhana
    if "soundcloud.com" not in soundcloud_url:
        await client.send_message(
            message.chat.id,
            "<blockquote><b>❌ ʟɪɴᴋ ʏᴀɴɢ ᴀɴᴅᴀ ʙᴇʀɪᴋᴀɴ ʙᴜᴋᴀɴ ʟɪɴᴋ ꜱᴏᴜɴᴅᴄʟᴏᴜᴅ ʏᴀɴɢ ᴠᴀʟɪᴅ!</b></blockquote>"
        )
        return
    
    await downloader_soundcloud(client, message, soundcloud_url)

@PY.BOT("sc")
async def soundcloud_downloader_bot(client, message):
    """Command handler for bot (with /)"""
    if len(message.command) < 2:
        await message.reply_text(
            f"""
<blockquote>
<b>❌ ꜰᴏʀᴍᴀᴛ ᴘᴇʀɪɴᴛᴀʜ ᴛɪᴅᴀᴋ ʟᴇɴɢᴋᴀᴘ!</b>

<b>ᴄᴀʀᴀ ᴘᴇɴɢɢᴜɴᴀᴀɴ:</b>
<code>/sc</code> <i>[ʟɪɴᴋ ꜱᴏᴜɴᴅᴄʟᴏᴜᴅ]</i> → ᴜɴᴛᴜᴋ ᴍᴇɴɢᴜɴᴅᴜʜ ᴍᴜꜱɪᴋ

<b>ᴄᴏɴᴛᴏʜ:</b>
<code>/sc https://soundcloud.com/artist/song</code>
</blockquote>
"""
        )
        return
        
    soundcloud_url = " ".join(message.command[1:])
    
    # Validasi URL SoundCloud sederhana
    if "soundcloud.com" not in soundcloud_url:
        await message.reply_text(
            "<blockquote><b>❌ ʟɪɴᴋ ʏᴀɴɢ ᴀɴᴅᴀ ʙᴇʀɪᴋᴀɴ ʙᴜᴋᴀɴ ʟɪɴᴋ ꜱᴏᴜɴᴅᴄʟᴏᴜᴅ ʏᴀɴɢ ᴠᴀʟɪᴅ!</b></blockquote>"
        )
        return
    
    await downloader_soundcloud(client, message, soundcloud_url)