from fansx import *
import aiohttp
import asyncio
import os
import random
from urllib.parse import quote
from pyrogram.enums import ChatAction, ParseMode
from pyrogram.types import Message

__MODULE__ = "ᴇ-ᴋᴛᴘ ɢᴇɴᴇʀᴀᴛᴏʀ ᴠ2"
__HELP__ = """
<blockquote><b>🆔 E-KTP GENERATOR V2</b>

<b>⌲ Perintah:</b>
ᚗ <code>{0}ektpv2</code> - Panduan lengkap
ᚗ <code>{0}ektp2 [provinsi]|[kota]|[nik]|[nama]|[ttl]</code> - Format minimal
ᚗ <code>{0}ektp2 [provinsi]|[kota]|[nik]|[nama]|[ttl]|[jk]|[goldar]|[alamat]|[rtrw]|[desa]|[kec]|[agama]|[status]|[kerja]|[warga]|[berlaku]|[terbuat]|[foto]</code> - Format lengkap

<b>⌲ Contoh format minimal:</b>
<code>.ektp2 JAWA BARAT|BANDUNG|1234567890123456|John Doe|Bandung, 01-01-1990</code>

<b>⌲ Contoh format lengkap:</b>
<code>.ektp2 JAWA BARAT|BANDUNG|1234567890123456|John Doe|Bandung, 01-01-1990|Laki-laki|O|Jl. Contoh No. 123|001/002|Sukajadi|Sukajadi|Islam|Belum Kawin|Pegawai Swasta|WNI|Seumur Hidup|01-01-2023|https://i.pinimg.com/736x/0b/9f/0a/0b9f0a92a598e6c22629004c1027d23f.jpg</code>

<b>⌲ Data akan otomatis di-uppercase untuk format E-KTP</b></blockquote>
"""

# ============================================
# KONFIGURASI
# ============================================
BASE_URL = "https://api.siputzx.my.id/api/canvas/ektp"

def clean_text(text):
    """Bersihkan teks untuk URL"""
    if not text:
        return ""
    return quote(str(text).strip().upper())

def parse_input(input_text):
    """Parse input dari user dengan format | separator"""
    parts = [p.strip() for p in input_text.split('|')]
    
    # Default values (kosong)
    data = {
        "provinsi": "",
        "kota": "",
        "nik": "",
        "nama": "",
        "ttl": "",
        "jenis_kelamin": "LAKI-LAKI",
        "golongan_darah": "O",
        "alamat": "JL. CONTOH NO. 123",
        "rt_rw": "001/002",
        "kel_desa": "SUKAJADI",
        "kecamatan": "SUKAJADI",
        "agama": "ISLAM",
        "status": "BELUM KAWIN",
        "pekerjaan": "PEGAWAI SWASTA",
        "kewarganegaraan": "WNI",
        "masa_berlaku": "SEUMUR HIDUP",
        "terbuat": "01-01-2023",
        "pas_photo": "https://i.pinimg.com/736x/0b/9f/0a/0b9f0a92a598e6c22629004c1027d23f.jpg"
    }
    
    # Update dengan input user (5 data pertama wajib)
    if len(parts) >= 1:
        data["provinsi"] = parts[0].upper()
    if len(parts) >= 2:
        data["kota"] = parts[1].upper()
    if len(parts) >= 3:
        data["nik"] = parts[2]
    if len(parts) >= 4:
        data["nama"] = parts[3].upper()
    if len(parts) >= 5:
        data["ttl"] = parts[4].upper()
    if len(parts) >= 6:
        data["jenis_kelamin"] = parts[5].upper()
    if len(parts) >= 7:
        data["golongan_darah"] = parts[6].upper()
    if len(parts) >= 8:
        data["alamat"] = parts[7].upper()
    if len(parts) >= 9:
        data["rt_rw"] = parts[8]
    if len(parts) >= 10:
        data["kel_desa"] = parts[9].upper()
    if len(parts) >= 11:
        data["kecamatan"] = parts[10].upper()
    if len(parts) >= 12:
        data["agama"] = parts[11].upper()
    if len(parts) >= 13:
        data["status"] = parts[12].upper()
    if len(parts) >= 14:
        data["pekerjaan"] = parts[13].upper()
    if len(parts) >= 15:
        data["kewarganegaraan"] = parts[14].upper()
    if len(parts) >= 16:
        data["masa_berlaku"] = parts[15].upper()
    if len(parts) >= 17:
        data["terbuat"] = parts[16]
    if len(parts) >= 18:
        data["pas_photo"] = parts[17]
    
    return data

def validate_data(data):
    """Validasi data wajib"""
    if not data["provinsi"]:
        return False, "Provinsi tidak boleh kosong"
    if not data["kota"]:
        return False, "Kota tidak boleh kosong"
    if not data["nik"] or len(data["nik"]) != 16:
        return False, "NIK harus 16 digit"
    if not data["nama"]:
        return False, "Nama tidak boleh kosong"
    if not data["ttl"]:
        return False, "Tempat/tanggal lahir tidak boleh kosong"
    return True, "OK"

async def generate_ektp(data):
    """Generate E-KTP dari API"""
    try:
        # Build URL dengan parameter
        params = {
            "provinsi": clean_text(data["provinsi"]),
            "kota": clean_text(data["kota"]),
            "nik": data["nik"],
            "nama": clean_text(data["nama"]),
            "ttl": clean_text(data["ttl"]),
            "jenis_kelamin": clean_text(data["jenis_kelamin"]),
            "golongan_darah": data["golongan_darah"],
            "alamat": clean_text(data["alamat"]),
            "rt/rw": data["rt_rw"],
            "kel/desa": clean_text(data["kel_desa"]),
            "kecamatan": clean_text(data["kecamatan"]),
            "agama": clean_text(data["agama"]),
            "status": clean_text(data["status"]),
            "pekerjaan": clean_text(data["pekerjaan"]),
            "kewarganegaraan": data["kewarganegaraan"],
            "masa_berlaku": clean_text(data["masa_berlaku"]),
            "terbuat": data["terbuat"],
            "pas_photo": data["pas_photo"]
        }
        
        # Build query string
        query_parts = []
        for key, value in params.items():
            if value:  # Hanya parameter yang tidak kosong
                query_parts.append(f"{key}={value}")
        
        url = f"{BASE_URL}?{'&'.join(query_parts)}"
        
        # Download gambar
        async with aiohttp.ClientSession() as session:
            async with session.get(url, timeout=30) as response:
                if response.status == 200:
                    return await response.read()
                else:
                    print(f"HTTP Error: {response.status}")
    except Exception as e:
        print(f"Error generate E-KTP: {e}")
    return None

@PY.UBOT("ektpv2")
@PY.UBOT("ektp2")
async def ektp_generator_v2(client: Client, message: Message):
    ggl = await EMO.GAGAL(client)
    sks = await EMO.BERHASIL(client)
    prs = await EMO.PROSES(client)
    
    try:
        await client.send_chat_action(message.chat.id, ChatAction.UPLOAD_PHOTO)
        
        # Cek apakah command tanpa argumen
        if len(message.text.split()) == 1:
            await message.reply_text(
                f"<blockquote><b>🆔 E-KTP GENERATOR V2</b>\n\n"
                f"<b>Format minimal (wajib):</b>\n"
                f"<code>.ektp2 provinsi|kota|nik|nama|ttl</code>\n\n"
                f"<b>Format lengkap:</b>\n"
                f"<code>.ektp2 provinsi|kota|nik|nama|ttl|jk|goldar|alamat|rtrw|desa|kec|agama|status|kerja|warga|berlaku|terbuat|foto</code>\n\n"
                f"<b>Contoh minimal:</b>\n"
                f"<code>.ektp2 JAWA BARAT|BANDUNG|1234567890123456|John Doe|Bandung, 01-01-1990</code>\n\n"
                f"<b>Data default untuk parameter opsional:</b>\n"
                f"• JK: Laki-laki\n"
                f"• Goldar: O\n"
                f"• Alamat: Jl. Contoh No. 123\n"
                f"• RT/RW: 001/002\n"
                f"• Desa: Sukajadi\n"
                f"• Kec: Sukajadi\n"
                f"• Agama: Islam\n"
                f"• Status: Belum Kawin\n"
                f"• Pekerjaan: Pegawai Swasta\n"
                f"• Warga: WNI\n"
                f"• Berlaku: Seumur Hidup\n"
                f"• Terbuat: 01-01-2023\n"
                f"• Foto: Default dari Pinterest</blockquote>"
            )
            return
        
        args = message.text.split(maxsplit=1)
        input_data = args[1]
        
        # Parse data
        data = parse_input(input_data)
        
        # Validasi data wajib
        valid, msg = validate_data(data)
        if not valid:
            await message.reply_text(f"{ggl} <b>{msg}</b>")
            return
        
        # Kirim processing
        processing = await message.reply_text(
            f"{prs} <b>Membuat E-KTP...</b>\n"
            f"👤 Nama: {data['nama']}\n"
            f"🆔 NIK: {data['nik']}\n"
            f"📍 Kota: {data['kota']}"
        )
        
        # Generate gambar
        image_data = await generate_ektp(data)
        
        if not image_data:
            await processing.edit_text(f"{ggl} <b>Gagal membuat E-KTP!</b>")
            return
        
        # Simpan sementara
        file_path = f"ektp2_{message.from_user.id}_{random.randint(1000,9999)}.jpg"
        with open(file_path, 'wb') as f:
            f.write(image_data)
        
        await processing.delete()
        
        # Kirim foto
        await client.send_photo(
            chat_id=message.chat.id,
            photo=file_path,
            caption=f"<blockquote><b>🆔 E-KTP GENERATOR V2</b>\n\n"
                    f"👤 <b>Nama:</b> {data['nama']}\n"
                    f"🆔 <b>NIK:</b> {data['nik']}\n"
                    f"📍 <b>Kota:</b> {data['kota']}\n"
                    f"📅 <b>TTL:</b> {data['ttl']}</blockquote>"
        )
        
        # Hapus file
        import os
        if os.path.exists(file_path):
            os.remove(file_path)
        
    except Exception as e:
        await message.reply_text(f"{ggl} <b>Error: {str(e)[:100]}</b>")