from fansx import *
import aiohttp
import asyncio
import os
import random
from pyrogram.enums import ChatAction, ParseMode
from pyrogram.types import Message

__MODULE__ = "ʀᴀɴᴅᴏᴍ ᴄᴏsᴘʟᴀʏ"
__HELP__ = """
<blockquote><b>⌲ Perintah:</b>
ᚗ <code>{0}randcosplay</code> - Ambil random gambar cosplay
ᚗ <code>{0}randcosplay [jumlah]</code> - Ambil beberapa gambar (max 5)

<b>⌲ Contoh:</b>
<code>.randcosplay</code>
<code>.randcosplay 3</code></blockquote>
"""

# ============================================
# KONFIGURASI
# ============================================
COSPLAY_API = "https://rynekoo-api.hf.space/random/cosplay"

# Source cosplay (dari response)
COSPLAY_SOURCE = "Hancame - www.patreon.com/hancame"

async def get_random_cosplay():
    """Ambil random gambar cosplay"""
    
    try:
        async with aiohttp.ClientSession() as session:
            async with session.get(COSPLAY_API, timeout=15) as response:
                if response.status == 200:
                    # Cek content-type
                    content_type = response.headers.get("Content-Type", "")
                    
                    if "image" in content_type:
                        # Langsung gambar
                        return {
                            "success": True,
                            "image": await response.read(),
                            "source": COSPLAY_SOURCE
                        }
                    else:
                        # Cek apakah response berupa teks (mungkin URL)
                        text_response = await response.text()
                        
                        # Cek apakah itu URL
                        if text_response.startswith(('http://', 'https://')):
                            # Download dari URL
                            async with session.get(text_response.strip(), timeout=15) as img_resp:
                                if img_resp.status == 200:
                                    return {
                                        "success": True,
                                        "image": await img_resp.read(),
                                        "source": COSPLAY_SOURCE
                                    }
                        
                        return {
                            "success": False,
                            "error": f"API tidak mengembalikan gambar. Response: {text_response[:100]}"
                        }
                else:
                    return {"success": False, "error": f"HTTP {response.status}"}
    except asyncio.TimeoutError:
        return {"success": False, "error": "Timeout - server terlalu lambat"}
    except Exception as e:
        return {"success": False, "error": str(e)}

@PY.UBOT("randcosplay")
async def randcosplay_command(client: Client, message: Message):
    ggl = await EMO.GAGAL(client)
    sks = await EMO.BERHASIL(client)
    prs = await EMO.PROSES(client)
    
    # Parse jumlah gambar dari argumen
    args = message.text.split()
    count = 1
    if len(args) > 1 and args[1].isdigit():
        count = min(int(args[1]), 5)  # Maksimal 5 gambar biar gak spam
    
    try:
        await client.send_chat_action(message.chat.id, ChatAction.UPLOAD_PHOTO)
        
        processing = await message.reply_text(f"{prs} <b>Mencari {count} gambar cosplay...</b>")
        
        # Koleksi gambar yang berhasil diambil
        images = []
        failed = 0
        
        for i in range(count):
            result = await get_random_cosplay()
            if result.get("success") and result.get("image"):
                images.append({
                    "image": result["image"],
                    "source": result.get("source", COSPLAY_SOURCE)
                })
            else:
                failed += 1
            
            # Jeda antar request biar gak kena limit
            if i < count - 1:
                await asyncio.sleep(1)
        
        await processing.delete()
        
        if images:
            # Kirim gambar satu per satu
            sent_count = 0
            for img_data in images:
                # Simpan gambar sementara
                file_path = f"cosplay_{message.from_user.id}_{random.randint(1000,9999)}.jpg"
                with open(file_path, "wb") as f:
                    f.write(img_data["image"])
                
                # Buat caption
                caption = f"<blockquote><b>📸 Source:</b> {img_data['source']}\n"
                caption += f"\n⚡ Powered by: Ubot Premium Zyura</blockquote>"
                
                # Kirim gambar
                await client.send_photo(
                    chat_id=message.chat.id,
                    photo=file_path,
                    caption=caption
                )
                
                # Hapus file
                if os.path.exists(file_path):
                    os.remove(file_path)
                
                sent_count += 1
                await asyncio.sleep(0.5)  # Jeda biar gak kena flood
            
            # Info tambahan jika ada yang gagal
            if failed > 0:
                await message.reply_text(f"{sks} <b>Berhasil mengirim {sent_count} gambar</b>\n⚠️ {failed} gambar gagal diambil")
        else:
            error_msg = result.get("error", "Unknown error") if 'result' in locals() else "Semua gambar gagal diambil"
            await message.reply_text(
                f"<blockquote><b>❌ GAGAL MENGAMBIL GAMBAR</b>\n\n"
                f"Error: {error_msg}</blockquote>"
            )
        
    except Exception as e:
        await message.reply_text(f"{ggl} <b>Error: {str(e)[:100]}</b>")

