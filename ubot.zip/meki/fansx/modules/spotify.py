from pyrogram import Client, filters
import requests, os
import random
from fansx import *

__MODULE__ = "sᴘᴏᴛɪғʏ"
__HELP__ = """
<b>⦪ ʙᴀɴᴛᴜᴀɴ ᴜɴᴛᴜᴋ sᴘᴏᴛɪғʏ ⦫</b>
<blockquote><b>
⎆ Perintah :
ᚗ <code>{0}spotify</code> judul lagu
⊶ Mendownload dan mengirimkan lagu otomatis.</b></blockquote>
"""

# Base URLs API vreden
SEARCH_URL = "https://api.vreden.my.id/api/v1/search/spotify"
DOWNLOAD_URL = "https://api.vreden.my.id/api/v1/download/spotify"

# Daftar API keys jika diperlukan (kosong karena API vreden mungkin tidak perlu key)
API_KEYS = [
    "",  # Jika tidak perlu API key
]

def get_random_apikey():
    """Mengambil API key secara random dari daftar"""
    return random.choice(API_KEYS)

def format_duration(duration_str):
    """Format duration string to seconds or keep as is"""
    if ":" in duration_str:
        parts = duration_str.split(":")
        if len(parts) == 2:
            minutes, seconds = parts
            return f"{int(minutes)} menit {int(seconds)} detik"
    return duration_str

@PY.UBOT("spotify")
async def spotify_search(client, message):
    query = " ".join(message.command[1:])
    if not query:
        await message.reply_text(
            "<blockquote><b>❌ Gunakan format:</b> <code>.spotify judul lagu</code>\n\n"
            "<b>Contoh:</b> <code>.spotify Jomblo Happy</code></blockquote>"
        )
        return

    proses = await message.reply_text("<blockquote><b>🔎 Sedang mencari lagu...</b></blockquote>")
    
    try:
        # Step 1: Search for the song
        search_params = {
            "query": query,
            "limit": "1"  # Ambil hasil pertama saja
        }
        
        search_response = requests.get(SEARCH_URL, params=search_params, timeout=10)
        
        if search_response.status_code != 200:
            await proses.edit_text(
                f"<blockquote><b>❌ Gagal terhubung ke server! Kode error: {search_response.status_code}</b></blockquote>"
            )
            return
        
        search_data = search_response.json()
        
        if not search_data.get("status"):
            await proses.edit_text(
                "<blockquote><b>❌ API mengembalikan status false</b></blockquote>"
            )
            return
        
        result = search_data.get("result", {})
        search_results = result.get("search_data", [])
        
        if not search_results:
            await proses.edit_text(
                f"<blockquote><b>❌ Tidak ditemukan hasil untuk pencarian:</b> <code>{query}</code></blockquote>"
            )
            return
        
        # Ambil lagu pertama
        song_info = search_results[0]
        
        title = song_info.get("title", "Unknown")
        artist = song_info.get("artist", "Unknown")
        album = song_info.get("album", "Unknown")
        duration = format_duration(song_info.get("duration", "0:00"))
        song_link = song_info.get("song_link", "")
        cover_img = song_info.get("cover_img", "")
        popularity = song_info.get("popularity", "0%")
        release_date = song_info.get("release_date", "Unknown")
        
        await proses.edit_text(
            f"<blockquote><b>🎶 Menemukan lagu:</b>\n\n"
            f"📝 Judul: {title}\n"
            f"👤 Artis: {artist}\n"
            f"💿 Album: {album}\n"
            f"📊 Popularitas: {popularity}\n"
            f"📅 Rilis: {release_date}\n\n"
            f"⏳ Mengunduh...</b></blockquote>"
        )
        
        # Step 2: Download the song using the Spotify link
        if not song_link:
            await proses.edit_text(
                "<blockquote><b>❌ Link Spotify tidak ditemukan dalam response!</b></blockquote>"
            )
            return
        
        download_params = {
            "url": song_link
        }
        
        download_response = requests.get(DOWNLOAD_URL, params=download_params, timeout=15)
        
        if download_response.status_code != 200:
            await proses.edit_text(
                f"<blockquote><b>❌ Gagal mengunduh! Kode error: {download_response.status_code}</b></blockquote>"
            )
            return
        
        download_data = download_response.json()
        
        if not download_data.get("status"):
            await proses.edit_text(
                "<blockquote><b>❌ API download mengembalikan status false</b></blockquote>"
            )
            return
        
        download_result = download_data.get("result", {})
        download_link = download_result.get("download", "")
        
        if not download_link:
            await proses.edit_text(
                "<blockquote><b>❌ Link download tidak ditemukan!</b></blockquote>"
            )
            return
        
        # Gunakan informasi dari download result jika ada
        download_title = download_result.get("title", title)
        download_artists = download_result.get("artists", artist)
        download_cover = download_result.get("cover_url", cover_img)
        
        # Download the audio file
        filename = f"spotify_{title.replace(' ', '_')[:30]}.mp3"
        
        audio_response = requests.get(download_link, timeout=30)
        
        if audio_response.status_code != 200:
            await proses.edit_text(
                "<blockquote><b>❌ Gagal mengunduh file audio!</b></blockquote>"
            )
            return
        
        with open(filename, "wb") as f:
            f.write(audio_response.content)
        
        # Download cover image for thumbnail
        thumb_filename = None
        if download_cover:
            try:
                thumb_response = requests.get(download_cover, timeout=10)
                if thumb_response.status_code == 200:
                    thumb_filename = f"thumb_{title.replace(' ', '_')[:20]}.jpg"
                    with open(thumb_filename, "wb") as f:
                        f.write(thumb_response.content)
            except Exception as e:
                print(f"Error downloading thumbnail: {e}")
        
        # Prepare caption
        caption = (
            f"<blockquote><b>🎵 Spotify Downloader</b>\n\n"
            f"📝 <b>Judul:</b> {download_title}\n"
            f"👤 <b>Artis:</b> {download_artists}\n"
            f"💿 <b>Album:</b> {album}\n"
            f"⏱️ <b>Durasi:</b> {duration}\n"
            f"📊 <b>Popularitas:</b> {popularity}\n"
            f"📅 <b>Rilis:</b> {release_date}\n\n"
            f"⚡ <b>Powered by:</b> Ubot Premium Zyura</blockquote>"
        )
        
        # Send the audio file
        await client.send_audio(
            chat_id=message.chat.id,
            audio=filename,
            title=download_title[:50] if len(download_title) > 50 else download_title,
            performer=download_artists[:50] if len(download_artists) > 50 else download_artists,
            caption=caption,
            thumb=thumb_filename if thumb_filename else None
        )
        
        # Clean up files
        if os.path.exists(filename):
            os.remove(filename)
        if thumb_filename and os.path.exists(thumb_filename):
            os.remove(thumb_filename)
        
        await proses.delete()
        
    except requests.exceptions.Timeout:
        await proses.edit_text(
            "<blockquote><b>⏱️ Waktu permintaan habis! Server sedang sibuk.</b></blockquote>"
        )
    except requests.exceptions.ConnectionError:
        await proses.edit_text(
            "<blockquote><b>❌ Gagal terhubung ke server! Periksa koneksi internet.</b></blockquote>"
        )
    except Exception as e:
        await proses.edit_text(
            f"<blockquote><b>❌ Error:</b> <code>{str(e)[:100]}</code></blockquote>"
        )

@PY.BOT("spotify")
async def spotify_search_bot(client, message):
    query = " ".join(message.command[1:])
    if not query:
        await message.reply_text(
            "<blockquote><b>❌ Gunakan format:</b> <code>/spotify judul lagu</code>\n\n"
            "<b>Contoh:</b> <code>/spotify Jomblo Happy</code></blockquote>"
        )
        return

    proses = await message.reply_text("<blockquote><b>🔎 Sedang mencari lagu...</b></blockquote>")
    
    try:
        # Step 1: Search for the song
        search_params = {
            "query": query,
            "limit": "1"
        }
        
        search_response = requests.get(SEARCH_URL, params=search_params, timeout=10)
        
        if search_response.status_code != 200:
            await proses.edit_text(
                f"<blockquote><b>❌ Gagal terhubung ke server! Kode error: {search_response.status_code}</b></blockquote>"
            )
            return
        
        search_data = search_response.json()
        
        if not search_data.get("status"):
            await proses.edit_text(
                "<blockquote><b>❌ API mengembalikan status false</b></blockquote>"
            )
            return
        
        result = search_data.get("result", {})
        search_results = result.get("search_data", [])
        
        if not search_results:
            await proses.edit_text(
                f"<blockquote><b>❌ Tidak ditemukan hasil untuk pencarian:</b> <code>{query}</code></blockquote>"
            )
            return
        
        # Ambil lagu pertama
        song_info = search_results[0]
        
        title = song_info.get("title", "Unknown")
        artist = song_info.get("artist", "Unknown")
        album = song_info.get("album", "Unknown")
        duration = format_duration(song_info.get("duration", "0:00"))
        song_link = song_info.get("song_link", "")
        cover_img = song_info.get("cover_img", "")
        popularity = song_info.get("popularity", "0%")
        release_date = song_info.get("release_date", "Unknown")
        
        await proses.edit_text(
            f"<blockquote><b>🎶 Menemukan lagu:</b>\n\n"
            f"📝 Judul: {title}\n"
            f"👤 Artis: {artist}\n"
            f"💿 Album: {album}\n"
            f"📊 Popularitas: {popularity}\n"
            f"📅 Rilis: {release_date}\n\n"
            f"⏳ Mengunduh...</b></blockquote>"
        )
        
        # Step 2: Download the song
        if not song_link:
            await proses.edit_text(
                "<blockquote><b>❌ Link Spotify tidak ditemukan!</b></blockquote>"
            )
            return
        
        download_params = {
            "url": song_link
        }
        
        download_response = requests.get(DOWNLOAD_URL, params=download_params, timeout=15)
        
        if download_response.status_code != 200:
            await proses.edit_text(
                f"<blockquote><b>❌ Gagal mengunduh! Kode error: {download_response.status_code}</b></blockquote>"
            )
            return
        
        download_data = download_response.json()
        
        if not download_data.get("status"):
            await proses.edit_text(
                "<blockquote><b>❌ API download mengembalikan status false</b></blockquote>"
            )
            return
        
        download_result = download_data.get("result", {})
        download_link = download_result.get("download", "")
        
        if not download_link:
            await proses.edit_text(
                "<blockquote><b>❌ Link download tidak ditemukan!</b></blockquote>"
            )
            return
        
        download_title = download_result.get("title", title)
        download_artists = download_result.get("artists", artist)
        download_cover = download_result.get("cover_url", cover_img)
        
        # Download audio
        filename = f"spotify_{title.replace(' ', '_')[:30]}.mp3"
        
        audio_response = requests.get(download_link, timeout=30)
        
        if audio_response.status_code != 200:
            await proses.edit_text(
                "<blockquote><b>❌ Gagal mengunduh file audio!</b></blockquote>"
            )
            return
        
        with open(filename, "wb") as f:
            f.write(audio_response.content)
        
        # Download thumbnail
        thumb_filename = None
        if download_cover:
            try:
                thumb_response = requests.get(download_cover, timeout=10)
                if thumb_response.status_code == 200:
                    thumb_filename = f"thumb_{title.replace(' ', '_')[:20]}.jpg"
                    with open(thumb_filename, "wb") as f:
                        f.write(thumb_response.content)
            except Exception:
                pass
        
        # Send audio
        caption = (
            f"<blockquote><b>🎵 Spotify Downloader</b>\n\n"
            f"📝 <b>Judul:</b> {download_title}\n"
            f"👤 <b>Artis:</b> {download_artists}\n"
            f"💿 <b>Album:</b> {album}\n"
            f"⏱️ <b>Durasi:</b> {duration}\n"
            f"📊 <b>Popularitas:</b> {popularity}\n"
            f"📅 <b>Rilis:</b> {release_date}\n\n"
            f"⚡ <b>Powered by:</b> Ubot Premium Zyura</blockquote>"
        )
        
        await client.send_audio(
            chat_id=message.chat.id,
            audio=filename,
            title=download_title[:50],
            performer=download_artists[:50],
            caption=caption,
            thumb=thumb_filename if thumb_filename else None
        )
        
        # Clean up
        if os.path.exists(filename):
            os.remove(filename)
        if thumb_filename and os.path.exists(thumb_filename):
            os.remove(thumb_filename)
        
        await proses.delete()
        
    except Exception as e:
        await proses.edit_text(
            f"<blockquote><b>❌ Error:</b> <code>{str(e)[:100]}</code></blockquote>"
        )