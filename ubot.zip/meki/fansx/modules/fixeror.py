from fansx import *
import requests
import random
import os
import re
import asyncio
from pyrogram.enums import ChatAction, ParseMode
from pyrogram.types import Message

__MODULE__ = "ғɪx ᴄᴏᴅᴇ"
__HELP__ = """
<blockquote><b>『 FIX CODE 』</b>

<b>⌲ Perintah:</b>
ᚗ <code>{0}fixcode</code> [balas ke pesan/file kode]
⊶ Memperbaiki kode yang error menggunakan AI

<b>⌲ Cara Pakai:</b>
1. Reply ke pesan teks yang berisi kode error
2. Atau reply ke file kode (.py, .js, .java, .cpp, dll)
3. Ketik <code>.fixcode</code>

<b>⌲ Contoh:</b>
<code>.fixcode</code> (reply ke kode error)</blockquote>
"""

# ============================================
# 12 API KEYS (LANGSUNG DI SINI)
# ============================================
API_KEYS = [
    "eIxUwMpn",
    "keoCFdc6",
    "bv7m372F",
    "iAiB9QKT",
    "JP7Cy8Y2",
    "GI4vPxYv",
    "HRPga9TN",
    "PDwqhVsj",
    "m8jpBeZR",
    "PXkxh5hw",
    "MFnlpM6A",
    "u299UiOF"
]

# Base URL API BOTCAHX
BASE_URL = "https://api.botcahx.eu.org/api/search/c-ai"

# Ekstensi file yang didukung
SUPPORTED_EXTENSIONS = {
    '.py': 'python',
    '.js': 'javascript',
    '.java': 'java',
    '.cpp': 'cpp',
    '.c': 'c',
    '.php': 'php',
    '.html': 'html',
    '.css': 'css',
    '.json': 'json',
    '.go': 'go',
    '.rb': 'ruby',
    '.rs': 'rust',
    '.swift': 'swift',
    '.kt': 'kotlin',
    '.ts': 'typescript'
}

def get_random_apikey():
    """Mengambil API key secara random dari 12 key"""
    return random.choice(API_KEYS)

def detect_language(code, filename=None):
    """Deteksi bahasa pemrograman dari kode atau nama file"""
    
    # Deteksi dari ekstensi file
    if filename:
        ext = os.path.splitext(filename)[1].lower()
        if ext in SUPPORTED_EXTENSIONS:
            return SUPPORTED_EXTENSIONS[ext]
    
    # Deteksi dari konten kode
    if 'def ' in code and 'import ' in code and ':' in code:
        return 'python'
    elif '#include' in code or 'cout <<' in code or 'cin >>' in code:
        return 'cpp'
    elif 'public class' in code or 'System.out.println' in code:
        return 'java'
    elif 'function' in code or '=>' in code or 'const ' in code or 'let ' in code:
        return 'javascript'
    elif '<?php' in code:
        return 'php'
    elif '<!DOCTYPE html>' in code or '<html>' in code:
        return 'html'
    elif 'package main' in code and 'func ' in code:
        return 'go'
    elif 'def ' in code and 'end' in code:
        return 'ruby'
    
    return 'text'  # default

def clean_response(text):
    """Bersihkan response dari tag HTML dan kalimat pengantar"""
    
    # Hapus tag HTML
    text = re.sub(r'<[^>]+>', '', text)
    
    # Hapus kalimat pengantar
    patterns = [
        r'^(Baik|Oke|Saya akan|Tentu|Ok|Oke,|Baiklah|Berikut|Ini dia).*?\n',
        r'^Halo.*?\n',
        r'^Hai.*?\n',
        r'^Saya Hako.*?\n',
        r'^Berikut.*?\n',
        r'^Ini.*?\n'
    ]
    
    for pattern in patterns:
        text = re.sub(pattern, '', text, flags=re.IGNORECASE)
    
    return text.strip()

async def call_fix_code_api(prompt, retry_count=0, max_retries=3):
    """Panggil API BOTCAHX untuk fix code dengan retry"""
    
    # Ambil API key random
    api_key = get_random_apikey()
    
    # Parameter API
    params = {
        'apikey': api_key,
        'prompt': prompt,
        'char': 'Hako'  # Character AI untuk fix code
    }
    
    print(f"🔄 Mencoba dengan API Key: {api_key[:8]}... (percobaan ke-{retry_count + 1})")
    
    try:
        response = requests.get(
            BASE_URL,
            params=params,
            timeout=30
        )
        
        if response.status_code == 200:
            data = response.json()
            
            if data.get('status') and data.get('message'):
                return {
                    'success': True,
                    'message': data['message'],
                    'api_key': api_key
                }
            else:
                error_msg = data.get('message', 'Unknown error')
                raise Exception(error_msg)
        else:
            raise Exception(f"HTTP {response.status_code}")
            
    except Exception as e:
        # Coba lagi dengan key berbeda
        if retry_count < max_retries - 1:
            print(f"❌ API Key {api_key[:8]}... gagal: {e}")
            await asyncio.sleep(1)
            return await call_fix_code_api(prompt, retry_count + 1, max_retries)
        
        return {
            'success': False,
            'error': str(e),
            'api_key': api_key
        }

@PY.UBOT("fixcode")
async def fix_code(client: Client, message: Message):
    ggl = await EMO.GAGAL(client)
    sks = await EMO.BERHASIL(client)
    prs = await EMO.PROSES(client)
    
    try:
        await client.send_chat_action(message.chat.id, ChatAction.TYPING)
        
        # Ambil kode dari reply
        code = None
        source_type = ""
        filename = ""
        
        # Cek apakah reply ke pesan teks
        if message.reply_to_message and message.reply_to_message.text:
            code = message.reply_to_message.text
            source_type = "📝 Teks"
            
        # Cek apakah reply ke file
        elif message.reply_to_message and message.reply_to_message.document:
            doc = message.reply_to_message.document
            ext = os.path.splitext(doc.file_name)[1].lower()
            
            if ext in SUPPORTED_EXTENSIONS:
                # Download file
                file_path = await message.reply_to_message.download()
                with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                    code = f.read()
                
                source_type = f"📄 File: {doc.file_name}"
                filename = doc.file_name
                
                # Hapus file setelah dibaca
                if os.path.exists(file_path):
                    os.remove(file_path)
            else:
                ext_list = ', '.join(SUPPORTED_EXTENSIONS.keys())
                await message.reply_text(
                    f"{ggl} <b>File harus berekstensi kode yang valid!</b>\n\n"
                    f"Ekstensi yang didukung: <code>{ext_list}</code>"
                )
                return
        
        # Kalau gak ada reply atau gak valid
        if not code:
            await message.reply_text(
                f"{ggl} <b>Balas pesan teks atau file kode dulu bre.</b>\n\n"
                f"Cara pakai:\n"
                f"1. Reply ke pesan teks yang berisi kode error\n"
                f"2. Atau reply ke file kode (.py, .js, .java, dll)\n"
                f"3. Ketik <code>.fixcode</code>"
            )
            return
        
        # Deteksi bahasa
        language = detect_language(code, filename)
        
        # Kirim pesan processing
        processing = await message.reply_text(
            f"{prs} <b>Hako AI sedang memperbaiki kode...</b>\n\n"
            f"📥 <b>Source:</b> {source_type}\n"
            f"🔤 <b>Bahasa:</b> {language}\n"
            f"🔄 <b>Mencoba dengan {len(API_KEYS)} API keys...</b>"
        )
        
        # Prompt untuk fix code
        prompt = f"""Lu adalah Hako, AI expert dalam memperbaiki semua kode pemrograman. Tugas lu:

1. Perbaiki kode yang error atau bermasalah di bawah ini.
2. Jangan kasih penjelasan tambahan apapun.
3. Langsung tulis ulang kodenya yang sudah diperbaiki.
4. Pastikan syntax benar dan kode bisa jalan.
5. Gunakan bahasa pemrograman yang sesuai dengan kode aslinya.

BAHASA: {language}
FILE: {filename or 'unknown'}

KODE YANG ERROR:
{code}

Ingat! HANYA KIRIM KODE HASIL PERBAIKANNYA, tanpa kata-kata lain!"""

        # Panggil API dengan retry mechanism
        result = await call_fix_code_api(prompt)
        
        # Hapus pesan loading
        await processing.delete()
        
        if result.get('success'):
            reply = result['message'].strip()
            
            # Bersihin response
            reply = clean_response(reply)
            
            # Hapus kalimat pengantar kalo masih ada
            reply = re.sub(r'^(Berikut|Ini|Hasil|Kode|Perbaikan).*?\n', '', reply, flags=re.IGNORECASE)
            
            # Cek apakah udah dibungkus backtick
            if not reply.startswith("```"):
                # Tambahin backtick sesuai bahasa
                reply = f"```{language}\n{reply}\n```"
            
            # Batasi panjang pesan (max 4000 karakter untuk Telegram)
            if len(reply) > 4000:
                reply = reply[:3997] + "...\n```"
            
            # Kirim hasil
            await message.reply_text(
                f"<blockquote><b>✅ KODE BERHASIL DIPERBAIKI</b>\n\n"
                f"🔑 <b>Key:</b> <code>{result['api_key'][:8]}...</code>\n"
                f"📥 <b>Source:</b> {source_type}\n"
                f"🔤 <b>Bahasa:</b> {language}\n\n"
                f"{reply}</blockquote>",
                parse_mode=ParseMode.MARKDOWN
            )
        else:
            # Kirim pesan error
            error_msg = f"{ggl} <b>Gagal memperbaiki kode!</b>\n\n"
            
            if 'Tidak ada API keys' in str(result.get('error', '')):
                error_msg += "🔑 <b>Tidak ada API keys tersedia</b>"
            else:
                error_msg += f"📛 <b>Error:</b> {result.get('error', 'Unknown error')}\n"
                error_msg += f"🔑 <b>Key:</b> <code>{result.get('api_key', '')[:8]}...</code>"
            
            await message.reply_text(error_msg)
            
    except Exception as e:
        await message.reply_text(f"{ggl} <b>Error: {str(e)[:100]}</b>")

@PY.BOT("fixcode")
async def fix_code_bot(client: Client, message: Message):
    """Handler untuk bot"""
    try:
        # Ambil kode dari reply
        code = None
        filename = ""
        
        if message.reply_to_message and message.reply_to_message.text:
            code = message.reply_to_message.text
        elif message.reply_to_message and message.reply_to_message.document:
            doc = message.reply_to_message.document
            ext = os.path.splitext(doc.file_name)[1].lower()
            
            if ext in SUPPORTED_EXTENSIONS:
                file_path = await message.reply_to_message.download()
                with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                    code = f.read()
                filename = doc.file_name
                if os.path.exists(file_path):
                    os.remove(file_path)
            else:
                await message.reply_text("❌ File harus berekstensi kode yang valid!")
                return
        
        if not code:
            await message.reply_text(
                "❌ Balas pesan teks atau file kode dulu!\n"
                "Contoh: /fixcode (reply ke kode error)"
            )
            return
        
        language = detect_language(code, filename)
        
        processing = await message.reply_text(f"🔍 Memperbaiki kode ({language})...")
        
        prompt = f"""Lu adalah Hako, AI expert dalam memperbaiki semua kode pemrograman. 
Perbaiki kode yang error di bawah ini. HANYA KIRIM KODE HASIL PERBAIKANNYA, tanpa kata-kata lain!

BAHASA: {language}
KODE: {code}"""
        
        result = await call_fix_code_api(prompt)
        
        await processing.delete()
        
        if result.get('success'):
            reply = clean_response(result['message'])
            
            if not reply.startswith("```"):
                reply = f"```{language}\n{reply}\n```"
            
            if len(reply) > 4000:
                reply = reply[:3997] + "...\n```"
            
            await message.reply_text(
                f"✅ *Kode berhasil diperbaiki!*\n\n"
                f"🔑 Key: `{result['api_key'][:8]}...`\n"
                f"🔤 Bahasa: {language}\n\n"
                f"{reply}",
                parse_mode=ParseMode.MARKDOWN
            )
        else:
            await message.reply_text(f"❌ Gagal: {result.get('error', 'Unknown error')}")
            
    except Exception as e:
        await message.reply_text(f"❌ Error: {str(e)[:100]}")