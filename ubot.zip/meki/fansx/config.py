import os
from dotenv import load_dotenv

load_dotenv(".env")

MAX_BOT = int(os.getenv("MAX_BOT", "400"))

DEVS = list(map(int, os.getenv("DEVS", "7860773742").split()))

API_ID = int(os.getenv("API_ID", "31697534"))

API_HASH = os.getenv("API_HASH", "2682eef79494ab9eadac040a7c5a1b47")

BOT_TOKEN = os.getenv("BOT_TOKEN", "8521865025:AAHg2aqwv4fX7VFum94uLlvZUC1uqwzryl8")

OWNER_ID = int(os.getenv("OWNER_ID", "7860773742"))

BLACKLIST_CHAT = list(map(int, os.getenv("BLACKLIST_CHAT", "-1003192483568").split()))

RMBG_API = os.getenv("RMBG_API", "a6qxsmMJ3CsNo7HyxuKGsP1o")

MONGO_URL = os.getenv("MONGO_URL", "mongodb+srv://juraganmanz7_db_user:7Gu1nfUwwgRULSPV@cluster0.r6aamla.mongodb.net/?appName=Cluster0")

LOGS_MAKER_UBOT = int(os.getenv("LOGS_MAKER_UBOT", "-1003786106284"))
