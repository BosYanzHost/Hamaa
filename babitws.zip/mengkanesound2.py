from fansx import *
import requests
import aiohttp
import os
import random
from pyrogram.enums import ChatAction, ParseMode
from pyrogram.types import Message

__MODULE__ = "ᴍᴀɴɢᴋᴀɴᴇ ᴠ2"
__HELP__ = """
<blockquote><b>『 SOUND EFFECTS MANGKANE V2 』</b>

<b>⌲ Perintah:</b>
ᚗ <code>{0}mangkane10</code> - <code>{0}mangkane26</code> 
⊶ Memutar sound effect manga V2

<b>⌲ Contoh:</b>
<code>.mangkane10</code>
<code>.mangkane15</code>
<code>.mangkane20 thumb</code> (dengan thumbnail)</blockquote>
"""

# URL base untuk berbagai sound
MANGAKANE_BASE = "https://raw.githubusercontent.com/hyuura/Rest-Sound/main/HyuuraKane"
MANGAKANE_BASE2 = "https://raw.githubusercontent.com/aisyah-rest/mangkane/main/mangkanenya"

# Thumbnail default
DEFAULT_THUMB = "https://telegra.ph/file/48b67f699cfa231e4d5c2.jpg"

# URL group bot
GROUPBOT_URL = "https://t.me/ubot_premium_zyura"  # Ganti dengan link group lo

# Daftar sound mangkane 10-26
SOUNDS = {}

# Generate mangkane 10-26
for i in range(10, 27):
    sound_name = f"mangkane{i}"
    # Pilih base URL berdasarkan nomor (ambang batas 25)
    if i < 25:
        url = f"{MANGAKANE_BASE}/mangkane{i}.mp3"
    else:
        url = f"{MANGAKANE_BASE2}/mangkane{i}.mp3"
    
    SOUNDS[sound_name] = {"url": url, "thumb": DEFAULT_THUMB}

async def download_audio(url):
    """Download audio dari URL"""
    try:
        async with aiohttp.ClientSession() as session:
            async with session.get(url, timeout=15) as response:
                if response.status == 200:
                    return await response.read()
    except Exception as e:
        print(f"Error download audio: {e}")
    return None

# Handler untuk mangkane10 - mangkane26
@PY.UBOT("mangkane10", "mangkane11", "mangkane12", "mangkane13", "mangkane14", 
         "mangkane15", "mangkane16", "mangkane17", "mangkane18", "mangkane19",
         "mangkane20", "mangkane21", "mangkane22", "mangkane23", "mangkane24",
         "mangkane25", "mangkane26")
async def mangkane_handler(client: Client, message: Message):
    await play_sound(client, message, message.command[0])

async def play_sound(client: Client, message: Message, sound_name: str):
    ggl = await EMO.GAGAL(client)
    sks = await EMO.BERHASIL(client)
    prs = await EMO.PROSES(client)
    
    try:
        await client.send_chat_action(message.chat.id, ChatAction.TYPING)
        
        # Cek apakah sound tersedia
        if sound_name not in SOUNDS:
            await message.reply_text(f"{ggl} <b>Sound '{sound_name}' tidak ditemukan!</b>")
            return
        
        sound_info = SOUNDS[sound_name]
        sound_url = sound_info["url"]
        thumb_url = sound_info["thumb"]
        
        # Cek apakah user minta thumbnail (pake argumen 'thumb')
        args = message.text.split()
        use_thumb = len(args) > 1 and args[1].lower() == 'thumb'
        
        # Kirim pesan processing
        processing = await message.reply_text(f"{prs} <b>Memutar {sound_name}...</b>")
        
        # Download audio
        audio_data = await download_audio(sound_url)
        
        if audio_data:
            # Simpan sementara
            file_path = f"{sound_name}_{message.from_user.id}.mp3"
            with open(file_path, 'wb') as f:
                f.write(audio_data)
            
            await processing.delete()
            
            if use_thumb:
                # Kirim dengan thumbnail external
                try:
                    # Download thumbnail
                    async with aiohttp.ClientSession() as session:
                        async with session.get(thumb_url, timeout=10) as thumb_resp:
                            if thumb_resp.status == 200:
                                thumb_data = await thumb_resp.read()
                                
                                # Kirim audio dengan thumbnail
                                await client.send_audio(
                                    chat_id=message.chat.id,
                                    audio=file_path,
                                    title=f"🎵 {sound_name}",
                                    performer="Mangkane V2",
                                    thumb=thumb_data,
                                    caption=f"<blockquote><b>🎵 {sound_name}</b></blockquote>"
                                )
                            else:
                                # Fallback kalo thumbnail gagal
                                await client.send_audio(
                                    chat_id=message.chat.id,
                                    audio=file_path,
                                    caption=f"<blockquote><b>🎵 {sound_name}</b></blockquote>"
                                )
                except Exception as e:
                    print(f"Error sending with thumb: {e}")
                    await client.send_audio(
                        chat_id=message.chat.id,
                        audio=file_path,
                        caption=f"<blockquote><b>🎵 {sound_name}</b></blockquote>"
                    )
            else:
                # Kirim audio biasa
                await client.send_audio(
                    chat_id=message.chat.id,
                    audio=file_path,
                    caption=f"<blockquote><b>🎵 {sound_name}</b></blockquote>"
                )
            
            # Hapus file
            if os.path.exists(file_path):
                os.remove(file_path)
        else:
            await processing.edit_text(f"{ggl} <b>Gagal memuat audio!</b>")
        
    except Exception as e:
        await message.reply_text(f"{ggl} <b>Error: {str(e)[:100]}</b>")

@PY.UBOT("mangkanelist")
async def mangkane_list(client: Client, message: Message):
    """Menampilkan daftar sound mangkane V2 yang tersedia"""
    
    # Ambil semua sound mangkane
    mangkane_sounds = list(SOUNDS.keys())
    
    text = "<blockquote><b>📋 DAFTAR SOUND MANGKANE V2</b>\n\n"
    
    # Tampilkan dalam beberapa baris
    rows = [mangkane_sounds[i:i+5] for i in range(0, len(mangkane_sounds), 5)]
    for row in rows:
        text += " • " + ", ".join(row) + "\n"
    
    text += f"\n<b>📊 Total:</b> {len(mangkane_sounds)} sound\n\n"
    text += "<b>💡 Cara pakai:</b>\n"
    text += "• <code>.mangkane10</code> (tanpa thumb)\n"
    text += "• <code>.mangkane10 thumb</code> (dengan thumb)</blockquote>"
    
    await message.reply_text(text)

@PY.BOT("mangkane10")
async def mangkane_bot_handler(client: Client, message: Message):
    """Handler untuk bot"""
    sound_name = message.text.split()[0].replace('/', '')
    await play_sound_bot(client, message, sound_name)

async def play_sound_bot(client: Client, message: Message, sound_name: str):
    try:
        if sound_name not in SOUNDS:
            await message.reply_text(f"❌ Sound '{sound_name}' tidak ditemukan!")
            return
        
        sound_info = SOUNDS[sound_name]
        sound_url = sound_info["url"]
        
        processing = await message.reply_text(f"🔍 Memutar {sound_name}...")
        
        audio_data = await download_audio(sound_url)
        
        if audio_data:
            file_path = f"{sound_name}_bot_{message.from_user.id}.mp3"
            with open(file_path, 'wb') as f:
                f.write(audio_data)
            
            await processing.delete()
            
            await client.send_audio(
                chat_id=message.chat.id,
                audio=file_path,
                caption=f"🎵 {sound_name}"
            )
            
            if os.path.exists(file_path):
                os.remove(file_path)
        else:
            await processing.edit_text("❌ Gagal memuat audio!")
        
    except Exception as e:
        await message.reply_text(f"❌ Error: {str(e)[:100]}")